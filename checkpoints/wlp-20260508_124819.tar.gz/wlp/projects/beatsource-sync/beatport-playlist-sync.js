/**
 * Beatport Playlist Sync
 * Adds tracks to Beatport playlists using stored track IDs
 * 
 * Usage: node beatport-playlist-sync.js [genre|all]
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_STATE = path.join(__dirname, 'auth-state.json');
const SYNC_STATE = path.join(__dirname, 'sync-state.json');
const LOG_DIR = path.join(__dirname, 'logs');

const TARGET_GENRE = process.argv[2] || 'all';

// Playlist mapping: genre → playlist URL
const PLAYLIST_URLS = {
  'African': 'https://www.beatport.com/library/playlists/7362468',
  'Latin': 'https://www.beatport.com/library/playlists/7362425',
  'Hip-Hop': 'https://www.beatport.com/library/playlists/7362419',
  'R&B': 'https://www.beatport.com/library/playlists/7362419',
  'Country': 'https://www.beatport.com/library/playlists/7362415',
  'Rock': 'https://www.beatport.com/library/playlists/7362411',
  'DJ Edits': 'https://www.beatport.com/library/playlists/7362407',
  'Pop': 'https://www.beatport.com/library/playlists/7362400',
};

function log(msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.mkdirSync(LOG_DIR, { recursive: true });
  fs.appendFileSync(path.join(LOG_DIR, `sync-${new Date().toISOString().slice(0, 10)}.log`), line + '\n');
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(SYNC_STATE, 'utf8')); } catch { return { seenTracks: {}, trackIds: {}, lastRun: null }; }
}

// Extract tracks from playlist to check for duplicates
async function getExistingTracks(page, playlistUrl) {
  await page.goto(playlistUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(3000);
  
  return await page.evaluate(() => {
    const tracks = [];
    const nextDataScript = document.getElementById('__NEXT_DATA__');
    if (!nextDataScript) return tracks;
    
    const nextData = JSON.parse(nextDataScript.textContent);
    if (!nextData.props?.pageProps?.dehydratedState?.queries) return tracks;
    
    const queries = nextData.props.pageProps.dehydratedState.queries;
    
    for (const query of queries) {
      if (query.state?.data?.results) {
        for (const item of query.state.data.results) {
          const track = item.item || item.track || item;
          if (track && (track.name || track.title)) {
            const artists = track.artists ? track.artists.map(a => a.name).join(', ') : track.artist?.name || 'Unknown';
            tracks.push(`${artists} - ${track.name || track.title}`.toLowerCase());
          }
        }
      }
    }
    return tracks;
  });
}

// Add track to playlist using direct track ID via API
async function addTrackToPlaylist(page, trackId, playlistId) {
  try {
    // Use Beatport's internal API to add track
    const response = await page.evaluate(async ({ tid, pid }) => {
      try {
        const res = await fetch(`https://www.beatport.com/api/playlists/${pid}/tracks`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: JSON.stringify({ track_id: parseInt(tid) })
        });
        return { success: res.ok, status: res.status };
      } catch (e) {
        return { success: false, error: e.message };
      }
    }, { tid: trackId, pid: playlistId });
    
    return response.success;
  } catch (err) {
    log(`  ERROR adding track: ${err.message}`);
    return false;
  }
}

(async () => {
  log('=== Beatport Playlist Sync Starting ===');
  
  if (!fs.existsSync(AUTH_STATE)) {
    log('ERROR: No auth state. Run: node login.js');
    process.exit(1);
  }
  
  const state = loadState();
  
  // Determine which genres to process
  const genresToProcess = TARGET_GENRE === 'all'
    ? Object.keys(PLAYLIST_URLS)
    : [TARGET_GENRE];
  
  if (genresToProcess.length === 0) {
    log('ERROR: No playlists configured.');
    process.exit(1);
  }
  
  const browser = await chromium.launch({
    executablePath: '/usr/local/bin/chromium-browser',
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    storageState: AUTH_STATE
  });
  
  const page = await context.newPage();
  
  for (const genreName of genresToProcess) {
    const playlistUrl = PLAYLIST_URLS[genreName];
    if (!playlistUrl) {
      log(`\n--- ${genreName}: No playlist URL configured ---`);
      continue;
    }
    
    log(`\n--- ${genreName} → ${playlistUrl} ---`);
    
    // Get tracks from state
    const tracks = state.seenTracks[genreName] || [];
    const trackIds = state.trackIds[genreName] || {};
    
    if (tracks.length === 0) {
      log('No tracks found in state for this genre');
      continue;
    }
    
    // Get existing tracks in playlist
    const existingTracks = await getExistingTracks(page, playlistUrl);
    log(`Playlist has ${existingTracks.length} existing tracks`);
    
    // Filter out duplicates
    const newTracks = tracks.filter(t => !existingTracks.includes(t.toLowerCase()));
    log(`${newTracks.length} new tracks to add`);
    
    if (newTracks.length === 0) {
      log('All tracks already in playlist');
      continue;
    }
    
    // Extract playlist ID from URL
    const playlistId = playlistUrl.split('/').pop();
    
    // Add tracks using IDs
    let added = 0;
    let failed = 0;
    const tracksToAdd = newTracks.slice(0, 50); // Limit to 50
    
    for (const trackKey of tracksToAdd) {
      const trackId = trackIds[trackKey.toLowerCase()];
      
      if (!trackId) {
        log(`  ❌ No ID for: ${trackKey}`);
        failed++;
        continue;
      }
      
      log(`  Adding: ${trackKey} (ID: ${trackId})`);
      const success = await addTrackToPlaylist(page, trackId, playlistId);
      
      if (success) {
        added++;
        log(`    ✅ Added`);
      } else {
        failed++;
        log(`    ❌ Failed`);
      }
      
      await page.waitForTimeout(500); // Rate limit
    }
    
    log(`\nResults: ${added} added, ${failed} failed, ${tracksToAdd.length - added - failed} skipped`);
  }
  
  await browser.close();
  log('\n=== Playlist Sync Complete ===');
  
})().catch(err => {
  log(`FATAL: ${err.message}`);
  process.exit(1);
});
