/**
 * Beatport Login - Force fresh login
 * Run: node login.js
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join(__dirname, 'auth-state.json');

(async () => {
  // Delete old auth state to force fresh login
  if (fs.existsSync(STATE_FILE)) {
    fs.unlinkSync(STATE_FILE);
    console.log('Old auth state deleted');
  }

  const browser = await chromium.launch({
    executablePath: '/usr/local/bin/chromium-browser',
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });

  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  });

  const page = await context.newPage();
  await page.route('**/*.{png,jpg,jpeg,gif,svg,ico,woff,woff2,otf,ttf}', r => r.abort());
  await page.route('**/google-analytics**', r => r.abort());
  await page.route('**/sentry**', r => r.abort());

  console.log('Loading Beatport...');
  await page.goto('https://www.beatport.com/', { waitUntil: 'domcontentloaded', timeout: 30000 });

  // Look for login link/button
  console.log('Looking for login button...');

  // Try multiple selectors
  const loginSelectors = [
    'text=Sign In',
    'text=Log In',
    'a[href*="login"]',
    'button:has-text("Sign")',
    'button:has-text("Log")',
    '[data-testid*="login"]',
    '[class*="login"]',
    '[class*="signin"]'
  ];

  let loginBtn = null;
  for (const selector of loginSelectors) {
    loginBtn = await page.$(selector);
    if (loginBtn) {
      console.log(`Found login button: ${selector}`);
      break;
    }
  }

  if (!loginBtn) {
    console.log('No login button found. Taking screenshot to debug...');
    await page.screenshot({ path: '/home/ubuntu/wlp/projects/beatsource-sync/login-debug.png' });
    console.log('Screenshot saved to login-debug.png');

    // List all links and buttons
    const links = await page.$$eval('a, button', els =>
      els.map(el => ({
        text: el.textContent.trim(),
        href: el.href || '',
        class: el.className
      })).filter(l => l.text.length > 0)
    );
    console.log('Available links/buttons:', JSON.stringify(links.slice(0, 20), null, 2));

    await browser.close();
    process.exit(1);
  }

  console.log('Clicking login...');
  await loginBtn.click();
  await page.waitForTimeout(2000);

  // Take screenshot after click
  await page.screenshot({ path: '/home/ubuntu/wlp/projects/beatsource-sync/login-form.png' });

  // Fill credentials
  console.log('Filling credentials...');

  // Try different username field selectors
  const usernameSelectors = [
    'input[name="username"]',
    'input[name="email"]',
    'input[type="email"]',
    'input[placeholder*="user" i]',
    'input[placeholder*="email" i]'
  ];

  let usernameFilled = false;
  for (const selector of usernameSelectors) {
    const field = await page.$(selector);
    if (field) {
      await field.fill('Animal7111');
      console.log(`Filled username using: ${selector}`);
      usernameFilled = true;
      break;
    }
  }

  if (!usernameFilled) {
    console.log('Could not find username field');
    await browser.close();
    process.exit(1);
  }

  // Try different password field selectors
  const passwordSelectors = [
    'input[name="password"]',
    'input[type="password"]',
    'input[placeholder*="pass" i]'
  ];

  let passwordFilled = false;
  for (const selector of passwordSelectors) {
    const field = await page.$(selector);
    if (field) {
      await field.fill('Wicked71!');
      console.log(`Filled password using: ${selector}`);
      passwordFilled = true;
      break;
    }
  }

  if (!passwordFilled) {
    console.log('Could not find password field');
    await browser.close();
    process.exit(1);
  }

  // Click submit
  console.log('Submitting login...');
  const submitBtn = await page.$('button[type="submit"]') ||
                    await page.$('button:has-text("Sign")') ||
                    await page.$('button:has-text("Log")') ||
                    await page.$('input[type="submit"]');

  if (submitBtn) {
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'networkidle', timeout: 25000 }).catch(() => {}),
      submitBtn.click()
    ]);
  } else {
    console.log('No submit button found, trying Enter key...');
    await page.press('input[type="password"]', 'Enter');
    await page.waitForTimeout(5000);
  }

  console.log('After login URL:', page.url().substring(0, 80));

  // Wait for session
  await page.waitForTimeout(3000);

  // Save state
  await context.storageState({ path: STATE_FILE });
  console.log('Auth state saved to', STATE_FILE);

  // Verify
  const libraryLink = await page.$('text=Library').catch(() => null);
  const myBeatport = await page.$('text=My Beatport').catch(() => null);

  if (libraryLink || myBeatport) {
    console.log('✅ Login verified!');
  } else {
    console.log('⚠️ Login may have failed - checking for errors...');
    const errorMsg = await page.$eval('.error, [class*="error"]', el => el.textContent).catch(() => null);
    if (errorMsg) console.log('Error message:', errorMsg);
  }

  await browser.close();
})().catch(err => {
  console.error('FATAL:', err.message);
  process.exit(1);
});
