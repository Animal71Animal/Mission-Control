/**
 * Beatport Automation
 * Streamlined weekly sync for Top 10 Releases + Latest 20 tracks
 * Supports all genres + DJ Edits crates
 * Now stores track IDs for playlist sync
 *
 * Usage: node beatport-automation.js [genre-name|dj-edits|all]
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_STATE = path.join(__dirname, 'auth-state.json');
const SYNC_STATE = path.join(__dirname, 'sync-state.json');
const LOG_DIR = path.join(__dirname, 'logs');
const OUTPUT_DIR = path.join(__dirname, 'output');

const TARGET = process.argv[2] || 'all';

const GENRES = [
  { name: 'African', id: 102, url: 'https://www.beatport.com/genre/african/102', playlist: 'African' },
  { name: 'Country', id: 104, url: 'https://www.beatport.com/genre/country/104', playlist: 'Country' },
  { name: 'DJ Edits', id: 110, url: 'https://www.beatport.com/genre/dj-edits/110', playlist: 'DJ Exclusives', isCrates: true },
  { name: 'Hip-Hop', id: 105, url: 'https://www.beatport.com/genre/hip-hop/105', playlist: 'HH/RnB' },
  { name: 'Latin', id: 106, url: 'https://www.beatport.com/genre/latin/106', playlist: 'Latin' },
  { name: 'Pop', id: 107, url: 'https://www.beatport.com/genre/pop/107', playlist: 'Pop/Top40' },
  { name: 'R&B', id: 108, url: 'https://www.beatport.com/genre/rb/108', playlist: 'HH/RnB' },
  { name: 'Rock', id: 109, url: 'https://www.beatport.com/genre/rock/109', playlist: 'Rock' },
];

function log(msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.mkdirSync(LOG_DIR, { recursive: true });
  fs.appendFileSync(path.join(LOG_DIR, `sync-${new Date().toISOString().slice(0, 10)}.log`), line + '\n');
}

function loadState() {
  try { 
    const data = JSON.parse(fs.readFileSync(SYNC_STATE, 'utf8'));
    // Ensure trackIds exists
    if (!data.trackIds) data.trackIds = {};
    return data;
  } catch { 
    return { seenTracks: {}, trackIds: {}, lastRun: null }; 
  }
}

function saveState(state) {
  fs.writeFileSync(SYNC_STATE, JSON.stringify(state, null, 2));
}

function monthPlaylist(suffix) {
  const now = new Date();
  const month = now.toLocaleString('en-US', { month: 'short' });
  const year = now.getFullYear();
  return `${month} ${year} ${suffix}`;
}

// ─── Extraction ───────────────────────────────────────────────────────────────

async function extractFromDehydratedState(page, genreId, isCrates = false) {
  return await page.evaluate(({ id, crates }) => {
    const results = [];
    const nextDataScript = document.getElementById('__NEXT_DATA__');
    if (!nextDataScript) return results;

    const nextData = JSON.parse(nextDataScript.textContent);
    if (!nextData.props?.pageProps?.dehydratedState?.queries) return results;

    const queries = nextData.props.pageProps.dehydratedState.queries;

    if (crates) {
      // DJ Edits: extract crates
      for (const query of queries) {
        if (query.queryKey?.[0]?.startsWith('page-module-')) {
          if (query.state?.data?.results) {
            for (const item of query.state.data.results) {
              const crate = item.item || item;
              if (crate?.name || crate?.title) {
                results.push({
                  name: crate.name || crate.title,
                  id: crate.id,
                  slug: (crate.name || crate.title).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
                  source: 'crate'
                });
              }
            }
          }
        }
      }
    } else {
      // Standard genres: Top 10 Releases + Latest Releases
      const top10Query = queries.find(q => q.queryKey?.[0] === `genre-${id}-top-10-releases`);
      if (top10Query?.state?.data?.results) {
        for (const release of top10Query.state.data.results) {
          const artists = release.artists ? release.artists.map(a => a.name).join(', ') : 'Unknown';
          results.push({ name: release.name, artist: artists, id: release.id, source: 'top10' });
        }
      }

      // Latest releases (first 20 from page modules)
      let count = 0;
      for (const query of queries) {
        if (query.queryKey?.[0]?.startsWith('page-module-') && query.queryKey?.[0]?.endsWith('-items')) {
          if (query.state?.data?.results) {
            for (const item of query.state.data.results) {
              if (item.item && item.item_type?.name === 'release') {
                const release = item.item;
                const artists = release.artists ? release.artists.map(a => a.name).join(', ') : 'Unknown';
                results.push({ name: release.name, artist: artists, id: release.id, source: 'latest' });
                count++;
                if (count >= 20) break;
              }
            }
          }
        }
        if (count >= 20) break;
      }
    }

    return results;
  }, { id: genreId, crates: isCrates });
}

async function extractTracksFromCrate(page, crateSlug, crateId) {
  const crateUrl = `https://www.beatport.com/chart/${crateSlug}/${crateId}`;
  await page.goto(crateUrl, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(2000);

  return await page.evaluate(() => {
    const tracks = [];
    const nextDataScript = document.getElementById('__NEXT_DATA__');
    if (!nextDataScript) return tracks;

    const nextData = JSON.parse(nextDataScript.textContent);
    if (!nextData.props?.pageProps?.dehydratedState?.queries) return tracks;

    const queries = nextData.props.pageProps.dehydratedState.queries;

    for (const query of queries) {
      if (query.state?.data?.results) {
        for (const item of query.state.data.results) {
          const track = item.item || item.track || item;
          if (track && (track.name || track.title)) {
            const artists = track.artists ? track.artists.map(a => a.name).join(', ') : track.artist?.name || 'Unknown';
            tracks.push({ name: track.name || track.title, artist: artists, id: track.id });
          }
        }
      }
    }
    return tracks;
  });
}

// ─── Main ─────────────────────────────────────────────────────────────────────

(async () => {
  log('=== Beatport Automation Starting ===');

  if (!fs.existsSync(AUTH_STATE)) {
    log('ERROR: No auth state. Run: node login.js');
    process.exit(1);
  }

  const state = loadState();
  const summary = [];

  const targets = TARGET === 'all'
    ? GENRES
    : GENRES.filter(g => g.name.toLowerCase().replace(/\s+/g, '-') === TARGET.toLowerCase());

  if (targets.length === 0) {
    log(`ERROR: Unknown target "${TARGET}". Use: all, african, country, dj-edits, hip-hop, latin, pop, rb, rock`);
    process.exit(1);
  }

  const browser = await chromium.launch({
    executablePath: '/usr/local/bin/chromium-browser',
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });

  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    storageState: AUTH_STATE
  });

  const page = await context.newPage();

  // Check session
  await page.goto('https://www.beatport.com/', { waitUntil: 'domcontentloaded', timeout: 30000 });
  const signInVisible = await page.$('text=Sign In').then(el => !!el).catch(() => false);
  if (signInVisible) {
    log('Session expired, re-logging in...');
    await page.goto('https://www.beatport.com/account/login', { waitUntil: 'domcontentloaded' });
    await page.fill('input[name="username"]', 'Animal7111');
    await page.fill('input[name="password"]', 'Wicked71!');
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'networkidle' }).catch(() => {}),
      page.click('button[type="submit"]')
    ]);
    await context.storageState({ path: AUTH_STATE });
  }

  for (const genre of targets) {
    const playlistName = monthPlaylist(genre.playlist);
    log(`\n--- ${genre.name} → "${playlistName}" ---`);

    if (!state.seenTracks[genre.name]) state.seenTracks[genre.name] = [];
    if (!state.trackIds[genre.name]) state.trackIds[genre.name] = {};
    const seen = new Set(state.seenTracks[genre.name]);

    try {
      await page.goto(genre.url, { waitUntil: 'networkidle', timeout: 30000 });
      await page.waitForTimeout(3000);

      let allTracks = [];

      if (genre.isCrates) {
        // DJ Edits: get crates, then tracks from each crate
        const crates = await extractFromDehydratedState(page, genre.id, true);
        log(`Found ${crates.length} crates, processing first 20...`);

        for (const crate of crates.slice(0, 20)) {
          log(`  Crate: ${crate.name}`);
          const tracks = await extractTracksFromCrate(page, crate.slug, crate.id);
          log(`    ${tracks.length} tracks`);

          for (const t of tracks) {
            const key = `${t.artist} - ${t.name}`.toLowerCase();
            if (!allTracks.some(x => `${x.artist} - ${x.name}`.toLowerCase() === key)) {
              allTracks.push(t);
            }
          }
        }
      } else {
        // Standard genres: Top 10 + Latest 20
        allTracks = await extractFromDehydratedState(page, genre.id, false);
      }

      // Show results
      const top10 = allTracks.filter(t => t.source === 'top10');
      const latest = allTracks.filter(t => t.source === 'latest');

      if (top10.length > 0) {
        console.log('\n=== TOP 10 RELEASES ===');
        top10.forEach((t, i) => console.log(`${i + 1}. ${t.artist} - ${t.name}`));
      }

      if (latest.length > 0) {
        console.log('\n=== LATEST RELEASES ===');
        latest.forEach((t, i) => console.log(`${i + 1}. ${t.artist} - ${t.name}`));
      }

      if (genre.isCrates && allTracks.length > 0) {
        console.log(`\n=== CRATE TRACKS (first 20) ===`);
        allTracks.slice(0, 20).forEach((t, i) => console.log(`${i + 1}. ${t.artist} - ${t.name}`));
      }

      // Deduplicate and filter
      const newTracks = allTracks.filter(t => {
        const key = `${t.artist} - ${t.name}`.toLowerCase();
        return !seen.has(key);
      });

      log(`${newTracks.length} new tracks (${allTracks.length} total, ${seen.size} existing)`);

      // Mark as seen and store IDs
      for (const t of allTracks) {
        const key = `${t.artist} - ${t.name}`.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          state.seenTracks[genre.name].push(key);
        }
        // Store track ID for playlist sync
        if (t.id) {
          state.trackIds[genre.name][key] = t.id;
        }
      }

      summary.push({
        genre: genre.name,
        playlist: playlistName,
        total: allTracks.length,
        new: newTracks.length
      });

    } catch (err) {
      log(`ERROR: ${err.message}`);
      summary.push({ genre: genre.name, error: err.message });
    }
  }

  saveState(state);
  await browser.close();

  // Generate CSV output
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  for (const genre of targets) {
    const tracks = state.seenTracks[genre.name] || [];
    if (tracks.length === 0) continue;

    const csv = tracks.map(t => {
      const parts = t.split(' - ');
      const trackId = state.trackIds[genre.name]?.[t.toLowerCase()] || '';
      return `"${parts[0]}","${parts.slice(1).join(' - ')}","${trackId}"`;
    }).join('\n');

    const filename = path.join(OUTPUT_DIR, `${genre.name.toLowerCase().replace(/\s+/g, '-')}-tracks.csv`);
    fs.writeFileSync(filename, `Artist,Track,BeatportID\n${csv}`);
  }

  log('\n=== SYNC COMPLETE ===');
  for (const s of summary) {
    if (s.error) log(`❌ ${s.genre}: ${s.error}`);
    else log(`✅ ${s.genre} → "${s.playlist}": ${s.new} new / ${s.total} total`);
  }
  log(`\nCSV files saved to: ${OUTPUT_DIR}`);

})().catch(err => {
  log(`FATAL: ${err.message}`);
  process.exit(1);
});
