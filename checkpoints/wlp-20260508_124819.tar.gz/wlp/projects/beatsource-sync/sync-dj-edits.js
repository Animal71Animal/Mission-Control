/**
 * DJ Edits Sync - Special handling for Remixer Crates
 * Extracts first 20 crates, gets tracks from each, adds to DJ Exclusives playlist
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const AUTH_STATE = path.join(__dirname, 'auth-state.json');
const SYNC_STATE = path.join(__dirname, 'sync-state.json');
const LOG_DIR = path.join(__dirname, 'logs');

function log(msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.mkdirSync(LOG_DIR, { recursive: true });
  fs.appendFileSync(path.join(LOG_DIR, `sync-${new Date().toISOString().slice(0,10)}.log`), line + '\n');
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(SYNC_STATE, 'utf8')); } catch { return { seenTracks: {}, playlists: {}, lastRun: null }; }
}

function saveState(state) {
  fs.writeFileSync(SYNC_STATE, JSON.stringify(state, null, 2));
}

function monthPlaylist(suffix) {
  const now = new Date();
  const month = now.toLocaleString('en-US', { month: 'short' });
  const year = now.getFullYear();
  return `${month} ${year} ${suffix}`;
}

// Extract crates from DJ Edits page
async function extractCrates(page) {
  return await page.evaluate(() => {
    const crates = [];
    const nextDataScript = document.getElementById('__NEXT_DATA__');
    if (!nextDataScript) return crates;
    
    const nextData = JSON.parse(nextDataScript.textContent);
    if (!nextData.props?.pageProps?.dehydratedState?.queries) return crates;
    
    const queries = nextData.props.pageProps.dehydratedState.queries;
    
    // Look for page-module queries with crates
    for (const query of queries) {
      if (query.queryKey && query.queryKey[0] && query.queryKey[0].startsWith('page-module-')) {
        if (query.state?.data?.results) {
          for (const item of query.state.data.results) {
            const crate = item.item || item;
            if (crate && (crate.name || crate.title)) {
              const name = crate.name || crate.title;
              const url = crate.url || crate.slug || '';
              crates.push({ name, url, id: crate.id });
            }
          }
        }
      }
    }
    return crates;
  });
}

// Extract tracks from a crate page
async function extractTracksFromCrate(page, crateUrl) {
  await page.goto(crateUrl, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(2000);
  
  return await page.evaluate(() => {
    const tracks = [];
    const nextDataScript = document.getElementById('__NEXT_DATA__');
    if (!nextDataScript) return tracks;
    
    const nextData = JSON.parse(nextDataScript.textContent);
    if (!nextData.props?.pageProps?.dehydratedState?.queries) return tracks;
    
    const queries = nextData.props.pageProps.dehydratedState.queries;
    
    for (const query of queries) {
      if (query.state?.data?.results) {
        for (const item of query.state.data.results) {
          const track = item.item || item.track || item;
          if (track && (track.name || track.title)) {
            const artists = track.artists 
              ? track.artists.map(a => a.name).join(', ')
              : track.artist?.name || 'Unknown';
            tracks.push({
              name: track.name || track.title,
              artist: artists,
              id: track.id
            });
          }
        }
      }
    }
    return tracks;
  });
}

(async () => {
  log('=== DJ Edits Sync Starting ===');
  
  if (!fs.existsSync(AUTH_STATE)) {
    log('ERROR: No auth state found. Run login.js first.');
    process.exit(1);
  }
  
  const state = loadState();
  const playlistName = monthPlaylist('DJ Exclusives');
  
  if (!state.seenTracks['DJ Edits']) state.seenTracks['DJ Edits'] = [];
  const seen = new Set(state.seenTracks['DJ Edits']);
  
  const browser = await chromium.launch({
    executablePath: '/usr/local/bin/chromium-browser',
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });
  
  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    storageState: AUTH_STATE
  });
  
  const page = await context.newPage();
  
  // Load DJ Edits page
  log('Loading DJ Edits page...');
  await page.goto('https://www.beatport.com/genre/dj-edits/110', { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(3000);
  
  // Extract crates
  const crates = await extractCrates(page);
  log(`Found ${crates.length} crates`);
  
  // Take first 20 crates
  const targetCrates = crates.slice(0, 20);
  log(`Processing first ${targetCrates.length} crates`);
  
  const allTracks = [];
  
  for (const crate of targetCrates) {
    log(`  Processing crate: ${crate.name}`);
    try {
      // Build proper Beatport URL from crate slug
      const crateSlug = crate.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const crateUrl = `https://www.beatport.com/chart/${crateSlug}/${crate.id}`;
      const tracks = await extractTracksFromCrate(page, crateUrl);
      log(`    Found ${tracks.length} tracks`);
      
      for (const track of tracks) {
        const key = `${track.artist} - ${track.name}`.toLowerCase();
        if (!allTracks.some(t => `${t.artist} - ${t.name}`.toLowerCase() === key)) {
          allTracks.push(track);
        }
      }
    } catch (err) {
      log(`    ERROR: ${err.message}`);
    }
  }
  
  log(`\nTotal unique tracks: ${allTracks.length}`);
  
  // Show tracks
  if (allTracks.length > 0) {
    console.log('\n=== TRACKS FROM CRATES ===');
    allTracks.forEach((t, i) => {
      console.log(`${i + 1}. ${t.artist} - ${t.name}`);
    });
  }
  
  // Filter new tracks
  const newTracks = allTracks.filter(t => !seen.has(`${t.artist} - ${t.name}`.toLowerCase()));
  log(`${newTracks.length} new tracks to add`);
  
  // Mark as seen
  for (const t of allTracks) {
    const key = `${t.artist} - ${t.name}`.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      state.seenTracks['DJ Edits'].push(key);
    }
  }
  
  saveState(state);
  await browser.close();
  
  log(`\n=== DJ Edits Sync Complete ===`);
  log(`✅ DJ Edits → "${playlistName}": ${newTracks.length} new from ${targetCrates.length} crates`);
  
})().catch(err => {
  log(`FATAL: ${err.message}`);
  process.exit(1);
});
