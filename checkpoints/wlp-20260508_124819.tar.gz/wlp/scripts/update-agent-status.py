#!/usr/bin/env python3
"""
Update agent status in mission-control.db (SQLite).
Source of truth: SQLite. GitHub backup runs daily.

Usage:
  python3 update-agent-status.py [agent-name] [task-name] [status] [blockers] [updated_by]

Examples:
  python3 update-agent-status.py coral "Suno v5.5 Research" completed ""
  python3 update-agent-status.py shelly "Release Strategy" in-progress ""
  python3 update-agent-status.py barnaby "DOE Partnership" blocked "Awaiting contract review"

Status values: completed, in-progress, blocked, idle

Backward-compatible with the old JSON-based interface.
"""

import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path("/home/ubuntu/wlp/projects/mission-control/mission-control.db")
JSON_PATH = Path("/home/ubuntu/wlp/data/agent-status.json")  # Kept as legacy fallback

STATUS_ICONS = {
    "idle":        "🟢",
    "in-progress": "🟡",
    "blocked":     "🔴",
    "completed":   "✅",
}

VALID_STATUSES = {"completed", "in-progress", "blocked", "idle"}

KNOWN_AGENTS = {
    "langostino", "homard", "clawdia", "shelly",
    "rockwell", "barnaby", "sebastian", "coral",
}


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def ensure_schema(conn: sqlite3.Connection):
    """Create tables if they don't exist (idempotent)."""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS agent_status_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT NOT NULL DEFAULT (datetime('now')),
            agent_name  TEXT NOT NULL,
            task_name   TEXT,
            status      TEXT NOT NULL,
            blockers    TEXT,
            updated_by  TEXT NOT NULL DEFAULT 'script'
        );

        CREATE TABLE IF NOT EXISTS agent_current_state (
            agent_name          TEXT PRIMARY KEY,
            total_completed     INTEGER NOT NULL DEFAULT 0,
            total_assigned      INTEGER NOT NULL DEFAULT 0,
            current_task        TEXT,
            current_status      TEXT NOT NULL DEFAULT 'idle',
            current_progress    INTEGER NOT NULL DEFAULT 0,
            blockers            TEXT,
            availability_status TEXT NOT NULL DEFAULT 'available',
            next_deadline       TEXT,
            last_updated        TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_log_agent     ON agent_status_log(agent_name);
        CREATE INDEX IF NOT EXISTS idx_log_timestamp ON agent_status_log(timestamp);
        CREATE INDEX IF NOT EXISTS idx_state_agent   ON agent_current_state(agent_name);
    """)
    conn.commit()


def get_current_state(conn: sqlite3.Connection, agent_name: str) -> dict | None:
    row = conn.execute(
        "SELECT * FROM agent_current_state WHERE agent_name = ?", (agent_name,)
    ).fetchone()
    if not row:
        return None
    cols = [d[0] for d in conn.execute(
        "SELECT * FROM agent_current_state WHERE agent_name = ?", (agent_name,)
    ).description]
    return dict(zip(cols, row))


def update_agent_status(
    agent_name: str,
    task_name: str,
    status: str,
    blockers: str = "",
    updated_by: str = "script",
):
    agent_name = agent_name.lower()

    if status not in VALID_STATUSES:
        print(f"❌ Invalid status '{status}'. Valid: {', '.join(sorted(VALID_STATUSES))}")
        sys.exit(1)

    if agent_name not in KNOWN_AGENTS:
        print(f"❌ Unknown agent '{agent_name}'. Known: {', '.join(sorted(KNOWN_AGENTS))}")
        sys.exit(1)

    if not DB_PATH.exists():
        print(f"❌ Database not found at {DB_PATH}")
        print("   Run: python3 init-agent-status-db.py")
        sys.exit(1)

    blockers_list = [b.strip() for b in blockers.split("|") if b.strip()] if blockers else []
    blockers_json = json.dumps(blockers_list)
    ts = now_utc()

    conn = sqlite3.connect(str(DB_PATH))
    try:
        ensure_schema(conn)
        current = get_current_state(conn, agent_name)

        # ── Derive new state ────────────────────────────────────────────────
        if current:
            total_completed = current["total_completed"]
            total_assigned  = current["total_assigned"]
        else:
            total_completed = 0
            total_assigned  = 0

        if status == "completed":
            total_completed += 1
            new_current_task     = None
            new_current_status   = "idle"
            new_availability     = "available"
            new_progress         = 0
            new_blockers         = "[]"

        elif status == "in-progress":
            total_assigned  += 1 if (not current or current["current_task"] != task_name) else 0
            new_current_task     = task_name
            new_current_status   = "in-progress"
            new_availability     = "in-progress"
            new_progress         = 0
            new_blockers         = "[]"

        elif status == "blocked":
            new_current_task     = task_name or (current["current_task"] if current else None)
            new_current_status   = "blocked"
            new_availability     = "blocked"
            new_progress         = current["current_progress"] if current else 0
            new_blockers         = blockers_json

        else:  # idle
            new_current_task     = None
            new_current_status   = "idle"
            new_availability     = "available"
            new_progress         = 0
            new_blockers         = "[]"

        # ── Atomic write (log + state in one transaction) ──────────────────
        with conn:
            # 1. Audit log
            conn.execute("""
                INSERT INTO agent_status_log
                    (timestamp, agent_name, task_name, status, blockers, updated_by)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (ts, agent_name, task_name, status, blockers_json, updated_by))

            # 2. Upsert current state
            conn.execute("""
                INSERT INTO agent_current_state
                    (agent_name, total_completed, total_assigned, current_task,
                     current_status, current_progress, blockers,
                     availability_status, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(agent_name) DO UPDATE SET
                    total_completed     = excluded.total_completed,
                    total_assigned      = excluded.total_assigned,
                    current_task        = excluded.current_task,
                    current_status      = excluded.current_status,
                    current_progress    = excluded.current_progress,
                    blockers            = excluded.blockers,
                    availability_status = excluded.availability_status,
                    last_updated        = excluded.last_updated
            """, (
                agent_name, total_completed, total_assigned,
                new_current_task, new_current_status, new_progress,
                new_blockers, new_availability, ts,
            ))

        # ── Print summary ───────────────────────────────────────────────────
        icon = STATUS_ICONS.get(status, "❓")
        display = agent_name.capitalize()
        print(f"{icon} {display}: {status}")
        if new_current_task:
            print(f"   Current: {new_current_task}")
        print(f"   Completed: {total_completed} | Assigned: {total_assigned}")
        if blockers_list:
            print(f"   ⚠️  Blockers: {', '.join(blockers_list)}")
        print()
        print("✅ Agent status updated in SQLite. Mission Control will reflect on next page load.")

    finally:
        conn.close()

    # ── Mirror to JSON (legacy) ──────────────────────────────────────────────
    _sync_json_from_db()


def _sync_json_from_db():
    """Keep agent-status.json in sync for legacy consumers."""
    if not JSON_PATH.exists():
        return
    try:
        conn = sqlite3.connect(str(DB_PATH))
        rows = conn.execute("SELECT * FROM agent_current_state").fetchall()
        cols = [d[0] for d in conn.execute("SELECT * FROM agent_current_state").description]
        conn.close()

        with open(JSON_PATH) as f:
            data = json.load(f)

        for row in rows:
            r = dict(zip(cols, row))
            key = r["agent_name"]
            if key not in data["agents"]:
                continue
            a = data["agents"][key]
            a["status"]              = r["current_status"]
            a["totalTasksCompleted"] = r["total_completed"]
            a["totalTasksAssigned"]  = r["total_assigned"]
            a["currentTask"]         = r["current_task"]
            a["currentTaskStatus"]   = r["current_status"] if r["current_task"] else None
            a["currentTaskProgress"] = r["current_progress"]
            a["blockers"]            = json.loads(r["blockers"] or "[]")
            a["availabilityStatus"]  = r["availability_status"]
            a["lastUpdated"]         = r["last_updated"]

        data["teamStats"]["totalTasksCompleted"] = sum(
            a["totalTasksCompleted"] for a in data["agents"].values()
        )
        data["teamStats"]["totalTasksAssigned"] = sum(
            a["totalTasksAssigned"] for a in data["agents"].values()
        )
        data["teamStats"]["tasksInProgress"] = sum(
            1 for a in data["agents"].values() if a["availabilityStatus"] == "in-progress"
        )
        data["teamStats"]["blockedTasks"] = sum(
            1 for a in data["agents"].values() if a["availabilityStatus"] == "blocked"
        )
        data["teamStats"]["lastTeamUpdate"] = now_utc()

        with open(JSON_PATH, "w") as f:
            json.dump(data, f, indent=2)

    except Exception as e:
        print(f"⚠️  JSON sync warning (non-fatal): {e}")


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)

    update_agent_status(
        agent_name  = sys.argv[1],
        task_name   = sys.argv[2],
        status      = sys.argv[3],
        blockers    = sys.argv[4] if len(sys.argv) > 4 else "",
        updated_by  = sys.argv[5] if len(sys.argv) > 5 else "script",
    )
