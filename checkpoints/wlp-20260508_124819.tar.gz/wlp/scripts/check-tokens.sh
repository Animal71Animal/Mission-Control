#!/bin/bash
# =============================================================================
# WLP Token Health Check — Run anytime to verify tokens are still valid
# =============================================================================
# Usage: bash /home/ubuntu/wlp/scripts/check-tokens.sh
# =============================================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
OK="${GREEN}✅${NC}"; WARN="${YELLOW}⚠️${NC}"; ERR="${RED}❌${NC}"

SECRETS_FILE="/home/ubuntu/wlp/secrets/tokens.env"

echo ""
echo "🦞 WLP Token Health Check"
echo "=================================================="

# ── Load stored tokens ─────────────────────────────────
source "$SECRETS_FILE" 2>/dev/null

# ── GitHub PAT ─────────────────────────────────────────
echo ""
echo -e "${BLUE}GitHub PAT${NC}"
GH_RESULT=$(curl -sf -H "Authorization: token $GITHUB_TOKEN" "https://api.github.com/user" 2>/dev/null)
if echo "$GH_RESULT" | python3 -c "import json,sys; d=json.load(sys.stdin); exit(0 if 'login' in d else 1)" 2>/dev/null; then
  GH_USER=$(echo "$GH_RESULT" | python3 -c "import json,sys; print(json.load(sys.stdin)['login'])")
  SCOPES=$(curl -sI -H "Authorization: token $GITHUB_TOKEN" "https://api.github.com/user" 2>/dev/null | grep -i "x-oauth-scopes" | cut -d: -f2)
  echo -e "  Status:   ${OK} Valid"
  echo -e "  User:     $GH_USER"
  echo -e "  Scopes:  $SCOPES"
else
  echo -e "  Status:   ${ERR} INVALID or EXPIRED"
  echo "  Action:   Generate new PAT at https://github.com/settings/tokens"
  echo "            Then update /home/ubuntu/wlp/secrets/tokens.env"
  echo "            Then run: bash /home/ubuntu/wlp/scripts/setup-tokens.sh"
fi

# ── Check .env.local GitHub token ─────────────────────
ENV_TOKEN=$(grep "^GITHUB_TOKEN=" /home/ubuntu/wlp/projects/mission-control/.env.local 2>/dev/null | cut -d= -f2)
if [ -z "$ENV_TOKEN" ]; then
  echo -e "  .env.local: ${OK} Clean (token lives in Vercel env vars — correct)"
elif [ "$ENV_TOKEN" = "$GITHUB_TOKEN" ]; then
  echo -e "  .env.local: ${OK} In sync"
else
  echo -e "  .env.local: ${WARN} Stale token — run setup-tokens.sh to fix"
fi

# ── Vercel Token ──────────────────────────────────────
echo ""
echo -e "${BLUE}Vercel Token${NC}"
VC_RESULT=$(curl -sf -H "Authorization: Bearer $VERCEL_TOKEN" "https://api.vercel.com/v2/user" 2>/dev/null)
if echo "$VC_RESULT" | python3 -c "import json,sys; d=json.load(sys.stdin); exit(0 if 'user' in d else 1)" 2>/dev/null; then
  VC_USER=$(echo "$VC_RESULT" | python3 -c "import json,sys; print(json.load(sys.stdin)['user'].get('email','?'))")
  echo -e "  Status:   ${OK} Valid"
  echo -e "  User:     $VC_USER"
else
  echo -e "  Status:   ${ERR} INVALID or EXPIRED"
  echo "  Action:   Generate new token at https://vercel.com/account/tokens"
  echo "            Then update /home/ubuntu/wlp/secrets/tokens.env"
  echo "            Then run: bash /home/ubuntu/wlp/scripts/setup-tokens.sh"
fi

# ── Check Vercel CLI auth ──────────────────────────────
CLI_TOKEN=$(cat ~/.local/share/com.vercel.cli/auth.json 2>/dev/null | python3 -c "import json,sys; print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
if [ "$CLI_TOKEN" = "$VERCEL_TOKEN" ]; then
  echo -e "  CLI auth: ${OK} In sync"
else
  echo -e "  CLI auth: ${WARN} Stale (run setup-tokens.sh to fix)"
fi

# ── GitHub Actions Secrets ─────────────────────────────
echo ""
echo -e "${BLUE}GitHub Actions Secrets${NC}"
SECRETS=$(curl -sf \
  -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/Animal71Animal/Mission-Control/actions/secrets" 2>/dev/null)

if [ -n "$SECRETS" ]; then
  for secret in VERCEL_TOKEN VERCEL_ORG_ID VERCEL_PROJECT_ID; do
    if echo "$SECRETS" | python3 -c "import json,sys; d=json.load(sys.stdin); names=[s['name'] for s in d.get('secrets',[])]; exit(0 if '$secret' in names else 1)" 2>/dev/null; then
      echo -e "  $secret: ${OK} Set"
    else
      echo -e "  $secret: ${ERR} MISSING (run setup-tokens.sh)"
    fi
  done
else
  echo -e "  ${WARN} Could not check (GitHub token may be invalid)"
fi

# ── Vercel Project Env Vars ─────────────────────────────
echo ""
echo -e "${BLUE}Vercel Project Env Vars${NC}"
source "$SECRETS_FILE"
VC_ENV=$(curl -sf \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  "https://api.vercel.com/v10/projects/${VERCEL_PROJECT_ID}/env" 2>/dev/null)

if [ -n "$VC_ENV" ]; then
  if echo "$VC_ENV" | python3 -c "import json,sys; d=json.load(sys.stdin); keys=[e['key'] for e in d.get('envs',[])]; exit(0 if 'GITHUB_TOKEN' in keys else 1)" 2>/dev/null; then
    echo -e "  GITHUB_TOKEN: ${OK} Set in Vercel"
  else
    echo -e "  GITHUB_TOKEN: ${ERR} MISSING in Vercel (run setup-tokens.sh)"
  fi
else
  echo -e "  ${WARN} Could not check (Vercel token may be invalid)"
fi

# ── git remote ─────────────────────────────────────────
echo ""
echo -e "${BLUE}git Remote${NC}"
cd /home/ubuntu/wlp/projects/mission-control
GIT_REMOTE=$(git remote get-url origin 2>/dev/null)
if echo "$GIT_REMOTE" | grep -q "@github.com"; then
  echo -e "  Credentials: ${OK} Token embedded in remote URL"
else
  echo -e "  Credentials: ${WARN} No token in remote URL (git push may fail)"
  echo "  Fix: run setup-tokens.sh"
fi

PENDING=$(git status --short | wc -l | tr -d ' ')
if [ "$PENDING" = "0" ]; then
  echo -e "  Pending changes: ${OK} Clean"
else
  echo -e "  Pending changes: ${WARN} $PENDING uncommitted files"
fi

echo ""
echo "=================================================="
echo "To fix all issues at once: bash /home/ubuntu/wlp/scripts/setup-tokens.sh"
echo ""
