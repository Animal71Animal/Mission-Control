#!/usr/bin/env python3
"""
Reconcile agent-status.json task counts against actual task arrays.
Runs daily to prevent count drift.
"""

import json
import sys
from pathlib import Path
from datetime import datetime

AGENT_STATUS_FILE = Path("/home/ubuntu/wlp/projects/mission-control/public/data/agent-status.json")

def reconcile():
    try:
        with open(AGENT_STATUS_FILE) as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error reading agent-status.json: {e}")
        return False

    changed = False
    
    # Reconcile each agent
    for agent_id, agent in data["agents"].items():
        hist = agent.get("taskHistory", {})
        
        completed = hist.get("completed", [])
        in_progress = hist.get("inProgress", [])
        upcoming = hist.get("upcoming", [])
        
        new_completed = len(completed)
        new_assigned = len(completed) + len(in_progress) + len(upcoming)
        new_in_progress = len(in_progress)
        
        # Check if counts differ
        if (agent.get("totalTasksCompleted") != new_completed or 
            agent.get("totalTasksAssigned") != new_assigned or
            agent.get("tasksInProgress") != new_in_progress):
            
            print(f"📝 {agent['name']}: Fixing counts")
            print(f"   Completed: {agent.get('totalTasksCompleted')} → {new_completed}")
            print(f"   Assigned: {agent.get('totalTasksAssigned')} → {new_assigned}")
            print(f"   In Progress: {agent.get('tasksInProgress')} → {new_in_progress}")
            
            agent["totalTasksCompleted"] = new_completed
            agent["totalTasksAssigned"] = new_assigned
            agent["tasksInProgress"] = new_in_progress
            changed = True
    
    # Reconcile team stats
    total_completed = sum(a.get("totalTasksCompleted", 0) for a in data["agents"].values())
    total_assigned = sum(a.get("totalTasksAssigned", 0) for a in data["agents"].values())
    total_in_progress = sum(a.get("tasksInProgress", 0) for a in data["agents"].values())
    blocked_tasks = sum(1 for a in data["agents"].values() if a.get("status") == "blocked" and a.get("tasksInProgress", 0) > 0)
    
    if (data["teamStats"].get("totalTasksCompleted") != total_completed or
        data["teamStats"].get("totalTasksAssigned") != total_assigned or
        data["teamStats"].get("tasksInProgress") != total_in_progress):
        
        print(f"📊 Team Stats: Fixing team totals")
        print(f"   Total Completed: {data['teamStats'].get('totalTasksCompleted')} → {total_completed}")
        print(f"   Total Assigned: {data['teamStats'].get('totalTasksAssigned')} → {total_assigned}")
        print(f"   In Progress: {data['teamStats'].get('tasksInProgress')} → {total_in_progress}")
        
        data["teamStats"]["totalTasksCompleted"] = total_completed
        data["teamStats"]["totalTasksAssigned"] = total_assigned
        data["teamStats"]["tasksInProgress"] = total_in_progress
        data["teamStats"]["blockedTasks"] = blocked_tasks
        data["teamStats"]["lastTeamUpdate"] = datetime.utcnow().isoformat() + "Z"
        changed = True
    
    if not changed:
        print("✅ All agent counts match task arrays - no drift detected")
        return True
    
    # Write back
    try:
        with open(AGENT_STATUS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        print("✅ agent-status.json reconciled and saved")
        return True
    except Exception as e:
        print(f"❌ Error writing agent-status.json: {e}")
        return False

if __name__ == "__main__":
    success = reconcile()
    sys.exit(0 if success else 1)
