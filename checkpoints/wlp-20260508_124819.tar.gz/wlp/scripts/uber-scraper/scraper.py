#!/usr/bin/env python3
"""
Uber Driver Earnings Scraper
Logs into Uber driver dashboard and extracts daily earnings summary
Runs daily at 5 AM MDT to pull yesterday's earnings data
"""

import asyncio
import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from playwright.async_api import async_playwright

# Configuration
UBER_EMAIL = os.getenv("UBER_EMAIL", "ericmills71@gmail.com")
UBER_PASSWORD = os.getenv("UBER_PASSWORD", "")
UBER_EARNINGS_URL = "https://drivers.uber.com/earnings/activities"
MC_DATA_FILE = Path("/home/ubuntu/wlp/projects/mission-control/public/data/uber-earnings.json")

async def login_and_extract(page):
    """Navigate to Uber earnings page and extract data (assumes already logged in or will prompt)"""
    print("📊 Navigating to Uber earnings page...")
    
    try:
        await page.goto(UBER_EARNINGS_URL, wait_until="networkidle", timeout=30000)
    except Exception as e:
        print(f"⚠️ Navigation timeout (might be redirect to login): {e}")
        await page.wait_for_url("**earnings**", timeout=60000)
    
    # Wait for page content to load
    await asyncio.sleep(2)
    
    # Try to extract earnings data from page
    page_content = await page.content()
    
    # Look for earnings data in the HTML/JSON
    earnings_data = await extract_from_page_content(page)
    
    return earnings_data

async def extract_from_page_content(page):
    """Extract earnings from the rendered page"""
    print("🔍 Extracting earnings data from page...")
    
    # Try multiple extraction methods
    data = await page.evaluate("""
    async () => {
        const earnings = {};
        
        // Method 1: Look for __NEXT_DATA__ (Next.js app)
        const scriptTag = document.querySelector('script#__NEXT_DATA__');
        if (scriptTag) {
            try {
                const data = JSON.parse(scriptTag.textContent);
                // Navigate through props to find earnings info
                if (data.props?.pageProps?.initialState?.earnings) {
                    return data.props.pageProps.initialState.earnings;
                }
            } catch(e) {
                console.log('Failed to parse __NEXT_DATA__');
            }
        }
        
        // Method 2: Look for data attributes
        const summaryCard = document.querySelector('[data-testid*="summary"], [class*="earnings"], [class*="summary"]');
        if (summaryCard) {
            const text = summaryCard.innerText;
            return { raw_text: text };
        }
        
        // Method 3: Return page text for debugging
        return { page_text: document.body.innerText.substring(0, 1000) };
    }
    """)
    
    return data

async def scrape_uber_earnings():
    """Main scraper function"""
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True, executable_path="/usr/local/bin/chromium")
            context = await browser.new_context()
            page = await context.new_page()
            
            # Set viewport
            await page.set_viewport_size({"width": 1280, "height": 720})
            
            print("📍 Navigating to Uber earnings dashboard...")
            await page.goto(UBER_EARNINGS_URL, wait_until="load", timeout=30000)
            
            # Wait a bit for JS to render
            await asyncio.sleep(3)
            
            # Check if we're on login or earnings page
            current_url = page.url
            print(f"📄 Current URL: {current_url}")
            
            if "login" in current_url or "auth" in current_url:
                print("🔓 Detected login page, attempting authentication...")
                # Try to fill login form
                try:
                    # Wait for email input
                    await page.wait_for_selector('input[type="email"]', timeout=10000)
                    await page.fill('input[type="email"]', UBER_EMAIL)
                    await page.fill('input[type="password"]', UBER_PASSWORD)
                    
                    # Click login
                    await page.click('button[type="submit"]')
                    
                    # Wait for redirect
                    await page.wait_for_url("**/earnings/**", timeout=30000)
                    print("✅ Login successful")
                    
                    await asyncio.sleep(2)
                except asyncio.TimeoutError as e:
                    print(f"⚠️ Login timeout or form not found: {e}")
                    print("   This likely means 2FA is enabled or form structure changed")
            
            # Extract earnings data
            earnings_data = await extract_from_page_content(page)
            print(f"📊 Extracted data: {earnings_data}")
            
            await browser.close()
            
            return earnings_data
    
    except Exception as e:
        print(f"❌ Error scraping Uber: {e}")
        import traceback
        traceback.print_exc()
        return None

def load_existing_data():
    """Load existing earnings data from JSON file"""
    if MC_DATA_FILE.exists():
        with open(MC_DATA_FILE, 'r') as f:
            return json.load(f)
    return {"dailySummaries": [], "lastUpdated": None}

def save_test_data():
    """Save sample test data from the PDF statement Eric provided"""
    data = load_existing_data()
    
    # Add sample from the PDF statement (Apr 20-22)
    sample_entry = {
        "date": "2026-04-21",
        "earnings": 158.36,
        "trips": 8,
        "tips": 24.00,
        "basefare": 128.22,
        "surge": 5.25,
        "promotions": 6.14,
        "expenses": -1.72,
        "netPayout": 156.64
    }
    
    # Only add if not already present
    if not any(e.get('date') == sample_entry['date'] for e in data['dailySummaries']):
        data['dailySummaries'].append(sample_entry)
        
        # Sort by date
        data['dailySummaries'].sort(key=lambda x: x['date'], reverse=True)
        data['lastUpdated'] = datetime.utcnow().isoformat() + 'Z'
        
        # Ensure directory exists
        MC_DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        # Write file
        with open(MC_DATA_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"✅ Saved test earnings entry to {MC_DATA_FILE}")

async def main():
    print(f"🚀 Uber Earnings Scraper Started at {datetime.now()} MDT")
    
    # For now, save test data since the scraper needs browser automation refinement
    print("⚠️ Scraper requires browser interaction refinement (2FA, form selectors)")
    print("📝 Saving sample data from PDF statement for testing...")
    save_test_data()
    print("✅ Ready for production when login automation is confirmed")

if __name__ == "__main__":
    asyncio.run(main())
