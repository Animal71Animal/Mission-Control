#!/bin/bash
# backup-agent-status.sh — Export agent_status_log to JSON, commit to GitHub
#
# Runs daily via cron. Keeps 30-day rolling history.
# Cron entry:
#   0 7 * * * /home/ubuntu/wlp/scripts/backup-agent-status.sh >> /home/ubuntu/wlp/logs/backup-agent-status.log 2>&1
#
# Files written to: wlp/projects/mission-control/backups/agent-status/

set -euo pipefail

DB="/home/ubuntu/wlp/projects/mission-control/mission-control.db"
BACKUP_DIR="/home/ubuntu/wlp/projects/mission-control/backups/agent-status"
REPO_DIR="/home/ubuntu/wlp/projects/mission-control"
TODAY=$(date -u +"%Y-%m-%d")
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "[$TIMESTAMP] Starting agent-status backup..."

# ── 1. Verify DB exists ─────────────────────────────────────────────────────
if [ ! -f "$DB" ]; then
  echo "[$TIMESTAMP] ❌ Database not found at $DB — aborting."
  exit 1
fi

# ── 2. Ensure backup dir exists ─────────────────────────────────────────────
mkdir -p "$BACKUP_DIR"

# ── 3. Export audit log (last 30 days) ──────────────────────────────────────
BACKUP_FILE="$BACKUP_DIR/agent-status-log-${TODAY}.json"

python3 - <<PYEOF
import json, sqlite3

db = sqlite3.connect("$DB")
db.row_factory = sqlite3.Row

# Audit log: last 30 days
rows = db.execute("""
    SELECT id, timestamp, agent_name, task_name, status, blockers, updated_by
    FROM agent_status_log
    WHERE timestamp >= datetime('now', '-30 days')
    ORDER BY timestamp DESC
""").fetchall()
log = [dict(r) for r in rows]

# Current state snapshot
state_rows = db.execute("SELECT * FROM agent_current_state ORDER BY agent_name").fetchall()
state = [dict(r) for r in state_rows]

db.close()

output = {
    "generated": "$TIMESTAMP",
    "current_state": state,
    "audit_log_30d": log,
}

with open("$BACKUP_FILE", "w") as f:
    json.dump(output, f, indent=2)

print(f"  Exported {len(log)} log entries + {len(state)} agent states")
PYEOF

echo "  ✅ Backup written: $BACKUP_FILE"

# ── 4. Prune files older than 30 days ───────────────────────────────────────
find "$BACKUP_DIR" -name "agent-status-log-*.json" -mtime +30 -delete
echo "  🗑  Pruned backups older than 30 days"

# ── 5. Commit to GitHub ─────────────────────────────────────────────────────
cd "$REPO_DIR"

# Check if there are changes
if git diff --quiet -- "backups/agent-status/" 2>/dev/null && \
   git ls-files --others --exclude-standard -- "backups/agent-status/" | grep -q .; then
  : # new untracked files — continue
fi

git add "backups/agent-status/" 2>/dev/null || true

if git diff --cached --quiet 2>/dev/null; then
  echo "  ℹ️  No changes to commit (backup already up to date)"
else
  git commit -m "chore: agent-status backup ${TODAY} [auto]" \
    --author="PriScylla <priscylla@wlp.ai>" 2>/dev/null
  
  if git push origin HEAD 2>/dev/null; then
    echo "  ✅ Pushed to GitHub"
  else
    echo "  ⚠️  Push failed — backup saved locally at $BACKUP_FILE"
  fi
fi

echo "[$TIMESTAMP] ✅ Backup complete."
