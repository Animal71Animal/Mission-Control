#!/bin/bash
# cron-fixer.sh - Auto-restart cron if it dies
# Called by crontab every 5 minutes to keep cron alive

LOG_FILE="/home/ubuntu/wlp/logs/cron-fixer.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Check if cron is running
if ! pgrep -x cron > /dev/null; then
  echo "[$TIMESTAMP] ALERT: Cron is dead. Restarting..." >> "$LOG_FILE"
  
  # Try to start cron
  if sudo service cron start >> "$LOG_FILE" 2>&1; then
    echo "[$TIMESTAMP] SUCCESS: Cron restarted" >> "$LOG_FILE"
    
    # Reinstall cron jobs if they're missing
    if ! sudo crontab -l 2>/dev/null | grep -q "WLP Cron Jobs"; then
      echo "[$TIMESTAMP] INFO: Reinstalling cron jobs..." >> "$LOG_FILE"
      (cat << 'EOF'
# === WLP Cron Jobs (auto-restored) ===
*/30 * * * * /usr/bin/python3 /home/ubuntu/wlp/skills/session-recovery/scripts/save-state.py >> /home/ubuntu/wlp/logs/save-state.log 2>&1
0 16 * * * /usr/bin/bash /home/ubuntu/wlp/skills/morning-briefing/scripts/morning-briefing.sh >> /home/ubuntu/wlp/logs/morning-briefing.log 2>&1
0 */2 * * * /usr/bin/python3 /home/ubuntu/wlp/skills/youtube-monitor/scripts/channel-monitor-local.py >> /home/ubuntu/wlp/logs/youtube-monitor.log 2>&1
*/5 * * * * /bin/bash /home/ubuntu/wlp/scripts/cron-fixer.sh >> /home/ubuntu/wlp/logs/cron-fixer.log 2>&1
EOF
      ) | sudo crontab - >> "$LOG_FILE" 2>&1
      echo "[$TIMESTAMP] SUCCESS: Cron jobs reinstalled" >> "$LOG_FILE"
    fi
  else
    echo "[$TIMESTAMP] ERROR: Failed to restart cron" >> "$LOG_FILE"
  fi
else
  # Cron is healthy; just log a heartbeat every 10 runs to save space
  HEARTBEAT_FILE="/tmp/cron-fixer-heartbeat"
  if [ ! -f "$HEARTBEAT_FILE" ] || [ $(find "$HEARTBEAT_FILE" -mmin +10 2>/dev/null) ]; then
    echo "[$TIMESTAMP] HEALTHY: Cron is running (PID: $(pgrep -x cron))" >> "$LOG_FILE"
    touch "$HEARTBEAT_FILE"
  fi
fi

exit 0
