#!/usr/bin/env python3
"""
Manual QMD Indexing Script
Walks through workspace and adds all markdown files to QMD
"""

import os
import subprocess
import glob
from pathlib import Path

# Collections config (from ~/.config/qmd/index.yml)
COLLECTIONS = {
    "workspace": {
        "path": "/home/ubuntu",
        "pattern": "*.md"
    },
    "memory": {
        "path": "/home/ubuntu/memory",
        "pattern": "**/*.md"
    },
    "agents": {
        "path": "/home/ubuntu/wlp/agents",
        "pattern": "**/*.md"
    },
    "projects": {
        "path": "/home/ubuntu/wlp/projects",
        "pattern": "**/*.md"
    },
    "skills": {
        "path": "/home/ubuntu/wlp/skills",
        "pattern": "**/*.md"
    }
}

def index_collection(collection_name, config):
    """Index all markdown files in a collection"""
    path = config["path"]
    pattern = config["pattern"]
    
    if not os.path.exists(path):
        print(f"⚠️  Skipping {collection_name}: path {path} not found")
        return 0
    
    # Find all matching files
    search_path = os.path.join(path, pattern)
    files = glob.glob(search_path, recursive=True)
    
    print(f"\n📚 Indexing {collection_name} ({len(files)} files)...")
    
    indexed = 0
    for filepath in files:
        if not os.path.isfile(filepath):
            continue
        
        try:
            # Read file content
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Add to QMD
            cmd = [
                'qmd', 'document', 'add',
                '--collection', collection_name,
                '--path', filepath,
                '--content', content[:5000]  # Limit content for now
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                indexed += 1
                print(f"  ✅ {os.path.basename(filepath)}")
            else:
                print(f"  ❌ {os.path.basename(filepath)}: {result.stderr[:100]}")
        
        except Exception as e:
            print(f"  ❌ {filepath}: {str(e)[:100]}")
    
    return indexed

def main():
    print("🚀 QMD Manual Indexing")
    print("=" * 50)
    
    total_indexed = 0
    
    for collection_name, config in COLLECTIONS.items():
        count = index_collection(collection_name, config)
        total_indexed += count
    
    print("\n" + "=" * 50)
    print(f"✅ Total indexed: {total_indexed} files")
    print("\nTo search, use:")
    print("  qmd search --collection workspace --query 'your search term'")

if __name__ == "__main__":
    main()
