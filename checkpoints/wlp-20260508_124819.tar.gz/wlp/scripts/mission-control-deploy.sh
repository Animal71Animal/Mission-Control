#!/bin/bash
# Mission Control Deployment Script
# Usage: ./mission-control-deploy.sh [--help|--manual|--push]

set -e

VERCEL_TOKEN="vcp_7a2USfgX3w1B41u8yoIHx9wV0aT1N92FCkm3TnBTzb6xU5nVVx1CpXmx"
PROJECT_DIR="/home/ubuntu/wlp/projects/mission-control"

usage() {
  cat << EOF
Mission Control Deploy

Usage: mission-control-deploy.sh [OPTIONS]

Options:
  --help      Show this help
  --manual    Deploy manually with VERCEL_TOKEN (no git push)
  --push      Commit changes and push to main (triggers auto-deploy)

Default: --manual

Examples:
  ./mission-control-deploy.sh           # Manual deploy
  ./mission-control-deploy.sh --push    # Git commit + push (requires SSH/HTTPS)
EOF
  exit 0
}

manual_deploy() {
  echo "🚀 Building Mission Control..."
  cd "$PROJECT_DIR"
  npm run build
  
  echo "📤 Deploying to Vercel (production)..."
  VERCEL_TOKEN="$VERCEL_TOKEN" npx vercel@latest deploy --prod --yes
  
  echo "✅ Deployment complete!"
  echo "🌐 Live at: https://mission-control-cyan-omega.vercel.app"
}

push_deploy() {
  echo "📝 Committing changes..."
  cd "$PROJECT_DIR"
  git add -A
  read -p "Commit message: " msg
  git commit -m "$msg" || echo "Nothing to commit"
  
  echo "🔄 Pushing to main (triggers GitHub Actions auto-deploy)..."
  git push origin main
  
  echo "✅ Pushed! Check GitHub Actions for deploy status:"
  echo "   https://github.com/Animal71Animal/Mission-Control/actions"
}

# Parse args
case "${1:-}" in
  --help) usage ;;
  --manual) manual_deploy ;;
  --push) push_deploy ;;
  "") manual_deploy ;;
  *)
    echo "Unknown option: $1"
    usage
    ;;
esac
