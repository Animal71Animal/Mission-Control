#!/bin/bash
# =============================================================================
# WLP Token Setup Script — Run this after getting new tokens
# =============================================================================
# Usage:
#   1. Fill in /home/ubuntu/wlp/secrets/tokens.env
#   2. Run: bash /home/ubuntu/wlp/scripts/setup-tokens.sh
#
# What it does:
#   - Configures git credential helper with GitHub token
#   - Installs Vercel CLI auth token
#   - Sets GITHUB_TOKEN in Vercel project env vars
#   - Sets GITHUB_TOKEN and Vercel secrets in GitHub Actions
#   - Updates .env.local with fresh token
#   - Commits and pushes any pending local changes
# =============================================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
OK="${GREEN}✅${NC}"; WARN="${YELLOW}⚠️${NC}"; ERR="${RED}❌${NC}"

SECRETS_FILE="/home/ubuntu/wlp/secrets/tokens.env"
PROJECT_DIR="/home/ubuntu/wlp/projects/mission-control"

echo ""
echo "🦞 WLP Token Setup"
echo "=================================================="

# ── Load tokens ────────────────────────────────────────
if [ ! -f "$SECRETS_FILE" ]; then
  echo -e "${ERR} Secrets file not found: $SECRETS_FILE"
  exit 1
fi

source "$SECRETS_FILE"

# ── Validate ──────────────────────────────────────────
ERRORS=0

if [ -z "$GITHUB_TOKEN" ]; then
  echo -e "${ERR} GITHUB_TOKEN is empty in $SECRETS_FILE"
  ERRORS=$((ERRORS+1))
fi

if [ -z "$VERCEL_TOKEN" ]; then
  echo -e "${ERR} VERCEL_TOKEN is empty in $SECRETS_FILE"
  ERRORS=$((ERRORS+1))
fi

if [ $ERRORS -gt 0 ]; then
  echo ""
  echo "Fill in the missing tokens in $SECRETS_FILE then re-run."
  echo ""
  echo "Get tokens here:"
  echo "  GitHub: https://github.com/settings/tokens (Classic, repo + workflow scopes)"
  echo "  Vercel: https://vercel.com/account/tokens (No expiry)"
  exit 1
fi

# ── Test GitHub token ─────────────────────────────────
echo -n "Testing GitHub token... "
GH_USER=$(curl -sf -H "Authorization: token $GITHUB_TOKEN" "https://api.github.com/user" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('login','?'))" 2>/dev/null || echo "FAILED")
if [ "$GH_USER" = "FAILED" ]; then
  echo -e "${ERR} GitHub token invalid"
  exit 1
fi
echo -e "${OK} Valid — user: $GH_USER"

# ── Test Vercel token ─────────────────────────────────
echo -n "Testing Vercel token... "
VC_USER=$(curl -sf -H "Authorization: Bearer $VERCEL_TOKEN" "https://api.vercel.com/v2/user" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('user',{}).get('email','?'))" 2>/dev/null || echo "FAILED")
if [ "$VC_USER" = "FAILED" ]; then
  echo -e "${ERR} Vercel token invalid"
  exit 1
fi
echo -e "${OK} Valid — user: $VC_USER"

# ── 1. Configure git credentials ──────────────────────
echo ""
echo "1. Configuring git credentials..."
git config --global credential.helper store
echo "https://${GH_USER}:${GITHUB_TOKEN}@github.com" > ~/.git-credentials
chmod 600 ~/.git-credentials
echo -e "   ${OK} git credential helper configured"

# ── 2. Update remote URL with token ──────────────────
cd "$PROJECT_DIR"
git remote set-url origin "https://${GH_USER}:${GITHUB_TOKEN}@github.com/Animal71Animal/Mission-Control.git"
echo -e "   ${OK} git remote URL updated with token"

# ── 3. Update .env.local ──────────────────────────────
echo ""
echo "2. Updating Mission Control .env.local..."
cat > "$PROJECT_DIR/.env.local" << EOF
# Mission Control v2 - Environment Configuration
# Auto-updated by setup-tokens.sh on $(date)

DATABASE_URL=file:./mission-control.db

GOOGLE_CALENDAR_ID=
GOOGLE_SERVICE_ACCOUNT_KEY=
GOOGLE_DRIVE_FOLDER_ID=

# GitHub API — data persistence layer
GITHUB_TOKEN=${GITHUB_TOKEN}
EOF
echo -e "   ${OK} .env.local updated"

# ── 4. Install Vercel CLI auth ─────────────────────────
echo ""
echo "3. Configuring Vercel CLI..."
mkdir -p ~/.local/share/com.vercel.cli
cat > ~/.local/share/com.vercel.cli/auth.json << EOF
{"token":"${VERCEL_TOKEN}"}
EOF
chmod 600 ~/.local/share/com.vercel.cli/auth.json

# Test vercel deploy will work
VERCEL_TOKEN_EXPORTED="$VERCEL_TOKEN"
VERCEL_ORG_ID_EXPORTED="$VERCEL_ORG_ID"
VERCEL_PROJECT_ID_EXPORTED="$VERCEL_PROJECT_ID"
echo -e "   ${OK} Vercel CLI token installed"

# ── 5. Set GITHUB_TOKEN in Vercel project env vars ────
echo ""
echo "4. Setting GITHUB_TOKEN in Vercel project env vars..."
# Remove old value first (ignore errors)
curl -sf -X DELETE \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  "https://api.vercel.com/v9/projects/${VERCEL_PROJECT_ID}/env?key=GITHUB_TOKEN&target=production&target=preview&target=development" \
  > /dev/null 2>&1 || true

# Add new value
RESPONSE=$(curl -sf -X POST \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  "https://api.vercel.com/v10/projects/${VERCEL_PROJECT_ID}/env" \
  -d "{\"key\":\"GITHUB_TOKEN\",\"value\":\"${GITHUB_TOKEN}\",\"type\":\"encrypted\",\"target\":[\"production\",\"preview\",\"development\"]}" 2>/dev/null || echo "FAILED")

if echo "$RESPONSE" | grep -q "FAILED\|error"; then
  echo -e "   ${WARN} Could not set Vercel env var automatically (may need dashboard)"
  echo "   Manual: vercel.com → mission-control → Settings → Environment Variables"
  echo "   Add: GITHUB_TOKEN = $GITHUB_TOKEN"
else
  echo -e "   ${OK} GITHUB_TOKEN set in Vercel project"
fi

# ── 6. Set GitHub Actions secrets ─────────────────────
echo ""
echo "5. Setting GitHub Actions secrets..."

set_gh_secret() {
  local SECRET_NAME="$1"
  local SECRET_VALUE="$2"
  
  # Get public key for secret encryption
  PK_RESPONSE=$(curl -sf \
    -H "Authorization: token $GITHUB_TOKEN" \
    "https://api.github.com/repos/Animal71Animal/Mission-Control/actions/secrets/public-key" 2>/dev/null)
  
  if [ -z "$PK_RESPONSE" ]; then
    echo -e "   ${WARN} Could not get repo public key for $SECRET_NAME"
    return
  fi
  
  KEY_ID=$(echo "$PK_RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin)['key_id'])")
  PUBLIC_KEY=$(echo "$PK_RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin)['key'])")
  
  # Encrypt the secret using PyNaCl (if available) or base64 fallback
  ENCRYPTED=$(python3 -c "
import base64, sys
try:
    from nacl import encoding, public
    pk = public.PublicKey(base64.b64decode('$PUBLIC_KEY'))
    box = public.SealedBox(pk)
    enc = box.encrypt('${SECRET_VALUE}'.encode())
    print(base64.b64encode(enc).decode())
except ImportError:
    # nacl not available - output placeholder
    print('NACL_MISSING')
" 2>/dev/null)
  
  if [ "$ENCRYPTED" = "NACL_MISSING" ]; then
    echo -e "   ${WARN} PyNaCl not installed — skipping $SECRET_NAME GitHub Actions secret"
    echo "         Install: pip3 install PyNaCl to enable auto-secret-setting"
    return
  fi
  
  curl -sf -X PUT \
    -H "Authorization: token $GITHUB_TOKEN" \
    -H "Content-Type: application/json" \
    "https://api.github.com/repos/Animal71Animal/Mission-Control/actions/secrets/$SECRET_NAME" \
    -d "{\"encrypted_value\":\"${ENCRYPTED}\",\"key_id\":\"${KEY_ID}\"}" > /dev/null 2>&1

  echo -e "   ${OK} $SECRET_NAME set"
}

# Install PyNaCl if needed
pip3 install PyNaCl --quiet 2>/dev/null || true

set_gh_secret "VERCEL_TOKEN" "$VERCEL_TOKEN"
set_gh_secret "VERCEL_ORG_ID" "$VERCEL_ORG_ID"
set_gh_secret "VERCEL_PROJECT_ID" "$VERCEL_PROJECT_ID"
set_gh_secret "GITHUB_TOKEN_SECRET" "$GITHUB_TOKEN"

# ── 7. Commit and push pending changes ────────────────
echo ""
echo "6. Committing and pushing pending local changes..."
cd "$PROJECT_DIR"
PENDING=$(git status --short | wc -l)
if [ "$PENDING" -gt 0 ]; then
  git add -A
  git commit -m "chore: sync local changes + token refresh $(date +%Y-%m-%d)"
  git push origin main
  echo -e "   ${OK} $PENDING files committed and pushed"
else
  echo -e "   ${OK} No pending changes"
fi

# ── 8. Update ~/.github-pat ────────────────────────────
echo "$GITHUB_TOKEN" > ~/.github-pat
chmod 600 ~/.github-pat
echo -e "   ${OK} ~/.github-pat updated"

# ── 9. Mark tokens as set in secrets file ─────────────
DATE_NOW=$(date +%Y-%m-%d)
sed -i "s/# GITHUB_TOKEN_SET=.*/# GITHUB_TOKEN_SET=$DATE_NOW/" "$SECRETS_FILE"
sed -i "s/# VERCEL_TOKEN_SET=.*/# VERCEL_TOKEN_SET=$DATE_NOW/" "$SECRETS_FILE"

echo ""
echo "=================================================="
echo -e "${OK} All done! Token setup complete."
echo ""
echo "Deploy Mission Control now with:"
echo "   cd $PROJECT_DIR && ./deploy.sh"
echo ""
echo "Tokens expire check:"
echo "   Run: bash /home/ubuntu/wlp/scripts/check-tokens.sh"
echo ""
