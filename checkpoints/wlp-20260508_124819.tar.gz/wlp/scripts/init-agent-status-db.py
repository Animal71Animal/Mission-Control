#!/usr/bin/env python3
"""
Initialize agent_status tables in mission-control.db and migrate from JSON.
Run once (or it's idempotent — safe to re-run).

Usage:
  python3 init-agent-status-db.py
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path("/home/ubuntu/wlp/projects/mission-control/mission-control.db")
JSON_PATH = Path("/home/ubuntu/wlp/data/agent-status.json")

SCHEMA = """
-- Audit log: every status change recorded forever
CREATE TABLE IF NOT EXISTS agent_status_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL DEFAULT (datetime('now')),
    agent_name  TEXT NOT NULL,
    task_name   TEXT,
    status      TEXT NOT NULL,
    blockers    TEXT,
    updated_by  TEXT NOT NULL DEFAULT 'script'
);

-- Live state: one row per agent, upserted on every update
CREATE TABLE IF NOT EXISTS agent_current_state (
    agent_name          TEXT PRIMARY KEY,
    total_completed     INTEGER NOT NULL DEFAULT 0,
    total_assigned      INTEGER NOT NULL DEFAULT 0,
    current_task        TEXT,
    current_status      TEXT NOT NULL DEFAULT 'idle',
    current_progress    INTEGER NOT NULL DEFAULT 0,
    blockers            TEXT,
    availability_status TEXT NOT NULL DEFAULT 'available',
    next_deadline       TEXT,
    last_updated        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_log_agent ON agent_status_log(agent_name);
CREATE INDEX IF NOT EXISTS idx_log_timestamp ON agent_status_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_state_agent ON agent_current_state(agent_name);
"""

def migrate_from_json(conn):
    """Migrate existing JSON data into SQLite."""
    if not JSON_PATH.exists():
        print("  No JSON file to migrate from.")
        return

    with open(JSON_PATH) as f:
        data = json.load(f)

    agents = data.get("agents", {})
    migrated = 0

    for key, agent in agents.items():
        blockers = json.dumps(agent.get("blockers", [])) if agent.get("blockers") else None
        conn.execute("""
            INSERT OR REPLACE INTO agent_current_state
            (agent_name, total_completed, total_assigned, current_task,
             current_status, current_progress, blockers, availability_status,
             next_deadline, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            key.lower(),
            agent.get("totalTasksCompleted", 0),
            agent.get("totalTasksAssigned", 0),
            agent.get("currentTask"),
            agent.get("status", "idle"),
            agent.get("currentTaskProgress", 0),
            blockers,
            agent.get("availabilityStatus", "available"),
            agent.get("nextDeadline"),
            agent.get("lastUpdated", datetime.utcnow().isoformat() + "Z"),
        ))

        # Seed one log entry per agent from the JSON snapshot
        conn.execute("""
            INSERT INTO agent_status_log (timestamp, agent_name, task_name, status, blockers, updated_by)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            agent.get("lastUpdated", datetime.utcnow().isoformat() + "Z"),
            key.lower(),
            agent.get("currentTask"),
            agent.get("status", "idle"),
            json.dumps(agent.get("blockers", [])),
            "migration",
        ))
        migrated += 1

    conn.commit()
    print(f"  ✅ Migrated {migrated} agents from JSON.")


def main():
    print(f"📦 Initializing agent status tables in {DB_PATH}")

    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row

    conn.executescript(SCHEMA)
    conn.commit()
    print("  ✅ Schema created (tables + indexes).")

    # Check if already has data
    count = conn.execute("SELECT COUNT(*) FROM agent_current_state").fetchone()[0]
    if count == 0:
        print("  ⚙️  No existing data — migrating from JSON...")
        migrate_from_json(conn)
    else:
        print(f"  ℹ️  Already has {count} agent rows — skipping migration.")

    conn.close()
    print("✅ Database ready.")


if __name__ == "__main__":
    main()
