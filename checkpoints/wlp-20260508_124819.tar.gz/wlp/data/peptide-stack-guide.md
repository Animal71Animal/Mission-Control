# Peptide Stack Guide — How They Work + What to Watch

## Stack Overview (May 4, 2026)

### Reta (Retratrutide — GLP-1/GIP/Glucagon Triple Agonist)
**What it does:**
- Suppresses appetite via GLP-1 pathway
- Enhances glucose control via GIP
- Increases energy expenditure via glucagon signaling
- Net effect: accelerated fat loss + metabolic boost

**How it fits:**
- Anchor of your metabolic stack
- Works synergistically with Tesa to maximize lean mass retention during fat loss
- Tesamorelin prevents muscle loss while Reta burns fat

**Watch out for:**
- GI side effects (nausea, constipation) especially first 2-3 weeks
- Dehydration — drink extra water daily
- Monitor for pancreatitis symptoms (severe stomach pain, fever) — rare but serious
- Can cause gallbladder issues with rapid weight loss — may need ultrasound if experiencing RUQ pain
- Hypoglycemia risk if combined with other glucose-lowering agents

---

### Tesa (Tesamorelin — GHRH Analog)
**What it does:**
- Stimulates natural growth hormone (GH) release from pituitary
- Increases lean muscle mass
- Accelerates fat oxidation (works WITH Reta)
- Improves recovery and body composition

**How it fits:**
- Counter-balance to Reta: while Reta strips fat, Tesa preserves muscle
- Together = lean recomposition (lose fat, build/maintain muscle simultaneously)
- 5-day weekday cycle avoids receptor desensitization

**Watch out for:**
- Water retention (mild) — normalize sodium/potassium intake
- Joint pain (transient) — warm up before workouts
- Increased hunger as GH rises — expected, doesn't negate Reta's appetite suppression
- Carpal tunnel risk if GH gets too high — monitor for wrist/hand numbness
- Monitor fasting glucose — GH can slightly raise it

---

### HCG (Human Chorionic Gonadotropin)
**What it does:**
- Stimulates natural testosterone production in testes
- Prevents testicular atrophy
- Maintains hormone balance and sexual function
- Preserves fertility

**How it fits:**
- Protective agent — keeps your endocrine system functional
- Necessary with Reta (some GLP-1 agonists can suppress testosterone slightly)
- 2x weekly dosing maintains steady hormone levels

**Watch out for:**
- Gynecomastia risk (breast tissue growth) — monitor chest for tenderness/lumps
- High estrogen if HCG causes excessive aromatization — consider adding DIM or calcium d-glucarate if needed
- Water retention at higher doses
- Testicular discomfort if injected into wrong spot — inject intramuscular (glute/thigh), not SQ
- Don't exceed 10u 2x weekly without bloodwork

---

### Semax (Nootropic Peptide)
**What it does:**
- Enhances cognitive function, focus, motivation
- Improves mood and stress resilience
- Increases BDNF (brain-derived neurotrophic factor) — brain plasticity
- May support mood during caloric deficit (when Reta suppresses appetite)

**How it fits:**
- Psychological support while in fat loss mode
- Keeps you sharp during high workload (DJ gigs + Uber shifts)
- Stacks well with Reta + Tesa (they can cause fatigue; Semax counteracts it)

**Watch out for:**
- Overstimulation if dosage too high — start at 5u and titrate
- Headaches (mild, transient) on first 2-3 days
- Sleep disturbance if dosed in evening — stick to morning dosing
- No major interactions with other compounds
- Adding second dose (2-3pm) is safe if first dose is too mild, but don't exceed 10u/day total

---

### MT1 (Melanotan I — Peptide Hormone)
**What it does:**
- Stimulates melanin production → skin pigmentation (tan)
- Increases libido/sexual function via melanocortin receptors
- Has mild appetite suppression side effect
- Anti-inflammatory effects

**How it fits:**
- Cosmetic + performance compound
- Works during loading phase (10-14 days) to build baseline pigmentation
- Synergizes with Reta (both suppress appetite, compounding effect)
- Maintenance phase (2x weekly) keeps tan without constant loading

**Watch out for:**
- Nausea (very common) — start low (5u), take 30-60 min before sun exposure, eat light meal before
- Nausea usually resolves after day 3-5 as you habituate
- Spontaneous erections (expected, not a problem)
- Moles/nevi can darken — monitor existing moles for ABCDE changes (asymmetry, border, color, diameter, evolution)
- Sun exposure without protection increases skin cancer risk — use SPF 30+ if outdoors
- Loading phase is 10-14 days, then drop to maintenance (10u 2x weekly)
- Don't exceed maintenance dose long-term (receptor downregulation)

---

## How They Work Together

**Primary Stack Synergy:**
```
Reta (fat loss) + Tesa (muscle preservation) = Lean recomposition
+ HCG (hormone maintenance) = Sustained endocrine function
+ Semax (cognitive support) = Mental clarity during deficit
+ MT1 (aesthetics) = Visible results
```

**Metabolic Axis:**
- Reta ↓ appetite, ↑ expenditure
- Tesa ↑ GH, ↑ recovery, ↑ lean mass
- Together maximize fat loss while preserving muscle

**Hormonal Safety:**
- HCG maintains testosterone while Reta + Tesa are working
- No direct conflicts
- All are peptides (no oral drug interactions)

---

## What to Monitor Weekly

| Metric | Target | If Off |
|--------|--------|---------|
| Nausea (MT1) | Gone by day 5 | Consider ginger, smaller meals, take before food |
| Appetite | Suppressed but eating enough | Tesa counter-balancing Reta correctly |
| Energy | High/normal | Semax working; if low, may need dose adjustment |
| Sleep | 7-9 hours | Semax too high? Move to 8am only |
| Bowel habits | Normal (Reta can cause constipation) | Increase fiber, magnesium, water |
| Skin | Darkening (MT1 loading) | Normal; should see change by day 10 |
| Sexual function | Normal or enhanced | HCG + MT1 should support this |

---

## What NOT to Add (High Risk)

### ❌ Testosterone (TRT)
- **Why:** HCG already maintaining test production; adding exogenous test will shut down natural production
- **If you need TRT:** Stop HCG, use test + AI (aromatase inhibitor)

### ❌ SARMs (Selective Androgen Receptor Modulators)
- **Why:** Stack onto Reta already causing GI stress; SARMs add liver burden
- **If you want more muscle:** Increase Tesa dose or add more frequent GH peptides (CJC-1295, GHRP-6)

### ❌ Insulin (unless you're competing)
- **Why:** Reta + Tesa already optimize glucose; insulin adds hypoglycemia risk
- **Incompatible with:** Fat loss goal

### ❌ Clenbuterol
- **Why:** Both are harsh on cardiovascular system; Reta already harsh on GI
- **Better alternative:** Stick with current stack or add T3 (thyroid) at low dose if plateau

### ❌ Multiple GLP-1 agonists (Semaglutide + Reta)
- **Why:** Redundant pathways, multiplies GI side effects and pancreatitis risk
- **Do one:** Reta is strongest, stick with it

---

## What CAN Be Added (Low/Medium Risk)

### ✅ BPC-157 (Gut Healing Peptide)
- **Why:** Reta can damage GI lining; BPC-157 heals it
- **When:** If experiencing persistent GI upset after week 2
- **Dose:** 250-500 mcg daily (SQ, any body part)

### ✅ Thyroid (T3/T4)
- **Why:** Increases metabolic rate further; synergizes with Reta
- **When:** Only if plateauing on fat loss by week 4+
- **Caution:** Thyroid is strong; start low, monitor heart rate/anxiety

### ✅ Low-Dose Finasteride (Propecia)
- **Why:** HCG may increase DHT-related side effects (acne, hair loss)
- **When:** If experiencing new acne or shedding by week 3
- **Dose:** 0.25-0.5mg daily (low dose to preserve benefits)

### ✅ Cabergoline or Bromocriptine (if prolactin rises)
- **Why:** HCG can increase prolactin; these suppress it
- **When:** Only if bloodwork shows elevated prolactin (>20 ng/mL)
- **Monitor:** Get prolactin checked at week 3-4

### ✅ Antihistamine (Famotidine, Ranitidine)
- **Why:** Blocks histamine release that causes MT1 nausea
- **When:** Days 1-3 of loading phase
- **Dose:** 20mg 1-2x daily with meals

---

## Bloodwork Checklist (Week 2-3)

Get these tested to ensure safety:
- **Lipid panel** (Reta can affect cholesterol)
- **Fasting glucose** (Tesa can raise it slightly)
- **Liver enzymes** (AST, ALT — all peptides are safe, but baseline matters)
- **Prolactin** (HCG baseline)
- **Free testosterone** (ensure HCG is working)
- **IGF-1** (to gauge Tesa's GH stimulation)
- **Amylase/Lipase** (pancreatitis markers — Reta safety check)

---

## Red Flags — Stop & Call Doctor If:

1. **Severe stomach pain** (not just nausea) → possible pancreatitis
2. **Chest pain or shortness of breath** → cardiovascular event
3. **Severe headache + vision changes** → possible hypertensive crisis
4. **Ankle/leg swelling** → possible thrombosis
5. **Testicular pain that doesn't improve** → possible complication of HCG
6. **New mole or existing mole changing rapidly** → skin cancer risk (MT1)
7. **Persistent vomiting** → dehydration risk with Reta

---

## Next 30 Days (Tracking)

**Week 1:** Baseline. Expect nausea (MT1), appetite suppression (Reta), possible water retention (Tesa/HCG).

**Week 2:** Nausea should fade. Energy should rise (Semax kicking in). Skin darkening begins (MT1).

**Week 3:** First fat loss visible. Get bloodwork. Decide on Semax dose increase if needed.

**Week 4:** MT1 loading phase ends (May 18). Transition to maintenance (10u 2x weekly on Tue/Fri). Reassess overall results.

---

## Summary Table

| Compound | Purpose | Synergy | Main Risk | Monitor |
|----------|---------|---------|-----------|---------|
| Reta | Fat loss | Anchor | GI upset, pancreatitis | Nausea, stomach pain |
| Tesa | Muscle preserve | Balances Reta | Water retention | Joint pain, glucose |
| HCG | Hormone | Protects endocrine | Estrogen spike | Gyno, prolactin |
| Semax | Cognition | Mood during deficit | Sleep if dosed late | Energy, sleep |
| MT1 | Pigmentation | Aesthetics | Skin cancer risk | Nausea, moles |

---

_Updated May 4, 2026. Always bloodwork before adding anything._
