# Agent Task Template

**Use this as a wrapper for ALL subagent spawns.** It ensures context is loaded before work begins.

---

## REQUIRED CONTEXT READS (FIRST)

Before doing ANY work, read these files in this order:

1. `/home/ubuntu/wlp/agents/[YOUR_AGENT]/PROFILE.md` — Your personality, discipline, approach (CRITICAL)
2. `/home/ubuntu/wlp/data/agent-context.json` — Full context about Eric, WLP, agents, workflows
3. `/home/ubuntu/MEMORY.md` — Long-term memory and decisions

**Why:** You need to understand WHO you're working for, WHAT they care about, and WHAT the company mission is.

---

## CONTEXT FROM THOSE FILES

After reading:

- **Principal:** Eric Mills (ANIMAL), Mountain Time, prefers simplicity + autonomous work
- **Company:** Wicked Liquid Productions — AI music label + DJ automation SaaS
- **Your Team:** 8 agents with specific disciplines (know who to coordinate with)
- **Key Blockers:** Check agent-status.json for who's stuck or blocked
- **Recent History:** Check MEMORY.md for what's been done recently

---

## YOUR TASK

[TASK DETAILS HERE]

**Deliverable Format:** [e.g., markdown file, JSON config, Discord post via webhook]

**Expected Timeline:** [e.g., 5min, 30min, 2h]

**Who to Coordinate With:** [if multi-agent work]

**Questions/Blockers:** Escalate to Eric in #general (but only if truly stuck)

---

## EXECUTION CHECKLIST

- [ ] Read agent-context.json
- [ ] Read MEMORY.md
- [ ] Know your discipline and who you are (from agent-context.json)
- [ ] Check agent-status.json for current blockers
- [ ] Understand Eric's preferences (MDT timezone, direct communication, URLs on deploy)
- [ ] Do the work
- [ ] Verify quality (don't send half-baked results)
- [ ] Post to Discord webhook (if applicable)
- [ ] Report completion (mention blockers if any)

---

## NOTES

- **Timezone:** Always use MDT (Mountain Time), never UTC
- **Communication:** Eric prefers direct, no corporate fluff
- **Discord:** Post results via webhook URL from `/home/ubuntu/wlp/data/discord-webhooks.json`
- **MEMORY.md:** If something significant happens, note it for PriScylla to review
- **Dependencies:** Check who else is working on related tasks (agent-status.json)

---

**Template Version:** 1.0 | Updated 2026-04-22
