#!/usr/bin/env python3
"""
Discord Updater - Posts agent status & task updates to Discord channels
Integrates with OpenClaw message tool for Discord
"""

import json
import os
import subprocess
from datetime import datetime
from typing import Optional, Dict

TASKS_DB = os.path.expanduser("~/wlp/agents/tasks_db.json")
LOG_FILE = os.path.expanduser("~/wlp/logs/discord-updater.log")
DISCORD_CONFIG = os.path.expanduser("~/wlp/data/discord-webhooks.json")

os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


AGENT_CHANNELS = {
    "shelly": "1488075726761496667",  # #kade-rivers (A&R)
    "rockwell": "1488075727747158016",  # #madison-blair (Production)
    "homard": "1488075728905048135",  # #aria-vale (Finance/metrics)
    "langostino": "1488075731568295946",  # #research (Marketing)
    "barnaby": "1488075732771934308",  # #agent-output (Business Dev)
    "coral": "1488075733925494904",  # #srb-weekly (R&D)
    "clawdia": "1488075734709965011",  # #dj-automation (Operations)
    "sebastian": "1488075737175949322"  # #live-production (Legal)
}


def load_tasks_db() -> Dict:
    """Load tasks database"""
    if os.path.exists(TASKS_DB):
        with open(TASKS_DB, 'r') as f:
            return json.load(f)
    return {"tasks": [], "total": 0}


def post_to_discord(channel_id: str, message: str, embed_data: Optional[Dict] = None):
    """
    Post message to Discord channel via OpenClaw message tool
    In production, calls: message(action="send", channel="discord", target=channel_id, message=message)
    """
    
    log(f"📤 Posting to Discord channel {channel_id}: {message[:60]}...")
    
    # In production, OpenClaw's message tool is called:
    # message(
    #     action="send",
    #     channel="discord",
    #     target=channel_id,  # or channel name
    #     message=message
    # )
    
    # For demo, we'll save to a file
    discord_log = os.path.expanduser("~/wlp/logs/discord-posts.jsonl")
    post_record = {
        "timestamp": datetime.now().isoformat(),
        "channel_id": channel_id,
        "message": message,
        "embed": embed_data
    }
    
    with open(discord_log, 'a') as f:
        f.write(json.dumps(post_record) + "\n")
    
    return True


def post_task_assigned(task_id: str, agent_id: str, task_description: str):
    """Post to Discord when task is assigned to agent"""
    
    channel_id = AGENT_CHANNELS.get(agent_id)
    if not channel_id:
        return
    
    message = f"""🚀 **New Task Assigned**

**Task ID:** `{task_id}`
**Task:** {task_description}

⏳ Starting work now..."""
    
    post_to_discord(channel_id, message)
    log(f"   ✅ Posted task assignment for {agent_id}")


def post_task_in_progress(task_id: str, agent_id: str):
    """Post to Discord when agent starts working"""
    
    channel_id = AGENT_CHANNELS.get(agent_id)
    if not channel_id:
        return
    
    message = f"""⚙️ **Task In Progress**

**Task ID:** `{task_id}`
**Status:** Working on it...

🔄 Will update when complete"""
    
    post_to_discord(channel_id, message)
    log(f"   ✅ Posted in-progress update for {agent_id}")


def post_task_complete(task_id: str, agent_id: str, result_summary: str):
    """Post to Discord when task is complete"""
    
    channel_id = AGENT_CHANNELS.get(agent_id)
    if not channel_id:
        return
    
    message = f"""✅ **Task Complete**

**Task ID:** `{task_id}`
**Status:** Work finished

**Summary:**
{result_summary[:300]}...

📋 Sent to PriScylla for verification"""
    
    post_to_discord(channel_id, message)
    log(f"   ✅ Posted completion update for {agent_id}")


def post_task_verified(task_id: str, agent_id: str, verified: bool):
    """Post to Discord when PriScylla verifies task"""
    
    channel_id = AGENT_CHANNELS.get(agent_id)
    if not channel_id:
        return
    
    if verified:
        message = f"""✨ **Task Verified & Approved**

**Task ID:** `{task_id}`
**Status:** ✅ Ready for delivery

🎉 Work approved by PriScylla!"""
    else:
        message = f"""🔄 **Revision Requested**

**Task ID:** `{task_id}`
**Status:** Needs refinement

Please revise and resubmit."""
    
    post_to_discord(channel_id, message)
    log(f"   ✅ Posted verification update for {agent_id}")


def post_agent_status_summary():
    """Post daily agent status summary to #agent-output"""
    
    db = load_tasks_db()
    
    # Count by agent
    agent_counts = {}
    for task in db["tasks"]:
        agent = task["agent_id"]
        agent_counts[agent] = agent_counts.get(agent, 0) + 1
    
    status_lines = []
    for agent_id, count in agent_counts.items():
        status_lines.append(f"  **{agent_id}**: {count} tasks")
    
    message = f"""📊 **Daily Agent Status**

Active agents:
{chr(10).join(status_lines) if status_lines else "  No active tasks"}

Total: {db['total']} tasks processed today
Last update: <t:{int(datetime.now().timestamp())}:t>"""
    
    # Post to #agent-output
    post_to_discord(AGENT_CHANNELS["barnaby"], message)
    log(f"   ✅ Posted daily status summary")


def simulate_full_workflow():
    """Demo the full task workflow with Discord updates"""
    
    log("=" * 60)
    log("DISCORD INTEGRATION DEMO")
    log("=" * 60)
    
    # Simulate a task lifecycle
    task_id = "demo_001"
    agent_id = "shelly"
    
    print("\n1️⃣ Task Assigned to Shelly")
    post_task_assigned(task_id, agent_id, "Analyze streaming performance for Kade Rivers")
    
    print("\n2️⃣ Task In Progress")
    post_task_in_progress(task_id, agent_id)
    
    print("\n3️⃣ Task Complete")
    post_task_complete(task_id, agent_id, "Analysis complete. Kade has 1,200 monthly listeners with 15% growth. Recommend playlist pitching strategy.")
    
    print("\n4️⃣ Task Verified")
    post_task_verified(task_id, agent_id, verified=True)
    
    print("\n5️⃣ Status Summary")
    post_agent_status_summary()
    
    log("\n" + "=" * 60)
    log("✅ Discord integration demo complete")
    log("=" * 60)


if __name__ == "__main__":
    simulate_full_workflow()
    
    # Show what was logged
    print("\n📋 Discord posts logged to:")
    print(f"   {os.path.expanduser('~/wlp/logs/discord-posts.jsonl')}")
