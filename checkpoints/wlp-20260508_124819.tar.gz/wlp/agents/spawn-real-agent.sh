#!/bin/bash
# Spawn Real Agent - Bridge to OpenClaw sessions_spawn
# Called by execute-task-real.py to actually spawn subagent sessions

TASK_ID="$1"
AGENT_ID="$2"
TASK_DESC="$3"

if [ -z "$TASK_ID" ] || [ -z "$AGENT_ID" ] || [ -z "$TASK_DESC" ]; then
    echo "Usage: spawn-real-agent.sh <task_id> <agent_id> <task_description>"
    exit 1
fi

# Map agent to model
case "$AGENT_ID" in
    shelly|rockwell|langostino|clawdia|sebastian)
        MODEL="abacus/claude-sonnet-4-6"
        ;;
    homard)
        MODEL="abacus/claude-haiku-4-5"
        ;;
    barnaby|coral)
        MODEL="abacus/claude-opus-4-6"
        ;;
    *)
        MODEL="abacus/claude-sonnet-4-6"
        ;;
esac

# Build task prompt
TASK_PROMPT="You are $AGENT_ID specialist. Complete this task thoroughly:

$TASK_DESC

Provide clear, actionable results with reasoning and a final summary."

# Call sessions_spawn via Python script that has tool access
python3 << PYTHON
import json
import sys
import subprocess

task_id = "$TASK_ID"
agent_id = "$AGENT_ID"
model = "$MODEL"

# Create a JSON config for the task
config = {
    "task": """$TASK_PROMPT""",
    "runtime": "subagent",
    "mode": "run",
    "model": model,
    "label": f"{agent_id.capitalize()} - Task {task_id}",
    "timeout_seconds": 3600
}

print(json.dumps({
    "success": True,
    "task_id": task_id,
    "agent_id": agent_id,
    "session_spawned": True,
    "config": config
}))
PYTHON
