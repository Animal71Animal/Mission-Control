#!/usr/bin/env python3
"""
Spawn Subagent - Wrapper to call sessions_spawn() with task data
This script is called by execute-task-real.py and uses OpenClaw's sessions_spawn tool
"""

import json
import sys
import os
from datetime import datetime

LOG_FILE = os.path.expanduser("~/wlp/logs/spawn-subagent.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def spawn_subagent(task_prompt: str, agent_name: str, model: str, timeout: int = 3600):
    """
    Spawn a subagent session using OpenClaw's sessions_spawn tool
    
    In production, this would use the sessions_spawn tool like:
    
    sessions_spawn(
        task=task_prompt,
        runtime="subagent",
        mode="run",
        model=model,
        label=f"{agent_name} - Task Execution",
        timeout_seconds=timeout
    )
    
    For now, we log the config and return a session ID
    """
    
    log(f"Spawning subagent: {agent_name}")
    log(f"Model: {model}")
    log(f"Timeout: {timeout}s")
    log(f"Task preview: {task_prompt[:100]}...")
    
    # In production, the sessions_spawn call would go here
    # It would return a session object with a sessionId
    
    # For now, return a success indicator
    import uuid
    session_id = str(uuid.uuid4())[:16]
    
    log(f"Subagent spawned with session ID: {session_id}")
    
    return {
        "success": True,
        "session_id": session_id,
        "agent_name": agent_name,
        "model": model
    }


if __name__ == "__main__":
    # Read task config from stdin or file
    if len(sys.argv) > 1:
        config_file = sys.argv[1]
        with open(config_file, 'r') as f:
            config = json.load(f)
    else:
        config = json.loads(sys.stdin.read())
    
    result = spawn_subagent(
        task_prompt=config['task'],
        agent_name=config['agent_name'],
        model=config['model'],
        timeout=config.get('timeout', 3600)
    )
    
    print(json.dumps(result))
