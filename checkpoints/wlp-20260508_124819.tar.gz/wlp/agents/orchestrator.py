#!/usr/bin/env python3
"""
Master Orchestrator - Ties together all components
NOW WITH REAL AGENT SESSION SPAWNING
"""

import json
import os
import subprocess
import uuid
from datetime import datetime
from typing import Dict, Tuple

TASKS_DB = os.path.expanduser("~/wlp/agents/tasks_db.json")
LOG_FILE = os.path.expanduser("~/wlp/logs/orchestrator.log")

os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def route_task(task_description: str) -> Tuple[str, int]:
    """Route task to best agent based on keywords"""
    AGENT_KEYWORDS = {
        "shelly": ["artist", "release", "streaming", "playlist", "tiktok", "career", "dsp", "distrokid"],
        "rockwell": ["production", "mixing", "mastering", "audio", "sound", "arrangement"],
        "homard": ["revenue", "budget", "mrr", "roi", "profit", "metrics", "financial"],
        "langostino": ["marketing", "brand", "campaign", "messaging", "content", "social"],
        "barnaby": ["partnership", "deal", "licensing", "sync", "collaboration"],
        "coral": ["research", "innovation", "technology", "experiment", "poc", "prototype", "analyze", "analysis"],
        "clawdia": ["deployment", "infrastructure", "automation", "devops", "system"],
        "sebastian": ["legal", "compliance", "contract", "copyright", "rights"]
    }
    
    task_lower = task_description.lower()
    scores = {}
    
    for agent_id, keywords in AGENT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in task_lower)
        scores[agent_id] = score
    
    best_agent = max(scores, key=scores.get)
    confidence = scores[best_agent]
    
    return best_agent, confidence


def run_command(script: str, args: list) -> bool:
    """Run a helper script"""
    try:
        cmd = ["python3", script] + args
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return result.returncode == 0
    except Exception as e:
        log(f"❌ Error running {script}: {e}")
        return False


def load_tasks_db() -> Dict:
    """Load tasks database"""
    if os.path.exists(TASKS_DB):
        with open(TASKS_DB, 'r') as f:
            return json.load(f)
    return {"tasks": [], "total": 0}


def save_tasks_db(db: Dict):
    """Save tasks database"""
    with open(TASKS_DB, 'w') as f:
        json.dump(db, f, indent=2)


def handle_eric_task(message_text: str) -> str:
    """
    Master handler for Eric's task messages
    NOW SPAWNS REAL AGENT SESSIONS
    """
    
    log(f"\n{'='*60}")
    log(f"🎯 NEW TASK FROM ERIC")
    log(f"{'='*60}")
    log(f"Message: {message_text[:80]}...")
    
    # Step 1: Route task to agent
    log(f"\n📍 Step 1: Route task to agent")
    agent_id, confidence = route_task(message_text)
    log(f"   ✓ Routed to {agent_id} (confidence: {confidence})")
    
    # Step 2: Create task record
    log(f"\n📋 Step 2: Create task record")
    task_id = str(uuid.uuid4())[:8]
    
    db = load_tasks_db()
    task = {
        "id": task_id,
        "description": message_text,
        "agent_id": agent_id,
        "confidence": confidence,
        "created_at": datetime.now().isoformat(),
        "status": "assigned",
        "session_id": None,
        "result": None
    }
    db["tasks"].append(task)
    db["total"] += 1
    save_tasks_db(db)
    log(f"   ✓ Task created: {task_id}")
    
    # Step 3: Spawn REAL agent session
    log(f"\n🚀 Step 3: Spawn REAL agent session")
    success = run_command(
        "/home/ubuntu/wlp/agents/execute-task-spawn.py",
        [task_id, message_text, agent_id]
    )
    if not success:
        log(f"   ❌ Failed to spawn agent")
        return "❌ Failed to spawn agent session"
    log(f"   ✓ Real agent session spawned")
    
    # Step 4: Sync to MC
    log(f"\n📊 Step 4: Sync to Mission Control")
    run_command(
        "/home/ubuntu/wlp/agents/mc-sync.py",
        []
    )
    log(f"   ✓ MC dashboard updated")
    
    # Step 5: Return response for Eric
    response = f"""✅ Task Assigned

📋 Task ID: {task_id}
🤖 Agent: {agent_id}

⏳ Agent is working on it now. I'll verify the result and report back when complete."""
    
    log(f"\n💬 Response: {response}")
    log(f"{'='*60}\n")
    
    return response


def demo():
    """Demo the full orchestration"""
    
    print("\n" + "="*60)
    print("MASTER ORCHESTRATOR DEMO (WITH REAL SESSION SPAWNING)")
    print("="*60)
    
    tasks = [
        "Analyze Kade Rivers' streaming growth and recommend next steps",
        "Analyze Tesla charging patterns from /home/ubuntu/wlp/data/tesla-charging.json"
    ]
    
    for task in tasks:
        response = handle_eric_task(task)
        print(f"\n{response}\n")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        # Process a single task
        task = " ".join(sys.argv[1:])
        response = handle_eric_task(task)
        print(f"\n{response}")
    else:
        # Run demo
        demo()
