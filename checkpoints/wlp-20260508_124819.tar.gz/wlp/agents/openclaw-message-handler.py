#!/usr/bin/env python3
"""
OpenClaw Message Handler
Hook for processing incoming Telegram messages from Eric
"""

import json
import os
import subprocess
from datetime import datetime
from typing import Dict, Optional

LOG_FILE = os.path.expanduser("~/wlp/logs/openclaw-handler.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def handle_message(message_data: Dict) -> str:
    """Process incoming message from OpenClaw"""
    message_text = message_data.get("message", "")
    sender = message_data.get("sender", "Unknown")
    
    if not message_text:
        return "No message content"
    
    log(f"📨 Message from {sender}: {message_text[:80]}...")
    
    try:
        cmd = [
            "python3",
            "/home/ubuntu/wlp/agents/orchestrator.py",
            message_text
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            output_lines = result.stdout.strip().split('\n')
            response = [line for line in output_lines if line and not line.startswith('[')][-1]
            log(f"✅ Response: {response[:80]}...")
            return response
        else:
            error = result.stderr.strip()
            log(f"❌ Error: {error}")
            return f"❌ Error processing task: {error[:100]}"
    
    except Exception as e:
        log(f"❌ Exception: {e}")
        return f"❌ Error: {str(e)}"


def process_incoming_message(inbound_data: Dict) -> Optional[str]:
    """
    Main entry point for OpenClaw message handler
    Called when message arrives from Eric on Telegram
    """
    
    sender_id = inbound_data.get("sender_id", "")
    message = inbound_data.get("message", "").strip()
    
    # Only process if from Eric
    if sender_id != "8180067794":
        return None
    
    # Skip empty messages
    if not message:
        return None
    
    # Skip status messages
    if any(x in message.lower() for x in ["heartbeat", "status", "ping", "test"]):
        return None
    
    # Process the task
    response = handle_message(inbound_data)
    
    return response


if __name__ == "__main__":
    # Test mode
    test_data = {
        "message": "Analyze Kade Rivers' streaming performance",
        "sender": "Eric Mills",
        "sender_id": "8180067794",
        "message_id": "test_001",
        "channel": "telegram",
        "timestamp": datetime.now().isoformat()
    }
    
    print("Testing message handler...")
    response = process_incoming_message(test_data)
    
    if response:
        print(f"\n✅ Response:\n{response}")
    else:
        print("\n⏭️  Message filtered (not from Eric or status check)")
