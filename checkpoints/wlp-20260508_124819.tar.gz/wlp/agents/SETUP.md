# Agent Orchestration System — Quick Setup

## Status: ✅ READY TO USE

The system is **fully built and tested**. Now you just need to hook it to Telegram.

## How It Works

```
You send task → OpenClaw handler → Orchestrator → Route to agent → Spawn agent → Work → Verify → Report
```

## Quick Start

### 1. Test the System (Already Working)
```bash
python3 /home/ubuntu/wlp/agents/orchestrator.py "Analyze Kade Rivers' streaming"
```

Output:
```
✅ Task Assigned

📋 Task ID: abc12345
🤖 Agent: shelly

⏳ Agent is working on it now. I'll verify the result and report back when complete.
```

### 2. Hook to Telegram (3 Steps)

The handler is ready at:
```
/home/ubuntu/wlp/agents/openclaw-message-handler.py
```

**Option A: Use this Python code in OpenClaw**

When Eric sends a message, call:
```python
from pathlib import Path
import sys

sys.path.insert(0, '/home/ubuntu/wlp/agents')
from openclaw_message_handler import process_incoming_message

# In your message handler:
response = process_incoming_message(inbound_message_data)

# Send back to Eric via message tool:
if response:
    message(action="send", channel="telegram", target="Eric Mills", message=response)
```

**Option B: Direct command line**

In OpenClaw's automation, when message received:
```bash
python3 /home/ubuntu/wlp/agents/openclaw-message-handler.py
```

### 3. Add MC Dashboard (Copy-Paste)

Add this file to Mission Control:
```
~/wlp/projects/mission-control/app/agents-status/page.tsx
```

The code is in: `/tmp/agents-status.tsx` (or regenerate via `mc-sync.py`)

This page shows:
- 🟢 🟡 🔴 Agent status lights
- Task count per agent
- Auto-refreshes every 10s

### 4. Enable Cron Sync (Optional)

Add to crontab to keep MC dashboard updated:
```bash
*/5 * * * * python3 /home/ubuntu/wlp/agents/mc-sync.py
```

## System Components

| File | Purpose | Status |
|------|---------|--------|
| `orchestrator.py` | Master orchestrator | ✅ Ready |
| `openclaw-message-handler.py` | Telegram hook | ✅ Ready |
| `execute-task.py` | Agent spawner | ✅ Ready |
| `verify-results.py` | Quality gate | ✅ Ready |
| `mc-sync.py` | MC updates | ✅ Ready |
| `discord-updater.py` | Discord posts | ✅ Ready |

## What Happens When You Send a Task

### Example: "Mix and master the Madison Blair vocal"

1. **Message received** → `openclaw-message-handler.py`
2. **Routed** → `orchestrator.py` → identifies "Rockwell" (production)
3. **Task created** → ID: `abc12345`
4. **Agent spawned** → Claude Sonnet 4, full context
5. **Agent works** → Completes mixing/mastering analysis
6. **Result returned** → sent to `verify-results.py`
7. **Quality checked** → 85% score, approved ✅
8. **Report sent** → back to you via Telegram
9. **Discord updated** → #madison-blair channel gets post
10. **MC updated** → Dashboard shows Rockwell's task count

**Total time:** ~2-5 minutes (depending on agent workload)

## Agent Routing

Tasks automatically route to the right agent:

| Keywords | Agent | Model |
|----------|-------|-------|
| artist, release, streaming, playlist, dsp | Shelly | Sonnet 4 |
| production, mixing, mastering, audio | Rockwell | Sonnet 4 |
| revenue, budget, metrics, financial | Homard | Haiku 4 |
| marketing, brand, campaign, social | Langostino | Sonnet 4 |
| partnership, deal, licensing | Barnaby | Opus 4 |
| research, innovation, technology | Coral | Opus 4 |
| deployment, infrastructure, automation | Clawdia | Sonnet 4 |
| legal, compliance, contract | Sebastian | Sonnet 4 |

## Live Monitoring

### Discord Channels
Each agent has a channel that gets live updates:
- `#kade-rivers` (Shelly - A&R)
- `#madison-blair` (Rockwell - Production)
- `#aria-vale` (Homard - Finance)
- `#research` (Langostino - Marketing)
- `#agent-output` (Barnaby - Business Dev)
- `#srb-weekly` (Coral - R&D)
- `#dj-automation` (Clawdia - Ops)
- `#live-production` (Sebastian - Legal)

### Mission Control Dashboard
Shows real-time:
- Agent status (🟢 idle, 🟡 working, 🔴 busy)
- Task counts
- Summary stats

## Testing

### Test routing
```bash
python3 -c "from orchestrator import route_task; print(route_task('Mix the new track'))"
# Output: ('rockwell', 2)
```

### Test full flow
```bash
python3 /home/ubuntu/wlp/agents/orchestrator.py "Your task here"
```

### Check status
```bash
cat ~/wlp/agents/tasks_db.json | python3 -m json.tool
```

## Logs

Monitor the system:
```bash
# Main orchestrator
tail -f ~/wlp/logs/orchestrator.log

# Message handler
tail -f ~/wlp/logs/message-handler.log
tail -f ~/wlp/logs/openclaw-handler.log

# All tasks
cat ~/wlp/agents/tasks_db.json | jq '.'
```

## Production Checklist

- [x] Orchestrator working
- [x] Agent routing working
- [x] Task spawning working
- [x] Verification gate working
- [x] MC sync working
- [x] Discord integration ready
- [x] Telegram hook ready
- [ ] Hook handler to OpenClaw message system
- [ ] Add MC dashboard page
- [ ] Enable cron sync (optional)

## Next Steps

1. **Integrate with OpenClaw** - Call `process_incoming_message()` when Eric sends message
2. **Send a real task** - System will route it, spawn agent, verify, report
3. **Monitor** - Watch Discord + MC dashboard for live updates
4. **Iterate** - System learns from results, improves routing over time

## Support

All files are self-contained and logged. Check logs when debugging:
```bash
tail -f ~/wlp/logs/orchestrator.log
tail -f ~/wlp/logs/message-handler.log
```

Tasks are stored in JSON for easy inspection:
```bash
cat ~/wlp/agents/tasks_db.json | jq '.'
```

---

**You're ready to go. Send a task and watch it flow through the system.**
