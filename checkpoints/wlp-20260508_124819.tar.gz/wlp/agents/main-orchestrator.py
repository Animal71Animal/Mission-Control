#!/usr/bin/env python3
"""
Main Orchestrator — PriScylla's Command Center
Listens for Eric's tasks, routes to agents, spawns sessions, collects results
"""

import json
import os
import sys
import time
import uuid
from datetime import datetime
from typing import Optional, Dict, Tuple

# Add to path for imports
sys.path.insert(0, '/home/ubuntu/wlp/agents')

# Import agent expertise (inline since module loading has issues)
from agent_orchestrator import AGENT_EXPERTISE, parse_task, get_agent_info

# ============ CONFIG ============
TASKS_DB = os.path.expanduser("~/wlp/agents/tasks_db.json")
RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
LOG_FILE = os.path.expanduser("~/wlp/logs/main-orchestrator.log")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
# ================================


def log(message: str):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def load_tasks_db() -> Dict:
    """Load tasks database"""
    if os.path.exists(TASKS_DB):
        with open(TASKS_DB, 'r') as f:
            return json.load(f)
    return {"tasks": [], "total": 0}


def save_tasks_db(db: Dict):
    """Save tasks database"""
    with open(TASKS_DB, 'w') as f:
        json.dump(db, f, indent=2)


def create_task(task_description: str, eric_message_id: Optional[str] = None) -> Dict:
    """
    Create a new task
    Returns task object with routing info
    """
    # Route the task
    agent_id, confidence = parse_task(task_description)
    agent_info = get_agent_info(agent_id)
    
    task_id = str(uuid.uuid4())[:8]
    
    task = {
        "id": task_id,
        "description": task_description,
        "agent_id": agent_id,
        "agent_name": agent_info['name'],
        "agent_discipline": agent_info['discipline'],
        "routing_confidence": confidence,
        "eric_message_id": eric_message_id,
        "created_at": datetime.now().isoformat(),
        "status": "assigned",  # assigned → spawned → completed → verified
        "session_id": None,
        "result": None,
        "verified": False
    }
    
    # Save to DB
    db = load_tasks_db()
    db["tasks"].append(task)
    db["total"] += 1
    save_tasks_db(db)
    
    log(f"✅ Task created: {task_id}")
    log(f"   Description: {task_description[:80]}...")
    log(f"   Assigned to: {agent_info['name']} ({agent_info['discipline']})")
    log(f"   Confidence: {confidence}/10")
    
    return task


def spawn_agent_for_task(task: Dict) -> Optional[Dict]:
    """
    Spawn a subagent session for the task
    In real implementation, this calls sessions_spawn from OpenClaw
    """
    agent_info = get_agent_info(task['agent_id'])
    
    # Build the task prompt
    task_prompt = f"""You are {agent_info['name']}, specializing in: {agent_info['discipline']}

Your core strengths:
{chr(10).join(f"• {cap}" for cap in agent_info['capabilities'])}

You have been assigned the following task:

---
{task['description']}
---

Please complete this task thoroughly:
1. Break down what needs to be done
2. Execute the work step-by-step
3. Provide clear, actionable results
4. Show your reasoning and any assumptions
5. Give a final summary of what you've delivered

Be detailed, thorough, and professional. This work will be reviewed by PriScylla before being sent to the client."""

    session_data = {
        "task_id": task['id'],
        "agent_name": task['agent_name'],
        "agent_id": task['agent_id'],
        "prompt": task_prompt,
        "spawned_at": datetime.now().isoformat(),
        "status": "pending"
    }
    
    # Save session data
    session_file = os.path.join(RESULTS_DIR, f"{task['id']}_session.json")
    with open(session_file, 'w') as f:
        json.dump(session_data, f, indent=2)
    
    log(f"🚀 Spawning subagent session for {task['agent_name']} (task: {task['id']})")
    log(f"   Session file: {session_file}")
    
    # TODO: In real implementation, call sessions_spawn here
    # For now, just return the config needed
    return session_data


def report_to_eric(task: Dict, status: str = "in_progress", details: str = "") -> str:
    """
    Format and prepare status report for Eric
    In real implementation, send via message tool to Telegram
    """
    agent_info = get_agent_info(task['agent_id'])
    
    if status == "assigned":
        report = f"""✅ Task Assigned

Task ID: {task['id']}
Agent: {agent_info['name']} ({agent_info['discipline']})
Task: {task['description'][:100]}...

Status: Now working on it. Will report back when complete."""
    
    elif status == "in_progress":
        report = f"""🔄 Task In Progress

Task ID: {task['id']}
Agent: {agent_info['name']}

{details}"""
    
    elif status == "completed":
        report = f"""✅ Task Complete

Task ID: {task['id']}
Agent: {agent_info['name']}

Result:
{details}"""
    
    else:
        report = f"Task {task['id']}: {status}"
    
    return report


def main():
    """
    Main orchestration loop
    In production, this would:
    1. Listen to Telegram for Eric's tasks
    2. Create task
    3. Spawn subagent
    4. Wait for result
    5. Report back
    """
    
    log("=" * 60)
    log("PriScylla Main Orchestrator — Starting")
    log("=" * 60)
    
    # Example: process test task
    if len(sys.argv) > 1:
        task_description = " ".join(sys.argv[1:])
    else:
        task_description = "Analyze the current streaming performance of our three AI artists (Kade Rivers, Madison Blair, Aria Vale) and provide recommendations for increasing their monthly listener count."
    
    # Create task
    task = create_task(task_description)
    
    # Spawn agent
    log("\n" + "=" * 60)
    log("SPAWNING SUBAGENT SESSION")
    log("=" * 60)
    session = spawn_agent_for_task(task)
    
    # Report to Eric
    log("\n" + "=" * 60)
    log("REPORTING TO ERIC")
    log("=" * 60)
    report = report_to_eric(task, status="assigned")
    print(f"\n📨 Message to Eric:\n{report}")
    
    print(f"\n\n🔗 Next steps:")
    print(f"   1. In production: Call sessions_spawn with the task prompt")
    print(f"   2. Wait for subagent to complete")
    print(f"   3. Collect result from subagent")
    print(f"   4. PriScylla (me) reviews and verifies")
    print(f"   5. Report final status to Eric")
    
    log("\n✅ Orchestration flow demonstrated successfully")


if __name__ == "__main__":
    main()
