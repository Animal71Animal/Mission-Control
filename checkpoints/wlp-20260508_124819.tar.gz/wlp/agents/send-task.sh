#!/bin/bash
# Send a task to the agent system
# Usage: ./send-task.sh "Your task here"

QUEUE_FILE="$HOME/wlp/agents/message_queue.json"
TEMP_FILE="/tmp/message_queue_$$.json"

if [ -z "$1" ]; then
    echo "Usage: send-task.sh \"Your task description\""
    echo "Example: send-task.sh \"Mix and master the new track\""
    exit 1
fi

TASK="$1"
MESSAGE_ID="$(date +%s)"
TIMESTAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Create message JSON
MESSAGE_JSON=$(cat <<EOF
{
  "message_id": "$MESSAGE_ID",
  "message": "$TASK",
  "sender": "Eric Mills",
  "sender_id": "8180067794",
  "timestamp": "$TIMESTAMP"
}
EOF
)

# Load existing queue or create new one
if [ -f "$QUEUE_FILE" ]; then
    # Add to existing queue
    python3 << PYTHON
import json
import sys

with open("$QUEUE_FILE", 'r') as f:
    data = json.load(f)

message = json.loads('''$MESSAGE_JSON''')
data['messages'].append(message)

with open("$QUEUE_FILE", 'w') as f:
    json.dump(data, f, indent=2)

print(f"✅ Task queued (ID: {message['message_id']})")
print(f"   Task: {message['message'][:60]}...")
print(f"   Checking for agent in 1 minute...")
PYTHON
else
    # Create new queue
    python3 << PYTHON
import json

message = json.loads('''$MESSAGE_JSON''')
data = {
    "messages": [message]
}

with open("$QUEUE_FILE", 'w') as f:
    json.dump(data, f, indent=2)

print(f"✅ Task queued (ID: {message['message_id']})")
print(f"   Task: {message['message'][:60]}...")
print(f"   Checking for agent in 1 minute...")
PYTHON
fi
