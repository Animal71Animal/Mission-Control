#!/usr/bin/env python3
"""
Mission Control Sync - Keep MC updated with agent status & task counts
Writes to MC-readable JSON files for dashboard display
"""

import json
import os
from datetime import datetime
from typing import Dict, List

TASKS_DB = os.path.expanduser("~/wlp/agents/tasks_db.json")
MC_DATA_DIR = os.path.expanduser("~/wlp/projects/mission-control/public/data")
MC_AGENTS_FILE = os.path.join(MC_DATA_DIR, "agents-status.json")

os.makedirs(MC_DATA_DIR, exist_ok=True)


AGENT_PROFILES = {
    "shelly": {"name": "Shelly", "discipline": "A&R", "color": "#00f5d4"},
    "rockwell": {"name": "Rockwell", "discipline": "Production", "color": "#f15bb5"},
    "homard": {"name": "Homard", "discipline": "Finance", "color": "#00bbf9"},
    "langostino": {"name": "Langostino", "discipline": "Marketing", "color": "#9b5de5"},
    "barnaby": {"name": "Barnaby", "discipline": "Business Dev", "color": "#f15b5b"},
    "coral": {"name": "Coral", "discipline": "R&D", "color": "#5bf166"},
    "clawdia": {"name": "Clawdia", "discipline": "Operations", "color": "#fee440"},
    "sebastian": {"name": "Sebastian", "discipline": "Legal", "color": "#f19b5b"},
}


def get_agent_status(agent_id: str) -> str:
    """
    Determine agent status based on task count
    🟢 Idle (0 tasks)
    🟡 Working (1-2 tasks)
    🔴 Busy (3+ tasks)
    """
    db = load_tasks_db()
    
    active_tasks = [t for t in db["tasks"] if t["agent_id"] == agent_id and t["status"] in ["assigned", "spawned", "in_progress"]]
    
    if len(active_tasks) == 0:
        return "🟢"  # Idle
    elif len(active_tasks) <= 2:
        return "🟡"  # Working
    else:
        return "🔴"  # Busy


def load_tasks_db() -> Dict:
    """Load tasks database"""
    if os.path.exists(TASKS_DB):
        with open(TASKS_DB, 'r') as f:
            return json.load(f)
    return {"tasks": [], "total": 0}


def get_agent_task_count(agent_id: str) -> int:
    """Count active tasks for agent"""
    db = load_tasks_db()
    return len([t for t in db["tasks"] if t["agent_id"] == agent_id and t["status"] in ["assigned", "spawned", "in_progress"]])


def sync_agents_to_mc() -> Dict:
    """
    Sync agent status to Mission Control format
    Returns data ready for MC dashboard
    """
    
    agents_data = {
        "timestamp": datetime.now().isoformat(),
        "agents": [],
        "summary": {
            "total_agents": len(AGENT_PROFILES),
            "active_count": 0,
            "working_count": 0,
            "busy_count": 0,
            "total_tasks": 0
        }
    }
    
    for agent_id, profile in AGENT_PROFILES.items():
        status = get_agent_status(agent_id)
        task_count = get_agent_task_count(agent_id)
        
        agent_data = {
            "id": agent_id,
            "name": profile["name"],
            "discipline": profile["discipline"],
            "color": profile["color"],
            "status": status,
            "status_text": {
                "🟢": "Idle",
                "🟡": "Working",
                "🔴": "Busy"
            }[status],
            "active_tasks": task_count
        }
        
        agents_data["agents"].append(agent_data)
        
        # Update summary
        agents_data["summary"]["total_tasks"] += task_count
        if status == "🟢":
            agents_data["summary"]["active_count"] += 1
        elif status == "🟡":
            agents_data["summary"]["working_count"] += 1
        else:
            agents_data["summary"]["busy_count"] += 1
    
    return agents_data


def write_mc_file():
    """Write agent status to MC data file"""
    data = sync_agents_to_mc()
    
    with open(MC_AGENTS_FILE, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"✅ Synced to MC: {MC_AGENTS_FILE}")
    
    # Print summary
    print(f"\n📊 Agent Status Summary:")
    print(f"   🟢 Idle: {data['summary']['active_count']}")
    print(f"   🟡 Working: {data['summary']['working_count']}")
    print(f"   🔴 Busy: {data['summary']['busy_count']}")
    print(f"   📋 Total tasks: {data['summary']['total_tasks']}")
    
    return data


def create_mc_dashboard_component() -> str:
    """
    Generate React component code for MC dashboard
    Shows agent status grid with red/yellow/green lights
    """
    
    component = '''// app/agents-status/page.tsx
"use client";

import { useEffect, useState } from "react";

interface Agent {
  id: string;
  name: string;
  discipline: string;
  color: string;
  status: string;
  status_text: string;
  active_tasks: number;
}

interface StatusData {
  timestamp: string;
  agents: Agent[];
  summary: {
    total_agents: number;
    active_count: number;
    working_count: number;
    busy_count: number;
    total_tasks: number;
  };
}

export default function AgentsStatus() {
  const [data, setData] = useState<StatusData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch("/data/agents-status.json");
        const json = await res.json();
        setData(json);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 10000); // Refresh every 10s
    return () => clearInterval(interval);
  }, []);

  if (loading) return <div>Loading...</div>;
  if (!data) return <div>No data</div>;

  return (
    <div style={{ maxWidth: "900px", margin: "0 auto" }}>
      <h1>⚡ Agent Status Dashboard</h1>
      
      {/* Summary Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
        <Card title="Total Agents" value={data.summary.total_agents} color="#fff" />
        <Card title="🟢 Idle" value={data.summary.active_count} color="#5bf166" />
        <Card title="🟡 Working" value={data.summary.working_count} color="#fee440" />
        <Card title="🔴 Busy" value={data.summary.busy_count} color="#f15b5b" />
      </div>

      {/* Tasks Summary */}
      <Card title="Active Tasks" value={data.summary.total_tasks} color="var(--accent)" />

      {/* Agent Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginTop: 24 }}>
        {data.agents.map(agent => (
          <div
            key={agent.id}
            style={{
              background: "var(--card)",
              border: `2px solid ${agent.color}`,
              borderRadius: 10,
              padding: 16,
              textAlign: "center"
            }}
          >
            <div style={{ fontSize: "2rem", marginBottom: 8 }}>{agent.status}</div>
            <div style={{ fontSize: "0.9rem", fontWeight: 600, marginBottom: 4 }}>{agent.name}</div>
            <div style={{ fontSize: "0.75rem", color: "var(--muted)", marginBottom: 8 }}>{agent.discipline}</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: agent.color }}>
              {agent.active_tasks}
            </div>
            <div style={{ fontSize: "0.7rem", color: "var(--muted)" }}>
              {agent.active_tasks === 1 ? "task" : "tasks"}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Card({ title, value, color }: { title: string; value: number | string; color: string }) {
  return (
    <div
      style={{
        background: "var(--card)",
        border: `1px solid ${color}`,
        borderRadius: 10,
        padding: 16,
        textAlign: "center"
      }}
    >
      <div style={{ fontSize: "0.85rem", color: "var(--muted)", marginBottom: 8 }}>{title}</div>
      <div style={{ fontSize: "2rem", fontWeight: 700, color }}>{value}</div>
    </div>
  );
}'''
    
    return component


if __name__ == "__main__":
    # Sync and display
    data = write_mc_file()
    
    # Show component code
    print("\n" + "=" * 60)
    print("MC Dashboard Component (ready to add to MC)")
    print("=" * 60)
    print("\nPath: app/agents-status/page.tsx")
    print("\nThe page will:")
    print("  ✅ Show all 8 agents with status lights")
    print("  ✅ Display active task count per agent")
    print("  ✅ Show summary (idle/working/busy counts)")
    print("  ✅ Auto-refresh every 10 seconds")
