#!/usr/bin/env python3
"""
Queue Monitor for Sub-Agent Spawning
Monitors spawn_queue.json and executes pending spawns
"""

import json
import os
import time
from datetime import datetime

QUEUE_FILE = os.path.expanduser("~/wlp/agents/spawn_queue.json")
RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
LOG_FILE = os.path.expanduser("~/wlp/logs/queue-monitor.log")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def load_queue():
    """Load the spawn queue"""
    if not os.path.exists(QUEUE_FILE):
        return []
    try:
        with open(QUEUE_FILE, 'r') as f:
            return json.load(f)
    except:
        return []


def save_queue(queue):
    """Save the spawn queue"""
    with open(QUEUE_FILE, 'w') as f:
        json.dump(queue, f, indent=2)


def process_spawn_request(request):
    """
    Process a spawn request.
    In production, this would call OpenClaw's sessions_spawn tool.
    For now, it creates a task file that OpenClaw can pick up.
    """
    agent_name = request['agent_name']
    model = request['model']
    task = request['task']
    
    log(f"Processing spawn request for {agent_name}")
    log(f"Model: {model}")
    
    # Create a task file for OpenClaw to process
    task_id = f"{agent_name.lower()}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    task_file = os.path.join(RESULTS_DIR, f"{task_id}.json")
    
    task_data = {
        "id": task_id,
        "agent_name": agent_name,
        "model": model,
        "task": task,
        "status": "pending_openclaw",
        "created_at": request['created_at'],
        "processed_at": datetime.now().isoformat()
    }
    
    with open(task_file, 'w') as f:
        json.dump(task_data, f, indent=2)
    
    log(f"Task file created: {task_file}")
    log(f"Status: pending_openclaw - waiting for OpenClaw to process")
    
    return task_id


def run_monitor():
    """Main monitor loop"""
    log("Queue monitor started")
    log(f"Watching: {QUEUE_FILE}")
    
    while True:
        try:
            queue = load_queue()
            
            # Find pending requests
            pending = [r for r in queue if r.get('status') == 'pending']
            
            if pending:
                log(f"Found {len(pending)} pending spawn requests")
                
                for request in pending:
                    try:
                        task_id = process_spawn_request(request)
                        request['status'] = 'processed'
                        request['task_id'] = task_id
                    except Exception as e:
                        log(f"Error processing request: {e}")
                        request['status'] = 'error'
                        request['error'] = str(e)
                
                save_queue(queue)
            
            # Sleep before next check
            time.sleep(5)
            
        except KeyboardInterrupt:
            log("Monitor stopped by user")
            break
        except Exception as e:
            log(f"Monitor error: {e}")
            time.sleep(10)


if __name__ == "__main__":
    run_monitor()
