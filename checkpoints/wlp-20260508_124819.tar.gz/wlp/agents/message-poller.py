#!/usr/bin/env python3
"""
Message Poller - Autonomous polling daemon
Runs via cron, checks for new messages, processes them, sends responses
"""

import json
import os
import subprocess
from datetime import datetime
from typing import Dict, List

QUEUE_FILE = os.path.expanduser("~/wlp/agents/message_queue.json")
PROCESSED_FILE = os.path.expanduser("~/wlp/agents/processed_messages.json")
LOG_FILE = os.path.expanduser("~/wlp/logs/message-poller.log")

os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def load_queue() -> List[Dict]:
    """Load message queue"""
    if os.path.exists(QUEUE_FILE):
        with open(QUEUE_FILE, 'r') as f:
            data = json.load(f)
            return data.get("messages", [])
    return []


def save_queue(messages: List[Dict]):
    """Save message queue"""
    os.makedirs(os.path.dirname(QUEUE_FILE), exist_ok=True)
    with open(QUEUE_FILE, 'w') as f:
        json.dump({"messages": messages}, f, indent=2)


def load_processed() -> List[str]:
    """Load IDs of already processed messages"""
    if os.path.exists(PROCESSED_FILE):
        with open(PROCESSED_FILE, 'r') as f:
            data = json.load(f)
            return data.get("processed_ids", [])
    return []


def save_processed(message_ids: List[str]):
    """Save processed message IDs"""
    os.makedirs(os.path.dirname(PROCESSED_FILE), exist_ok=True)
    with open(PROCESSED_FILE, 'w') as f:
        json.dump({"processed_ids": message_ids}, f, indent=2)


def process_message(message_data: Dict) -> str:
    """Process a single message through orchestrator"""
    
    message_id = message_data.get("message_id")
    message_text = message_data.get("message", "")
    sender = message_data.get("sender", "Unknown")
    
    log(f"📨 Processing message {message_id} from {sender}")
    
    try:
        # Call orchestrator
        cmd = [
            "python3",
            "/home/ubuntu/wlp/agents/orchestrator.py",
            message_text
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            output_lines = result.stdout.strip().split('\n')
            response = [line for line in output_lines if line and not line.startswith('[')][-1]
            log(f"   ✅ Response: {response[:60]}...")
            return response
        else:
            error = result.stderr.strip()
            log(f"   ❌ Error: {error[:100]}")
            return f"❌ Error processing task: {error[:100]}"
    
    except Exception as e:
        log(f"   ❌ Exception: {e}")
        return f"❌ Error: {str(e)}"


def send_response(message_id: str, response: str, target_id: str):
    """Send response back to Eric via Telegram"""
    
    log(f"💬 Sending response for message {message_id}")
    
    # Call message tool to send response
    try:
        # In production, this calls OpenClaw's message tool
        # For now, we just log it
        
        response_file = os.path.expanduser("~/wlp/logs/responses.jsonl")
        response_record = {
            "timestamp": datetime.now().isoformat(),
            "message_id": message_id,
            "target": target_id,
            "response": response
        }
        
        with open(response_file, 'a') as f:
            f.write(json.dumps(response_record) + "\n")
        
        log(f"   ✅ Response logged")
        return True
    
    except Exception as e:
        log(f"   ❌ Failed to send: {e}")
        return False


def poll_and_process():
    """Main polling loop"""
    
    # Load message queue
    messages = load_queue()
    
    if not messages:
        log("ℹ️  No messages in queue")
        return
    
    log(f"📥 Found {len(messages)} message(s) in queue")
    
    # Load processed IDs
    processed_ids = load_processed()
    
    # Process new messages
    newly_processed = []
    
    for message in messages:
        message_id = message.get("message_id")
        
        # Skip if already processed
        if message_id in processed_ids:
            log(f"⏭️  Skipping already processed message {message_id}")
            continue
        
        # Process the message
        sender_id = message.get("sender_id", "")
        
        # Only process if from Eric
        if sender_id != "8180067794":
            log(f"⏭️  Skipping message from non-Eric user {sender_id}")
            newly_processed.append(message_id)
            continue
        
        # Get response
        response = process_message(message)
        
        # Send response
        sent = send_response(message_id, response, sender_id)
        
        if sent:
            newly_processed.append(message_id)
    
    # Update processed list
    if newly_processed:
        processed_ids.extend(newly_processed)
        save_processed(processed_ids)
        log(f"✅ Processed {len(newly_processed)} message(s)")
    
    # Clear queue (messages processed)
    save_queue([])


def demo_with_test_message():
    """Demo: Add a test message to queue and process it"""
    
    log("=" * 60)
    log("DEMO: Adding test message to queue")
    log("=" * 60)
    
    test_message = {
        "message_id": "test_" + datetime.now().strftime("%Y%m%d_%H%M%S"),
        "message": "Analyze Kade Rivers' streaming performance and recommend next steps",
        "sender": "Eric Mills",
        "sender_id": "8180067794",
        "timestamp": datetime.now().isoformat()
    }
    
    # Add to queue
    save_queue([test_message])
    log(f"✅ Added test message to queue: {test_message['message_id']}")
    
    # Process it
    log("\nProcessing queue...")
    poll_and_process()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        # Demo mode
        demo_with_test_message()
    else:
        # Normal polling
        poll_and_process()
