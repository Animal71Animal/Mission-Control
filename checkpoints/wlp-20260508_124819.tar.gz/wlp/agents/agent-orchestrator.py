#!/usr/bin/env python3
"""
Agent Orchestrator — PriScylla's Task Router & Verification System
Routes tasks to appropriate agents based on expertise, spawns subagent sessions,
collects results, verifies quality, and reports to Eric.
"""

import json
import os
from datetime import datetime
from typing import Optional, Dict, List, Tuple

# ============ AGENT EXPERTISE MAPPING ============
AGENT_EXPERTISE = {
    "shelly": {
        "name": "Shelly",
        "color": "#00f5d4",
        "model": "Claude Sonnet 4",
        "discipline": "A&R + Artist Management",
        "keywords": [
            "artist", "release strategy", "streaming", "playlist", "tiktok",
            "promotional", "career trajectory", "dsp", "music strategy",
            "virality", "distrokid", "metadata", "ep release", "single",
            "album planning", "chart strategy"
        ],
        "capabilities": [
            "Release planning (singles/EPs/albums)",
            "Streaming optimization (all DSPs)",
            "Artist career strategy",
            "Playlist pitching",
            "TikTok/social strategy",
            "Revenue optimization"
        ]
    },
    "rockwell": {
        "name": "Rockwell",
        "color": "#f15bb5",
        "model": "Claude Sonnet 4",
        "discipline": "Music Production + Technical Audio",
        "keywords": [
            "production", "mixing", "mastering", "audio", "sound design",
            "arrangement", "beat", "track", "daw", "ableton", "fl studio",
            "mixing session", "master", "loudness", "processing", "eq", "compression",
            "recording session", "vocal", "instrument", "sample"
        ],
        "capabilities": [
            "Mixing & mastering",
            "Sound design",
            "Production troubleshooting",
            "Quality assurance (audio)",
            "Arrangement guidance",
            "Technical audio analysis"
        ]
    },
    "homard": {
        "name": "Homard",
        "color": "#00bbf9",
        "model": "Claude Haiku 4",
        "discipline": "Finance + Metrics",
        "keywords": [
            "revenue", "budget", "cost", "mrr", "arr", "roi", "profit",
            "financial", "metrics", "analytics", "spending", "income",
            "cash flow", "forecast", "pricing", "payment", "invoice",
            "subscription", "refund", "payout", "earnings"
        ],
        "capabilities": [
            "Revenue tracking & forecasting",
            "Budget analysis & optimization",
            "ROI calculation",
            "Financial reporting",
            "Metrics analysis",
            "Cost/benefit analysis"
        ]
    },
    "langostino": {
        "name": "Langostino",
        "color": "#9b5de5",
        "model": "Claude Sonnet 4",
        "discipline": "Marketing + Brand Strategy",
        "keywords": [
            "marketing", "brand", "campaign", "messaging", "positioning",
            "social media", "content", "launch", "narrative", "storytelling",
            "audience", "engagement", "seo", "copy", "landing page",
            "email", "announcement", "press", "pr", "branding"
        ],
        "capabilities": [
            "Brand strategy & positioning",
            "Campaign planning",
            "Content strategy",
            "Messaging/copywriting",
            "Launch planning",
            "Social media strategy"
        ]
    },
    "barnaby": {
        "name": "Barnaby",
        "color": "#f15b5b",
        "model": "Claude Opus 4",
        "discipline": "Business Development + Partnerships",
        "keywords": [
            "partnership", "deal", "collaboration", "licensing", "sync",
            "sponsorship", "co-marketing", "joint venture", "agreement",
            "negotiation", "contract", "opportunity", "vendor", "investor",
            "acquisition", "distribution", "relationship"
        ],
        "capabilities": [
            "Partnership identification & outreach",
            "Deal structuring",
            "Licensing negotiations",
            "Co-marketing opportunities",
            "Relationship development",
            "Revenue partnership analysis"
        ]
    },
    "coral": {
        "name": "Coral",
        "color": "#5bf166",
        "model": "Claude Opus 4",
        "discipline": "Research + Development + Innovation",
        "keywords": [
            "research", "innovation", "technology", "experiment", "poc",
            "prototype", "feasibility", "emerging", "ai", "trend",
            "analysis", "discovery", "improvement", "optimization",
            "new approach", "beta", "pilot", "evaluation"
        ],
        "capabilities": [
            "Tech research & evaluation",
            "Feasibility analysis",
            "Prototype development",
            "Market research",
            "Trend analysis",
            "Innovation strategy"
        ]
    },
    "clawdia": {
        "name": "Clawdia",
        "color": "#fee440",
        "model": "Claude Sonnet 4",
        "discipline": "Operations + Infrastructure",
        "keywords": [
            "deployment", "infrastructure", "automation", "ops", "devops",
            "system", "workflow", "process", "reliability", "scalability",
            "monitoring", "ci/cd", "docker", "server", "database",
            "backup", "maintenance", "troubleshooting", "optimization"
        ],
        "capabilities": [
            "Deployment & infrastructure",
            "System optimization",
            "Workflow automation",
            "Reliability engineering",
            "DevOps/CI-CD",
            "Operational troubleshooting"
        ]
    },
    "sebastian": {
        "name": "Sebastian",
        "color": "#f19b5b",
        "model": "Claude Sonnet 4",
        "discipline": "Legal + Compliance + Administration",
        "keywords": [
            "legal", "compliance", "contract", "agreement", "terms",
            "policy", "risk", "liability", "copyright", "rights",
            "administration", "org", "structure", "documentation",
            "approval", "audit", "pro registration", "publishing"
        ],
        "capabilities": [
            "Contract review & drafting",
            "Compliance verification",
            "Risk assessment",
            "Legal documentation",
            "Publishing/copyright issues",
            "Administrative procedures"
        ]
    }
}

# ============ CONFIG ============
TASKS_DIR = os.path.expanduser("~/wlp/agents/tasks")
RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
LOG_FILE = os.path.expanduser("~/wlp/logs/agent-orchestrator.log")

os.makedirs(TASKS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
# ================================


def log(message: str):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def parse_task(task_description: str) -> Tuple[str, str]:
    """
    Parse task description and return (agent_id, task_details)
    Uses keyword matching to identify best agent
    """
    task_lower = task_description.lower()
    
    # Score each agent based on keyword matches
    scores = {}
    for agent_id, profile in AGENT_EXPERTISE.items():
        score = sum(1 for keyword in profile["keywords"] if keyword in task_lower)
        scores[agent_id] = score
    
    # Find best match
    best_agent = max(scores, key=scores.get)
    confidence = scores[best_agent]
    
    return best_agent, confidence


def get_agent_info(agent_id: str) -> Optional[Dict]:
    """Get agent profile info"""
    return AGENT_EXPERTISE.get(agent_id)


def create_task_file(agent_id: str, task_description: str, eric_message_id: str) -> str:
    """
    Create task file for agent to work on
    Returns task_id
    """
    task_id = f"{agent_id}_{eric_message_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    task_file = os.path.join(TASKS_DIR, f"{task_id}.json")
    
    task_data = {
        "id": task_id,
        "agent": agent_id,
        "description": task_description,
        "created_at": datetime.now().isoformat(),
        "status": "assigned",
        "eric_message_id": eric_message_id
    }
    
    with open(task_file, 'w') as f:
        json.dump(task_data, f, indent=2)
    
    log(f"Created task: {task_id}")
    return task_id


def save_task_result(task_id: str, result: Dict):
    """Save agent's result for verification"""
    result_file = os.path.join(RESULTS_DIR, f"{task_id}_result.json")
    
    result_data = {
        "task_id": task_id,
        "result": result,
        "submitted_at": datetime.now().isoformat(),
        "status": "pending_verification"
    }
    
    with open(result_file, 'w') as f:
        json.dump(result_data, f, indent=2)
    
    log(f"Saved result for task: {task_id}")


def main():
    """Test the routing system"""
    log("=== Agent Orchestrator Ready ===")
    
    # Test tasks
    test_tasks = [
        "I need a release strategy for Kade Rivers' new single coming out in 3 weeks",
        "Can you mix the vocal track for the new Madison Blair demo? Here's the file...",
        "What's our current MRR and what revenue are we expecting from the AI artists?",
        "Create a marketing campaign for the Aria Vale launch",
        "Look into licensing opportunities for our music with Netflix",
        "Research the latest AI music generation tools and evaluate them",
        "Set up automated deployment for the new dashboard",
        "Review the publishing rights on all our released tracks"
    ]
    
    log("\n=== Testing Task Router ===\n")
    
    for task in test_tasks:
        agent_id, confidence = parse_task(task)
        agent_info = get_agent_info(agent_id)
        
        print(f"\n📋 Task: {task[:60]}...")
        print(f"   → Agent: {agent_info['name']} ({agent_info['discipline']})")
        print(f"   → Confidence: {confidence}/10")


if __name__ == "__main__":
    main()
