#!/usr/bin/env python3
"""
Message Handler - OpenClaw Integration
Called when Eric sends a Telegram message
Sends response back via OpenClaw message tool
"""

import json
import os
import sys
import subprocess
from datetime import datetime

LOG_FILE = os.path.expanduser("~/wlp/logs/message-handler.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def handle_message(message_data: dict) -> str:
    """
    Handle incoming Telegram message from Eric
    Called by OpenClaw message handler
    
    Args:
        message_data: {
            "message": "task text",
            "sender": "Eric Mills",
            "sender_id": "8180067794",
            "message_id": "12345",
            "channel": "telegram"
        }
    
    Returns:
        Response text to send back to Eric
    """
    
    message_text = message_data.get("message", "")
    sender = message_data.get("sender", "Unknown")
    message_id = message_data.get("message_id", "")
    
    if not message_text:
        return "No message content"
    
    log(f"📨 Message from {sender}: {message_text[:80]}...")
    
    # Call orchestrator
    try:
        cmd = [
            "python3",
            "/home/ubuntu/wlp/agents/orchestrator.py",
            message_text
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            # Get the response from orchestrator output
            output_lines = result.stdout.strip().split('\n')
            # Last non-empty line is the response
            response = [line for line in output_lines if line and not line.startswith('[')][-1]
            log(f"✅ Response: {response[:80]}...")
            return response
        else:
            error = result.stderr.strip()
            log(f"❌ Error: {error}")
            return f"❌ Error processing task: {error[:100]}"
    
    except Exception as e:
        log(f"❌ Exception: {e}")
        return f"❌ Error: {str(e)}"


def send_response_via_message_tool(response_text: str, target_user: str = "Eric Mills"):
    """
    Send response back to Eric via OpenClaw message tool
    
    In a live environment, this would call:
    message(
        action="send",
        channel="telegram",
        target=target_user,
        message=response_text
    )
    """
    
    log(f"💬 Sending response to {target_user}")
    
    # Note: In production, OpenClaw's message tool is called directly
    # For now, we just log that it would be sent
    
    return response_text


# ============ OPENCLAW INTEGRATION ============
# 
# This file should be called by OpenClaw's message handler.
# 
# Option 1: Direct Python Import
# In your OpenClaw config or handler:
# ```python
# from wlp.agents.message_handler import handle_message, send_response_via_message_tool
# 
# def on_telegram_message(inbound_data):
#     response = handle_message(inbound_data)
#     send_response_via_message_tool(response)
# ```
#
# Option 2: Command Line
# When a message arrives, OpenClaw calls:
# ```bash
# python3 /home/ubuntu/wlp/agents/message-handler.py '{"message": "...", "sender": "Eric Mills", ...}'
# ```
#
# Option 3: OpenClaw Plugin Hook
# In openclaw.json:
# ```json
# {
#   "plugins": {
#     "message-handlers": {
#       "telegram": "/home/ubuntu/wlp/agents/message-handler.py"
#     }
#   }
# }
# ```
#
# =============================================


if __name__ == "__main__":
    # CLI mode (for testing)
    if len(sys.argv) > 1:
        # Try to parse JSON from command line
        try:
            message_data = json.loads(sys.argv[1])
        except:
            # Otherwise treat as plain message text
            message_data = {
                "message": " ".join(sys.argv[1:]),
                "sender": "Eric Mills",
                "channel": "telegram"
            }
        
        response = handle_message(message_data)
        print(f"\n{response}")
    else:
        # Demo mode
        print("Usage:")
        print("  python3 message-handler.py 'your task here'")
        print("  python3 message-handler.py '{\"message\": \"task\", \"sender\": \"Eric Mills\"}'")
