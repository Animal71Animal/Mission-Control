#!/usr/bin/env python3
"""
OpenClaw Queue Processor
This script is called by OpenClaw during heartbeat to process pending spawn requests
"""

import json
import os
from datetime import datetime

RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
LOG_FILE = os.path.expanduser("~/wlp/logs/openclaw-queue-processor.log")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def get_pending_tasks():
    """Get all pending tasks from results directory AND spawn queue"""
    pending = []
    
    # Check results directory for pending_openclaw tasks
    if os.path.exists(RESULTS_DIR):
        for filename in os.listdir(RESULTS_DIR):
            if filename.endswith('.json'):
                filepath = os.path.join(RESULTS_DIR, filename)
                try:
                    with open(filepath, 'r') as f:
                        task = json.load(f)
                    if task.get('status') == 'pending_openclaw':
                        pending.append(task)
                except:
                    continue
    
    # Check spawn_queue.json for pending requests
    queue_file = os.path.expanduser("~/wlp/agents/spawn_queue.json")
    if os.path.exists(queue_file):
        try:
            with open(queue_file, 'r') as f:
                queue = json.load(f)
            for request in queue:
                if request.get('status') == 'pending':
                    # Convert queue format to task format
                    task = {
                        'id': request.get('task_id', f"queue_{datetime.now().strftime('%Y%m%d_%H%M%S')}"),
                        'agent_name': request.get('agent_name', 'unknown'),
                        'model': request.get('model', 'abacus/m2.7'),
                        'task': request.get('task', ''),
                        'status': 'pending_openclaw',
                        'created_at': request.get('created_at', datetime.now().isoformat())
                    }
                    pending.append(task)
        except:
            pass
    
    return pending


def mark_task_spawned(task_id, session_key):
    """Mark a task as spawned with session key"""
    task_file = os.path.join(RESULTS_DIR, f"{task_id}.json")
    if os.path.exists(task_file):
        with open(task_file, 'r') as f:
            task = json.load(f)
        
        task['status'] = 'spawned'
        task['session_key'] = session_key
        task['spawned_at'] = datetime.now().isoformat()
        
        with open(task_file, 'w') as f:
            json.dump(task, f, indent=2)
        
        log(f"Task {task_id} marked as spawned")


def process_pending_tasks():
    """Process all pending tasks - this is called by OpenClaw"""
    pending = get_pending_tasks()
    
    if not pending:
        return []
    
    log(f"Found {len(pending)} pending tasks to spawn")
    
    spawn_requests = []
    for task in pending:
        spawn_requests.append({
            "task_id": task['id'],
            "agent_name": task['agent_name'],
            "model": task['model'],
            "task": task['task']
        })
    
    return spawn_requests


if __name__ == "__main__":
    requests = process_pending_tasks()
    print(json.dumps(requests, indent=2))
