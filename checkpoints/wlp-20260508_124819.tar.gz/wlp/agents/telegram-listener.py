#!/usr/bin/env python3
"""
Telegram Listener - PriScylla's task intake system
Listens for Eric's messages, routes tasks to agents, spawns subagent sessions
Integrated with OpenClaw's message tool for Telegram
"""

import json
import os
import sys
import subprocess
from datetime import datetime
from typing import Optional, Dict, Tuple

TASKS_DB = os.path.expanduser("~/wlp/agents/tasks_db.json")
RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
LOG_FILE = os.path.expanduser("~/wlp/logs/telegram-listener.log")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


# Task routing keywords
AGENT_KEYWORDS = {
    "shelly": ["artist", "release", "streaming", "playlist", "tiktok", "career", "dsp", "distrokid", "spotify", "apple music", "dsps"],
    "rockwell": ["production", "mixing", "mastering", "audio", "sound", "arrangement", "beat", "track", "mix", "master"],
    "homard": ["revenue", "budget", "mrr", "roi", "profit", "metrics", "analytics", "financial", "cost", "earnings", "mrr", "arr"],
    "langostino": ["marketing", "brand", "campaign", "messaging", "content", "social", "launch", "copy", "story"],
    "barnaby": ["partnership", "deal", "licensing", "sync", "collaboration", "vendor", "opportunity", "investor"],
    "coral": ["research", "innovation", "technology", "experiment", "poc", "prototype", "emerging", "ai", "evaluate"],
    "clawdia": ["deployment", "infrastructure", "automation", "devops", "system", "workflow", "ops", "reliability"],
    "sebastian": ["legal", "compliance", "contract", "copyright", "rights", "publishing", "registration", "agreement"]
}


def route_task(task_description: str) -> Tuple[str, int]:
    """
    Route task to best agent based on keyword matching
    Returns (agent_id, confidence_score)
    """
    task_lower = task_description.lower()
    scores = {}
    
    for agent_id, keywords in AGENT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in task_lower)
        scores[agent_id] = score
    
    best_agent = max(scores, key=scores.get)
    confidence = scores[best_agent]
    
    return best_agent, confidence


def load_tasks_db() -> Dict:
    """Load tasks database"""
    if os.path.exists(TASKS_DB):
        with open(TASKS_DB, 'r') as f:
            return json.load(f)
    return {"tasks": [], "total": 0}


def save_tasks_db(db: Dict):
    """Save tasks database"""
    with open(TASKS_DB, 'w') as f:
        json.dump(db, f, indent=2)


def create_task_record(task_description: str, agent_id: str, confidence: int) -> Dict:
    """Create a task record"""
    import uuid
    task_id = str(uuid.uuid4())[:8]
    
    task = {
        "id": task_id,
        "description": task_description,
        "agent_id": agent_id,
        "confidence": confidence,
        "created_at": datetime.now().isoformat(),
        "status": "assigned",  # assigned → spawned → in_progress → completed → verified
        "session_id": None,
        "result": None
    }
    
    # Save to DB
    db = load_tasks_db()
    db["tasks"].append(task)
    db["total"] += 1
    save_tasks_db(db)
    
    return task


def spawn_agent_session(task: Dict) -> bool:
    """
    Spawn subagent session for the task
    Returns True if spawn was successful
    """
    try:
        log(f"🚀 Spawning subagent for task {task['id']} (agent: {task['agent_id']})")
        
        # Call execute-task.py to prepare and spawn the session
        cmd = [
            "python3",
            "/home/ubuntu/wlp/agents/execute-task.py",
            task["description"],
            task["agent_id"]
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            log(f"   ✅ Subagent spawned for task {task['id']}")
            # Update task status
            db = load_tasks_db()
            for t in db["tasks"]:
                if t["id"] == task["id"]:
                    t["status"] = "spawned"
                    break
            save_tasks_db(db)
            return True
        else:
            log(f"   ❌ Failed to spawn: {result.stderr}")
            return False
    
    except Exception as e:
        log(f"   ❌ Error spawning: {e}")
        return False


def handle_eric_message(message_text: str, message_id: str = None) -> Dict:
    """
    Handle an incoming message from Eric
    1. Parse task
    2. Route to agent
    3. Spawn subagent
    4. Return status
    """
    
    log(f"\n📨 New message from Eric: {message_text[:80]}...")
    
    # Route the task
    agent_id, confidence = route_task(message_text)
    log(f"   ✓ Routed to: {agent_id} (confidence: {confidence}/10)")
    
    # Create task record
    task = create_task_record(message_text, agent_id, confidence)
    log(f"   ✓ Task created: {task['id']}")
    
    # Spawn agent session
    spawned = spawn_agent_session(task)
    
    # Prepare response
    response = {
        "task_id": task["id"],
        "agent_id": agent_id,
        "status": "spawned" if spawned else "failed",
        "message": f"✅ Task assigned to {agent_id}. Working on it now..." if spawned else "❌ Failed to spawn agent session"
    }
    
    return response


def send_response_to_eric(response: Dict):
    """
    Send task status response back to Eric via Telegram
    In production, this uses the message tool
    """
    
    message = response["message"]
    
    if response["status"] == "spawned":
        message += f"\n\n📋 Task ID: {response['task_id']}\nAgent: {response['agent_id']}\n\n⏳ Will report back when complete."
    
    log(f"\n💬 Sending to Eric: {message[:60]}...")
    
    # In production, this would call:
    # message(
    #     action="send",
    #     target="Eric Mills",
    #     channel="telegram",
    #     message=message
    # )
    
    return message


def main():
    """
    Main loop - simulate receiving messages from Eric
    In production, this would be triggered by OpenClaw's inbound message handler
    """
    
    log("=" * 60)
    log("PriScylla Telegram Listener — Starting")
    log("=" * 60)
    
    # Test messages
    test_messages = [
        "Can you analyze Kade Rivers' streaming performance and recommend next steps?",
        "I need the new Madison Blair vocal track mixed and mastered ASAP",
        "What's our projected revenue for Q2 from the three AI artists?",
        "Create a comprehensive marketing campaign for Aria Vale's upcoming release"
    ]
    
    print("\n" + "=" * 60)
    print("SIMULATING INCOMING MESSAGES FROM ERIC")
    print("=" * 60 + "\n")
    
    for msg in test_messages:
        response = handle_eric_message(msg)
        reply = send_response_to_eric(response)
        print(f"\n💬 Reply to Eric:\n{reply}\n")
    
    log("\n" + "=" * 60)
    log("✅ Telegram listener demo complete")
    log("=" * 60)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Process a single message
        message = " ".join(sys.argv[1:])
        response = handle_eric_message(message)
        reply = send_response_to_eric(response)
        print(f"\n{reply}")
    else:
        # Run demo
        main()
