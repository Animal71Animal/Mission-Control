#!/usr/bin/env python3
"""
Task Executor — Spawns subagent sessions and manages their work
"""

import json
import os
import time
from datetime import datetime
from typing import Optional, Dict

LOG_FILE = os.path.expanduser("~/wlp/logs/task-executor.log")
RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def spawn_agent_session(agent_name: str, task_description: str, agent_profile: Dict) -> Optional[Dict]:
    """
    Spawn a subagent session for the given task
    Returns session info: {session_id, agent_name, task_id, status, ...}
    
    In actual implementation, this would call sessions_spawn from OpenClaw
    For now, returning the structure we'd pass to sessions_spawn
    """
    
    session_id = f"{agent_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    # This is what we'd pass to sessions_spawn in OpenClaw
    spawn_config = {
        "task": f"""You are {agent_profile['name']}, a {agent_profile['discipline']} expert.
        
Your expertise areas:
{chr(10).join(f"- {cap}" for cap in agent_profile['capabilities'])}

You have been assigned the following task:

{task_description}

Please:
1. Break down what needs to be done
2. Execute the task fully 
3. Provide your final result/deliverable
4. Note any assumptions or dependencies
5. Be thorough and show your work

When you're done, provide a final summary of what you've completed.""",
        "runtime": "subagent",
        "mode": "run",
        "label": f"{agent_name} — Task Session",
        "timeout_seconds": 3600,  # 1 hour timeout
        "model": agent_profile.get("model", "Claude Sonnet 4")
    }
    
    session_data = {
        "session_id": session_id,
        "agent_name": agent_name,
        "agent_profile": agent_profile,
        "task": task_description,
        "spawn_config": spawn_config,
        "spawned_at": datetime.now().isoformat(),
        "status": "spawned"
    }
    
    log(f"Spawned session: {session_id} for {agent_name}")
    
    # Save session data
    session_file = os.path.join(RESULTS_DIR, f"{session_id}_session.json")
    with open(session_file, 'w') as f:
        json.dump(session_data, f, indent=2)
    
    return session_data


def collect_result(session_id: str, result_content: str, status: str = "completed") -> Dict:
    """
    Collect result from completed subagent session
    """
    result_data = {
        "session_id": session_id,
        "result": result_content,
        "status": status,
        "collected_at": datetime.now().isoformat(),
        "verification_status": "pending"  # I (PriScylla) will review this
    }
    
    result_file = os.path.join(RESULTS_DIR, f"{session_id}_result.json")
    with open(result_file, 'w') as f:
        json.dump(result_data, f, indent=2)
    
    log(f"Collected result for session: {session_id}")
    return result_data


def main():
    """Demo"""
    log("=== Task Executor Ready ===")
    log("This module will spawn subagent sessions and collect their work")


if __name__ == "__main__":
    main()
