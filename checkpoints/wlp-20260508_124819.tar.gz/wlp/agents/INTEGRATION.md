# Agent Orchestration System — Integration Guide

## Overview

Complete end-to-end agent system:
```
Eric's Task → Router → Agent Spawned → Work Completes → PriScylla Verifies → Report Back
```

## Files

| File | Purpose |
|------|---------|
| `orchestrator.py` | Master orchestrator (entry point) |
| `execute-task.py` | Spawns subagent with full context |
| `verify-results.py` | Quality gate (PriScylla review) |
| `mc-sync.py` | Syncs agent status to Mission Control |
| `discord-updater.py` | Posts updates to Discord channels |
| `telegram-hook.py` | OpenClaw integration |
| `tasks_db.json` | Task database |

## How It Works

### 1. **Eric Sends a Task** (via Telegram)
```
"Analyze Kade Rivers' streaming and recommend next steps"
```

### 2. **Orchestrator Receives It**
- Routes based on keywords → picks best agent
- Creates task record
- Spawns subagent session

### 3. **Agent Works**
- Agent has full context + model info
- Completes the task
- Returns result

### 4. **PriScylla Verifies**
- Reviews quality (✓ length, structure, clarity, professionalism)
- Quality score: 0-100%
- Decision: ✅ Approve | 🔄 Request Revision | ❌ Reject

### 5. **Report to Eric**
- Task summary
- Result
- Final status

### 6. **Live Updates**
- **Discord:** Agent channels get status updates
- **Mission Control:** Dashboard shows agent status & task counts

## Integration Points

### Telegram Integration

When Eric sends a message, OpenClaw calls:

```python
from orchestrator import handle_eric_task

response = handle_eric_task(message_text)
# Send response back to Eric via Telegram
```

**Option A: Direct Python Integration**
```python
# In OpenClaw's inbound message handler
from wlp.agents.orchestrator import handle_eric_task

def on_telegram_message(message):
    response = handle_eric_task(message.text)
    send_to_telegram(response)
```

**Option B: Command Line Integration**
```bash
# When Eric sends a message, call:
python3 /home/ubuntu/wlp/agents/orchestrator.py "message text"
```

### Discord Integration

Agents post updates to Discord automatically via `discord-updater.py`.

**Channel Mappings:**
```
shelly    → #kade-rivers
rockwell  → #madison-blair
homard    → #aria-vale
langostino → #research
barnaby   → #agent-output
coral     → #srb-weekly
clawdia   → #dj-automation
sebastian → #live-production
```

When a task is assigned/completed/verified, posts are made automatically.

### Mission Control Dashboard

Add this page to Mission Control:

**File:** `app/agents-status/page.tsx`

```bash
cp /tmp/agents-status.tsx /home/ubuntu/wlp/projects/mission-control/app/agents-status/page.tsx
```

The page shows:
- 🟢 Idle agents
- 🟡 Working agents
- 🔴 Busy agents (3+ tasks)
- Active task counts per agent
- Auto-refreshes every 10 seconds

## Usage

### Quick Test
```bash
python3 /home/ubuntu/wlp/agents/orchestrator.py "Your task here"
```

### Production Setup

1. **Hook Telegram:**
   - Add orchestrator call to OpenClaw message handler
   - Response automatically sent back to Eric

2. **Discord Active:**
   - discord-updater.py runs automatically when tasks are created
   - Posts to appropriate agent channels

3. **MC Dashboard:**
   - Add agents-status page to MC
   - mc-sync.py updates data every time task status changes

4. **Cron Job (Recommended):**
   ```bash
   # Sync MC dashboard every 5 minutes
   */5 * * * * python3 /home/ubuntu/wlp/agents/mc-sync.py >> /home/ubuntu/wlp/logs/mc-sync.log 2>&1
   ```

## Agent Routing

Task keywords → agent assignment:

| Agent | Keywords |
|-------|----------|
| shelly | artist, release, streaming, playlist, tiktok, dsp |
| rockwell | production, mixing, mastering, audio, sound |
| homard | revenue, budget, mrr, roi, financial |
| langostino | marketing, brand, campaign, messaging, social |
| barnaby | partnership, deal, licensing, sync, collaboration |
| coral | research, innovation, technology, experiment |
| clawdia | deployment, infrastructure, automation, devops |
| sebastian | legal, compliance, contract, copyright |

## Task States

```
assigned → spawned → in_progress → completed → verification_pending → verified/rejected
```

## Models Per Agent

```
Sonnet 4: shelly, rockwell, langostino, clawdia, sebastian
Haiku 4: homard (cost-optimized for data analysis)
Opus 4: barnaby, coral (complex negotiation/research)
```

## Verification Quality Checks

PriScylla reviews:
- ✅ **Length:** >100 chars (substantive)
- ✅ **Structure:** Has summary/recommendation
- ✅ **Clarity:** 3+ sections
- ✅ **Professional:** >500 chars (thorough)

Score calculation:
- 75%+: **Approved** ✅
- 50-75%: **Revision requested** 🔄
- <50%: **Rejected** ❌

## File Locations

- Tasks: `~/wlp/agents/tasks_db.json`
- Results: `~/wlp/agents/results/`
- Logs: `~/wlp/logs/`
- MC Data: `~/wlp/projects/mission-control/public/data/agents-status.json`

## Logs

Monitor activity:
```bash
# Orchestrator
tail -f ~/wlp/logs/orchestrator.log

# Discord updates
tail -f ~/wlp/logs/discord-updater.log

# MC sync
tail -f ~/wlp/logs/mc-sync.log

# All agent tasks
cat ~/wlp/agents/tasks_db.json | jq .
```

## Next Steps

1. ✅ System is **production-ready**
2. Hook to Telegram (3 lines of code)
3. Add MC dashboard page
4. Start sending tasks

The system runs autonomously once integrated. You just send tasks, agents work, I verify, and Eric gets results.
