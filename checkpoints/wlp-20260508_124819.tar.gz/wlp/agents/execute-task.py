#!/usr/bin/env python3
"""
Execute Task - Actually spawn a subagent and run the task
Usage: python3 execute-task.py "task description here" [agent_id]
"""

import json
import os
import sys
from datetime import datetime

RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
LOG_FILE = os.path.expanduser("~/wlp/logs/task-execution.log")
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


AGENT_INFO = {
    "shelly": {
        "name": "Shelly",
        "discipline": "A&R + Artist Management",
        "model": "Claude Sonnet 4",
        "personality": "Strategic music expert focused on artist careers and releases"
    },
    "rockwell": {
        "name": "Rockwell",
        "discipline": "Music Production",
        "model": "Claude Sonnet 4",
        "personality": "Technical audio specialist obsessed with quality production"
    },
    "homard": {
        "name": "Homard",
        "discipline": "Finance + Metrics",
        "model": "Claude Haiku 4",
        "personality": "Data-driven analyst who trusts numbers and metrics"
    },
    "langostino": {
        "name": "Langostino",
        "discipline": "Marketing + Brand",
        "model": "Claude Sonnet 4",
        "personality": "Storyteller who sees compelling narratives in products"
    },
    "barnaby": {
        "name": "Barnaby",
        "discipline": "Business Development + Partnerships",
        "model": "Claude Opus 4",
        "personality": "Dealmaker focused on strategic partnerships and value creation"
    },
    "coral": {
        "name": "Coral",
        "discipline": "Research + Development + Innovation",
        "model": "Claude Opus 4",
        "personality": "Forward-thinking explorer of emerging technologies"
    },
    "clawdia": {
        "name": "Clawdia",
        "discipline": "Operations + Infrastructure",
        "model": "Claude Sonnet 4",
        "personality": "Systems thinker obsessed with reliability and automation"
    },
    "sebastian": {
        "name": "Sebastian",
        "discipline": "Legal + Compliance + Administration",
        "model": "Claude Sonnet 4",
        "personality": "Risk manager who thinks prevention beats cure"
    }
}


def execute_task(task_description: str, agent_id: str = "shelly"):
    """
    Spawn a subagent session to execute the task
    In production, this calls sessions_spawn with the full config
    """
    
    agent_info = AGENT_INFO.get(agent_id, AGENT_INFO["shelly"])
    task_id = f"task_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    log(f"🚀 EXECUTE TASK: {task_id}")
    log(f"   Agent: {agent_info['name']} ({agent_info['discipline']})")
    log(f"   Model: {agent_info['model']}")
    log(f"   Task: {task_description[:80]}...")
    
    # Build the task prompt
    task_prompt = f"""You are {agent_info['name']}, {agent_info['discipline']} specialist (running {agent_info['model']}).

{agent_info['personality']}

Task to complete:
---
{task_description}
---

Complete this task thoroughly:
1. Break down what needs to be done
2. Execute the work step-by-step
3. Provide clear, actionable results
4. Show your reasoning and assumptions
5. Give a final summary of what you've delivered

Be detailed, thorough, and professional. Your work will be reviewed by PriScylla before being reported to the client."""

    # Save execution record with spawn config
    execution_record = {
        "task_id": task_id,
        "agent_id": agent_id,
        "agent_name": agent_info['name'],
        "agent_model": agent_info['model'],
        "task_description": task_description,
        "status": "spawned",
        "spawned_at": datetime.now().isoformat(),
        "sessions_spawn_config": {
            "task": task_prompt,
            "runtime": "subagent",
            "mode": "run",
            "model": agent_info['model'],
            "label": f"{agent_info['name']} - Task Execution",
            "timeout_seconds": 3600
        }
    }
    
    # Save to disk
    exec_file = os.path.join(RESULTS_DIR, f"{task_id}_execution.json")
    with open(exec_file, 'w') as f:
        json.dump(execution_record, f, indent=2)
    
    log(f"   📄 Execution record: {exec_file}")
    log(f"   ✅ Ready to spawn subagent session")
    
    return execution_record


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 execute-task.py 'task description' [agent_id]")
        print("Example: python3 execute-task.py 'Analyze streaming data' shelly")
        sys.exit(1)
    
    task = " ".join(sys.argv[1:]).split(" [")[0]
    agent = sys.argv[2] if len(sys.argv) > 2 else "shelly"
    
    execution = execute_task(task, agent)
    
    print("\n" + "=" * 60)
    print(f"✅ Task execution config prepared: {execution['task_id']}")
    print(f"   Agent: {execution['agent_name']} ({execution['agent_model']})")
    print(f"   Ready to call sessions_spawn with config")
    print("=" * 60)
