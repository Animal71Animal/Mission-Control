# Agent Orchestration System — How It Works

## Architecture

```
User Task
    ↓
Message Poller (cron every 1 min)
    ↓
Orchestrator (route + create task record)
    ↓
Execute Task Spawner (build agent config + spawn)
    ↓
Real Subagent Session (via sessions_spawn)
    ↓
Agent Works (Claude Opus/Sonnet/Haiku)
    ↓
Result Returned
    ↓
PriScylla Verifies
    ↓
Report to User
```

## Components

### 1. Message Poller (`message-poller.py`)
- Runs every minute via cron
- Checks `~/wlp/agents/message_queue.json` for new tasks
- Routes each task through orchestrator
- Marks tasks as processed to avoid duplicates

**Cron entry:**
```
* * * * * python3 /home/ubuntu/wlp/agents/message-poller.py
```

### 2. Orchestrator (`orchestrator.py`)
- Receives task from poller
- Routes based on keywords → agent assignment
- Creates task record in database
- Calls executor to spawn agent

**Agent Routing (keyword-based):**
```
"streaming", "playlist", "artist" → Shelly (A&R)
"mixing", "mastering", "production" → Rockwell (Production)
"revenue", "budget", "metrics" → Homard (Finance)
"marketing", "campaign", "social" → Langostino (Marketing)
"partnership", "deal", "licensing" → Barnaby (Business Dev)
"research", "innovation", "analyze" → Coral (R&D)
"deployment", "infrastructure" → Clawdia (Operations)
"legal", "contract", "compliance" → Sebastian (Legal)
```

### 3. Task Spawner (`execute-task-spawn.py`)
- Builds task prompt with agent personality + model info
- Calls `sessions_spawn()` to create real subagent session
- Gets session ID back
- Updates task record with session ID
- Task status: `assigned` → `in_progress`

**Spawn Config:**
```python
sessions_spawn(
    task=task_prompt,
    runtime="subagent",
    mode="run",
    model=agent_model,  # e.g., "abacus/claude-opus-4-6"
    label=f"{agent_name} - Task {task_id}",
    timeout_seconds=3600
)
```

### 4. Subagent Session
- Real OpenClaw subagent spawned
- Runs with assigned model (Opus, Sonnet, or Haiku)
- Completes task work
- Returns result

### 5. Mission Control Dashboard (`/agents-status`)
- Real-time agent status (🟢 idle, 🟡 working, 🔴 busy)
- Synced every time task status changes
- Shows active task counts per agent
- Updates every 5 seconds

## Data Flow

### Task Database (`~/wlp/agents/tasks_db.json`)
```json
{
  "tasks": [
    {
      "id": "abc123",
      "description": "Analyze Tesla charging data",
      "agent_id": "coral",
      "confidence": 2,
      "created_at": "2026-04-26T06:00:00",
      "status": "in_progress",
      "session_id": "sess-uuid-123",
      "result": null
    }
  ],
  "total": 1
}
```

**Task Status Lifecycle:**
1. `assigned` - Task created, ready for spawn
2. `spawned` - Executor called (deprecated in new version)
3. `in_progress` - Real subagent session active
4. `verification_pending` - Result ready for PriScylla review
5. `verified` - Approved, ready to report
6. `rejected` - Did not meet quality gate

### Message Queue (`~/wlp/agents/message_queue.json`)
```json
{
  "messages": [
    {
      "message_id": "123456",
      "message": "Your task description",
      "sender": "Eric Mills",
      "sender_id": "8180067794",
      "timestamp": "2026-04-26T06:00:00Z"
    }
  ]
}
```

### Mission Control Data (`public/data/agents-status.json`)
```json
{
  "timestamp": "2026-04-26T06:00:00",
  "agents": [
    {
      "id": "coral",
      "name": "Coral",
      "discipline": "R&D",
      "color": "#5bf166",
      "status": "🟡",
      "status_text": "Working",
      "active_tasks": 1
    }
  ],
  "summary": {
    "total_agents": 8,
    "active_count": 5,
    "working_count": 2,
    "busy_count": 1,
    "total_tasks": 3
  }
}
```

## How to Use

### Queue a Task (via bash script)
```bash
/home/ubuntu/wlp/agents/send-task.sh "Analyze Kade Rivers' streaming data"
```

This:
1. Adds message to queue
2. Poller picks it up in ~1 minute
3. Routes to best agent
4. Spawns real subagent
5. Agent works
6. Result ready for verification

### Monitor
```bash
# Watch the logs
tail -f ~/wlp/logs/orchestrator.log

# Check task status
cat ~/wlp/agents/tasks_db.json | jq '.'

# View MC dashboard
https://mission-control-cyan-omega.vercel.app/agents-status
```

### Trigger Manually (for testing)
```bash
# Queue task
python3 /home/ubuntu/wlp/agents/orchestrator.py "Your task here"

# Or process immediately
python3 /home/ubuntu/wlp/agents/message-poller.py
```

## Agent Models

| Agent | Model | Best For |
|-------|-------|----------|
| Shelly | Claude Sonnet 4 | Artist management, releases |
| Rockwell | Claude Sonnet 4 | Audio production, mixing |
| Homard | Claude Haiku 4 (cost) | Financial analysis, metrics |
| Langostino | Claude Sonnet 4 | Marketing campaigns |
| Barnaby | Claude Opus 4 | Complex negotiations, deals |
| Coral | Claude Opus 4 | Research, innovation, analysis |
| Clawdia | Claude Sonnet 4 | Infrastructure, automation |
| Sebastian | Claude Sonnet 4 | Legal review, contracts |

## Cron Jobs

```bash
# Auto-save state (every 30 min)
*/30 * * * * python3 /home/ubuntu/wlp/skills/session-recovery/scripts/save-state.py

# YouTube monitor (daily noon MDT)
0 18 * * * python3 /home/ubuntu/wlp/skills/youtube-monitor/scripts/channel-monitor-local.py

# Cron health check (every 5 min)
*/5 * * * * bash /home/ubuntu/wlp/scripts/cron-fixer.sh

# Message poller (every 1 min)
* * * * * python3 /home/ubuntu/wlp/agents/message-poller.py

# MC sync (every 5 min)
*/5 * * * * python3 /home/ubuntu/wlp/agents/mc-sync.py
```

## Logs

```bash
~/wlp/logs/
├── orchestrator.log         # Routing & task creation
├── task-execution.log       # Agent spawning
├── message-poller.log       # Queue processing
├── mc-sync.log             # Dashboard updates
└── message-handler.log     # Inbound message handling
```

## Key Files

```
~/wlp/agents/
├── orchestrator.py           # Main task router
├── message-poller.py        # Cron daemon
├── execute-task-spawn.py    # Real agent spawner
├── verify-results.py        # Quality gate
├── mc-sync.py              # Dashboard sync
├── discord-updater.py      # Discord posts
├── send-task.sh            # Manual task queuing
├── tasks_db.json           # Task database
├── message_queue.json      # Inbound queue
├── SETUP.md               # Quick start
├── INTEGRATION.md         # Detailed integration
└── HOW-IT-WORKS.md       # This file
```

## Next Steps

1. **Telegram Integration** - Hook message poller to actual OpenClaw Telegram inbound (currently manual or polling)
2. **Discord Updates** - Agents post to Discord channels as they work
3. **Result Collection** - Poll subagent sessions for results and update task DB
4. **Verification Loop** - Run PriScylla verification on complete tasks
5. **Report Generation** - Final summary reports back to Eric

## Status

✅ **Complete and working:**
- Task routing (8 agents, keyword matching)
- Task database (persistent JSON)
- Message queue (for async task intake)
- Real agent spawning (via sessions_spawn)
- MC dashboard (live status + counts)
- Cron polling (every 1 min)
- All infrastructure ready

⚠️ **Needs OpenClaw integration:**
- Telegram hook (for automatic message intake)
- Discord posting (live progress updates)
- Result polling (retrieve subagent output)
- Verification workflow (quality gate)

The system is **production-ready for manual task queuing**. Automate the Telegram hook and result polling to complete full autonomous operation.
