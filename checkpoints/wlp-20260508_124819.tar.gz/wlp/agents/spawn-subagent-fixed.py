#!/usr/bin/env python3
"""
Spawn Subagent - Fixed version using OpenClaw's sessions_spawn tool
This script creates a task config that triggers the actual spawn via OpenClaw
"""

import json
import sys
import os
from datetime import datetime

LOG_FILE = os.path.expanduser("~/wlp/logs/spawn-subagent.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def create_spawn_config(task_prompt: str, agent_name: str, model: str, timeout: int = 3600):
    """
    Create a spawn configuration file that OpenClaw will read and execute
    """
    
    config = {
        "action": "spawn_subagent",
        "agent_name": agent_name,
        "model": model,
        "task": task_prompt,
        "timeout": timeout,
        "created_at": datetime.now().isoformat(),
        "status": "pending"
    }
    
    # Write to a queue file that OpenClaw monitors
    queue_file = os.path.expanduser("~/wlp/agents/spawn_queue.json")
    
    # Load existing queue or create new
    queue = []
    if os.path.exists(queue_file):
        with open(queue_file, 'r') as f:
            queue = json.load(f)
    
    queue.append(config)
    
    with open(queue_file, 'w') as f:
        json.dump(queue, f, indent=2)
    
    log(f"Spawn config created for {agent_name}")
    log(f"Model: {model}")
    log(f"Queue file: {queue_file}")
    
    return {
        "success": True,
        "config": config,
        "queue_file": queue_file
    }


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python3 spawn-subagent-fixed.py <agent_name> <model> <task_file>")
        sys.exit(1)
    
    agent_name = sys.argv[1]
    model = sys.argv[2]
    task_file = sys.argv[3]
    
    with open(task_file, 'r') as f:
        task_prompt = f.read()
    
    result = create_spawn_config(task_prompt, agent_name, model)
    print(json.dumps(result, indent=2))
