#!/usr/bin/env python3
"""
Verify Results - PriScylla's Quality Gate
Review agent work, approve/reject, request revisions
"""

import json
import os
import sys
from datetime import datetime
from typing import Optional, Dict, List

RESULTS_DIR = os.path.expanduser("~/wlp/agents/results")
TASKS_DB = os.path.expanduser("~/wlp/agents/tasks_db.json")
LOG_FILE = os.path.expanduser("~/wlp/logs/verification.log")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def get_pending_results() -> List[Dict]:
    """Get all results pending verification"""
    pending = []
    
    for filename in os.listdir(RESULTS_DIR):
        if filename.endswith("_result.json"):
            filepath = os.path.join(RESULTS_DIR, filename)
            with open(filepath, 'r') as f:
                result = json.load(f)
                if result.get("verification_status") == "pending":
                    pending.append(result)
    
    return pending


def load_task_db() -> Dict:
    """Load tasks database"""
    if os.path.exists(TASKS_DB):
        with open(TASKS_DB, 'r') as f:
            return json.load(f)
    return {"tasks": [], "total": 0}


def save_task_db(db: Dict):
    """Save tasks database"""
    with open(TASKS_DB, 'w') as f:
        json.dump(db, f, indent=2)


def review_result(task_id: str, agent_result: str) -> Dict:
    """
    Review an agent's result
    Returns verification object with quality score + notes
    """
    
    log(f"\n🔍 REVIEWING RESULT FOR TASK: {task_id}")
    
    # Quality checks (simple heuristics for demo)
    checks = {
        "length": len(agent_result) > 100,  # Has substantial content
        "structure": any(x in agent_result.lower() for x in ["summary", "recommendation", "complete", "done", "result"]),  # Has conclusion
        "clarity": len(agent_result.split('\n')) > 3,  # Multiple sections
        "professional": len(agent_result) > 500  # Thorough response
    }
    
    passed = sum(checks.values())
    total = len(checks)
    quality_score = (passed / total) * 100
    
    log(f"   Quality checks:")
    for check, passed_check in checks.items():
        status = "✅" if passed_check else "⚠️"
        log(f"      {status} {check}")
    
    log(f"   Quality score: {quality_score:.0f}%")
    
    # Determine approval
    if quality_score >= 75:
        approval = "approved"
        notes = "High quality work. Approved for delivery."
    elif quality_score >= 50:
        approval = "needs_revision"
        notes = "Good work, but needs refinement. Requesting revision."
    else:
        approval = "rejected"
        notes = "Work quality below standard. Rejecting and reassigning."
    
    verification = {
        "task_id": task_id,
        "reviewed_at": datetime.now().isoformat(),
        "quality_score": quality_score,
        "checks_passed": passed,
        "checks_total": total,
        "approval": approval,
        "notes": notes,
        "verifier": "PriScylla"
    }
    
    log(f"   Decision: {approval.upper()}")
    log(f"   Notes: {notes}")
    
    return verification


def approve_result(task_id: str, verification: Dict) -> Dict:
    """Mark result as approved for delivery"""
    log(f"✅ APPROVING: {task_id}")
    
    # Update task status
    db = load_task_db()
    for task in db["tasks"]:
        if task["id"] == task_id:
            task["status"] = "verified"
            task["verified_at"] = datetime.now().isoformat()
            break
    save_task_db(db)
    
    # Save verification record
    verify_file = os.path.join(RESULTS_DIR, f"{task_id}_verification.json")
    with open(verify_file, 'w') as f:
        json.dump(verification, f, indent=2)
    
    log(f"   Ready to report to Eric")
    
    return {
        "task_id": task_id,
        "status": "approved",
        "verification_file": verify_file
    }


def request_revision(task_id: str, verification: Dict, revision_notes: str) -> Dict:
    """Request agent to revise work"""
    log(f"🔄 REQUESTING REVISION: {task_id}")
    log(f"   Reason: {verification['notes']}")
    log(f"   Agent notes: {revision_notes}")
    
    # Update task status
    db = load_task_db()
    for task in db["tasks"]:
        if task["id"] == task_id:
            task["status"] = "revision_requested"
            task["revision_notes"] = revision_notes
            break
    save_task_db(db)
    
    log(f"   Agent will receive revision request on next heartbeat")
    
    return {
        "task_id": task_id,
        "status": "revision_requested",
        "notes": revision_notes
    }


def generate_report_for_eric(task_id: str, approval: str, agent_result: str) -> str:
    """Generate final report for Eric"""
    
    db = load_task_db()
    task = next((t for t in db["tasks"] if t["id"] == task_id), None)
    
    if not task:
        return f"Task {task_id} not found"
    
    if approval == "approved":
        report = f"""✅ Task Complete

Task ID: {task_id}
Agent: {task["agent_id"]}
Original Request: {task["description"][:100]}...

Result:
---
{agent_result}
---

Status: Verified and ready. Work meets quality standards."""
    
    elif approval == "revision":
        report = f"""🔄 Task Revision Requested

Task ID: {task_id}
Agent: {task["agent_id"]}

The work is being refined. I've requested a revision to improve quality.
Will report back when complete."""
    
    else:
        report = f"""❌ Task Failed

Task ID: {task_id}
Agent: {task["agent_id"]}

Work quality was below standard. Reassigning to a different agent."""
    
    return report


def demo_verification_flow():
    """Demo the verification workflow"""
    
    log("=" * 60)
    log("VERIFICATION INTERFACE DEMO")
    log("=" * 60)
    
    # Simulate agent results
    sample_results = {
        "task_001": """## Kade Rivers Streaming Analysis

### Current Performance
- Monthly listeners: 1,200
- Monthly streams: 8,500
- Growth trend: +15% month-over-month
- Top markets: US (35%), UK (20%), CA (15%)

### Recommendations
1. Playlist Pitching: Target "Independent Rock" and "Emerging Artists" playlists
2. TikTok Strategy: Create 3-5 30-second clips per release
3. Social Media: Post behind-the-scenes content 3x weekly
4. Collaboration: Reach out to 5 similar-sized artists for co-releases

### Next Steps
- Submit to 20+ playlists within 48 hours of release
- Prepare TikTok hooks for next single
- Schedule social content calendar for Q2

Summary: Kade has strong fundamentals. With targeted playlist pitching and social strategy, we can 3x listeners within 6 months.""",
        
        "task_002": """## Madison Blair Vocal Mix & Master Report

### Mixing Status
✅ Vocal EQ: Presence peak at 3kHz, warmth at 250Hz
✅ Dynamics: Compressor (4:1, 5ms attack) for consistency
✅ Reverb: 1.5s plate reverb, 20% wet
✅ Automation: Vocal rides for emotional impact

### Mastering
✅ Loudness: -14 LUFS (streaming standard)
✅ Frequency balance: Checked on reference monitors + headphones
✅ Loudness normalized across genres
✅ Final check: Translated to phone speakers - crystal clear

### Quality Assurance
- A/B tested against comparable releases
- Peak level: -1.0dB (safe margin)
- Phase coherence: Perfect
- Distortion analysis: None detected

Summary: Professional mix & master. Ready for all DSPs immediately."""
    }
    
    print("\n" + "=" * 60)
    print("SIMULATING VERIFICATION WORKFLOW")
    print("=" * 60)
    
    for task_id, result in sample_results.items():
        print(f"\n📥 Received result from agent for {task_id}")
        print(f"   Content length: {len(result)} characters")
        
        # Review
        verification = review_result(task_id, result)
        print(f"\n   ✅ Quality score: {verification['quality_score']:.0f}%")
        print(f"   Decision: {verification['approval']}")
        
        # Approve
        if verification["approval"] == "approved":
            approve_result(task_id, verification)
            report = generate_report_for_eric(task_id, "approved", result[:200] + "...")
            print(f"\n💬 Report for Eric:\n{report}")
        
        else:
            request_revision(task_id, verification, "Please expand on specific recommendations")
            report = generate_report_for_eric(task_id, "revision", result)
            print(f"\n💬 Report for Eric:\n{report}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Process a specific task result
        task_id = sys.argv[1]
        result = sys.argv[2] if len(sys.argv) > 2 else "No result provided"
        
        verification = review_result(task_id, result)
        
        if verification["approval"] == "approved":
            approve_result(task_id, verification)
        else:
            print(f"\nVerification decision: {verification['approval']}")
            print(f"Notes: {verification['notes']}")
    
    else:
        # Run demo
        demo_verification_flow()
