#!/usr/bin/env python3
"""
Telegram Hook - Integrates agent system with OpenClaw message tool
Called by OpenClaw when Eric sends a message
"""

import json
import os
import sys
import subprocess
from datetime import datetime

LOG_FILE = os.path.expanduser("~/wlp/logs/telegram-hook.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)


def log(message: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")


def process_eric_message(message_text: str, sender: str = "Eric Mills"):
    """
    Process incoming message from Eric
    1. Route to agent
    2. Spawn subagent
    3. Return response for Telegram
    """
    
    log(f"\n📨 Incoming from {sender}: {message_text[:80]}...")
    
    # Call telegram-listener to process
    try:
        cmd = [
            "python3",
            "/home/ubuntu/wlp/agents/telegram-listener.py",
            message_text
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        response_text = result.stdout.strip()
        
        log(f"✅ Processed. Response: {response_text[:100]}...")
        
        return response_text
    
    except Exception as e:
        log(f"❌ Error: {e}")
        return f"❌ Error processing task: {e}"


def send_response_to_eric(response: str):
    """
    Send response back to Eric via Telegram
    Uses OpenClaw's message tool
    """
    
    # In production, OpenClaw calls this function with response
    # and handles routing via message tool automatically
    
    log(f"💬 Response sent to Eric via Telegram")
    return response


def handle_inbound_message(inbound_data: dict):
    """
    Called by OpenClaw message handler when Eric sends a message
    
    inbound_data should contain:
    {
        "message": "task description",
        "sender": "Eric Mills",
        "channel": "telegram",
        "message_id": "123456"
    }
    """
    
    message = inbound_data.get("message", "")
    sender = inbound_data.get("sender", "Eric Mills")
    
    if not message:
        return "No message content"
    
    # Process the message
    response = process_eric_message(message, sender)
    
    # Send back
    send_response_to_eric(response)
    
    return response


# ============ OPENCLAWN MESSAGE INTEGRATION ============
# Add this to openclaw.json in the message section:
#
# "message": {
#   "handlers": [
#     {
#       "channel": "telegram",
#       "pattern": "^(?!.*[🔔⏳]).*$",  // exclude status messages
#       "handler": "/home/ubuntu/wlp/agents/telegram-hook.py"
#     }
#   ]
# }
#
# Or call this function directly from OpenClaw's inbound message handler:
#
# from telegram_hook import handle_inbound_message
# response = handle_inbound_message(inbound_data)
# =====================================================


if __name__ == "__main__":
    # Demo mode
    if len(sys.argv) > 1:
        message = " ".join(sys.argv[1:])
        response = process_eric_message(message)
        print(f"\n{response}")
    else:
        print("Usage: python3 telegram-hook.py 'your task here'")
        print("\nOr integrate with OpenClaw message handler:")
        print("  from telegram_hook import handle_inbound_message")
        print("  handle_inbound_message(inbound_data)")
