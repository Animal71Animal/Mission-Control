#!/bin/bash
# Check if tailscaled is running, start if not
# Called by OpenClaw cron every 10 minutes

SOCK=/run/tailscale/tailscaled.sock

if ! pgrep -x tailscaled > /dev/null; then
  echo "tailscaled not running, starting..."
  mkdir -p /var/lib/tailscale /run/tailscale
  sudo tailscaled --tun=userspace-networking \
    --state=/var/lib/tailscale/tailscaled.state \
    --socket=$SOCK > /tmp/tailscaled.log 2>&1 &
  sleep 5
  sudo tailscale up --hostname=priscylla-abacus --accept-routes >> /tmp/tailscaled.log 2>&1
  echo "Tailscale restarted. IP: $(sudo tailscale ip -4 2>/dev/null)"
else
  # Check if actually connected
  STATUS=$(sudo tailscale status 2>/dev/null | head -1)
  if [ -z "$STATUS" ]; then
    sudo tailscale up --hostname=priscylla-abacus --accept-routes >> /tmp/tailscaled.log 2>&1
    echo "Tailscale was down, brought back up"
  else
    echo "Tailscale OK: $STATUS"
  fi
fi
