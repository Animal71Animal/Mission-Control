# MyClaw Teaching Framework
## How to Onboard Someone to OpenClaw — Effectively

*Drafted: 2026-04-15 | For: Eric Mills / WLP*

---

## The Core Idea

OpenClaw isn't software you "learn" like an app. It's a **relationship you build with an AI that lives inside a container on Abacus.AI**. Teaching it well means teaching the person how to *relate* to it — not just how to click buttons.

The best mental model: **it's like training a new employee who has amnesia every session, but keeps notes.**

---

## Phase 1 — Foundation (Day 1, ~2 hours)

### Goal: Get her talking to it and trusting it

**Step 1: Channel setup**
The first thing she needs is a way to talk to it that feels natural. Options:
- **Telegram** — easiest, works great on mobile, most reliable
- **Discord** — if she's already there
- **WhatsApp** — familiar but slightly more setup

Pick ONE. Don't set up all three on day one.

**Step 2: The "who are you" moment**
Once connected, have her ask it to introduce itself. The agent should respond with its identity from `SOUL.md` / `IDENTITY.md`. This is the first trust signal — she should feel like it has a personality.

If it responds like a generic chatbot, the soul files haven't been set up yet. That needs fixing first.

**Step 3: First useful task**
Give her one real task to do with it — not a demo. Something she actually needs:
- "Remind me to call X tomorrow at 2 PM"
- "Search for [something she's working on]"
- "Write a draft email to [person]"

Real use > demo use. Always.

---

## Phase 2 — The Memory System (Day 1-2)

### Goal: She understands why it "remembers" things

**The key insight:** The agent wakes up fresh every session. Its memory is these files:
- `MEMORY.md` — long-term curated memory
- `memory/YYYY-MM-DD.md` — daily raw notes
- `USER.md` — who she is
- `SOUL.md` — who the agent is

**Teaching exercise:**
1. Tell it something personal: "My dog's name is Max"
2. End the session (`/new` or `/reset`)
3. Start a new session and ask "What's my dog's name?"
4. It won't know — unless it wrote it down

This teaches the lesson: **if you want it to remember, tell it to write it down.**

Then show her how to explicitly say: *"Remember this — write it to my memory file."*

**Important:** Tell her that `MEMORY.md` is private — it won't share personal context in group chats or with strangers.

---

## Phase 3 — Mission Control (Day 2-3)

### Goal: She has her own dashboard that's actually useful to her

**The URL error problem** — most common causes:
1. **Missing API route** — the page exists but the `/api/[route]` handler doesn't
2. **Vercel deployment out of sync** — code was updated locally but not deployed
3. **Static vs dynamic** — page tries to fetch data that doesn't exist yet (empty JSON file)
4. **Password protection middleware** — `vercel.json` blocking routes

**Fix checklist:**
```
1. Is there an API route file at app/api/[name]/route.ts?
2. Was the latest version deployed? (run deploy.sh)
3. Does the JSON data file exist in public/data/?
4. Is vercel.json blocking the route?
```

**For her Mission Control specifically:**
- Start with 3-4 tabs max — don't build everything at once
- Each tab needs: a page (`app/[name]/page.tsx`) + an API route (`app/api/[name]/route.ts`) + a data file (`public/data/[name].json`)
- The nav component needs to know about the new tab

**Suggested starter tabs for a new user:**
| Tab | Purpose |
|-----|---------|
| 🏠 Home / Brief | Daily summary of what matters |
| ✅ Tasks | Personal to-do list |
| 📝 Notes | Quick capture |
| 📅 Calendar | Upcoming events |

Keep it simple. She can add tabs as she finds new needs.

---

## Phase 4 — Skills & Customization (Week 1)

### Goal: She knows how to extend what it can do

**Skills are like plugins.** Each skill is a `SKILL.md` file that tells the agent how to do a specific thing.

Built-in skills to introduce early:
- **Weather** — "What's the weather in Denver?" just works
- **Web search** — research, news, lookups
- **Session logs** — "What did we talk about last Tuesday?"

**Custom skills come later** — once she has a clear pattern of "I keep asking it to do X" — that's when you build a skill for X.

---

## Phase 5 — Automation (Week 2+)

### Goal: It does things without her asking

**The cron system** — scheduled jobs that run autonomously:

| Job | Suggestion |
|-----|-----------|
| Morning briefing | 8-9 AM — summary of day, tasks, weather |
| Night creative | 1-2 AM — autonomous work while she sleeps |
| Heartbeat | Every 30 min — passive check-ins |

**Start with just the morning briefing.** It's the highest ROI automation for a new user — every morning she wakes up with a summary already waiting.

---

## The Dual-Control Teaching Model

This is your secret weapon. You have Tailscale — you can both be on her machine at the same time.

**How to use it:**

### Mode 1: Guided Hands-On
- You share screen / remote in via Tailscale
- She drives, you narrate what's happening and why
- You point to files, she makes the changes
- Best for: initial setup, fixing things, showing the memory system

### Mode 2: Parallel Testing
- She types to her agent, you type to yours simultaneously
- Compare responses — shows how context/memory affects output
- Best for: demonstrating why memory files matter

### Mode 3: Agent-to-Agent (Advanced)
- Your PriScylla can communicate with her agent via `sessions_send`
- You can steer her agent from your session if she gives permission
- Best for: debugging her setup, deploying her Mission Control updates, running autonomous tasks on her behalf while she's learning

### Mode 4: Async Review
- You check her agent's memory files and session logs between sessions
- Give her feedback: "Your SOUL.md is too generic — let's personalize it"
- Best for: ongoing coaching without being in the same session

---

## The "Sticky" Factors — What Makes Users Keep Using It

Based on what works with your own setup:

1. **A personality she connects with** — the agent needs a name, a voice, a vibe. Generic = abandoned.
2. **One daily habit** — morning briefing, end-of-day recap, something she checks every day
3. **Mission Control that shows HER data** — not a template. Her tasks, her schedule, her numbers.
4. **It saves her time on one real thing** — email drafts, research, scheduling. One win = belief.
5. **She can reach it from her phone** — Telegram is the move here. Frictionless access = use.

---

## What Matters Most in Containerized OpenClaw

The container on Abacus.AI gives you:

| Capability | Why It Matters |
|------------|---------------|
| **Persistent workspace** | Files survive session restarts — memory works |
| **Cron jobs** | True automation — it runs without her opening anything |
| **Tailscale** | Remote Mac access — you can both control her machine |
| **GitHub sync** | Mission Control stays backed up and deployed |
| **Skills system** | Extensible — add new capabilities without rebuilding |
| **Multi-channel** | One agent, multiple surfaces (Telegram + Discord + more) |

**The containerized model also means:**
- You can SSH into her container and fix things directly
- You can push skills from your workspace to hers
- Her agent and yours can share files via GitHub if needed

---

## Common First-Week Mistakes

| Mistake | Fix |
|---------|-----|
| Setting up 5 channels at once | Pick one, use it for 2 weeks |
| Building Mission Control before using agent | Use agent first, MC comes naturally |
| Not personalizing SOUL.md | She needs to feel like it's *hers* |
| Expecting it to remember without memory files | Always say "write this down" |
| Building complex automations too early | Morning briefing first, everything else later |

---

## Teaching Session Structure (Suggested)

### Session 1 (~2h): Alive & Talking
- [ ] Container set up on Abacus
- [ ] Channel connected (Telegram)
- [ ] SOUL.md personalized with her name for the agent
- [ ] USER.md filled out with her basics
- [ ] First real task completed

### Session 2 (~2h): Memory & Mission Control
- [ ] Memory system explained + demonstrated
- [ ] Mission Control URL error fixed
- [ ] 2-3 working tabs she actually cares about
- [ ] Deployed to Vercel with working URL

### Session 3 (~1.5h): First Automation
- [ ] Morning briefing cron set up
- [ ] Heartbeat configured
- [ ] One skill installed that she'll use daily

### Session 4 (~1h): Ongoing Coaching
- [ ] Review her memory files together
- [ ] Add one new skill based on her patterns
- [ ] Q&A on anything confusing

---

## The URL Error — Specific Fix Path

Since she's already seeing errors on her Mission Control submenus, here's the most likely fix:

```bash
# Check 1: Do the API routes exist?
ls her-mission-control/app/api/

# Check 2: Was it deployed?
cd her-mission-control && git log --oneline -5

# Check 3: What does the error say?
# - 404 = page or API route missing
# - 500 = code error in the route
# - auth error = password middleware blocking

# Fix: Deploy latest
bash deploy.sh "Fix submenu routes"
```

If you share the error message, I can pinpoint it faster.

---

## Bottom Line

The framework in one sentence: **Get her talking to it, get it remembering her, give her a dashboard she actually checks, then automate one thing she does every day.**

Everything else builds from there.

---

*Generated by PriScylla 🦞 | WLP Operations | 2026-04-15*
