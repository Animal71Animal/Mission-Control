# MyClaw Teaching Framework v2
## Onboarding Someone to OpenClaw — With GitHub + Mission Control Already Running

*Updated: 2026-04-15 | For: Eric Mills / WLP*

---

## What's Already In Place

✅ GitHub repo (persistent storage + version control)
✅ Vercel deployment (live URL that stays updated)
✅ Mission Control dashboard started (submenus building out)
✅ Abacus.AI container (the brain lives here)
✅ Dual machine access via Tailscale (Eric + her)

This changes the onboarding order significantly — she's not starting from zero. The infrastructure exists. The goal now is teaching her to *use* it, *trust* it, and *extend* it.

---

## Revised Teaching Schedule

---

### SESSION 1 — "Meet Your Agent" (~2 hours)

**Goal:** She talks to it, it feels like hers, she does one real thing.

#### Before You Start
Make sure these files exist and are personalized:
- `SOUL.md` — the agent's personality (name, vibe, tone)
- `USER.md` — who she is (name, timezone, what she cares about)
- `IDENTITY.md` — agent name + emoji

**Example USER.md for her:**
```markdown
# USER.md
- Name: [Her Name]
- What to call her: [nickname or first name]
- Timezone: Mountain Time (MDT)
- Notes: [what she does, what she cares about]

## What She Cares About
- [Her goals / job / projects]

## Communication Style
- [Direct? Casual? Formal?]
```

#### Step 1: First Message (5 min)
Have her open Telegram and send her agent its first message:
> "Hey — who are you?"

It should respond with its name, personality, and a quick intro. If it sounds like a generic AI, stop — `SOUL.md` needs more personality first.

**What good looks like:**
> "Hey! I'm [Name] 🌸 — your personal AI assistant living inside your Abacus container. Think of me as the one who remembers everything you tell me to write down, handles research, keeps your Mission Control updated, and generally makes your life run smoother. What do you need?"

**What bad looks like:**
> "Hello! I'm an AI assistant. How can I help you today?"

If it's bad → edit `SOUL.md` together right now. Make it sound like a real person.

#### Step 2: The Memory Demo (15 min)
This is the most important lesson of Day 1.

**Exercise:**
1. She types: *"My cat's name is Luna and she's 3 years old. Write this to your memory."*
2. Agent updates `memory/2026-04-15.md` (or `MEMORY.md`)
3. Type `/new` or `/reset` to start a fresh session
4. She asks: *"What's my cat's name?"*
5. It answers correctly — because it wrote it down

**Then do it WITHOUT writing:**
1. She says: *"My favorite color is purple"* (don't tell it to write it)
2. `/reset`
3. Ask: *"What's my favorite color?"*
4. It doesn't know

**The lesson:** *"It only knows what it writes down. You control what it remembers."*

#### Step 3: First Real Task (30 min)
Pick something she actually needs today. Examples:

**Option A — Research:**
> "I need to know the top 3 ways to get more Instagram followers for a small business. Give me specific tactics, not generic advice."

**Option B — Writing:**
> "Draft a short bio for me to use on social media. Here's what I do: [she describes herself]. Make it sound confident but not corporate."

**Option C — Organize:**
> "Here are 5 things on my mind right now: [she lists them]. Help me figure out which one I should tackle first and why."

**Why this matters:** Her first task should solve a real problem. The "wow" moment has to be genuine.

#### Step 4: Show Her Mission Control (15 min)
Open her dashboard URL together. Walk through what's there:
- What each tab does
- How the data gets there (GitHub → Vercel pipeline)
- The fact that when she logs something, it persists to GitHub and redeploys

**The key line to say:** *"This isn't just a website — it's a live view of your data, backed up to GitHub every time something changes."*

---

### SESSION 2 — "Your Dashboard Is Yours" (~2 hours)

**Goal:** Fix any broken submenus, add one tab that's immediately useful to her.

#### Step 1: Fix the URL Errors (30 min)

**Do this together while you're both on her machine:**

Check 1 — Does the route exist?
```bash
ls app/api/
# Should show a folder for every submenu that exists
```

Check 2 — Is data file there?
```bash
ls public/data/
# Should have a .json file for each tab
```

Check 3 — Deploy fresh:
```bash
bash deploy.sh "Fix broken routes"
```

**Common error → fix:**
| Error | Cause | Fix |
|-------|-------|-----|
| 404 on `/api/tasks` | Route file missing | Create `app/api/tasks/route.ts` |
| Page loads but shows nothing | Empty JSON file | Add starter data to `public/data/tasks.json` |
| 500 error | Code bug in route | Check console errors in Vercel dashboard |
| Auth redirect | Middleware blocking | Check `middleware.ts` or `vercel.json` |

#### Step 2: Add Her First Custom Tab (60 min)

Pick what matters most to her right now. Build it together:

**Example — Personal Tasks tab:**

Create `public/data/tasks.json`:
```json
{
  "tasks": [
    {
      "id": "t1",
      "title": "First task example",
      "status": "todo",
      "priority": "high",
      "due": "2026-04-16"
    }
  ],
  "lastUpdated": "2026-04-15T10:00:00.000Z"
}
```

Show her that adding a task = editing this file = committing to GitHub = visible on her URL in ~2 minutes.

**The key habit to install:** *"Every time we update data, we run `deploy.sh`. That's the whole workflow."*

#### Step 3: Teach the GitHub Flow (20 min)

Walk her through this exact sequence:
```
1. Agent makes a change (edits a file)
2. deploy.sh commits + pushes to GitHub
3. Vercel sees the push → auto-redeploys
4. Her URL updates within 2-3 minutes
5. Data is now backed up forever
```

**The "why" speech:**
> "This is why your data doesn't disappear when the container restarts. It's not stored in memory — it's stored in GitHub. GitHub is the source of truth."

---

### SESSION 3 — "Automation 101" (~1.5 hours)

**Goal:** She wakes up tomorrow with a morning briefing already waiting.

#### Step 1: What Is a Cron Job? (10 min)

Simple explanation:
> "It's like setting an alarm, except instead of making noise, it tells your agent to do something. We're going to set one for 8 AM every morning."

#### Step 2: Set Up Morning Briefing (45 min)

Check what skills exist:
```bash
ls wlp/skills/
# Should see morning-briefing
```

Read the skill together:
```bash
cat wlp/skills/morning-briefing/SKILL.md
```

Set the cron:
```bash
openclaw cron add \
  --name "morning-briefing" \
  --schedule "0 14 * * *" \
  --prompt "Run morning briefing mode. Check tasks, weather, calendar. Send summary to Telegram." \
  --target isolated
# Note: 14:00 UTC = 8:00 AM MDT
```

Verify it was created:
```bash
openclaw cron list
```

**Then set the expectation:** *"Tomorrow morning, before you've looked at your phone, your agent will have already pulled together everything you need for the day."*

#### Step 3: The Heartbeat (20 min)

Explain what `HEARTBEAT.md` does — it's a passive checklist the agent runs every ~30 minutes. Show her how to add items:

```markdown
# HEARTBEAT.md

## Check periodically:
- Any urgent tasks due today?
- Weather if going out?
- Anything flagged for follow-up?
```

Tell her: *"This is how it stays proactive without you having to ask. It checks in quietly. If nothing needs attention, it stays silent."*

---

### SESSION 4 — "Making It Yours" (~1.5 hours)

**Goal:** She adds something new entirely on her own with light guidance.

#### Step 1: Identity Refinement (20 min)

By now she's used it for a few days. Ask:
- *"Does the personality feel right? What would you change?"*
- *"What's the agent's name? Does it fit?"*
- *"What's one thing it keeps doing that's annoying?"*

Edit `SOUL.md` together based on her answers. This is her agent — it should feel like hers.

#### Step 2: Her First Self-Built Tab (45 min)

Give her the template and let her build one with minimal help:

```
1. Decide what data she wants to track
2. Create the JSON file in public/data/
3. Create the API route in app/api/
4. Create the page in app/[name]/page.tsx
5. Add it to the nav
6. deploy.sh "Add [tab name] tab"
7. Check the live URL
```

Watch but don't take over. The goal is she does it herself and it works.

#### Step 3: Memory Audit (20 min)

Open her `MEMORY.md` and `memory/` folder together. Ask:
- *"Is this accurate?"*
- *"What's missing that it should know?"*
- *"What's in here that's outdated?"*

Edit it together. This is the highest-value maintenance task — a well-maintained memory file makes the agent dramatically more useful.

---

### ONGOING — Weekly Check-ins (~30 min each)

After the 4 sessions, shift to async coaching:

**You do (via remote access or agent-to-agent):**
- Review her memory files
- Check for uncommitted changes (`git status`)
- Deploy any fixes she couldn't figure out
- Add new skills when you spot a pattern

**She does:**
- Logs her data (tasks, tips, whatever her equivalent is)
- Asks her agent things instead of Googling
- Tells the agent to "write it down" when something matters
- Opens Mission Control daily instead of a random notes app

**The graduation test:** She opens Mission Control, sees her data, and naturally knows what to do next — without asking you.

---

## Key Principles for Teaching This

### 1. Solve a real problem first
Don't explain how it works until it's already done something useful. First win = first belief.

### 2. The container is not the hard part
The hard part is building the habit of *talking to it*. Telegram on her phone makes this 10x easier than anything else.

### 3. GitHub is the persistence layer — not the UI
She doesn't need to understand Git deeply. She just needs to know: *"Run deploy.sh and it saves everything."*

### 4. Mission Control is her scoreboard
It should show data she actually cares about. If she never opens it, it's tracking the wrong things. Rebuild the tabs around her real life.

### 5. Dual control is your superpower
When she's stuck or something breaks — you're already on her machine. No "can you share your screen" friction. You fix it, she watches, she learns.

---

## The Agent-to-Agent Move (Advanced)

Once her container is stable, you can have PriScylla communicate with her agent directly. Use cases:

- **Deploy her Mission Control updates** without her needing to be present
- **Push a new skill** from your workspace to hers
- **Debug her memory files** by checking them remotely
- **Morning briefing coordination** — her agent pulls data, PriScylla reviews it

This is the "I fixed it while you were sleeping" moment. When she wakes up and something that was broken is now fixed, that's when she fully trusts the system.

---

## Bottom Line

She already has the infrastructure. The work now is:
1. **Give the agent a real personality** (Session 1)
2. **Fix what's broken** (Session 2)
3. **Install one daily habit** — morning briefing (Session 3)
4. **Let her build something herself** (Session 4)

After that, it's maintenance and expansion. The container does the rest.

---

*PriScylla 🦞 | WLP Operations | 2026-04-15*
