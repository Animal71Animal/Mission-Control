#!/bin/bash
# PriScylla Setup Script — Run this once to connect your Mac to Eric's network

echo "🦞 Starting setup..."

# Step 1: Add Tailscale to terminal path
sudo ln -s /Applications/Tailscale.app/Contents/MacOS/Tailscale /usr/local/bin/tailscale 2>/dev/null

# Step 2: Join Eric's Tailscale network
sudo tailscale up --authkey=tskey-auth-kKjA4oQxxi11CNTRL-9Qyq5zNRACcgRAz1UNc4CczErGfL2a7f --hostname=her-mac

# Step 3: Add PriScylla's SSH key
mkdir -p ~/.ssh
chmod 700 ~/.ssh
echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIO1pKbjGmK09wkN3j/bmKcBJ4YUijK574e2mGpJHB8S4 priscylla" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys

# Step 4: Show her IP
echo ""
echo "✅ Done! Your IP address is:"
tailscale ip -4
echo ""
echo "Send this number to Eric!"
