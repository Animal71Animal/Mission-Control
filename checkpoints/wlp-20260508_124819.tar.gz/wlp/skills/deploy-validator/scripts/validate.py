#!/usr/bin/env python3
"""
validate.py — Check a deployed Vercel URL is live and working
Usage: python3 validate.py <url> [--expect "string1" "string2"]
"""

import sys
import urllib.request
import urllib.error
import json

def check_url(url, expect_strings=None):
    print(f"\n🔍 Validating: {url}")
    results = []

    # Check main URL
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "PriScylla-Validator/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            status = resp.status
            body = resp.read().decode("utf-8", errors="ignore")
            final_url = resp.url

        if status == 200:
            results.append(("✅", f"HTTP {status} OK"))
        else:
            results.append(("⚠️", f"HTTP {status}"))

        if len(body) < 100:
            results.append(("❌", f"Page body suspiciously short ({len(body)} chars) — possible blank deploy"))
        else:
            results.append(("✅", f"Page has content ({len(body):,} chars)"))

        # Check for Vercel error page
        if "DEPLOYMENT_NOT_FOUND" in body or "404: Not Found" in body:
            results.append(("❌", "Vercel 404 — deployment not found"))
        elif "Application error" in body or "Internal Server Error" in body:
            results.append(("❌", "Application error detected in page"))
        else:
            results.append(("✅", "No error pages detected"))

        # Check expected strings
        if expect_strings:
            for s in expect_strings:
                if s in body:
                    results.append(("✅", f"Found expected string: '{s}'"))
                else:
                    results.append(("❌", f"Missing expected string: '{s}'"))

    except urllib.error.HTTPError as e:
        results.append(("❌", f"HTTP Error: {e.code} {e.reason}"))
    except urllib.error.URLError as e:
        results.append(("❌", f"Connection failed: {e.reason}"))
    except Exception as e:
        results.append(("❌", f"Unexpected error: {e}"))

    return results


def check_api(base_url, paths):
    print(f"\n🔌 Checking APIs...")
    results = []
    for path in paths:
        url = base_url.rstrip("/") + path
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "PriScylla-Validator/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                status = resp.status
                body = resp.read().decode("utf-8", errors="ignore")
                try:
                    json.loads(body)
                    results.append(("✅", f"{path} → {status} (valid JSON)"))
                except Exception:
                    results.append(("⚠️", f"{path} → {status} (non-JSON response)"))
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                results.append(("⚠️", f"{path} → {e.code} (auth required — may be OK)"))
            else:
                results.append(("❌", f"{path} → {e.code} {e.reason}"))
        except Exception as e:
            results.append(("❌", f"{path} → {e}"))
    return results


# --- Main ---
if len(sys.argv) < 2:
    print("Usage: python3 validate.py <url> [--expect string1 string2...]")
    sys.exit(1)

url = sys.argv[1]
expect = []
if "--expect" in sys.argv:
    idx = sys.argv.index("--expect")
    expect = sys.argv[idx+1:]

# Known project configs
api_checks = {
    "featured-entertainer.vercel.app": ["/api/weekends"],
    "mission-control-cyan-omega.vercel.app": ["/api/tasks", "/api/todos"],
}

results = check_url(url, expect)

# Auto-detect API paths
for domain, paths in api_checks.items():
    if domain in url:
        results += check_api(url, paths)

# Print results
print()
passed = sum(1 for r in results if r[0] == "✅")
failed = sum(1 for r in results if r[0] == "❌")
warned = sum(1 for r in results if r[0] == "⚠️")

for icon, msg in results:
    print(f"  {icon} {msg}")

print(f"\n{'='*40}")
print(f"  {passed} passed  |  {warned} warnings  |  {failed} failed")
if failed > 0:
    print(f"\n❌ DEPLOY VALIDATION FAILED — do not share URL until fixed")
    sys.exit(1)
else:
    print(f"\n✅ Deploy looks good!")
