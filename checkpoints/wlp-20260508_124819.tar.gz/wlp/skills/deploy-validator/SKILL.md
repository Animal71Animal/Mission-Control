---
name: deploy-validator
description: Validate deployed Vercel projects before calling them done. Run after every deployment to verify URLs load, forms work, APIs respond, and no broken links exist. Use when deploying any WLP project, or when user asks "is it working?", "check the deploy", or "make sure it's live". Catches broken deploys before the user finds them.
---

# Deploy Validator

Run after every deployment. Never ship broken.

---

## Quick Check

```bash
python3 /home/ubuntu/wlp/skills/deploy-validator/scripts/validate.py <url>
```

Example:
```bash
python3 /home/ubuntu/wlp/skills/deploy-validator/scripts/validate.py https://featured-entertainer.vercel.app
```

---

## What It Checks

| Check | Method |
|-------|--------|
| URL loads (200 OK) | HTTP GET |
| No redirect to error page | Response URL check |
| Page has content (not blank) | Content-Length / body check |
| Key strings present | String match (configurable) |
| API endpoints respond | HTTP GET on /api/* |

---

## Project-Specific Checks

### Mission Control
- URL: https://mission-control-cyan-omega.vercel.app
- Key strings: `Mission Control`, `wlp2025` login gate
- APIs: `/api/tasks`, `/api/todos`

### Featured Entertainer
- URL: https://featured-entertainer.vercel.app
- Key strings: `Featured Entertainer`, `Spearmint Rhino`
- APIs: `/api/weekends`, `/api/submit`
- Flyer: https://featured-entertainer.vercel.app/flyer.html

### DJ Automation
- URL: https://dj-automation-srb.vercel.app
- Key strings: `DJ Automation`, `Schedule`

---

## Manual Checks (When Script Can't Cover It)

After any form change:
1. Open URL in browser / Playwright screenshot
2. Verify form fields render
3. Verify submit button is clickable
4. Verify checkbox/required fields respond to clicks

---

## Failure Response

If validation fails:
1. Check Vercel build logs: `npx vercel@latest logs <url>`
2. Check for JS errors in the page source
3. Re-deploy: `bash deploy.sh "Fix: [description]"` or `npx vercel@latest deploy --prod --yes`
4. Re-validate

---

## Rules

- Always validate after deploy before reporting success to user
- If validation fails, fix it before sharing the URL
- A URL that returns 200 but is blank is still a failed deploy
