# Data Integrity Checker

## Description

Verifies data consistency across local files, GitHub, and deployed app. Prevents data loss by detecting conflicts and auto-backing up before mutations.

## Usage

```
data-integrity check              # Check all data files
data-integrity check <file>       # Check specific file
data-integrity sync               # Sync local → GitHub
data-integrity backup             # Create manual backup
data-integrity restore <backup>   # Restore from backup
```

## When to Use

- Before modifying data files
- When data seems missing or outdated
- After system recovery
- Weekly health check

## What It Checks

1. **File Consistency:**
   - Local file vs GitHub version
   - GitHub vs deployed app
   - JSON validity
   - Required fields present

2. **Data Integrity:**
   - No duplicate IDs
   - Totals match calculated values
   - Dates are valid
   - References resolve

3. **Backup Status:**
   - Last backup timestamp
   - Backup integrity
   - Recovery options

## Data Files Monitored

| File | Purpose | Critical Fields |
|------|---------|-----------------|
| `srb-tips-data.json` | SRB tip tracking | monthlyTotals, dailyTips, allDancers |
| `tesla-charging.json` | Tesla sessions | sessions, summary, monthly_summary |
| `personal-tasks.json` | Personal todos | id, title, completed, created_at |
| `live-episodes.json` | YouTube episodes | episodes, lastUpdated |

## Examples

### Full check

```bash
data-integrity check
```

Output:
```
🔍 Data Integrity Check

srb-tips-data.json
  ✓ Local ↔ GitHub: synced
  ✓ JSON valid
  ✓ Totals match: $564 April
  ✓ Last backup: 2h ago

tesla-charging.json
  ✓ Local ↔ GitHub: synced
  ✓ JSON valid
  ⚠ Local has uncommitted changes
  ✓ 46 sessions, $733.60 total

personal-tasks.json
  ✓ Local ↔ GitHub: synced
  ✓ JSON valid
  ✓ 1 task, 0 completed

⚠ 1 file needs attention
Run 'data-integrity sync' to fix
```

### Check specific file

```bash
data-integrity check tesla-charging.json
```

### Sync to GitHub

```bash
data-integrity sync
```

Output:
```
🔄 Syncing to GitHub...

srb-tips-data.json: ✓ synced
tesla-charging.json: ✓ committed changes
personal-tasks.json: ✓ synced

✅ All files synced
```

### Pre-mutation backup

```bash
data-integrity backup
```

Output:
```
💾 Creating backup...
✓ Backup: backups/data-20260405_213300.zip
✓ Uploaded to GitHub: backups/data-20260405.zip
✓ Checkpoint: checkpoints/data-20260405_213300
```

## Auto-Backup Triggers

Backups automatically created before:
- Any data file modification
- Adding new Tesla session
- Adding SRB tips
- Modifying personal tasks

## Implementation

See: `scripts/data-integrity.py`

## Recovery

```bash
# List available backups
data-integrity list-backups

# Restore specific backup
data-integrity restore 20260405_213300
```

## Notes

- Always syncs to GitHub before reporting "synced"
- Creates checkpoint on every mutation
- Validates JSON before any operation
- Reports exact discrepancies found
