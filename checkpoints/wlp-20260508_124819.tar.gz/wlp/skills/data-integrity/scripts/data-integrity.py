#!/usr/bin/env python3
"""
Data Integrity Checker - Verify data consistency
Usage: python3 data-integrity.py [check|sync|backup|list-backups|restore]
"""

import os
import sys
import json
import subprocess
import base64
from datetime import datetime
from pathlib import Path

# Config
GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN') or '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'
REPO = 'Animal71Animal/Mission-Control'
BRANCH = 'main'
DATA_DIR = Path('/home/ubuntu/wlp/projects/mission-control/public/data')

def run_cmd(cmd, cwd=None):
    """Run shell command"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
    return result.stdout.strip(), result.stderr.strip(), result.returncode

def get_github_file(path):
    """Get file content from GitHub"""
    import urllib.request
    url = f'https://api.github.com/repos/{REPO}/contents/{path}?ref={BRANCH}'
    headers = {
        'Authorization': f'Bearer {GITHUB_TOKEN}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28'
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            content = base64.b64decode(data['content']).decode('utf-8')
            return content, data['sha']
    except Exception as e:
        return None, None

def commit_to_github(path, content, sha, message):
    """Commit file to GitHub"""
    import urllib.request
    url = f'https://api.github.com/repos/{REPO}/contents/{path}'
    headers = {
        'Authorization': f'Bearer {GITHUB_TOKEN}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type': 'application/json'
    }
    data = {
        'message': message,
        'content': base64.b64encode(content.encode()).decode(),
        'sha': sha,
        'branch': BRANCH
    }
    req = urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers, method='PUT')
    try:
        with urllib.request.urlopen(req) as resp:
            return True
    except Exception as e:
        print(f"    Error: {e}")
        return False

def get_data_files():
    """Get list of data files"""
    files = []
    if DATA_DIR.exists():
        for f in DATA_DIR.glob('*.json'):
            files.append(f)
    return files

def check_file(file_path):
    """Check a single file"""
    rel_path = f'public/data/{file_path.name}'
    
    # Read local
    with open(file_path, 'r') as f:
        local_content = f.read()
    
    # Validate JSON
    try:
        local_json = json.loads(local_content)
        valid_json = True
    except:
        return {'status': 'invalid-json', 'file': file_path.name}
    
    # Get GitHub version
    gh_content, sha = get_github_file(rel_path)
    
    if gh_content is None:
        return {'status': 'new', 'file': file_path.name, 'content': local_content}
    
    # Compare
    if local_content.strip() == gh_content.strip():
        return {'status': 'synced', 'file': file_path.name, 'sha': sha}
    else:
        return {'status': 'modified', 'file': file_path.name, 'sha': sha, 'content': local_content}

def check_all():
    """Check all data files"""
    print("🔍 Data Integrity Check\n")
    
    files = get_data_files()
    if not files:
        print("No data files found")
        return []
    
    results = []
    for file_path in files:
        result = check_file(file_path)
        results.append(result)
        
        status = result['status']
        if status == 'synced':
            print(f"  ✓ {result['file']} — synced")
        elif status == 'modified':
            print(f"  ⚠ {result['file']} — local has changes")
        elif status == 'new':
            print(f"  ⚠ {result['file']} — not on GitHub")
        elif status == 'invalid-json':
            print(f"  ✗ {result['file']} — invalid JSON")
    
    return results

def sync_files(results):
    """Sync modified files to GitHub"""
    print("\n🔄 Syncing to GitHub...\n")
    
    synced = []
    for result in results:
        if result['status'] in ['modified', 'new']:
            file_name = result['file']
            rel_path = f'public/data/{file_name}'
            content = result['content']
            sha = result.get('sha')
            
            print(f"  {file_name}...")
            
            message = f"data: update {file_name}"
            if commit_to_github(rel_path, content, sha, message):
                print(f"    ✓ committed")
                synced.append(file_name)
            else:
                print(f"    ✗ failed")
    
    return synced

def create_backup():
    """Create manual backup"""
    print("💾 Creating backup...\n")
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_dir = Path(f'/home/ubuntu/backups/data-{timestamp}')
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    # Copy data files
    files = get_data_files()
    for file_path in files:
        dest = backup_dir / file_path.name
        subprocess.run(['cp', str(file_path), str(dest)], check=False)
    
    # Create zip
    zip_path = f'/home/ubuntu/backups/data-{timestamp}.zip'
    subprocess.run(['zip', '-r', zip_path, str(backup_dir)], check=False, cwd='/home/ubuntu')
    
    print(f"  ✓ Backup: {zip_path}")
    return zip_path

def list_backups():
    """List available backups"""
    print("📋 Available Backups\n")
    
    backups_dir = Path('/home/ubuntu/backups')
    if not backups_dir.exists():
        print("No backups directory")
        return
    
    backups = sorted(backups_dir.glob('data-*.zip'), reverse=True)
    
    if not backups:
        print("No backups found")
        return
    
    for i, backup in enumerate(backups[:10], 1):
        size = backup.stat().st_size / 1024  # KB
        print(f"  {i}. {backup.name} ({size:.1f} KB)")

def restore_backup(backup_name):
    """Restore from backup"""
    print(f"📥 Restoring from {backup_name}...\n")
    
    backup_path = Path(f'/home/ubuntu/backups/{backup_name}')
    if not backup_path.exists():
        print(f"Backup not found: {backup_path}")
        return False
    
    # Extract
    subprocess.run(['unzip', '-o', str(backup_path), '-d', '/tmp/'], check=False)
    
    # Find extracted files
    extracted_dir = Path(f'/tmp/home/ubuntu/backups/{backup_name.replace(".zip", "")}')
    if not extracted_dir.exists():
        # Try alternative structure
        extracted_dir = Path(f'/tmp/{backup_name.replace(".zip", "")}')
    
    if not extracted_dir.exists():
        print("Could not find extracted files")
        return False
    
    # Copy files back
    for file_path in extracted_dir.glob('*.json'):
        dest = DATA_DIR / file_path.name
        subprocess.run(['cp', str(file_path), str(dest)], check=False)
        print(f"  ✓ Restored {file_path.name}")
    
    print("\n✅ Restore complete")
    print("Run 'data-integrity.py sync' to push to GitHub")
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: data-integrity.py [check|sync|backup|list-backups|restore]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'check':
        results = check_all()
        modified = [r for r in results if r['status'] in ['modified', 'new']]
        if modified:
            print(f"\n⚠ {len(modified)} files need syncing")
            print("Run 'data-integrity.py sync' to fix")
        else:
            print("\n✅ All files synced")
    
    elif command == 'sync':
        results = check_all()
        modified = [r for r in results if r['status'] in ['modified', 'new']]
        if modified:
            synced = sync_files(modified)
            print(f"\n✅ Synced {len(synced)} files")
        else:
            print("\n✅ Nothing to sync")
    
    elif command == 'backup':
        backup_path = create_backup()
        print(f"\n✅ Backup created: {backup_path}")
    
    elif command == 'list-backups':
        list_backups()
    
    elif command == 'restore':
        if len(sys.argv) < 3:
            print("Usage: data-integrity.py restore <backup-name>")
            list_backups()
            sys.exit(1)
        restore_backup(sys.argv[2])
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

if __name__ == '__main__':
    main()
