# Subagent Orchestration Skill

**For:** PriScylla (main agent)  
**Purpose:** Autonomous task delegation to 8-agent system  
**Status:** Production-ready  
**Created:** 2026-04-22

---

## Overview

This skill defines how I (PriScylla) autonomously decide whether to handle a task myself or delegate to a subagent. It ensures consistent, high-quality task routing without requiring Eric to specify.

**Core principle:** Tasks get delegated based on **fit + value**, not laziness.

---

## The 8-Agent System

| Agent | Discipline | Model | Best For |
|-------|-----------|-------|----------|
| Langostino | Marketing | Sonnet 4 | Brand narrative, positioning, content strategy |
| Homard | Finance | Haiku | Metrics, analysis, forecasting, revenue tracking |
| Clawdia | Operations | Sonnet 4 | Infrastructure, deployment, automation, system health |
| Shelly | A&R/Artists | Sonnet 4 | Release strategy, artist positioning, streaming ops |
| Rockwell | Production | Sonnet 4 | Mixing, mastering, sound design, quality assurance |
| Barnaby | Business Dev | Opus | Partnerships, licensing deals, B2B strategy |
| Sebastian | Legal/Admin | Sonnet 4 | Compliance, PRO registration, contracts, IP |
| Coral | R&D/Innovation | Opus | Research, competitive analysis, tech monitoring |

---

## Decision Framework

### Step 1: Task Characteristics

Ask myself these 7 questions:

```
1. Does this task fit one agent's discipline perfectly?  
   YES → likely spawn
   NO → likely do it myself

2. Is this 30+ minutes of work OR complex multi-step?  
   YES → likely spawn
   NO → likely do it myself

3. Can this run in parallel (Eric works on other things)?  
   YES → spawn
   NO → do it myself (need to stay available)

4. Is this self-contained (no mid-work input from Eric)?  
   YES → spawn
   NO → do it myself (needs back-and-forth)

5. Is agent expertise significantly better than my quick attempt?  
   YES → spawn (Rockwell on mixing > me guessing)
   NO → do it myself

6. Is this repeatable work that benefits from specialization?  
   YES → spawn (gets better each time with agent focus)
   NO → do it myself

7. Does Eric need answer immediately?  
   YES → do it myself
   NO → spawn (can wait for background execution)
```

### Step 2: Scoring

**Spawn threshold:** 5+ YES answers → spawn  
**Do myself threshold:** 3+ NO answers → do it myself  
**Gray area (4-3):** Use gut judgment + "what's best for Eric?"

---

## When to Spawn (Examples)

### ✅ SPAWN
- "Create a release strategy for Madison Blair" → Shelly (1h, domain expert, self-contained, parallel)
- "Analyze SRB revenue YTD" → Homard (finance domain, metrics work, can run overnight)
- "Draft partnership inquiry emails for licensing platforms" → Barnaby (BD domain, repeatable, parallel)
- "Research Suno v5.5 and recommend adoption" → Coral (R&D domain, research, can wait)
- "Create PRO registration checklist for Madison" → Sebastian (legal domain, self-contained, reusable)

### ❌ DO MYSELF
- "What's Madison's current status?" → Quick synthesis, Eric needs answer now
- "Should we release Kade or Madison first?" → Decision support, needs Eric's input/judgment
- "Send a message to Discord about X" → Quick, administrative
- "Summarize last week's wins" → Quick synthesis, <10 min
- "Coordinate between Shelly and Rockwell on track quality" → Coordination, I need oversight

---

## Spawning Process

When I decide to spawn:

```
1. Identify agent + discipline match
2. Create context preamble:
   - Agent reads: [Agent] PROFILE.md
   - Agent reads: agent-context.json
   - Agent reads: MEMORY.md
   - Then: [actual task]

3. Include task details:
   - Goal: What success looks like
   - Context: Background, constraints
   - Deliverable: Format/output expected
   - Deadline: Timeline (if any)

4. Spawn via sessions_spawn(runtime=subagent, task=..., model=[agent's model])

5. Yield and wait for completion

6. On completion:
   - Review deliverable quality
   - Report results to Eric (brief summary)
   - Update agent-status.json if needed
   - Log to #[agent-name] Discord channel via webhook (when webhooks live)
```

---

## Task Templates

### Full Task (30+ min, complex)
```
CONTEXT READS:
1. /home/ubuntu/wlp/agents/[AGENT]/PROFILE.md
2. /home/ubuntu/wlp/data/agent-context.json
3. /home/ubuntu/MEMORY.md

TASK: [Specific work to do]

GOAL: [What success looks like]
DELIVERABLE: [Format/output]
DEADLINE: [When needed, if urgent]
CONSTRAINTS: [Budget, scope, tech limits]
```

### Quick Task (<30 min, focused)
```
CONTEXT READS:
1. /home/ubuntu/wlp/agents/[AGENT]/PROFILE.md
2. /home/ubuntu/MEMORY.md (abbreviated if quick)

TASK: [Specific work to do]

DELIVERABLE: [Format]
DEADLINE: [If any]
```

---

## Reporting Results

After agent completes:

1. **Quality check:** Is this what Eric needs? Does it match deliverable?
2. **Summary:** 1-2 sentence recap of what the agent did
3. **Output:** Key findings, recommendations, next steps
4. **Blockers:** Any issues encountered? Escalations needed?
5. **Discord post:** Via webhook to agent's channel (future automation)

---

## Edge Cases

### When Spawning Fails
- Agent times out (>4 min) → Kill + do it myself
- Agent gets stuck → Kill + try different approach
- Output quality poor → Rerun with clearer task, or do myself

### When I Should Intervene
- Agent asks for clarification → Provide it, they rerun
- Agent encounters blocker → Help them (or escalate to Eric)
- Agent output needs refinement → Send back for revision

### When to Escalate to Eric
- Decision requires Eric's judgment
- Budget/hiring decision needed
- Public-facing work (verify tone/messaging first)
- Any legal/compliance concern

---

## Parallel Execution

**The beauty:** While Shelly plans a release, Homard analyzes revenue, and Clawdia fixes infrastructure — I can help Eric on other things simultaneously.

**Limit:** Don't spawn 8 agents at once (too many completions to manage). 2-3 parallel is sweet spot.

**Tracking:** Use agent-status.json to see who's working on what.

---

## Continuous Learning

- **Weekly:** Review agent PROFILE.md files — are they accurate?
- **Monthly:** Assess which agents overperform (trust them more)
- **Quarterly:** Evaluate model assignments — are Haiku/Sonnet/Opus right?
- **As needed:** Update MEMORY.md with new patterns, learnings

---

## Remember

- **Autonomy = better for Eric.** He focuses on decisions, agents execute.
- **Fit > speed.** Shelly designs releases better than me, even if it takes longer.
- **Parallel > sequential.** Multiple agents working = faster overall.
- **Quality > speed.** A slower, excellent deliverable beats a fast mediocre one.
- **Communication > silence.** Always report what agents did and why.

---

**Version:** 1.0 | **Last Updated:** 2026-04-22 | **Status:** Ready to enforce


---

## Status Tracking Integration (2026-04-22 Update)

Agent status is now **automatically tracked** in Mission Control.

**Workflow:**
1. When I spawn agent → I run update script with in-progress
2. Agent works in background
3. When agent completes → I run update script with completed or blocked
4. Mission Control refreshes in real-time (30-second intervals)
5. Eric sees 8 agents with task counts, status lights, blockers

**Command:**
python3 /home/ubuntu/wlp/scripts/update-agent-status.py [agent] "[task]" [status] "[blockers]"

**Status values:** in-progress, completed, blocked, idle

**Result:** Every agent assignment is visible in Mission Control. No guessing who's working on what.

See /home/ubuntu/wlp/skills/agent-status-tracker/SKILL.md for full details.
