---
name: ableton-organize
description: Recursively organize Ableton Live folders into Ableton's native User Library structure. Scans all subfolders, identifies 100+ file extensions, auto-categorizes audio by type (drums, synths, vocals, FX, loops), aligns presets to User Library, deletes orphan .asd files, and logs unknown extensions. No backup by default for speed. Works on 100GB+ libraries.
---

# Ableton Folder Organization

One script. Scans everything. Puts it where Ableton expects it.

## Quick Start

Send the user the script file at `scripts/organize-ableton.sh`. They run:

```bash
chmod +x ~/Downloads/organize-ableton.sh && ~/Downloads/organize-ableton.sh
```

After completion: **Ableton → Preferences → Library → User Library** → point to the `User Library` folder.

## What It Does

1. Backs up entire folder first (safe)
2. Recursively scans entire folder tree
3. Identifies files by extension (100+ mapped)
4. Categorizes audio by filename + parent folder path keywords
5. Creates Ableton-native User Library structure
6. Deletes orphan `.asd` files (Ableton recreates them)
7. Logs unknown extensions to `~/ableton-unknown-extensions.txt`
8. Cleans up empty folders
9. Prints report with file counts per category

## Companion Scripts

Also available in `scripts/`:

- **`merge-project-dupes.sh`** — Merges duplicate project folders (`Song-1`, `Song-v2` → `Song`). Also searches for SRB SoundBoard files.
- **`remove-dupes.sh`** — Removes duplicate files within the same folder (keeps different-folder duplicates).
- **`organize-others.sh`** — Specifically targets the `Others/` folder with smart extension handling.
- **`organize-samplepacks.sh`** — Targets `Others/Music Samples and Packs/` for bulk sample pack organization.

## Target Structure

```
Ableton/
├── User Library/
│   ├── Presets/
│   │   ├── Instruments/    (.fxp .fxb .nmsv .nki .ksd .adg .sf2 .aupreset)
│   │   ├── Audio Effects/  (.adv .tfx .vstpreset)
│   │   ├── MIDI Effects/
│   │   ├── Max Instrument/ (.amxd .maxpat)
│   │   └── Max Audio Effect/
│   ├── Clips/              (.alc)
│   ├── Grooves/            (.agr)
│   ├── Templates/
│   └── Defaults/
├── Projects/               (.als .alp)
├── Samples/
│   ├── Drums/              kick snare hat clap tom perc 808 909 ride crash
│   ├── Synths/             synth bass lead sub pluck arp reese wobble
│   ├── Pads/               pad chord string ambient texture drone
│   ├── Vocals/             vocal vox acapella voice sing rap
│   ├── FX/                 fx effect whoosh impact sweep riser transition
│   ├── Loops/              loop break groove bpm pattern beat
│   ├── One-Shots/          shot stab hitz
│   ├── Instruments/        piano guitar horn organ violin sax trumpet
│   └── Other/              (unmatched audio)
├── MIDI/                   (.mid .midi)
├── Audio Recordings/       (freeze files, regions)
├── Exports/
├── Reference Tracks/
├── Plugin Data/            (.vst .vst3 .component .dll)
├── Video/                  (.mp4 .mov)
├── Docs/                   (.pdf .txt .xml .jpg .png)
└── Archive/                (.zip .rar .dmg + unknown extensions)
```

## Extension Map

| Extension | Destination |
|-----------|------------|
| `.als` `.alp` | Projects |
| `.alc` | User Library/Clips |
| `.asd` | DELETE (orphan analysis files) |
| `.wav` `.mp3` `.aiff` `.flac` `.ogg` `.m4a` | Smart audio categorization |
| `.rx2` `.rex` | Samples/Loops |
| `.mid` `.midi` | MIDI |
| `.fxp` `.fxb` `.aupreset` `.vstpreset` | User Library/Presets/Instruments |
| `.nmsv` `.nfm` `.nki` `.nkm` `.nks` | User Library/Presets/Instruments |
| `.ksd` `.kmp` `.ksf` | User Library/Presets/Instruments |
| `.adg` `.ams` `.sf2` `.sfz` `.gig` | User Library/Presets/Instruments |
| `.adv` `.tfx` | User Library/Presets/Audio Effects |
| `.agr` | User Library/Grooves |
| `.amxd` `.maxpat` | User Library/Presets/Max Instrument |
| `.vst` `.vst3` `.component` `.dll` | Plugin Data |
| `.pdf` `.txt` `.xml` `.html` `.nfo` | Docs |
| `.jpg` `.png` `.gif` `.psd` | Docs |
| `.mp4` `.mov` `.avi` | Video |
| `.zip` `.rar` `.dmg` `.pkg` | Archive |
| Unknown | Archive + logged |

## Audio Categorization

Matches filename AND parent folder path (case-insensitive):

- **Drums:** kick kik snare snr clap tom perc shaker hh hihat ride crash cymbal rim 808 909 conga bongo tamb cowbell
- **Synths:** synth bass lead sub pluck arp reese wobble growl
- **Pads:** pad chord string ambient atmo texture drone evolv
- **Vocals:** vocal acapella vox voice sing rap spoken chant
- **FX:** fx effect whoosh impact sweep riser transition reverse swell noise noize sfx
- **Loops:** loop break groove bpm pattern beat
- **One-Shots:** shot stab hitz
- **Instruments:** piano guitar horn organ violin brass flute cello trumpet sax harp bell mallet kalimba
- **Audio Recordings:** freeze region
- **Other:** everything else

## Progress Check

While running, open new Terminal tab:

```bash
ps aux | grep organize-ableton
```

## Troubleshooting

**Directory not found** — Verify path: `ls -la "/Users/animal/Music Production/Ableton"`

**Files stuck in Other** — Check filenames. Rename to include keywords and re-run.

**Ableton not seeing presets** — Preferences → Library → set User Library path → restart Ableton.

**Unknown extensions** — Check `~/ableton-unknown-extensions.txt` and manually move if needed.

**Duplicate project folders** — Run `merge-project-dupes.sh` to consolidate `Song-1`, `Song-v2`, etc.

**SRB SoundBoard files missing** — Run `merge-project-dupes.sh` — it searches and reports their location.

## Project Organization Best Practices

After running the main script, organize `.als` projects into subfolders:

```
Projects/
├── 2026-Kade-Rivers/
│   └── Song-Name/
│       └── Song-Name.als
├── 2026-Madison-Blair/
├── 2026-Aria-Vale/
├── Live-Sets/
│   └── SRB-Friday/
│       └── SRB-Friday.als
├── DJ-Sets/
├── Remixes/
├── Drafts/
└── 2026-Other/
```

Each `.als` file lives in its own folder named after the project. This keeps samples, exports, and project data together.
