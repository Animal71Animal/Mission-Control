#!/bin/bash
MUSIC_DIR="/Users/animal/Music Production/Ableton"
LOGFILE="$HOME/ableton-final-log.txt"
UNKNOWNS="$HOME/ableton-final-unknown.txt"
echo "" > "$LOGFILE"
echo "" > "$UNKNOWNS"

echo "Final Ableton organization pass..."
echo "Aligning to Ableton User Library structure..."

echo "Creating backup..."
BACKUP_DIR="$MUSIC_DIR/.backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -r "$MUSIC_DIR"/* "$BACKUP_DIR/" 2>/dev/null || true
echo "Backup complete: $BACKUP_DIR"

# Ableton's native User Library structure
mkdir -p "$MUSIC_DIR/User Library/Presets/Audio Effects"
mkdir -p "$MUSIC_DIR/User Library/Presets/Instruments"
mkdir -p "$MUSIC_DIR/User Library/Presets/MIDI Effects"
mkdir -p "$MUSIC_DIR/User Library/Presets/Max Audio Effect"
mkdir -p "$MUSIC_DIR/User Library/Presets/Max Instrument"
mkdir -p "$MUSIC_DIR/User Library/Presets/Max MIDI Effect"
mkdir -p "$MUSIC_DIR/User Library/Samples"
mkdir -p "$MUSIC_DIR/User Library/Clips"
mkdir -p "$MUSIC_DIR/User Library/Defaults"
mkdir -p "$MUSIC_DIR/User Library/Grooves"
mkdir -p "$MUSIC_DIR/User Library/Templates"

# Production-friendly additions
mkdir -p "$MUSIC_DIR/Projects"
mkdir -p "$MUSIC_DIR/Samples/Drums"
mkdir -p "$MUSIC_DIR/Samples/Synths"
mkdir -p "$MUSIC_DIR/Samples/Pads"
mkdir -p "$MUSIC_DIR/Samples/Vocals"
mkdir -p "$MUSIC_DIR/Samples/FX"
mkdir -p "$MUSIC_DIR/Samples/Loops"
mkdir -p "$MUSIC_DIR/Samples/One-Shots"
mkdir -p "$MUSIC_DIR/Samples/Instruments"
mkdir -p "$MUSIC_DIR/Samples/Other"
mkdir -p "$MUSIC_DIR/MIDI"
mkdir -p "$MUSIC_DIR/Exports"
mkdir -p "$MUSIC_DIR/Audio Recordings"
mkdir -p "$MUSIC_DIR/Reference Tracks"
mkdir -p "$MUSIC_DIR/Archive"
mkdir -p "$MUSIC_DIR/Plugin Data"
mkdir -p "$MUSIC_DIR/Video"
mkdir -p "$MUSIC_DIR/Docs"

get_dest_by_ext() {
  local ext=$(echo "$1" | tr '[:upper:]' '[:lower:]')
  case "$ext" in
    als|alp) echo "Projects" ;;
    alc) echo "User Library/Clips" ;;
    asd) echo "DELETE" ;;
    wav|wave|mp3|aiff|aif|flac|ogg|m4a|aac|wma|opus|caf|w64) echo "AUDIO" ;;
    rx2|rex|rex2) echo "Samples/Loops" ;;
    mid|midi) echo "MIDI" ;;
    nmsv|nfm|nki|nkm|nkc|nkx|nkr|nks|nbkt) echo "User Library/Presets/Instruments" ;;
    ens|rkplr) echo "User Library/Presets/Instruments" ;;
    mxgrp|mxsnd|mxpat|mxprj|mxkit) echo "User Library/Presets/Instruments" ;;
    fxp|fxb) echo "User Library/Presets/Instruments" ;;
    aupreset|vstpreset) echo "User Library/Presets/Instruments" ;;
    ksd|kmp|ksf) echo "User Library/Presets/Instruments" ;;
    adg) echo "User Library/Presets/Instruments" ;;
    adv) echo "User Library/Presets/Audio Effects" ;;
    agr) echo "User Library/Grooves" ;;
    ams) echo "User Library/Presets/Instruments" ;;
    amxd) echo "User Library/Presets/Max Instrument" ;;
    maxpat|maxhelp|mxf) echo "User Library/Presets/Max Instrument" ;;
    sf2|sfz|sf3|gig) echo "User Library/Presets/Instruments" ;;
    tfx) echo "User Library/Presets/Audio Effects" ;;
    dll|vst|vst3|component|dylib|so) echo "Plugin Data" ;;
    xml) echo "Docs" ;;
    pdf|txt|rtf|doc|docx|md|html|htm|nfo) echo "Docs" ;;
    jpg|jpeg|png|gif|bmp|tif|tiff|svg|ico|webp|psd|ai) echo "Docs" ;;
    mp4|mov|avi|mkv|wmv|flv|m4v|webm) echo "Video" ;;
    zip|rar|7z|gz|tar|dmg|iso|pkg|sit|sitx) echo "Archive" ;;
    ds_store|db|ini|cfg|log|plist|json) echo "SKIP" ;;
    torrent|exe|msi|app) echo "Archive" ;;
    *) echo "UNKNOWN" ;;
  esac
}

categorize_audio() {
  local filepath="$1"
  local name=$(basename "$filepath" | tr '[:upper:]' '[:lower:]')
  local path=$(echo "$filepath" | tr '[:upper:]' '[:lower:]')
  if [[ "$name" == *"kick"* ]] || [[ "$name" == *"kik"* ]] || [[ "$name" == *"snare"* ]] || [[ "$name" == *"snr"* ]] || [[ "$name" == *"clap"* ]] || [[ "$name" == *"tom"* ]] || [[ "$name" == *"perc"* ]] || [[ "$name" == *"shaker"* ]] || [[ "$name" == *"_hh"* ]] || [[ "$name" == *"hihat"* ]] || [[ "$name" == *"hi-hat"* ]] || [[ "$name" == *"ride"* ]] || [[ "$name" == *"crash"* ]] || [[ "$name" == *"cymbal"* ]] || [[ "$name" == *"rim"* ]] || [[ "$name" == *"808"* ]] || [[ "$name" == *"909"* ]] || [[ "$name" == *"conga"* ]] || [[ "$name" == *"bongo"* ]] || [[ "$name" == *"tamb"* ]] || [[ "$name" == *"cowbell"* ]] || [[ "$path" == *"/drum"* ]] || [[ "$path" == *"/kick"* ]] || [[ "$path" == *"/snare"* ]] || [[ "$path" == *"/perc"* ]]; then
    echo "Samples/Drums"
  elif [[ "$name" == *"pad"* ]] || [[ "$name" == *"chord"* ]] || [[ "$name" == *"string"* ]] || [[ "$name" == *"ambient"* ]] || [[ "$name" == *"atmo"* ]] || [[ "$name" == *"texture"* ]] || [[ "$name" == *"drone"* ]] || [[ "$name" == *"evolv"* ]] || [[ "$path" == *"/pad"* ]] || [[ "$path" == *"/ambient"* ]]; then
    echo "Samples/Pads"
  elif [[ "$name" == *"synth"* ]] || [[ "$name" == *"bass"* ]] || [[ "$name" == *"lead"* ]] || [[ "$name" == *"sub"* ]] || [[ "$name" == *"pluck"* ]] || [[ "$name" == *"arp"* ]] || [[ "$name" == *"reese"* ]] || [[ "$name" == *"wobble"* ]] || [[ "$name" == *"growl"* ]] || [[ "$path" == *"/synth"* ]] || [[ "$path" == *"/bass"* ]] || [[ "$path" == *"/lead"* ]]; then
    echo "Samples/Synths"
  elif [[ "$name" == *"vocal"* ]] || [[ "$name" == *"acapella"* ]] || [[ "$name" == *"vox"* ]] || [[ "$name" == *"voice"* ]] || [[ "$name" == *"sing"* ]] || [[ "$name" == *"rap"* ]] || [[ "$name" == *"spoken"* ]] || [[ "$name" == *"chant"* ]] || [[ "$path" == *"/vocal"* ]] || [[ "$path" == *"/vox"* ]]; then
    echo "Samples/Vocals"
  elif [[ "$name" == *"_fx"* ]] || [[ "$name" == *"effect"* ]] || [[ "$name" == *"whoosh"* ]] || [[ "$name" == *"impact"* ]] || [[ "$name" == *"sweep"* ]] || [[ "$name" == *"riser"* ]] || [[ "$name" == *"transition"* ]] || [[ "$name" == *"reverse"* ]] || [[ "$name" == *"swell"* ]] || [[ "$name" == *"noise"* ]] || [[ "$name" == *"noize"* ]] || [[ "$name" == *"sfx"* ]] || [[ "$path" == *"/fx"* ]] || [[ "$path" == *"/effect"* ]]; then
    echo "Samples/FX"
  elif [[ "$name" == *"loop"* ]] || [[ "$name" == *"break"* ]] || [[ "$name" == *"groove"* ]] || [[ "$name" == *"bpm"* ]] || [[ "$name" == *"pattern"* ]] || [[ "$name" == *"beat"* ]] || [[ "$path" == *"/loop"* ]] || [[ "$path" == *"/groove"* ]]; then
    echo "Samples/Loops"
  elif [[ "$name" == *"shot"* ]] || [[ "$name" == *"stab"* ]] || [[ "$name" == *"hitz"* ]] || [[ "$path" == *"/one-shot"* ]] || [[ "$path" == *"/oneshot"* ]]; then
    echo "Samples/One-Shots"
  elif [[ "$name" == *"piano"* ]] || [[ "$name" == *"guitar"* ]] || [[ "$name" == *"horn"* ]] || [[ "$name" == *"organ"* ]] || [[ "$name" == *"violin"* ]] || [[ "$name" == *"brass"* ]] || [[ "$name" == *"flute"* ]] || [[ "$name" == *"cello"* ]] || [[ "$name" == *"trumpet"* ]] || [[ "$name" == *"sax"* ]] || [[ "$name" == *"harp"* ]] || [[ "$name" == *"bell"* ]] || [[ "$name" == *"mallet"* ]] || [[ "$name" == *"kalimba"* ]] || [[ "$path" == *"/instrument"* ]] || [[ "$path" == *"/piano"* ]] || [[ "$path" == *"/guitar"* ]]; then
    echo "Samples/Instruments"
  elif [[ "$name" == *"freeze"* ]] || [[ "$name" == *"region"* ]]; then
    echo "Audio Recordings"
  else
    echo "Samples/Other"
  fi
}

echo "Scanning all files..."

find "$MUSIC_DIR" -type f 2>/dev/null | grep -v ".backup-" | grep -v "/User Library/" | grep -v ".DS_Store" | while read f; do
  filename=$(basename "$f")
  ext="${filename##*.}"
  dest=$(get_dest_by_ext "$ext")
  if [ "$dest" = "SKIP" ]; then
    continue
  elif [ "$dest" = "DELETE" ]; then
    rm "$f" 2>/dev/null
    echo "DELETED: $filename" >> "$LOGFILE"
  elif [ "$dest" = "AUDIO" ]; then
    audiodest=$(categorize_audio "$f")
    mv "$f" "$MUSIC_DIR/$audiodest/" 2>/dev/null && echo "MOVED: $filename -> $audiodest" >> "$LOGFILE"
  elif [ "$dest" = "UNKNOWN" ]; then
    echo "$ext - $filename" >> "$UNKNOWNS"
    mv "$f" "$MUSIC_DIR/Archive/" 2>/dev/null
    echo "UNKNOWN: $filename ($ext) -> Archive" >> "$LOGFILE"
  else
    mv "$f" "$MUSIC_DIR/$dest/" 2>/dev/null && echo "MOVED: $filename -> $dest" >> "$LOGFILE"
  fi
done

# Move old Presets into User Library structure
if [ -d "$MUSIC_DIR/Presets/Instruments" ]; then
  find "$MUSIC_DIR/Presets/Instruments" -type f | while read f; do
    mv "$f" "$MUSIC_DIR/User Library/Presets/Instruments/" 2>/dev/null
  done
fi
if [ -d "$MUSIC_DIR/Presets/Effects" ]; then
  find "$MUSIC_DIR/Presets/Effects" -type f | while read f; do
    mv "$f" "$MUSIC_DIR/User Library/Presets/Audio Effects/" 2>/dev/null
  done
fi
if [ -d "$MUSIC_DIR/Presets/MIDI" ]; then
  find "$MUSIC_DIR/Presets/MIDI" -type f | while read f; do
    mv "$f" "$MUSIC_DIR/User Library/Presets/MIDI Effects/" 2>/dev/null
  done
fi
if [ -d "$MUSIC_DIR/Templates" ]; then
  find "$MUSIC_DIR/Templates" -type f | while read f; do
    mv "$f" "$MUSIC_DIR/User Library/Templates/" 2>/dev/null
  done
fi

# Move existing Ableton User Library if separate
if [ -d "$MUSIC_DIR/Ableton User Llibrary" ]; then
  find "$MUSIC_DIR/Ableton User Llibrary" -type f | while read f; do
    filename=$(basename "$f")
    ext="${filename##*.}"
    dest=$(get_dest_by_ext "$ext")
    if [ "$dest" = "SKIP" ] || [ "$dest" = "DELETE" ]; then
      rm "$f" 2>/dev/null
    elif [ "$dest" = "AUDIO" ]; then
      audiodest=$(categorize_audio "$f")
      mv "$f" "$MUSIC_DIR/$audiodest/" 2>/dev/null
    else
      mv "$f" "$MUSIC_DIR/$dest/" 2>/dev/null
    fi
  done
fi

echo "Cleaning up empty folders..."
find "$MUSIC_DIR" -type d -empty ! -path "*/.backup-*" -delete 2>/dev/null || true

echo ""
echo "Done!"
echo ""
echo "-- FINAL STRUCTURE --"
find "$MUSIC_DIR" -maxdepth 3 -type d ! -name ".backup-*" 2>/dev/null | sort | sed "s|$MUSIC_DIR/||g" | sed 's/^/  /'
echo ""
echo "-- FILE COUNTS --"
for dir in Projects "User Library/Presets/Instruments" "User Library/Presets/Audio Effects" "User Library/Presets/MIDI Effects" "User Library/Presets/Max Instrument" "User Library/Clips" "User Library/Grooves" "User Library/Templates" "Samples/Drums" "Samples/Synths" "Samples/Pads" "Samples/Vocals" "Samples/FX" "Samples/Loops" "Samples/One-Shots" "Samples/Instruments" "Samples/Other" MIDI Exports "Audio Recordings" "Reference Tracks" Archive "Plugin Data" Video Docs; do
  count=$(find "$MUSIC_DIR/$dir" -type f 2>/dev/null | wc -l)
  if [ "$count" -gt 0 ]; then
    echo "  $dir: $count files"
  fi
done
echo ""
echo "Total size: $(du -sh "$MUSIC_DIR" | cut -f1)"
echo ""
if [ -s "$UNKNOWNS" ]; then
  echo "-- UNKNOWN EXTENSIONS --"
  sort -u "$UNKNOWNS"
fi
echo ""
echo "Log: $LOGFILE"
echo ""
echo "NEXT STEP: Open Ableton -> Preferences -> Library"
echo "Set User Library to: $MUSIC_DIR/User Library"
echo "Ableton will auto-discover all presets, clips, and grooves."
echo ""
echo "Ready to produce!"
