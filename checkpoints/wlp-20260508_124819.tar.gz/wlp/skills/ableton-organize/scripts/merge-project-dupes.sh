#!/bin/bash
PROJECTS_DIR="/Users/animal/Music Production/Ableton/Projects"

echo "Merging exact duplicate project folders..."

# Function to get base name (remove trailing numbers)
get_base_name() {
    echo "$1" | sed -E 's/[._-]?[0-9]+$//' | sed -E 's/[._-]?v[0-9]+$//' | sed 's/[._-]$//'
}

# Find all folders and group by base name
find "$PROJECTS_DIR" -mindepth 2 -maxdepth 2 -type d | sort | while read folder; do
    basename=$(basename "$folder")
    base=$(get_base_name "$basename")
    parent=$(dirname "$folder")
    target="$parent/$base"
    
    # Skip if already the base name
    if [ "$basename" = "$base" ]; then
        continue
    fi
    
    # If target exists, merge into it
    if [ -d "$target" ] && [ "$folder" != "$target" ]; then
        echo "Merging: $basename -> $base"
        find "$folder" -maxdepth 1 -type f | while read f; do
            mv "$f" "$target/" 2>/dev/null
        done
        rmdir "$folder" 2>/dev/null || true
    # If target doesn't exist, rename to base
    elif [ ! -d "$target" ]; then
        echo "Renaming: $basename -> $base"
        mv "$folder" "$target" 2>/dev/null
    fi
done

echo "Cleaning up empty folders..."
find "$PROJECTS_DIR" -type d -empty -delete 2>/dev/null || true

echo "Done!"

echo ""
echo "Searching for SRB SoundBoard files..."
find "$PROJECTS_DIR" -type f -iname "*srb*" -o -iname "*soundboard*" 2>/dev/null

echo ""
echo "Project folders after merge:"
find "$PROJECTS_DIR" -maxdepth 2 -type d | sort | sed "s|$PROJECTS_DIR/||g" | sed 's/^/  /'
