#!/bin/bash
MUSIC_DIR="/Users/animal/Music Production/Ableton"
echo "Removing duplicate files in same folders..."
find "$MUSIC_DIR" -type d | while read dir; do
  find "$dir" -maxdepth 1 -type f ! -name ".DS_Store" | sort | while read f; do
    name=$(basename "$f")
    size=$(stat -f%z "$f" 2>/dev/null)
    find "$dir" -maxdepth 1 -type f -name "$name" ! -path "$f" | while read dupe; do
      dupesize=$(stat -f%z "$dupe" 2>/dev/null)
      if [ "$size" = "$dupesize" ]; then
        echo "Removing: $dupe"
        rm "$dupe"
      fi
    done
  done
done
echo "Done!"
