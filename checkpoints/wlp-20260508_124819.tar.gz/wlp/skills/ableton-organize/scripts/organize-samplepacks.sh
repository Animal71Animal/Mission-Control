#!/bin/bash
MUSIC_DIR="/Users/animal/Music Production/Ableton"
SOURCE="$MUSIC_DIR/Others/Music Samples and Packs"
LOGFILE="$HOME/ableton-samplepacks-log.txt"
UNKNOWNS="$HOME/ableton-samplepacks-unknown.txt"
echo "" > "$LOGFILE"
echo "" > "$UNKNOWNS"

if [ ! -d "$SOURCE" ]; then
  echo "Folder not found: $SOURCE"
  exit 1
fi

echo "Organizing Music Samples and Packs..."

get_dest_by_ext() {
  local ext=$(echo "$1" | tr '[:upper:]' '[:lower:]')
  case "$ext" in
    als|alp|alc) echo "Projects" ;;
    asd) echo "SKIP" ;;
    wav|wave|mp3|aiff|aif|flac|ogg|m4a|aac|wma|opus|caf|w64) echo "AUDIO" ;;
    rx2|rex|rex2) echo "Samples/Loops" ;;
    mid|midi) echo "MIDI" ;;
    nmsv|nfm|nki|nkm|nkc|nkx|nkr|nks|nbkt) echo "Presets/Instruments" ;;
    ens|rkplr) echo "Presets/Instruments" ;;
    mxgrp|mxsnd|mxpat|mxprj|mxkit) echo "Presets/Instruments" ;;
    fxp|fxb) echo "Presets/Instruments" ;;
    aupreset|vstpreset) echo "Presets/Instruments" ;;
    ksd|kmp|ksf) echo "Presets/Instruments" ;;
    adg|adv|agr|ams|amxd) echo "Presets/Instruments" ;;
    maxpat|maxhelp|mxf) echo "Presets/Instruments" ;;
    sf2|sfz|sf3|gig) echo "Presets/Instruments" ;;
    tfx) echo "Presets/Effects" ;;
    dll|vst|vst3|component|dylib|so) echo "Plugin Data" ;;
    xml) echo "Docs" ;;
    pdf|txt|rtf|doc|docx|md|html|htm|nfo) echo "Docs" ;;
    jpg|jpeg|png|gif|bmp|tif|tiff|svg|ico|webp|psd|ai) echo "Docs" ;;
    mp4|mov|avi|mkv|wmv|flv|m4v|webm) echo "Video" ;;
    zip|rar|7z|gz|tar|dmg|iso|pkg|sit|sitx) echo "Archive" ;;
    ds_store|db|ini|cfg|log|plist|json) echo "SKIP" ;;
    torrent|exe|msi|app) echo "Archive" ;;
    *) echo "UNKNOWN" ;;
  esac
}

categorize_audio() {
  local filepath="$1"
  local name=$(basename "$filepath" | tr '[:upper:]' '[:lower:]')
  local path=$(echo "$filepath" | tr '[:upper:]' '[:lower:]')
  if [[ "$name" == *"kick"* ]] || [[ "$name" == *"kik"* ]] || [[ "$name" == *"snare"* ]] || [[ "$name" == *"snr"* ]] || [[ "$name" == *"clap"* ]] || [[ "$name" == *"tom"* ]] || [[ "$name" == *"perc"* ]] || [[ "$name" == *"shaker"* ]] || [[ "$name" == *"_hh"* ]] || [[ "$name" == *"hihat"* ]] || [[ "$name" == *"hi-hat"* ]] || [[ "$name" == *"ride"* ]] || [[ "$name" == *"crash"* ]] || [[ "$name" == *"cymbal"* ]] || [[ "$name" == *"rim"* ]] || [[ "$name" == *"808"* ]] || [[ "$name" == *"909"* ]] || [[ "$name" == *"conga"* ]] || [[ "$name" == *"bongo"* ]] || [[ "$name" == *"tamb"* ]] || [[ "$name" == *"cowbell"* ]] || [[ "$path" == *"/drum"* ]] || [[ "$path" == *"/kick"* ]] || [[ "$path" == *"/snare"* ]] || [[ "$path" == *"/perc"* ]]; then
    echo "Samples/Drums"
  elif [[ "$name" == *"pad"* ]] || [[ "$name" == *"chord"* ]] || [[ "$name" == *"string"* ]] || [[ "$name" == *"ambient"* ]] || [[ "$name" == *"atmo"* ]] || [[ "$name" == *"texture"* ]] || [[ "$name" == *"drone"* ]] || [[ "$name" == *"evolv"* ]] || [[ "$path" == *"/pad"* ]] || [[ "$path" == *"/ambient"* ]]; then
    echo "Samples/Pads"
  elif [[ "$name" == *"synth"* ]] || [[ "$name" == *"bass"* ]] || [[ "$name" == *"lead"* ]] || [[ "$name" == *"sub"* ]] || [[ "$name" == *"pluck"* ]] || [[ "$name" == *"arp"* ]] || [[ "$name" == *"reese"* ]] || [[ "$name" == *"wobble"* ]] || [[ "$name" == *"growl"* ]] || [[ "$path" == *"/synth"* ]] || [[ "$path" == *"/bass"* ]] || [[ "$path" == *"/lead"* ]]; then
    echo "Samples/Synths"
  elif [[ "$name" == *"vocal"* ]] || [[ "$name" == *"acapella"* ]] || [[ "$name" == *"vox"* ]] || [[ "$name" == *"voice"* ]] || [[ "$name" == *"sing"* ]] || [[ "$name" == *"rap"* ]] || [[ "$name" == *"spoken"* ]] || [[ "$name" == *"chant"* ]] || [[ "$path" == *"/vocal"* ]] || [[ "$path" == *"/vox"* ]]; then
    echo "Samples/Vocals"
  elif [[ "$name" == *"_fx"* ]] || [[ "$name" == *"effect"* ]] || [[ "$name" == *"whoosh"* ]] || [[ "$name" == *"impact"* ]] || [[ "$name" == *"sweep"* ]] || [[ "$name" == *"riser"* ]] || [[ "$name" == *"transition"* ]] || [[ "$name" == *"reverse"* ]] || [[ "$name" == *"swell"* ]] || [[ "$name" == *"noise"* ]] || [[ "$name" == *"noize"* ]] || [[ "$name" == *"sfx"* ]] || [[ "$path" == *"/fx"* ]] || [[ "$path" == *"/effect"* ]]; then
    echo "Samples/FX"
  elif [[ "$name" == *"loop"* ]] || [[ "$name" == *"break"* ]] || [[ "$name" == *"groove"* ]] || [[ "$name" == *"bpm"* ]] || [[ "$name" == *"pattern"* ]] || [[ "$name" == *"beat"* ]] || [[ "$path" == *"/loop"* ]] || [[ "$path" == *"/groove"* ]]; then
    echo "Samples/Loops"
  elif [[ "$name" == *"shot"* ]] || [[ "$name" == *"stab"* ]] || [[ "$name" == *"hitz"* ]] || [[ "$path" == *"/one-shot"* ]] || [[ "$path" == *"/oneshot"* ]]; then
    echo "Samples/One-Shots"
  elif [[ "$name" == *"piano"* ]] || [[ "$name" == *"guitar"* ]] || [[ "$name" == *"horn"* ]] || [[ "$name" == *"organ"* ]] || [[ "$name" == *"violin"* ]] || [[ "$name" == *"brass"* ]] || [[ "$name" == *"flute"* ]] || [[ "$name" == *"cello"* ]] || [[ "$name" == *"trumpet"* ]] || [[ "$name" == *"sax"* ]] || [[ "$name" == *"harp"* ]] || [[ "$name" == *"bell"* ]] || [[ "$name" == *"mallet"* ]] || [[ "$name" == *"kalimba"* ]] || [[ "$path" == *"/instrument"* ]] || [[ "$path" == *"/piano"* ]] || [[ "$path" == *"/guitar"* ]]; then
    echo "Samples/Instruments"
  elif [[ "$name" == *"freeze"* ]] || [[ "$name" == *"region"* ]]; then
    echo "Audio Recordings"
  else
    echo "Samples/Other"
  fi
}

echo "Scanning all files in Music Samples and Packs..."

find "$SOURCE" -type f ! -name ".DS_Store" | while read f; do
  filename=$(basename "$f")
  ext="${filename##*.}"
  dest=$(get_dest_by_ext "$ext")
  if [ "$dest" = "SKIP" ]; then
    continue
  elif [ "$dest" = "AUDIO" ]; then
    audiodest=$(categorize_audio "$f")
    mv "$f" "$MUSIC_DIR/$audiodest/" 2>/dev/null && echo "MOVED: $filename -> $audiodest" >> "$LOGFILE"
  elif [ "$dest" = "UNKNOWN" ]; then
    echo "$ext - $filename" >> "$UNKNOWNS"
    mv "$f" "$MUSIC_DIR/Archive/" 2>/dev/null
    echo "UNKNOWN: $filename ($ext) -> Archive" >> "$LOGFILE"
  else
    mv "$f" "$MUSIC_DIR/$dest/" 2>/dev/null && echo "MOVED: $filename -> $dest" >> "$LOGFILE"
  fi
done

echo "Cleaning up empty folders..."
find "$SOURCE" -type d -empty -delete 2>/dev/null || true

echo ""
echo "Done!"
echo ""
echo "-- REPORT --"
for dir in Projects "Presets/Instruments" "Presets/Effects" "Samples/Drums" "Samples/Synths" "Samples/Pads" "Samples/Vocals" "Samples/FX" "Samples/Loops" "Samples/One-Shots" "Samples/Instruments" "Samples/Other" MIDI Templates Exports "Audio Recordings" Archive "Plugin Data" Video Docs; do
  count=$(find "$MUSIC_DIR/$dir" -type f 2>/dev/null | wc -l)
  echo "$dir: $count files"
done
echo ""
echo "Total size: $(du -sh "$MUSIC_DIR" | cut -f1)"
echo ""
if [ -s "$UNKNOWNS" ]; then
  echo "-- UNKNOWN EXTENSIONS --"
  sort -u "$UNKNOWNS"
fi
echo ""
echo "Log: $LOGFILE"
echo "Ready to produce!"
