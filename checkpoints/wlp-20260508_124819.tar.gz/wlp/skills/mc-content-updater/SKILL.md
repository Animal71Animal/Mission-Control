---
name: mc-content-updater
description: Update content in Mission Control business documents and deploy changes. Use when user asks to update pricing, market size, investor materials, ROI calculator, shared pages, or any business documentation in the MC dashboard. Handles markdown edits, component updates, builds, and Vercel deployment.
---

# Mission Control Content Updater

Quick workflow for updating MC business docs, components, and deploying.

## Steps

1. **Locate the file** — Business docs in `public/data/business/`, components in `components/`, pages in `app/`
2. **Edit with sed or write** — Use sed for simple replacements, write for rewrites
3. **Build** — `npm run build` (must pass)
4. **Deploy** — `npx vercel@latest deploy --prod --yes`
5. **Verify** — Check live URL

## Common Patterns

### Pricing Updates
```bash
cd /home/ubuntu/wlp/projects/mission-control
sed -i 's/\$OLD/\$NEW/g' public/data/business/FILE.md
```

### Market Size Recalculation
- US TAM = venues × monthly_price × 12
- Global TAM = total_venues × monthly_price × 12
- SAM = TAM × capture_percentage

### ROI Calculator Updates
- File: `app/wlp-dj-roi/page.tsx`
- Formula changes: update calculations in component
- Input changes: add/remove state variables
- Always test calculations after changes

### Adding New Docs
1. Create markdown in `public/data/business/`
2. Add to WLP page in `app/wlp/page.tsx` DocGrid
3. Add to shared links in `app/shared-links/page.tsx` if needed
4. Create shared page in `app/shared/NAME/page.tsx` if password-protected

### Mobile Optimization
- Shared docs use `SharedDocView.tsx`
- Mobile breakpoints at 640px
- Font sizes: h1 1.4rem, h2 1.2rem, body 0.95rem on mobile
- Padding: 24px 20px on mobile (vs 40px 48px desktop)

### Creating Shared Pages
1. Create `app/shared/NAME/page.tsx`
2. Use password protection with `wlp2026`
3. Use `SharedDocView` component for doc rendering
4. Add to `app/shared-links/page.tsx`

## Deployment

Always use the Vercel token from environment:
```bash
VERCEL_TOKEN="$(grep -o 'vcp_[^"]*' ~/.openclaw/openclaw.json | head -1)"
npx vercel@latest deploy --prod --yes
```

## Files to Know

| File | Purpose |
|------|---------|
| `public/data/business/*.md` | Business documentation |
| `app/wlp/page.tsx` | WLP Business dashboard |
| `app/wlp-dj-roi/page.tsx` | ROI calculator |
| `app/shared-links/page.tsx` | Shared resources list |
| `app/shared/*/page.tsx` | Password-protected shared pages |
| `components/WLPDocPage.tsx` | Doc viewer with tabs |
| `components/SharedDocView.tsx` | Shared page doc renderer |
| `components/RootLayoutWrapper.tsx` | Layout wrapper with sidebar logic |

## Quick Commands

```bash
# Build and deploy
cd /home/ubuntu/wlp/projects/mission-control
npm run build && VERCEL_TOKEN="$(grep -o 'vcp_[^"]*' ~/.openclaw/openclaw.json | head -1)" npx vercel@latest deploy --prod --yes

# Search for pricing references
grep -rn "\$[0-9]" public/data/business/ --include="*.md"

# Check all shared pages
ls app/shared/
```
