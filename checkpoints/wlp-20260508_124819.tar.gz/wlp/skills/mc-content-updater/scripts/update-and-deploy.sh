#!/bin/bash
# Update MC content and deploy

set -e

PROJECT_DIR="/home/ubuntu/wlp/projects/mission-control"
cd "$PROJECT_DIR"

# Build
npm run build

# Deploy
VERCEL_TOKEN="$(grep -o 'vcp_[^"]*' ~/.openclaw/openclaw.json | head -1)"
npx vercel@latest deploy --prod --yes

echo "Deployed successfully"
