# Channel Router

## Description

Manages cross-channel messaging by detecting context and routing messages through proper channel-bound subagents. Solves Telegram→Discord and other cross-context delivery issues.

## Usage

```
channel-router send discord <channel-id> <message>   # Send to Discord
channel-router send telegram <chat-id> <message>     # Send to Telegram
channel-router test <channel>                          # Test channel connectivity
channel-router status                                  # Show channel bindings
```

## When to Use

- Need to send from Telegram to Discord
- Subagent failed with "cross-context messaging denied"
- Testing channel connectivity
- Verifying channel configuration

## The Problem

OpenClaw blocks cross-context messaging for security:
- Telegram-bound sessions cannot send to Discord
- Discord-bound sessions cannot send to Telegram
- Subagents inherit parent's channel binding

## The Solution

Channel Router spawns fresh subagents with explicit channel bindings:

```
Telegram Session → Channel Router → Discord-Bound Subagent → Discord Channel
```

## Examples

### Send to Discord from Telegram

```bash
channel-router send discord 1488075732771934308 "Hello from Telegram"
```

Output:
```
📡 Channel Router

Source: telegram (current session)
Target: discord #1488075732771934308

Spawning Discord-bound subagent...
✓ Subagent spawned: agent:main:subagent:xyz123
✓ Message delivered
✓ Delivery confirmed
```

### Send report to Discord

```bash
channel-router send discord 1488075732771934308 "$(cat report.md)"
```

### Test Discord connectivity

```bash
channel-router test discord
```

Output:
```
🧪 Testing Discord channel 1488075732771934308...

Spawning test subagent...
✓ Subagent spawned with discord binding
✓ Test message sent
✓ Delivery confirmed

✅ Discord channel is reachable
```

### Check status

```bash
channel-router status
```

Output:
```
📊 Channel Router Status

Current session: telegram (8180067794)
Available channels:
  ✓ telegram — bound (current)
  ✓ discord — configured, reachable

Recent routing:
  2026-04-05 21:30 → discord #1488075732771934308 ✓
  2026-04-05 21:25 → discord #1488075732771934308 ✗ (failed)
```

## Implementation

See: `scripts/channel-router.py`

## How It Works

1. Detects current channel context
2. Spawns subagent with `--channel <target>` binding
3. Subagent sends message from proper context
4. Reports success/failure back to parent

## Configuration

Requires channels configured in `~/.openclaw/openclaw.json`:
```json
{
  "channels": {
    "telegram": { "enabled": true, ... },
    "discord": { "enabled": true, ... }
  }
}
```

## Notes

- Always spawns fresh subagents for cross-context sends
- Subagents auto-terminate after delivery
- Logs all routing attempts
- Reports exact error if delivery fails
