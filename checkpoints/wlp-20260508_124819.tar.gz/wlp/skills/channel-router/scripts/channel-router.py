#!/usr/bin/env python3
"""
Channel Router - Cross-channel messaging
Usage: python3 channel-router.py send <channel> <target> <message>
"""

import os
import sys
import json
import subprocess

def run_cmd(cmd):
    """Run shell command"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout.strip(), result.stderr.strip(), result.returncode

def spawn_discord_subagent(channel_id, message):
    """Spawn a Discord-bound subagent to send message"""
    
    # Create a temporary script for the subagent
    script_content = f'''
import json
import urllib.request

DISCORD_TOKEN = "MTQ4ODA2NDY0MjUyMDcxNTMzNA.Gv5d7H.mUC1NOyHHjHmnYs8iwoOHnYcyuS_nm2uQRK0Is"
CHANNEL_ID = "{channel_id}"

message = """{message}"""

# Send to Discord
url = f"https://discord.com/api/v10/channels/{{CHANNEL_ID}}/messages"
headers = {{
    "Authorization": f"Bot {{DISCORD_TOKEN}}",
    "Content-Type": "application/json"
}}
data = {{"content": message}}

req = urllib.request.Request(
    url,
    data=json.dumps(data).encode(),
    headers=headers,
    method="POST"
)

try:
    with urllib.request.urlopen(req) as resp:
        print("Message sent successfully")
except Exception as e:
    print(f"Error: {{e}}")
'''
    
    # Write temp script
    with open('/tmp/discord_send.py', 'w') as f:
        f.write(script_content)
    
    # Run it
    stdout, stderr, rc = run_cmd('python3 /tmp/discord_send.py')
    return rc == 0, stdout + stderr

def send_to_discord(channel_id, message):
    """Send message to Discord channel"""
    print(f"📡 Routing to Discord #{channel_id}...")
    
    success, output = spawn_discord_subagent(channel_id, message)
    
    if success:
        print("✅ Message delivered")
        return True
    else:
        print(f"❌ Failed: {output}")
        return False

def send_to_telegram(chat_id, message):
    """Send message to Telegram chat"""
    print(f"📡 Routing to Telegram {chat_id}...")
    
    # Get bot token from config
    stdout, _, _ = run_cmd("cat ~/.openclaw/openclaw.json | grep -o 'botToken.*' | cut -d'"' -f4")
    bot_token = stdout.strip()
    
    if not bot_token:
        print("❌ Could not find Telegram bot token")
        return False
    
    import urllib.request
    import urllib.parse
    
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = urllib.parse.urlencode({
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'Markdown'
    }).encode()
    
    try:
        req = urllib.request.Request(url, data=data, method='POST')
        with urllib.request.urlopen(req) as resp:
            print("✅ Message delivered")
            return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        return False

def test_channel(channel):
    """Test channel connectivity"""
    print(f"🧪 Testing {channel}...\n")
    
    if channel == 'discord':
        # Test with agent-output channel
        test_msg = "🧪 Channel Router test message"
        success = send_to_discord('1488075732771934308', test_msg)
        if success:
            print("\n✅ Discord channel is reachable")
        else:
            print("\n❌ Discord test failed")
    
    elif channel == 'telegram':
        # Test with current chat
        stdout, _, _ = run_cmd("cat ~/.openclaw/openclaw.json | grep -A5 'telegram' | grep 'allowFrom' | head -1 | tr -d '[]\"' | cut -d',' -f1")
        chat_id = stdout.strip() or '8180067794'
        
        test_msg = "🧪 Channel Router test message"
        success = send_to_telegram(chat_id, test_msg)
        if success:
            print("\n✅ Telegram channel is reachable")
        else:
            print("\n❌ Telegram test failed")
    
    else:
        print(f"Unknown channel: {channel}")
        return False

def show_status():
    """Show channel routing status"""
    print("📊 Channel Router Status\n")
    
    # Get current context
    print("Current session: telegram")
    print("Available channels:")
    print("  ✓ telegram — bound (current)")
    print("  ✓ discord — configured")
    print("\nRouting rules:")
    print("  telegram → discord: spawn subagent")
    print("  discord → telegram: spawn subagent")

def main():
    if len(sys.argv) < 2:
        print("Usage: channel-router.py [send|test|status]")
        print("\nExamples:")
        print("  channel-router.py send discord 1488075732771934308 'Hello'")
        print("  channel-router.py test discord")
        print("  channel-router.py status")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'send':
        if len(sys.argv) < 5:
            print("Usage: channel-router.py send <channel> <target> <message>")
            sys.exit(1)
        
        channel = sys.argv[2]
        target = sys.argv[3]
        message = sys.argv[4]
        
        if channel == 'discord':
            send_to_discord(target, message)
        elif channel == 'telegram':
            send_to_telegram(target, message)
        else:
            print(f"Unknown channel: {channel}")
    
    elif command == 'test':
        if len(sys.argv) < 3:
            print("Usage: channel-router.py test <channel>")
            sys.exit(1)
        test_channel(sys.argv[2])
    
    elif command == 'status':
        show_status()
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

if __name__ == '__main__':
    main()
