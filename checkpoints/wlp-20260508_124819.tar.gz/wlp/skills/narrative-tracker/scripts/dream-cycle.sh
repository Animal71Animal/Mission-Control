#!/bin/bash
# Dream Cycle - Nightly Memory Optimization
# Implements Video #36's pattern: review, compress, migrate, prevent bloat

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MEMORY_DIR="/home/ubuntu/memory"
WLP_CORE="/home/ubuntu"
LOG_FILE="$MEMORY_DIR/dream-cycle-$(date +%Y%m%d).log"

log() {
    echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Dream Cycle Started ==="

# Check Tier 1 file sizes and report bloat
log "Auditing Tier 1 memory files..."

for file in "$WLP_CORE/SOUL.md" "$WLP_CORE/MEMORY.md" "$WLP_CORE/AGENTS.md"; do
    if [ -f "$file" ]; then
        size=$(wc -c < "$file")
        name=$(basename "$file")
        log "  $name: $size bytes"
        
        # Flag bloated files
        case "$name" in
            SOUL.md)
                [ $size -gt 5000 ] && log "  ⚠️  SOUL.md is bloated (>5000 chars)"
                ;;
            MEMORY.md)
                [ $size -gt 7000 ] && log "  ⚠️  MEMORY.md is bloated (>7000 chars)"
                ;;
            AGENTS.md)
                [ $size -gt 3000 ] && log "  ⚠️  AGENTS.md is bloated (>3000 chars)"
                ;;
        esac
    fi
done

# Process today's sessions if they exist
TODAY=$(date +%Y-%m-%d)
YESTERDAY=$(date -d "yesterday" +%Y-%m-%d 2>/dev/null || date -v-1d +%Y-%m-%d)

log "Processing recent sessions..."

# Find session logs from the last 24 hours
find /home/ubuntu/.openclaw/agents/main/sessions -name "*.jsonl" -mtime -1 | while read session; do
    session_name=$(basename "$session" .jsonl)
    log "  Processing: $session_name"
    
    # Convert jsonl to markdown for processing
    # This is a simplified extraction - in practice you'd use jq
    cat "$session" | grep '"role":"user"\|"role":"assistant"' > "/tmp/$session_name.txt" 2>/dev/null || true
done

# Run narrative tracker on any new content
if [ -f "/tmp/session-*.txt" ]; then
    log "Compressing sessions and updating narrative..."
    cat /tmp/session-*.txt 2>/dev/null | "$SCRIPT_DIR/narrative-tracker.py" --full \
        --output-dir "$MEMORY_DIR" \
        --session-name "dream-cycle-$TODAY" 2>&1 | tee -a "$LOG_FILE"
fi

# Clean up temp files
rm -f /tmp/session-*.txt

# Generate bloat report
log "Generating bloat report..."
cat > "$MEMORY_DIR/bloat-report.md" << EOF
# Memory Bloat Report — $TODAY

Generated: $(date)

## Tier 1 File Status

| File | Size | Status |
|------|------|--------|
| SOUL.md | $(wc -c < "$WLP_CORE/SOUL.md" 2>/dev/null || echo 0) bytes | $([ $(wc -c < "$WLP_CORE/SOUL.md" 2>/dev/null || echo 0) -gt 5000 ] && echo "⚠️ Bloated" || echo "✅ Healthy") |
| MEMORY.md | $(wc -c < "$WLP_CORE/MEMORY.md" 2>/dev/null || echo 0) bytes | $([ $(wc -c < "$WLP_CORE/MEMORY.md" 2>/dev/null || echo 0) -gt 7000 ] && echo "⚠️ Bloated" || echo "✅ Healthy") |
| AGENTS.md | $(wc -c < "$WLP_CORE/AGENTS.md" 2>/dev/null || echo 0) bytes | $([ $(wc -c < "$WLP_CORE/AGENTS.md" 2>/dev/null || echo 0) -gt 3000 ] && echo "⚠️ Bloated" || echo "✅ Healthy") |

## Recommendations

$(if [ $(wc -c < "$WLP_CORE/SOUL.md" 2>/dev/null || echo 0) -gt 5000 ]; then echo "- Consider migrating SOUL.md details to narrative.md"; fi)
$(if [ $(wc -c < "$WLP_CORE/MEMORY.md" 2>/dev/null || echo 0) -gt 7000 ]; then echo "- MEMORY.md should be compressed"; fi)

## Next Dream Cycle
Scheduled for: $(date -d "+1 day" +%Y-%m-%d 2>/dev/null || date -v+1d +%Y-%m-%d) 3:00 AM
EOF

log "=== Dream Cycle Complete ==="
log "Report saved to: $MEMORY_DIR/bloat-report.md"
