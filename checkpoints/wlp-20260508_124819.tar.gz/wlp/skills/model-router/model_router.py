#!/usr/bin/env python3
"""
Model Router - Cost-efficient model switching for Abacus RouteLLM
Usage: python3 model_router.py "your prompt here"
"""

import sys
import re

# === CONFIGURATION ===
TIER_SIMPLE = "gpt-5-nano"
TIER_STANDARD = "minimax-m2.7"
TIER_COMPLEX = "claude-opus-4.7"
TIER_CREATIVE = "kimi-k2.6"

# MiniMax M2.7 keywords (standard tier - coding, Mission Control, WLP)
M2_7_KEYWORDS = [
    "mission control", "vercel deploy", "github", "workout tracker",
    "data file", "update page", "add feature", "fix bug", "dashboard",
    "api route", "react", "nextjs", "javascript", "typescript", "exercise",
    "wlp project", "deploy script", "build error", "uber earnings",
    "srb tip", "srb tips", "tesla charging", "spearmint rhino", "push to github",
    "redeploy", "peptides", "openclaw youtube", "action items"
]

# Complex tier keywords (reasoning, legal, investor docs)
COMPLEX_KEYWORDS = [
    "investor", "legal", "contract", "terms", "agreement",
    "advanced reasoning", "deep analysis", "complex problem",
    "multi-step", "strategic planning", "financial model"
]

# Creative tier keywords (vision, art, creative)
CREATIVE_KEYWORDS = [
    "image", "vision", "creative", "art", "design", "generate image",
    "visual", "logo", "album art", "cover art", "illustration"
]


def route_model(prompt: str) -> str:
    """
    Route a prompt to the most cost-effective model based on keywords.
    
    Args:
        prompt: The user's prompt/message
        
    Returns:
        Model ID string for Abacus RouteLLM
    """
    prompt_lower = prompt.lower()
    
    # Check creative tier first (most specific)
    for keyword in CREATIVE_KEYWORDS:
        if keyword in prompt_lower:
            return TIER_CREATIVE
    
    # Check complex tier
    for keyword in COMPLEX_KEYWORDS:
        if keyword in prompt_lower:
            return TIER_COMPLEX
    
    # Check standard tier (Mission Control / coding)
    for keyword in M2_7_KEYWORDS:
        if keyword in prompt_lower:
            return TIER_STANDARD
    
    # Default to simple tier
    return TIER_SIMPLE


def route_with_metadata(prompt: str) -> dict:
    """
    Route with full metadata including matched keyword and tier.
    
    Returns:
        dict with model, tier, matched_keyword, estimated_cost
    """
    prompt_lower = prompt.lower()
    
    # Check each tier
    tiers = [
        (CREATIVE_KEYWORDS, TIER_CREATIVE, "creative"),
        (COMPLEX_KEYWORDS, TIER_COMPLEX, "complex"),
        (M2_7_KEYWORDS, TIER_STANDARD, "standard"),
    ]
    
    for keywords, model, tier_name in tiers:
        for keyword in keywords:
            if keyword in prompt_lower:
                return {
                    "model": model,
                    "tier": tier_name,
                    "matched_keyword": keyword,
                    "estimated_cost_per_1k": get_cost(model)
                }
    
    # Default
    return {
        "model": TIER_SIMPLE,
        "tier": "simple",
        "matched_keyword": None,
        "estimated_cost_per_1k": get_cost(TIER_SIMPLE)
    }


def get_cost(model_id: str) -> str:
    """Get estimated cost per 1K tokens for a model."""
    costs = {
        TIER_SIMPLE: "$0.00045",
        TIER_STANDARD: "$0.0009",
        TIER_COMPLEX: "$0.0175",
        TIER_CREATIVE: "$0.00545"
    }
    return costs.get(model_id, "unknown")


def test_router():
    """Test the router with sample prompts."""
    test_cases = [
        ("What's the weather like?", TIER_SIMPLE),
        ("Update the Mission Control dashboard", TIER_STANDARD),
        ("Fix bug in the React component", TIER_STANDARD),
        ("Draft investor terms sheet", TIER_COMPLEX),
        ("Generate album art for Kade Rivers", TIER_CREATIVE),
        ("Push to GitHub and redeploy", TIER_STANDARD),
        ("Simple reminder: call mom", TIER_SIMPLE),
    ]
    
    print("🧪 Model Router Tests\n")
    
    for prompt, expected in test_cases:
        result = route_model(prompt)
        status = "✅" if result == expected else "❌"
        meta = route_with_metadata(prompt)
        print(f"{status} {prompt[:50]}...")
        print(f"   → {result} ({meta['tier']}, {meta['estimated_cost_per_1k']})")
        if result != expected:
            print(f"   Expected: {expected}")
        print()
    
    print("\n📊 Cost Summary (per 1K input / 500 output tokens):")
    print(f"  Simple ({TIER_SIMPLE}):    $0.00045")
    print(f"  Standard ({TIER_STANDARD}):  $0.0009")
    print(f"  Creative ({TIER_CREATIVE}):  $0.00545")
    print(f"  Complex ({TIER_COMPLEX}):    $0.0175")


def main():
    if len(sys.argv) < 2:
        print("Usage: model_router.py '<prompt>'")
        print("       model_router.py --test")
        sys.exit(1)
    
    if sys.argv[1] == "--test":
        test_router()
        return
    
    prompt = sys.argv[1]
    model = route_model(prompt)
    meta = route_with_metadata(prompt)
    
    print(f"Prompt: {prompt}")
    print(f"Model:  {model}")
    print(f"Tier:   {meta['tier']}")
    if meta['matched_keyword']:
        print(f"Match:  '{meta['matched_keyword']}'")
    print(f"Cost:   {meta['estimated_cost_per_1k']} per 1K tokens")


if __name__ == "__main__":
    main()
