#!/usr/bin/env python3
"""
Cost Tracker - Log every routed API call for spend analysis
Shows savings vs legacy models (RouteLLM, GPT-4o, Claude Sonnet)
Usage: python3 cost_tracker.py log <model> <prompt_tokens> <output_tokens>
       python3 cost_tracker.py report
       python3 cost_tracker.py summary
       python3 cost_tracker.py savings
"""

import json
import os
import sys
from datetime import datetime
from collections import defaultdict

LOG_FILE = "/home/ubuntu/wlp/data/model-cost-log.jsonl"
DATA_DIR = os.path.dirname(LOG_FILE)

# Current tiered model costs (per 1K tokens)
COST_RATES = {
    "gpt-5-nano": {"input": 0.00000005, "output": 0.0000004},
    "minimax-m2.7": {"input": 0.0000003, "output": 0.0000012},
    "kimi-k2.6": {"input": 0.00000095, "output": 0.000004},
    "claude-opus-4.7": {"input": 0.000005, "output": 0.000025},
}

# Legacy model costs (what you were paying before)
LEGACY_RATES = {
    "routellm": {"input": 0.000003, "output": 0.000015},      # RouteLLM auto-router
    "gpt-4o": {"input": 0.0000025, "output": 0.00001},        # GPT-4o
    "claude-sonnet": {"input": 0.000003, "output": 0.000015}, # Claude Sonnet 4.6
    "claude-opus": {"input": 0.000005, "output": 0.000025},   # Claude Opus 4.7
    "kimi-k2.5": {"input": 0.0000006, "output": 0.000003},    # Kimi K2.5
}

# Default legacy model to compare against
DEFAULT_LEGACY = "kimi-k2.5"

# Legacy model mapping (what you actually used)
LEGACY_USAGE = {
    "simple": "kimi-k2.5",      # You used Kimi for most things
    "standard": "kimi-k2.5",    # You used Kimi for most things
    "creative": "kimi-k2.5",    # You used Kimi for most things
    "complex": "claude-opus",   # Opus for complex tasks
}


def ensure_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


def calculate_cost(model, input_tokens, output_tokens, rates=None):
    """Calculate cost in dollars for a given model and token count."""
    rates = rates or COST_RATES
    model_rates = rates.get(model, {"input": 0, "output": 0})
    input_cost = (input_tokens / 1000) * model_rates["input"]
    output_cost = (output_tokens / 1000) * model_rates["output"]
    return input_cost + output_cost


def log_call(model, prompt, input_tokens, output_tokens, tier=None):
    """Log a model API call to the cost tracker."""
    ensure_dir()
    
    cost = calculate_cost(model, input_tokens, output_tokens)
    
    # Calculate what this would have cost with YOUR legacy usage pattern
    detected_tier = tier or infer_tier(model)
    legacy_model = LEGACY_USAGE.get(detected_tier, DEFAULT_LEGACY)
    legacy_cost = calculate_cost(legacy_model, input_tokens, output_tokens, LEGACY_RATES)
    savings = legacy_cost - cost
    
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "model": model,
        "tier": detected_tier,
        "prompt_preview": prompt[:100] if prompt else "",
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cost_usd": round(cost, 8),
        "legacy_model": legacy_model,
        "legacy_cost_usd": round(legacy_cost, 8),
        "savings_usd": round(savings, 8),
        "savings_pct": round((savings / legacy_cost * 100), 1) if legacy_cost > 0 else 0
    }
    
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")
    
    return cost, legacy_cost, savings


def infer_tier(model):
    """Infer tier from model name."""
    tiers = {
        "gpt-5-nano": "simple",
        "minimax-m2.7": "standard",
        "kimi-k2.6": "creative",
        "claude-opus-4.7": "complex"
    }
    return tiers.get(model, "unknown")


def load_logs():
    """Load all log entries."""
    if not os.path.exists(LOG_FILE):
        return []
    
    entries = []
    with open(LOG_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return entries


def generate_report():
    """Generate detailed cost report."""
    entries = load_logs()
    
    if not entries:
        print("No cost data logged yet.")
        return
    
    # Aggregate by model
    by_model = defaultdict(lambda: {"calls": 0, "input_tokens": 0, "output_tokens": 0, "cost": 0, "legacy_cost": 0, "savings": 0})
    by_tier = defaultdict(lambda: {"calls": 0, "cost": 0, "savings": 0})
    
    for entry in entries:
        model = entry["model"]
        tier = entry.get("tier", "unknown")
        
        by_model[model]["calls"] += 1
        by_model[model]["input_tokens"] += entry["input_tokens"]
        by_model[model]["output_tokens"] += entry["output_tokens"]
        by_model[model]["cost"] += entry["cost_usd"]
        by_model[model]["legacy_cost"] += entry.get("legacy_cost_usd", 0)
        by_model[model]["savings"] += entry.get("savings_usd", 0)
        
        by_tier[tier]["calls"] += 1
        by_tier[tier]["cost"] += entry["cost_usd"]
        by_tier[tier]["savings"] += entry.get("savings_usd", 0)
    
    total_cost = sum(e["cost_usd"] for e in entries)
    total_legacy = sum(e.get("legacy_cost_usd", 0) for e in entries)
    total_savings = sum(e.get("savings_usd", 0) for e in entries)
    total_calls = len(entries)
    
    print("📊 Model Cost Report\n")
    print(f"Total Calls: {total_calls}")
    print(f"Total Cost: ${total_cost:.8f}")
    print(f"Legacy Cost (if using {DEFAULT_LEGACY}): ${total_legacy:.8f}")
    print(f"💰 Savings: ${total_savings:.8f} ({(total_savings/total_legacy*100):.1f}%)\n")
    
    print("By Model:")
    print("-" * 80)
    for model, stats in sorted(by_model.items()):
        savings_pct = (stats["savings"] / stats["legacy_cost"] * 100) if stats["legacy_cost"] > 0 else 0
        print(f"  {model:20} | Calls: {stats['calls']:4}")
        print(f"  {'':20} | Actual: ${stats['cost']:.8f} | Legacy: ${stats['legacy_cost']:.8f}")
        print(f"  {'':20} | Saved: ${stats['savings']:.8f} ({savings_pct:.1f}%)")
        print(f"  {'':20} | Tokens: {stats['input_tokens']} in / {stats['output_tokens']} out")
        print()
    
    print("By Tier:")
    print("-" * 60)
    for tier, stats in sorted(by_tier.items()):
        pct = (stats["cost"] / total_cost * 100) if total_cost > 0 else 0
        print(f"  {tier:10} | Calls: {stats['calls']:4} | Cost: ${stats['cost']:.8f} ({pct:.1f}%)")
        print(f"  {'':10} | Saved: ${stats['savings']:.8f}")
    
    print(f"\nLog file: {LOG_FILE}")


def generate_savings_report():
    """Generate savings-focused report."""
    entries = load_logs()
    
    if not entries:
        print("No cost data logged yet.")
        return
    
    total_cost = sum(e["cost_usd"] for e in entries)
    total_legacy = sum(e.get("legacy_cost_usd", 0) for e in entries)
    total_savings = sum(e.get("savings_usd", 0) for e in entries)
    total_calls = len(entries)
    
    print("💰 SAVINGS REPORT\n")
    print("=" * 60)
    print(f"Comparison: New Router vs Your Legacy Usage")
    print(f"  Simple tasks → Kimi K2.5")
    print(f"  Standard tasks → Kimi K2.5")
    print(f"  Creative tasks → Kimi K2.5")
    print(f"  Complex tasks → Claude Opus 4.7")
    print("=" * 60)
    print()
    print(f"Total Calls:        {total_calls}")
    print(f"Actual Cost:        ${total_cost:.8f}")
    print(f"Legacy Cost:        ${total_legacy:.8f}")
    print(f"💵 YOU SAVED:       ${total_savings:.8f}")
    print(f"📉 Savings Rate:     {(total_savings/total_legacy*100):.1f}%")
    print()
    
    # Per-call averages
    avg_actual = total_cost / total_calls
    avg_legacy = total_legacy / total_calls
    avg_savings = total_savings / total_calls
    
    print("Per-Call Averages:")
    print(f"  Actual:  ${avg_actual:.8f}")
    print(f"  Legacy:  ${avg_legacy:.8f}")
    print(f"  Saved:   ${avg_savings:.8f}")
    print()
    
    # Projected savings
    print("Projected Savings (if scaled):")
    print(f"  100 calls:  ${avg_savings * 100:.8f}")
    print(f"  1K calls:   ${avg_savings * 1000:.8f}")
    print(f"  10K calls:  ${avg_savings * 10000:.6f}")
    print()
    
    # By model breakdown
    by_model = defaultdict(lambda: {"calls": 0, "savings": 0, "legacy": 0})
    for entry in entries:
        model = entry["model"]
        by_model[model]["calls"] += 1
        by_model[model]["savings"] += entry.get("savings_usd", 0)
        by_model[model]["legacy"] += entry.get("legacy_cost_usd", 0)
    
    print("Savings by Model:")
    print("-" * 60)
    for model, stats in sorted(by_model.items(), key=lambda x: -x[1]["savings"]):
        pct = (stats["savings"] / stats["legacy"] * 100) if stats["legacy"] > 0 else 0
        print(f"  {model:20} | {stats['calls']} calls | ${stats['savings']:.8f} saved ({pct:.1f}%)")


def generate_summary():
    """Generate brief summary."""
    entries = load_logs()
    
    if not entries:
        print("No cost data logged yet.")
        return
    
    total_cost = sum(e["cost_usd"] for e in entries)
    total_savings = sum(e.get("savings_usd", 0) for e in entries)
    total_calls = len(entries)
    
    by_tier = defaultdict(lambda: {"calls": 0, "cost": 0})
    for entry in entries:
        tier = entry.get("tier", "unknown")
        by_tier[tier]["calls"] += 1
        by_tier[tier]["cost"] += entry["cost_usd"]
    
    print(f"💰 Total: {total_calls} calls, ${total_cost:.8f}")
    print(f"💵 Saved: ${total_savings:.8f}")
    for tier, stats in sorted(by_tier.items()):
        print(f"   {tier}: {stats['calls']} calls, ${stats['cost']:.8f}")


def main():
    if len(sys.argv) < 2:
        print("Usage: cost_tracker.py [log|report|summary|savings]")
        print("  log <model> <input_tokens> <output_tokens> [prompt]")
        print("  report       - Full cost report with legacy comparison")
        print("  summary      - Brief summary")
        print("  savings      - Savings-focused report")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "log":
        if len(sys.argv) < 5:
            print("Usage: cost_tracker.py log <model> <input_tokens> <output_tokens> [prompt]")
            sys.exit(1)
        
        model = sys.argv[2]
        input_tokens = int(sys.argv[3])
        output_tokens = int(sys.argv[4])
        prompt = sys.argv[5] if len(sys.argv) > 5 else ""
        
        cost, legacy, savings = log_call(model, prompt, input_tokens, output_tokens)
        print(f"✅ Logged: {model}")
        print(f"   Actual:  ${cost:.8f}")
        print(f"   Legacy:  ${legacy:.8f}")
        if legacy > 0:
            print(f"   Saved:   ${savings:.8f} ({(savings/legacy*100):.1f}%)")
        else:
            print(f"   Saved:   ${savings:.8f} (N/A)")
    
    elif command == "report":
        generate_report()
    
    elif command == "summary":
        generate_summary()
    
    elif command == "savings":
        generate_savings_report()
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
