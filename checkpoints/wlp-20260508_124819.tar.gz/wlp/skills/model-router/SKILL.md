# Model Router Skill

Cost-efficient model switching for Abacus RouteLLM.

## Tiers

| Tier | Model | Cost (1K in / 500 out) | Use Case |
|------|-------|------------------------|----------|
| Simple | gpt-5-nano | $0.00045 | Weather, reminders, simple chat |
| Standard | minimax-m2.7 | $0.0009 | Mission Control, coding, WLP projects |
| Complex | gpt-5.5 | $0.0175 | Investor docs, legal, advanced reasoning |
| Creative | kimi-k2.6 | $0.00545 | Vision, creative tasks |

## M2.7 Keywords (29)

mission control, vercel deploy, github, workout tracker, data file, update page, add feature, fix bug, dashboard, api route, react, nextjs, javascript, typescript, exercise, wlp project, deploy script, build error, uber earnings, srb tips, tesla charging, spearmint rhino, push to github, redeploy, peptides, openclaw youtube, action items

## Usage

```python
from model_router import route_model

model = route_model("Update the Mission Control dashboard")
# Returns: "minimax-m2.7"
```
