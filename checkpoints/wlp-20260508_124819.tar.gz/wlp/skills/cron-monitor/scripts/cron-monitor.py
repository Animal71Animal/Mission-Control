#!/usr/bin/env python3
"""
Cron Monitor - Monitor and validate cron jobs
Usage: python3 cron-monitor.py [list|check|test|fix|logs]
"""

import os
import sys
import json
import subprocess
from datetime import datetime

def run_cmd(cmd):
    """Run shell command and return output"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout.strip(), result.stderr.strip(), result.returncode

def get_cron_jobs():
    """Get list of cron jobs"""
    stdout, stderr, rc = run_cmd('openclaw cron list --json 2>&1')
    if rc != 0:
        # Try without --json
        stdout, stderr, rc = run_cmd('openclaw cron list 2>&1')
        return None, stdout
    try:
        return json.loads(stdout), None
    except:
        return None, stdout

def get_job_runs(job_id):
    """Get run history for a job"""
    stdout, stderr, rc = run_cmd(f'openclaw cron runs --id {job_id} 2>&1')
    try:
        data = json.loads(stdout)
        return data.get('entries', [])
    except:
        return []

def list_jobs():
    """List all cron jobs"""
    print("📋 Cron Jobs\n")
    
    jobs, text = get_cron_jobs()
    if jobs:
        for job in jobs:
            name = job.get('name', 'unknown')
            schedule = job.get('schedule', {})
            expr = schedule.get('expr', 'unknown')
            tz = schedule.get('tz', 'UTC')
            state = job.get('state', {})
            next_run = state.get('nextRunAtMs')
            last_run = state.get('lastRunAtMs')
            
            print(f"  {name}")
            print(f"    Schedule: {expr} @ {tz}")
            if next_run:
                next_dt = datetime.fromtimestamp(next_run/1000)
                print(f"    Next: {next_dt.strftime('%Y-%m-%d %H:%M')}")
            print()
    else:
        print(text)

def check_jobs():
    """Check all jobs for issues"""
    print("🔍 Cron Job Health Check\n")
    
    jobs, _ = get_cron_jobs()
    if not jobs:
        print("Could not fetch jobs")
        return
    
    issues = []
    
    for job in jobs:
        name = job.get('name', 'unknown')
        job_id = job.get('id', '')
        delivery = job.get('delivery', {})
        
        print(f"  {name}")
        
        # Check delivery config
        if job.get('sessionTarget') == 'isolated':
            # Agent jobs need delivery config
            if not delivery.get('channel'):
                print(f"    ⚠ Missing --channel flag")
                issues.append((name, 'no-channel'))
            elif delivery.get('channel') == 'discord' and not delivery.get('to'):
                print(f"    ⚠ Missing --to for Discord")
                issues.append((name, 'no-target'))
            else:
                print(f"    ✓ Delivery: {delivery.get('channel')} → {delivery.get('to', 'default')}")
        
        # Check recent runs
        runs = get_job_runs(job_id)
        if runs:
            last_run = runs[0]
            status = last_run.get('status')
            delivery_status = last_run.get('deliveryStatus')
            
            if status == 'ok':
                print(f"    ✓ Last run: OK")
            else:
                print(f"    ✗ Last run: {status}")
                issues.append((name, 'run-failed'))
            
            if delivery_status and delivery_status != 'ok':
                print(f"    ⚠ Delivery: {delivery_status}")
                issues.append((name, 'delivery-failed'))
        else:
            print(f"    ℹ No run history")
        
        print()
    
    if issues:
        print(f"⚠ Found {len(issues)} issues")
        print("Run 'cron-monitor fix' to auto-fix")
    else:
        print("✅ All jobs healthy")

def test_job(name):
    """Test run a specific job"""
    print(f"🧪 Testing job: {name}\n")
    
    jobs, _ = get_cron_jobs()
    if not jobs:
        print("Could not fetch jobs")
        return
    
    job = None
    for j in jobs:
        if j.get('name') == name:
            job = j
            break
    
    if not job:
        print(f"Job '{name}' not found")
        print("Run 'cron-monitor list' to see available jobs")
        return
    
    job_id = job.get('id')
    print(f"Triggering test run for {name}...")
    
    stdout, stderr, rc = run_cmd(f'openclaw cron run {job_id} 2>&1')
    
    if rc == 0:
        print(f"✓ Test run triggered")
        print(f"  Check 'openclaw cron runs --id {job_id}' for results")
    else:
        print(f"✗ Failed to trigger: {stderr}")

def fix_jobs():
    """Auto-fix common issues"""
    print("🔧 Auto-fixing cron jobs\n")
    
    jobs, _ = get_cron_jobs()
    if not jobs:
        print("Could not fetch jobs")
        return
    
    # Discord channel for reports
    DISCORD_CHANNEL = '1488075732771934308'
    
    for job in jobs:
        name = job.get('name', '')
        job_id = job.get('id', '')
        delivery = job.get('delivery', {})
        
        # Check if it's an agent job that needs fixing
        if job.get('sessionTarget') == 'isolated':
            needs_fix = False
            
            if not delivery.get('channel'):
                print(f"  {name}: Adding --channel discord")
                needs_fix = True
            
            if delivery.get('channel') == 'discord' and not delivery.get('to'):
                print(f"  {name}: Adding --to {DISCORD_CHANNEL}")
                needs_fix = True
            
            if needs_fix:
                # Remove and recreate job
                print(f"    Recreating {name}...")
                run_cmd(f'openclaw cron rm {job_id} 2>&1')
                
                # Get job details
                schedule = job.get('schedule', {})
                expr = schedule.get('expr', '0 0 * * *')
                tz = schedule.get('tz', 'America/Denver')
                payload = job.get('payload', {})
                message = payload.get('text', '')
                
                # Recreate with proper delivery
                cmd = f'''openclaw cron add \
  --name "{name}" \
  --cron "{expr}" \
  --tz "{tz}" \
  --session isolated \
  --message "{message}" \
  --channel discord \
  --to {DISCORD_CHANNEL} \
  --announce 2>&1'''
                
                stdout, stderr, rc = run_cmd(cmd)
                if rc == 0:
                    print(f"    ✓ Fixed")
                else:
                    print(f"    ✗ Failed: {stderr}")
            else:
                print(f"  {name}: ✓ OK")
    
    print("\n✅ Fix complete")

def show_logs(name):
    """Show recent logs for a job"""
    print(f"📜 Logs for: {name}\n")
    
    jobs, _ = get_cron_jobs()
    if not jobs:
        print("Could not fetch jobs")
        return
    
    job = None
    for j in jobs:
        if j.get('name') == name:
            job = j
            break
    
    if not job:
        print(f"Job '{name}' not found")
        return
    
    job_id = job.get('id')
    runs = get_job_runs(job_id)
    
    if not runs:
        print("No run history")
        return
    
    for i, run in enumerate(runs[:5], 1):
        ts = run.get('ts', 0)
        status = run.get('status', 'unknown')
        dt = datetime.fromtimestamp(ts/1000)
        
        print(f"  Run {i}: {dt.strftime('%Y-%m-%d %H:%M')}")
        print(f"    Status: {status}")
        
        if run.get('error'):
            print(f"    Error: {run['error'][:100]}")
        
        if run.get('summary'):
            summary = run['summary'][:200] + '...' if len(run['summary']) > 200 else run['summary']
            print(f"    Summary: {summary}")
        
        print()

def main():
    if len(sys.argv) < 2:
        print("Usage: cron-monitor.py [list|check|test|fix|logs]")
        print("\nExamples:")
        print("  cron-monitor.py list")
        print("  cron-monitor.py check")
        print("  cron-monitor.py test night-creative")
        print("  cron-monitor.py fix")
        print("  cron-monitor.py logs night-creative")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'list':
        list_jobs()
    elif command == 'check':
        check_jobs()
    elif command == 'test':
        if len(sys.argv) < 3:
            print("Usage: cron-monitor.py test <job-name>")
            sys.exit(1)
        test_job(sys.argv[2])
    elif command == 'fix':
        fix_jobs()
    elif command == 'logs':
        if len(sys.argv) < 3:
            print("Usage: cron-monitor.py logs <job-name>")
            sys.exit(1)
        show_logs(sys.argv[2])
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

if __name__ == '__main__':
    main()
