# Cron Monitor

## Description

Monitors and validates cron jobs, tests execution, and alerts on failures. Ensures scheduled tasks run properly and deliver output to the correct channels.

## Usage

```
cron-monitor list              # List all cron jobs with status
cron-monitor check             # Verify all jobs are healthy
cron-monitor test <job-name>   # Test run a specific job
cron-monitor fix               # Auto-fix common issues
cron-monitor logs <job-name>   # Show recent run logs
```

## When to Use

- After creating or modifying cron jobs
- When jobs aren't delivering to Discord
- To verify jobs ran overnight
- To debug job failures

## What It Checks

1. **Job Configuration:**
   - Schedule is valid
   - Timezone is set (America/Denver)
   - Delivery channel is specified
   - Target channel/destination is valid

2. **Run History:**
   - Last run timestamp
   - Success/failure status
   - Delivery status
   - Error messages

3. **Common Issues:**
   - Missing `--channel` flag
   - Invalid Discord channel ID
   - Wrong session target
   - Delivery failures

## Examples

### Check all jobs

```bash
cron-monitor check
```

Output:
```
🔍 Cron Monitor Check

night-creative (1:30 AM)
  ✓ Schedule: 30 1 * * * @ America/Denver
  ✓ Target: isolated subagent
  ✓ Channel: discord → 1488075732771934308
  ✓ Last run: 33m ago — OK
  ⚠ Delivery: not-delivered (will retry tonight)

dream-cycle (3:00 AM)
  ✓ Schedule: 0 3 * * * @ America/Denver
  ✓ Target: isolated subagent
  ✓ Channel: discord → 1488075732771934308
  ✓ Last run: 32m ago — OK
  ⚠ Delivery: not-delivered

⚠ 2 jobs need attention
Run 'cron-monitor fix' to auto-fix
```

### Test a job

```bash
cron-monitor test night-creative
```

Output:
```
🧪 Testing night-creative...

Spawning test job...
✓ Job started: run-xyz123
✓ Completed in 45s
✓ Output delivered to Discord

Test passed!
```

### Fix issues

```bash
cron-monitor fix
```

Output:
```
🔧 Auto-fixing cron jobs...

night-creative:
  ✓ Added --channel discord
  ✓ Verified --to 1488075732771934308

dream-cycle:
  ✓ Added --channel discord
  ✓ Verified --to 1488075732771934308

✅ All jobs fixed
```

## Implementation

See: `scripts/cron-monitor.py`

## Job Requirements

For Discord delivery, jobs MUST have:
- `--channel discord`
- `--to <channel-id>`
- `--announce` (for output)

## Notes

- Checks run history via `openclaw cron runs`
- Can trigger test runs on demand
- Maintains health status log
- Alerts on consecutive failures
