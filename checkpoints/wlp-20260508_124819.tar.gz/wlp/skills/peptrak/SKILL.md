# PepTrak — Research Compound Tracker

**Status:** Production Ready · v4.0  
**Description:** Next.js app for tracking peptide/research compound dosing schedules with reconstitution math, weekly calendar, and daily checklist. All data in localStorage.  
**Location:** `wlp/projects/mission-control/app/peptrak/`

---

## What It Does

- **Compound Library:** 30+ peptides with autocomplete — type to search, select to auto-fill name, legal name, classification, effects, and overdose symptoms
- **Dose Calculator:** Enter total mg (or IU), prescribed dose (mg or mcg), BAC water volume — outputs units on U-100 insulin syringe
- **Weekly Schedule:** Pick days + time per compound, see 7-day grid with today's highlight
- **Daily Checklist:** Click dose cards to mark done, persistent per date
- **Reconstitution Guide:** 5-step sterile protocol with proper technique
- **Disclaimer:** "NOT FOR HUMAN USE" banners top and bottom

---

## File Structure

```
app/peptrak/
  page.tsx          — Main component (all logic inline, no external deps)
```

No API routes needed. All data stored in `localStorage` keys:
- `peptrak-v2-compounds` — compound configs
- `peptrak-v2-checklist` — daily completion state

---

## CompoundConfig Interface

```typescript
interface CompoundConfig {
  id: string;                    // crypto.randomUUID()
  name: string;                  // e.g., "Retatrutide"
  color: string;                 // hex from PRESET_COLORS
  legalName: string;             // e.g., "Retatrutide (LY3437943)"
  classification: string;        // e.g., "GLP-1/GIP/Glucagon Triple Agonist"
  intendedEffects: string;       // e.g., "Weight loss, metabolic support"
  overdoseSymptoms: string;      // e.g., "Severe nausea, hypoglycemia"
  totalMgInVial: number;         // total amount in vial
  vialUnit: "mg" | "IU";         // unit toggle
  prescribedDosageMg: number;    // stored as mg internally
  doseUnit: "mg" | "mcg";        // unit toggle (mcg ÷1000 for calc)
  bacWaterRatioMl: number;       // mL of BAC water added
  timesPerWeek: number;          // 1-7
  scheduleDays: string[];        // ["Monday", "Wednesday", ...]
  scheduleTime: string;          // "10am", "11pm", etc.
  notes: string;                 // freeform text
}
```

---

## Key Calculations

```typescript
function calculateUnits(dosageMg: number, totalMgInVial: number, bacWaterMl: number): number {
  const mgPerMl = totalMgInVial / bacWaterMl;  // concentration
  const mlNeeded = dosageMg / mgPerMl;
  return Math.round(mlNeeded * 100);             // U-100 syringe
}
```

**Example:** 10 mg vial + 2 mL BAC water = 5 mg/mL. For 1 mg dose = **20 units**.

---

## UI Layout (Top to Bottom)

1. **Disclaimer banner** (red)
2. **Header** — 💉 PepTrak + ▲/▼ Add Compound button + Reconstitution Guide toggle
3. **Add Compound card** (collapsible) — form with all fields
4. **Progress bar** — today's completion %
5. **Day tabs** — Mon-Sun, dot indicator for scheduled days
6. **Daily dose cards** — clickable, color-coded, checkbox
7. **Weekly Schedule** — 7-day grid with compound mini-cards
8. **Compound Inventory** — full detail cards
9. **Disclaimer banner** (red)

---

## Peptide Database (30+ entries)

Stored inline in `PEPTIDE_DATABASE` array. Each entry:
```typescript
{ name, legalName, classification, effects, symptoms }
```

Covers: BPC-157, TB-500, Semaglutide, Tirzepatide, Retatrutide, Tesamorelin, CJC-1295, Ipamorelin, MK-677, HCG, PT-141, Melanotan I/II, Semax, Selank, Epithalon, GHK-Cu, AOD-9604, DSIP, NAD+, LL-37, Thymosin Alpha-1, SS-31, MOTS-c, Humanin, VIP, KPV, Dihexa, PE-22-28, Cerebrolysin, Pentosan Polysulfate

---

## Deployment

```bash
cd wlp/projects/mission-control
npx vercel deploy --prod --token $VERCEL_TOKEN
```

**URL:** https://mission-control-cyan-omega.vercel.app/peptrak

---

## Notes

- **No server-side storage** — all localStorage
- **No auth required** — open to public with disclaimer
- **Compound cards** show: Name (Legal — Classification), concentration, dose, schedule, frequency, effects paragraph, symptoms warning
- **Reconstitution protocol** emphasizes: swab, inject air first, draw air from vial, expel to atmosphere, repeat, never shake
- **Color picker** — 10 preset colors, user-selectable per compound

---

*🦞 PriScylla — Wicked Liquid Productions*
