#!/usr/bin/env python3
"""
Deployment Guardian - Safe deployment with GitHub sync
Usage: python3 deployment-guardian.py [check|deploy|status|history]
"""

import os
import sys
import json
import subprocess
from datetime import datetime
from pathlib import Path

# Config
GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN') or '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'
REPO = 'Animal71Animal/Mission-Control'
BRANCH = 'main'
DATA_FILES = [
    'public/data/srb-tips-data.json',
    'public/data/tesla-charging.json',
    'public/data/personal-tasks.json',
    'public/data/live-episodes.json',
]

def run_cmd(cmd, cwd=None):
    """Run shell command and return output"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
    return result.stdout.strip(), result.stderr.strip(), result.returncode

def get_github_file_sha(path):
    """Get SHA of file on GitHub"""
    import urllib.request
    url = f'https://api.github.com/repos/{REPO}/contents/{path}?ref={BRANCH}'
    headers = {
        'Authorization': f'Bearer {GITHUB_TOKEN}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28'
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode())
            return data.get('sha'), data.get('content')
    except Exception as e:
        return None, None

def commit_file_to_github(path, content, sha, message):
    """Commit file to GitHub"""
    import urllib.request
    url = f'https://api.github.com/repos/{REPO}/contents/{path}'
    headers = {
        'Authorization': f'Bearer {GITHUB_TOKEN}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type': 'application/json'
    }
    data = {
        'message': message,
        'content': content,
        'sha': sha,
        'branch': BRANCH
    }
    req = urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers, method='PUT')
    try:
        with urllib.request.urlopen(req) as resp:
            return True
    except Exception as e:
        print(f"Error committing {path}: {e}")
        return False

def check_local_vs_github():
    """Check if local data files match GitHub"""
    print("🔍 Checking local vs GitHub...\n")
    
    mc_dir = Path('/home/ubuntu/wlp/projects/mission-control')
    issues = []
    
    for file_path in DATA_FILES:
        local_path = mc_dir / file_path
        if not local_path.exists():
            print(f"  ⚠ {file_path} — local file missing")
            issues.append((file_path, 'missing'))
            continue
        
        # Get local content
        with open(local_path, 'r') as f:
            local_content = f.read()
        local_b64 = subprocess.run(
            ['base64', '-w0', str(local_path)],
            capture_output=True, text=True
        ).stdout.strip()
        
        # Get GitHub content
        sha, gh_content_b64 = get_github_file_sha(file_path)
        
        if not gh_content_b64:
            print(f"  ⚠ {file_path} — not on GitHub (needs initial commit)")
            issues.append((file_path, 'new'))
            continue
        
        # Compare
        import base64
        gh_content = base64.b64decode(gh_content_b64).decode('utf-8')
        
        if local_content.strip() == gh_content.strip():
            print(f"  ✓ {file_path} — synced")
        else:
            print(f"  ⚠ {file_path} — local has changes")
            issues.append((file_path, 'modified', sha))
    
    return issues

def commit_changes(issues):
    """Commit modified files to GitHub"""
    print("\n📤 Committing changes to GitHub...\n")
    
    mc_dir = Path('/home/ubuntu/wlp/projects/mission-control')
    committed = []
    
    for issue in issues:
        if issue[1] == 'modified':
            file_path, status, sha = issue
            local_path = mc_dir / file_path
            
            with open(local_path, 'r') as f:
                content = f.read()
            
            import base64
            content_b64 = base64.b64encode(content.encode()).decode()
            
            message = f"data: update {Path(file_path).name}"
            if commit_file_to_github(file_path, content_b64, sha, message):
                print(f"  ✓ {file_path} — committed")
                committed.append(file_path)
            else:
                print(f"  ✗ {file_path} — failed")
    
    return committed

def create_checkpoint():
    """Create local checkpoint"""
    print("\n💾 Creating checkpoint...\n")
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    checkpoint_dir = Path(f'/home/ubuntu/checkpoints/{timestamp}')
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    # Copy essential files
    items_to_copy = [
        '/home/ubuntu/wlp',
        '/home/ubuntu/.openclaw',
        '/home/ubuntu/.env',
        '/home/ubuntu/MEMORY.md',
        '/home/ubuntu/AGENTS.md',
        '/home/ubuntu/USER.md',
        '/home/ubuntu/SOUL.md',
        '/home/ubuntu/TOOLS.md',
        '/home/ubuntu/IDENTITY.md',
    ]
    
    for item in items_to_copy:
        if os.path.exists(item):
            dest = checkpoint_dir / Path(item).name
            if os.path.isdir(item):
                subprocess.run(['cp', '-r', item, str(dest)], check=False)
            else:
                subprocess.run(['cp', item, str(dest)], check=False)
    
    print(f"  ✓ Checkpoint: {checkpoint_dir}")
    return checkpoint_dir

def deploy_to_vercel():
    """Deploy to Vercel"""
    print("\n🚀 Deploying to Vercel...\n")
    
    mc_dir = '/home/ubuntu/wlp/projects/mission-control'
    stdout, stderr, rc = run_cmd('npx vercel --prod --yes', cwd=mc_dir)
    
    if rc == 0:
        # Extract URL from output
        for line in stdout.split('\n'):
            if 'mission-control-' in line and 'vercel.app' in line:
                print(f"  ✓ Deployed: {line.strip()}")
                return True
        print("  ✓ Deployed successfully")
        return True
    else:
        print(f"  ✗ Deployment failed: {stderr}")
        return False

def log_deployment(committed_files, checkpoint):
    """Log deployment to file"""
    log_entry = {
        'timestamp': datetime.now().isoformat(),
        'files_committed': committed_files,
        'checkpoint': str(checkpoint),
        'vercel_url': 'https://mission-control-cyan-omega.vercel.app'
    }
    
    log_dir = Path('/home/ubuntu/wlp/ops')
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / 'deploy-log.json'
    
    logs = []
    if log_file.exists():
        with open(log_file, 'r') as f:
            logs = json.load(f)
    
    logs.append(log_entry)
    
    with open(log_file, 'w') as f:
        json.dump(logs, f, indent=2)

def show_status():
    """Show current deployment status"""
    print("📊 Deployment Status\n")
    
    # Check last deploy
    log_file = Path('/home/ubuntu/wlp/ops/deploy-log.json')
    if log_file.exists():
        with open(log_file, 'r') as f:
            logs = json.load(f)
        if logs:
            last = logs[-1]
            print(f"Last deployment: {last['timestamp']}")
            print(f"URL: {last['vercel_url']}")
            print(f"Files committed: {len(last['files_committed'])}")
    
    # Check GitHub sync status
    print("\nGitHub Sync Status:")
    issues = check_local_vs_github()
    
    if not issues:
        print("\n✅ All files synced")
    else:
        print(f"\n⚠ {len(issues)} files need attention")

def show_history():
    """Show deployment history"""
    print("📜 Deployment History\n")
    
    log_file = Path('/home/ubuntu/wlp/ops/deploy-log.json')
    if not log_file.exists():
        print("No deployments logged yet")
        return
    
    with open(log_file, 'r') as f:
        logs = json.load(f)
    
    for i, log in enumerate(reversed(logs[-10:]), 1):
        ts = datetime.fromisoformat(log['timestamp']).strftime('%Y-%m-%d %H:%M')
        files = len(log['files_committed'])
        print(f"{i}. {ts} — {files} files — {log['vercel_url']}")

def main():
    if len(sys.argv) < 2:
        print("Usage: deployment-guardian.py [check|deploy|status|history]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'check':
        issues = check_local_vs_github()
        if issues:
            print(f"\n⚠ {len(issues)} files need attention")
            print("Run 'deployment-guardian deploy' to commit and deploy")
        else:
            print("\n✅ All files synced with GitHub")
    
    elif command == 'deploy':
        # Step 1: Check for changes
        issues = check_local_vs_github()
        
        # Step 2: Commit changes
        if issues:
            committed = commit_changes(issues)
        else:
            committed = []
        
        # Step 3: Create checkpoint
        checkpoint = create_checkpoint()
        
        # Step 4: Deploy
        if deploy_to_vercel():
            # Step 5: Log
            log_deployment(committed, checkpoint)
            print("\n✅ Deployment complete!")
        else:
            print("\n✗ Deployment failed")
            sys.exit(1)
    
    elif command == 'status':
        show_status()
    
    elif command == 'history':
        show_history()
    
    else:
        print(f"Unknown command: {command}")
        print("Usage: deployment-guardian.py [check|deploy|status|history]")
        sys.exit(1)

if __name__ == '__main__':
    main()
