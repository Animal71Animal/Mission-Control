# Deployment Guardian

## Description

Automated deployment verification and state management for Mission Control. Ensures data is committed to GitHub before deployment, verifies deployment success, and maintains deployment history.

## Usage

```
deployment-guardian check     # Check local vs GitHub vs deployed state
deployment-guardian deploy    # Full deploy with safety checks
deployment-guardian status    # Show current deployment status
deployment-guardian history   # Show recent deploy log
```

## When to Use

- Before any Mission Control deployment
- When data seems out of sync
- To verify deployment succeeded
- To check what changed since last deploy

## What It Does

1. **Pre-deploy checks:**
   - Compares local data files with GitHub
   - Identifies uncommitted changes
   - Auto-commits data changes if needed
   - Verifies GitHub token is valid

2. **Deploy process:**
   - Creates checkpoint backup
   - Runs Vercel deployment
   - Waits for deployment completion
   - Verifies new deployment is live

3. **Post-deploy:**
   - Logs deployment with timestamp
   - Records what changed
   - Reports success/failure

## Examples

### Check state before deploying

```bash
deployment-guardian check
```

Output:
```
Checking deployment state...

Local vs GitHub:
  ✓ srb-tips-data.json — synced
  ✓ tesla-charging.json — synced
  ⚠ personal-tasks.json — local has changes

Action: Run 'deployment-guardian deploy' to commit and deploy
```

### Full deploy with checks

```bash
deployment-guardian deploy
```

Output:
```
🛡️ Deployment Guardian

Step 1: Committing data changes...
  ✓ personal-tasks.json committed to GitHub

Step 2: Creating checkpoint...
  ✓ Checkpoint saved: checkpoints/20260405_213300

Step 3: Deploying to Vercel...
  ✓ Build started: mission-control-xyz123
  ✓ Deployment complete

Step 4: Verifying...
  ✓ New version is live at mission-control-cyan-omega.vercel.app

✅ Deployment successful!
Logged: 2026-04-05 21:33 UTC
Changes: personal-tasks.json
```

## Implementation

See: `scripts/guardian.py`

## Files Managed

- `public/data/srb-tips-data.json`
- `public/data/tesla-charging.json`
- `public/data/personal-tasks.json`
- `public/data/*.json` (all data files)

## Notes

- Always commits data before deploying
- Creates checkpoint on every deploy
- Logs all deployments to `wlp/ops/deploy-log.json`
- Requires `GITHUB_TOKEN` env var
