# Checkpoint Manager

## Description

Automated system checkpointing with GitHub backup and recovery procedures. Ensures quick restoration after failures or migrations.

## Usage

```
checkpoint-manager create              # Create manual checkpoint
checkpoint-manager auto                # Enable auto-daily checkpoints
checkpoint-manager list                # List available checkpoints
checkpoint-manager restore <name>      # Restore from checkpoint
checkpoint-manager verify <name>       # Verify checkpoint integrity
checkpoint-manager clean               # Remove old checkpoints
```

## When to Use

- Before major system changes
- After completing significant work
- Weekly backup routine
- When setting up new instance
- After system recovery

## What It Backs Up

| Category | Files |
|----------|-------|
| **Config** | `.openclaw/openclaw.json`, `.openclaw/cron/`, `.openclaw/credentials/` |
| **Memory** | `.openclaw/memory/`, `MEMORY.md`, daily logs |
| **Identity** | `IDENTITY.md`, `SOUL.md`, `USER.md`, `AGENTS.md`, `TOOLS.md` |
| **Data** | `wlp/data/`, `wlp/ops/`, `wlp/skills/` |
| **Projects** | `wlp/projects/mission-control/public/data/`, `.env.local` |
| **Secrets** | `.env`, `.config/gogcli/credentials.json`, `.local/share/com.vercel.cli/` |

## Examples

### Create checkpoint

```bash
checkpoint-manager create
```

Output:
```
💾 Creating checkpoint...

Files included:
  ✓ .openclaw/ (config, cron, credentials)
  ✓ Memory files (6.7KB)
  ✓ Identity files (5 files)
  ✓ wlp/ (skills, data, ops)
  ✓ Project data files
  ✓ Secrets (tokens, env)

Creating archive...
  ✓ Local: checkpoints/20260405_213300/
  ✓ Zip: backups/wlp-essentials-20260405_213300.zip (1.1MB)
  ✓ Full: backups/wlp-full-20260405_213300.zip (51MB)

Uploading to GitHub...
  ✓ backups/wlp-backup-20260405.zip
  ✓ backups/memory-backup-20260405.zip
  ✓ checkpoints/CHECKPOINT-2026-04-05.json

✅ Checkpoint complete!
Timestamp: 2026-04-05 21:33 UTC
GitHub: https://github.com/Animal71Animal/Mission-Control/tree/main/backups
```

### List checkpoints

```bash
checkpoint-manager list
```

Output:
```
📋 Available Checkpoints

GitHub Backups:
  2026-04-05 21:33 — wlp-backup-2026-04-05.zip (1.1MB)
  2026-04-05 21:33 — memory-backup-2026-04-05.zip (1.8KB)
  2026-04-04 11:29 — wlp-backup-2026-04-04.zip (1.0MB)

Local Checkpoints:
  20260405_213042/ (60KB)
  20260405_112959/ (58KB)

Recovery Priority: Use GitHub backups for new instances
```

### Restore on new instance

```bash
# Download from GitHub
curl -L -o backup.zip https://github.com/Animal71Animal/Mission-Control/raw/main/backups/wlp-backup-2026-04-05.zip

# Extract
unzip backup.zip -d /home/ubuntu/

# Verify
checkpoint-manager verify
```

### Enable auto-checkpoints

```bash
checkpoint-manager auto
```

Output:
```
🤖 Auto-checkpoint enabled

Schedule: Daily at 3:00 AM MDT (after dream-cycle)
Retention: 7 local, 30 GitHub
Next checkpoint: 2026-04-06 03:00 AM
```

## Recovery Procedures

### Full system recovery

```bash
# 1. Download latest backup
curl -L -o wlp-backup.zip \
  https://github.com/Animal71Animal/Mission-Control/raw/main/backups/wlp-backup-2026-04-05.zip

# 2. Extract to home
cd ~ && unzip wlp-backup.zip

# 3. Verify OpenClaw config
openclaw doctor

# 4. Restore cron jobs
openclaw cron import .openclaw/cron/jobs.json

# 5. Test channels
channel-router test discord
channel-router test telegram

# 6. Deploy Mission Control
deployment-guardian deploy
```

### Partial data recovery

```bash
# Restore specific data file
curl -L -o srb-tips-data.json \
  https://raw.githubusercontent.com/Animal71Animal/Mission-Control/main/public/data/srb-tips-data.json
```

## Implementation

See: `scripts/checkpoint-manager.py`

## Auto-Checkpoint Triggers

Daily checkpoint runs after:
- `dream-cycle` completes (3:00 AM MDT)
- Before any major deployment
- After data mutations (Tesla, SRB tips, tasks)

## Notes

- GitHub backups survive local failures
- Local checkpoints for quick rollback
- Always verify after restore
- Keep `GITHUB_TOKEN` safe for recovery
