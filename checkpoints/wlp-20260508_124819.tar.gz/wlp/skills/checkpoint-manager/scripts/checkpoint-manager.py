#!/usr/bin/env python3
"""
Checkpoint Manager - Automated system backup and recovery
Usage: python3 checkpoint-manager.py [create|auto|list|restore|verify]
"""

import os
import sys
import json
import subprocess
import base64
from datetime import datetime
from pathlib import Path

# Config
GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN') or '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'
REPO = 'Animal71Animal/Mission-Control'
BRANCH = 'main'

# Files to backup
BACKUP_ITEMS = [
    '/home/ubuntu/wlp',
    '/home/ubuntu/.openclaw',
    '/home/ubuntu/.env',
    '/home/ubuntu/.config/gogcli',
    '/home/ubuntu/.local/share/com.vercel.cli',
    '/home/ubuntu/MEMORY.md',
    '/home/ubuntu/AGENTS.md',
    '/home/ubuntu/USER.md',
    '/home/ubuntu/SOUL.md',
    '/home/ubuntu/TOOLS.md',
    '/home/ubuntu/HEARTBEAT.md',
    '/home/ubuntu/IDENTITY.md',
]

def run_cmd(cmd, cwd=None):
    """Run shell command"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
    return result.stdout.strip(), result.stderr.strip(), result.returncode

def upload_to_github(path, content, message, sha=None):
    """Upload file to GitHub"""
    import urllib.request
    
    url = f'https://api.github.com/repos/{REPO}/contents/{path}'
    headers = {
        'Authorization': f'Bearer {GITHUB_TOKEN}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type': 'application/json'
    }
    
    data = {
        'message': message,
        'content': base64.b64encode(content).decode(),
        'branch': BRANCH
    }
    
    if sha:
        data['sha'] = sha
    
    req = urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers, method='PUT')
    try:
        with urllib.request.urlopen(req) as resp:
            return True
    except Exception as e:
        print(f"    Error uploading: {e}")
        return False

def create_checkpoint():
    """Create full system checkpoint"""
    print("💾 Creating checkpoint...\n")
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    date_str = datetime.now().strftime('%Y-%m-%d')
    
    # Create local checkpoint
    checkpoint_dir = Path(f'/home/ubuntu/checkpoints/{timestamp}')
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    print("Copying files...")
    for item in BACKUP_ITEMS:
        if os.path.exists(item):
            dest = checkpoint_dir / Path(item).name
            if os.path.isdir(item):
                subprocess.run(['cp', '-r', item, str(dest)], check=False)
            else:
                subprocess.run(['cp', item, str(dest)], check=False)
            print(f"  ✓ {Path(item).name}")
    
    # Create essentials zip (without node_modules)
    print("\nCreating essentials zip...")
    essentials_zip = f'/home/ubuntu/backups/wlp-essentials-{timestamp}.zip'
    subprocess.run([
        'zip', '-r', essentials_zip,
        str(checkpoint_dir),
        '-x', '*/node_modules/*', '-x', '*/.next/*', '-x', '*/.git/*'
    ], check=False, cwd='/home/ubuntu')
    
    # Create full zip
    print("Creating full zip...")
    full_zip = f'/home/ubuntu/backups/wlp-full-{timestamp}.zip'
    subprocess.run(['zip', '-r', full_zip, str(checkpoint_dir)], check=False, cwd='/home/ubuntu')
    
    # Upload to GitHub
    print("\nUploading to GitHub...")
    
    # Read essentials zip
    with open(essentials_zip, 'rb') as f:
        essentials_content = f.read()
    
    # Upload with date-based name
    github_path = f'backups/wlp-backup-{date_str}.zip'
    if upload_to_github(github_path, essentials_content, f'backup: full system {date_str}'):
        print(f"  ✓ Uploaded: {github_path}")
    
    # Create checkpoint info
    checkpoint_info = {
        'timestamp': datetime.now().isoformat(),
        'date': date_str,
        'description': 'Full system checkpoint',
        'local_path': str(checkpoint_dir),
        'github_url': f'https://github.com/{REPO}/blob/main/{github_path}',
        'files_included': len(BACKUP_ITEMS)
    }
    
    info_path = f'checkpoints/CHECKPOINT-{date_str}.json'
    upload_to_github(info_path, json.dumps(checkpoint_info, indent=2).encode(), 
                    f'checkpoint: system state {date_str}')
    
    print(f"\n✅ Checkpoint complete!")
    print(f"  Local: {checkpoint_dir}")
    print(f"  GitHub: {github_path}")
    
    return checkpoint_dir

def list_checkpoints():
    """List available checkpoints"""
    print("📋 Available Checkpoints\n")
    
    # Local checkpoints
    checkpoints_dir = Path('/home/ubuntu/checkpoints')
    if checkpoints_dir.exists():
        local = sorted([d.name for d in checkpoints_dir.iterdir() if d.is_dir()], reverse=True)
        if local:
            print("Local checkpoints:")
            for cp in local[:5]:
                print(f"  • {cp}")
    
    # GitHub backups
    print("\nGitHub backups (download with curl):")
    print("  • wlp-backup-2026-04-05.zip")
    print("  • memory-backup-2026-04-05.zip")
    print(f"\nURL: https://github.com/{REPO}/tree/main/backups")

def enable_auto():
    """Enable auto-daily checkpoints"""
    print("🤖 Enabling auto-checkpoints...\n")
    
    # Check if cron job exists
    stdout, _, _ = run_cmd('openclaw cron list | grep checkpoint')
    
    if stdout:
        print("Auto-checkpoint already enabled")
        return
    
    # Create checkpoint job (runs at 3:30 AM after dream-cycle)
    cmd = '''openclaw cron add \
  --name "checkpoint-manager" \
  --cron "30 3 * * *" \
  --tz "America/Denver" \
  --session main \
  --system-event "checkpoint-manager" 2>&1'''
    
    stdout, stderr, rc = run_cmd(cmd)
    
    if rc == 0:
        print("✅ Auto-checkpoint enabled")
        print("  Schedule: Daily at 3:30 AM MDT")
        print("  Next: Tomorrow 3:30 AM")
    else:
        print(f"❌ Failed: {stderr}")

def verify_checkpoint(checkpoint_name):
    """Verify checkpoint integrity"""
    checkpoint_dir = Path(f'/home/ubuntu/checkpoints/{checkpoint_name}')
    
    if not checkpoint_dir.exists():
        print(f"Checkpoint not found: {checkpoint_name}")
        return False
    
    print(f"🔍 Verifying {checkpoint_name}...\n")
    
    # Check critical files
    critical = ['.openclaw/openclaw.json', 'wlp', 'MEMORY.md']
    
    for item in critical:
        path = checkpoint_dir / item
        if path.exists():
            print(f"  ✓ {item}")
        else:
            print(f"  ⚠ {item} missing")
    
    print("\n✅ Verification complete")
    return True

def restore_checkpoint(checkpoint_name):
    """Restore from checkpoint"""
    print(f"📥 Restoring from {checkpoint_name}...\n")
    
    checkpoint_dir = Path(f'/home/ubuntu/checkpoints/{checkpoint_name}')
    
    if not checkpoint_dir.exists():
        print(f"Checkpoint not found locally")
        print("Download from GitHub first:")
        print(f"  curl -L -o backup.zip https://github.com/{REPO}/raw/main/backups/wlp-backup-2026-04-05.zip")
        return False
    
    # Restore files
    for item in ['.openclaw', 'wlp', 'MEMORY.md', 'AGENTS.md', 'USER.md', 'SOUL.md', 'TOOLS.md', 'IDENTITY.md']:
        src = checkpoint_dir / item
        if src.exists():
            dest = Path(f'/home/ubuntu/{item}')
            if dest.exists():
                subprocess.run(['rm', '-rf', str(dest)], check=False)
            subprocess.run(['cp', '-r', str(src), str(dest)], check=False)
            print(f"  ✓ Restored {item}")
    
    print("\n✅ Restore complete")
    print("\nNext steps:")
    print("  1. Run 'openclaw doctor' to verify")
    print("  2. Run 'openclaw cron list' to check jobs")
    print("  3. Deploy Mission Control if needed")
    
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: checkpoint-manager.py [create|auto|list|restore|verify]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'create':
        create_checkpoint()
    
    elif command == 'auto':
        enable_auto()
    
    elif command == 'list':
        list_checkpoints()
    
    elif command == 'restore':
        if len(sys.argv) < 3:
            print("Usage: checkpoint-manager.py restore <checkpoint-name>")
            list_checkpoints()
            sys.exit(1)
        restore_checkpoint(sys.argv[2])
    
    elif command == 'verify':
        if len(sys.argv) < 3:
            print("Usage: checkpoint-manager.py verify <checkpoint-name>")
            sys.exit(1)
        verify_checkpoint(sys.argv[2])
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)

if __name__ == '__main__':
    main()
