---
name: uber-tracking
description: Uber shift profit calculation and expense tracking with Tesla charging deduction. Tracks gross earnings, miles, charging costs, and net profit per shift. Generates monthly summaries for P&L analysis.
---

# Uber Shift Tracking

Track Uber earnings with proportional Tesla charging cost deduction.

---

## Shift Data Format

When you complete an Uber shift, you'll provide:

```
Uber start: [odometer reading]
Uber done: [final odometer], gross $[earnings], charged [yes/no]
```

I calculate everything else.

---

## Profit Calculation Formula

### Inputs
- **Gross Earnings** — from Uber app (sum of all rides)
- **Miles Driven** — final odometer - start odometer
- **Charging Session** — if you charged before/after shift
  - Cost: $Z
  - Total kWh: K
  - Rate per kWh: P

### Formula

```
Tesla Efficiency: 3.5 mi/kWh (EPA rating for Model 3/Y)

kWh Used in Shift: miles_driven ÷ 3.5

Proportional Charging Cost:
  = session_cost × (kWh_used / kWh_total)

Net Profit:
  = gross_earnings - proportional_charging_cost

Hourly Rate:
  = net_profit ÷ (duration_minutes ÷ 60)
```

### Example

**Scenario:**
- Start odometer: 107,735
- End odometer: 107,773
- Miles: 38
- Gross: $44.90
- Charged: Yes (37.54 kWh @ $14.26 before shift)

**Calculation:**
```
kWh used = 38 ÷ 3.5 = 10.86 kWh
proportional cost = $14.26 × (10.86 / 37.54) = $4.12
net profit = $44.90 - $4.12 = $40.78
duration = 1 hr 57 min = 1.95 hrs
hourly rate = $40.78 ÷ 1.95 = $20.91/hr
```

---

## Data Storage

**Location:** `/home/ubuntu/wlp/projects/mission-control/public/data/uber-profit.json`

**Structure:**
```json
{
  "uber_shifts": [
    {
      "id": "uber-YYYYMMDD-#",
      "date": "YYYY-MM-DD",
      "start_time": "HH:MM",
      "end_time": "HH:MM",
      "duration_minutes": 117,
      "start_odometer": 107735,
      "end_odometer": 107773,
      "miles_driven": 38,
      "gross_earnings": 44.90,
      "charging_session_id": "tesla-YYYYMMDD-##",
      "charging_cost_total": 14.26,
      "charging_kwh_total": 37.54,
      "charging_kwh_used_in_shift": 10.86,
      "proportional_charging_cost": 4.12,
      "net_profit": 40.78,
      "hourly_rate": 20.91,
      "notes": "Optional notes",
      "created_at": "ISO timestamp"
    }
  ],
  "expenses": [
    {
      "date": "YYYY-MM-DD",
      "type": "charging",
      "amount": 4.12,
      "shift_id": "uber-YYYYMMDD-1",
      "notes": "Proportional deduction from session"
    }
  ],
  "monthly_summary": {
    "YYYY-MM": {
      "shifts": 5,
      "total_gross": 224.50,
      "total_charges": 18.45,
      "total_net": 206.05,
      "total_miles": 189,
      "avg_hourly_rate": 22.35,
      "avg_miles_per_shift": 37.8
    }
  },
  "last_updated": "ISO timestamp"
}
```

---

## Workflow

### 1. Start Shift
Text: `Uber start 107735`
- I log start time + odometer
- Awaiting end-of-shift report

### 2. End Shift
Text: `Uber done 107773, gross $44.90, charged yes`
- I pull the Tesla charging session from that date (if "charged yes")
- Calculate proportional cost
- Log shift to uber-profit.json
- Update monthly_summary
- Deploy to Mission Control

### 3. Review
- Check `/uber-profit` on Mission Control
- Weekly/monthly summaries auto-generate

---

## Notes

- **Efficiency Constant:** 3.5 mi/kWh is EPA spec for Tesla Model 3/Y. If your actual efficiency differs, let me know and I'll adjust.
- **Charging Attribution:** Only deduct charging costs for sessions directly tied to Uber. Personal trips don't count.
- **No Maintenance/Insurance:** This tracks fuel cost only, not wear-and-tear, insurance, registration, or taxes.
- **Platform:** Uber app screenshot gives gross earnings (100% accurate from their system).

---

## Files

- **Data:** `public/data/uber-profit.json`
- **Dashboard:** Mission Control > `/uber-profit` tab
- **Formula:** TOOLS.md (backup reference)

