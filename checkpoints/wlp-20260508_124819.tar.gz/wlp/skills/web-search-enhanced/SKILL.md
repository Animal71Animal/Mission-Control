---
name: web-search-enhanced
description: Enhanced web search with result synthesis, source credibility scoring, and structured output. Searches multiple engines (Brave, fallback to others), ranks results by relevance and authority, and provides synthesized summaries with citations. Use when you need comprehensive research, fact-checking, or current information beyond a simple search.
triggers:
  - "deep search"
  - "research this"
  - "find comprehensive"
  - "synthesize search results"
  - "enhanced search"
---

# Web Search Enhanced

Multi-engine web search with intelligent synthesis and source ranking.

## What It Does

1. **Searches** across multiple sources (Brave primary, others as fallback)
2. **Ranks** results by relevance, authority, and recency
3. **Synthesizes** findings into coherent summaries
4. **Cites** sources with credibility indicators

## When to Use

- Deep research on a topic
- Fact-checking claims
- Finding current information (news, trends)
- Comparing multiple sources
- Building knowledge for decisions

## When NOT to Use

- Simple lookups (use basic `web_search`)
- Known specific URLs (use `web_fetch` directly)
- Code documentation (use skill docs or fetch)

## Usage

```python
# Run enhanced search
python3 ~/wlp/skills/web-search-enhanced/scripts/search.py "AI music generation tools 2026"

# With options
python3 ~/wlp/skills/web-search-enhanced/scripts/search.py \
  --query "BeatSource vs DJ City pricing" \
  --results 10 \
  --synthesize \
  --output json
```

## Output Format

### Standard (Markdown)
```markdown
# Search: "AI music generation tools 2026"

## Synthesis
The AI music generation landscape in 2026 is dominated by Suno and Udio for 
consumer-facing tools, with professional DJs increasingly using AI stems 
and remix tools integrated into traditional DAWs.

## Key Findings

### 1. Suno v4 (High Credibility)
- **Source:** TechCrunch, The Verge
- **Key Point:** New stem separation features target DJs
- **URL:** https://...

### 2. Udio Studio (High Credibility)
- **Source:** MusicTech, DJ Mag
- **Key Point:** Professional tier launched with commercial licensing
- **URL:** https://...

### 3. Native Integration (Medium Credibility)
- **Source:** Reddit r/DJs, Gearslutz
- **Key Point:** Ableton and FL Studio adding AI features natively
- **URL:** https://...

## Source Credibility
- High: 4 sources (established publications)
- Medium: 3 sources (industry blogs, forums)
- Low: 1 source (social media, unverified)
```

### JSON Output
```json
{
  "query": "AI music generation tools 2026",
  "synthesis": "The AI music generation landscape...",
  "findings": [
    {
      "title": "Suno v4",
      "credibility": "high",
      "sources": ["TechCrunch", "The Verge"],
      "key_point": "New stem separation features target DJs",
      "url": "https://..."
    }
  ],
  "credibility_summary": {
    "high": 4,
    "medium": 3,
    "low": 1
  }
}
```

## Credibility Scoring

| Score | Indicators |
|-------|------------|
| **High** | Established publications (NYT, WSJ, TechCrunch), official sources, academic papers |
| **Medium** | Industry blogs, reputable forums, known experts |
| **Low** | Social media, unknown blogs, user-generated content without verification |

## Features

- **Multi-engine:** Brave primary, DuckDuckGo fallback
- **Deduplication:** Removes duplicate content across sources
- **Freshness bias:** Prioritizes recent results for time-sensitive queries
- **Source diversity:** Ensures multiple perspectives
- **Quote extraction:** Pulls key quotes with context

## Rate Limits

- Brave: 2000 queries/month free tier
- Respects robots.txt and crawl delays
- Caches results for 1 hour to reduce API calls

## Safety

- No tracking or logging of queries
- Respects source robots.txt
- Includes source URLs for verification
- Flags potential misinformation sources
