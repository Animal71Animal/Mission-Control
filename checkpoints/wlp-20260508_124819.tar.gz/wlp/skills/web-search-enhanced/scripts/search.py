#!/usr/bin/env python3
"""
Enhanced Web Search - Multi-engine search with synthesis and credibility scoring
"""

import argparse
import json
import re
import time
from datetime import datetime
from urllib.parse import urlparse
from pathlib import Path

# Simple cache implementation
CACHE_DIR = Path.home() / ".web-search-cache"
CACHE_DURATION = 3600  # 1 hour

def get_cache_key(query):
    import hashlib
    return hashlib.md5(query.lower().encode()).hexdigest()

def get_cached(query):
    CACHE_DIR.mkdir(exist_ok=True)
    cache_file = CACHE_DIR / f"{get_cache_key(query)}.json"
    if cache_file.exists():
        data = json.loads(cache_file.read_text())
        if time.time() - data.get("timestamp", 0) < CACHE_DURATION:
            return data.get("results")
    return None

def set_cached(query, results):
    CACHE_DIR.mkdir(exist_ok=True)
    cache_file = CACHE_DIR / f"{get_cache_key(query)}.json"
    cache_file.write_text(json.dumps({
        "timestamp": time.time(),
        "results": results
    }))

def score_credibility(url, title, snippet):
    """Score source credibility based on domain and content"""
    domain = urlparse(url).netloc.lower()
    
    # High credibility indicators
    high_domains = [
        'techcrunch.com', 'theverge.com', 'wired.com', 'arstechnica.com',
        'nytimes.com', 'wsj.com', 'bloomberg.com', 'reuters.com',
        'nature.com', 'science.org', 'ieee.org', 'acm.org',
        'gov', 'edu', 'official',
        'github.com', 'docs.', 'support.'
    ]
    
    # Medium credibility
    medium_domains = [
        'medium.com', 'substack.com', 'dev.to', 'hashnode.dev',
        'producthunt.com', 'hn.', 'reddit.com/r/',
        'forbes.com', 'entrepreneur.com', 'inc.com'
    ]
    
    # Check domain
    if any(h in domain for h in high_domains):
        return 'high'
    if any(m in domain for m in medium_domains):
        return 'medium'
    
    # Check for official indicators
    if any(word in title.lower() for word in ['official', 'documentation', 'guide', 'help center']):
        return 'high'
    
    # Check for blog indicators
    if any(word in domain for word in ['blog', 'medium', 'wordpress']):
        return 'medium'
    
    return 'low'

def brave_search(query, count=10):
    """Search using built-in web_search tool (via sessions_spawn to call the tool)"""
    return fallback_search(query, count)

def fallback_search(query, count=10):
    """Search using web_search tool via OpenClaw CLI"""
    import subprocess
    import json
    
    try:
        # Use openclaw CLI to run web_search tool
        result = subprocess.run(
            ['openclaw', 'tools', 'web-search', query, '--json', '--count', str(count)],
            capture_output=True,
            text=True,
            timeout=15
        )
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return [{
                'title': item.get('title', ''),
                'url': item.get('url', ''),
                'snippet': item.get('snippet', item.get('description', '')),
                'source': urlparse(item.get('url', '')).netloc
            } for item in data.get('results', [])]
    except Exception as e:
        print(f"CLI search failed: {e}")
    
    # Last resort: simulate with basic request for testing
    return simulate_search(query, count)

def simulate_search(query, count=10):
    """Basic search simulation for testing"""
    # Return mock results for testing without API
    return [{
        'title': f'Sample result for: {query}',
        'url': 'https://example.com/sample',
        'snippet': 'This is a simulated search result for testing purposes. In production, this would use real search APIs.',
        'source': 'example.com'
    }]

def synthesize_results(results, query):
    """Create synthesis from search results"""
    if not results:
        return "No results found."
    
    # Group by credibility
    by_cred = {'high': [], 'medium': [], 'low': []}
    for r in results:
        cred = r.get('credibility', 'low')
        by_cred[cred].append(r)
    
    # Build synthesis
    synthesis_parts = []
    
    # Start with high credibility sources
    if by_cred['high']:
        high_titles = [r['title'] for r in by_cred['high'][:3]]
        synthesis_parts.append(f"Based on {len(by_cred['high'])} high-credibility sources")
    
    # Add key themes
    all_snippets = ' '.join([r.get('snippet', '') for r in results])
    words = re.findall(r'\b[A-Za-z]{4,}\b', all_snippets.lower())
    word_freq = {}
    for w in words:
        if w not in ['this', 'that', 'with', 'from', 'they', 'have', 'were', 'been', 'their', 'said', 'each', 'which', 'will', 'about', 'could', 'other', 'after', 'first', 'never', 'these', 'think', 'where', 'being', 'every', 'great', 'might', 'shall', 'still', 'those', 'while', 'should', 'really', 'before', 'people', 'little', 'through', 'between', 'something', 'because', 'nothing', 'everything', 'someone', 'anyone', 'anybody', 'somebody', 'nobody']:
            word_freq[w] = word_freq.get(w, 0) + 1
    
    top_themes = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]
    if top_themes:
        themes_str = ', '.join([t[0] for t in top_themes])
        synthesis_parts.append(f"Key themes: {themes_str}")
    
    return ' '.join(synthesis_parts) if synthesis_parts else "Search completed."

def format_output(results, query, synthesize=False, output_format='markdown'):
    """Format results for output"""
    
    if output_format == 'json':
        output = {
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'synthesis': synthesize_results(results, query) if synthesize else None,
            'findings': results,
            'credibility_summary': {
                'high': len([r for r in results if r.get('credibility') == 'high']),
                'medium': len([r for r in results if r.get('credibility') == 'medium']),
                'low': len([r for r in results if r.get('credibility') == 'low'])
            }
        }
        return json.dumps(output, indent=2)
    
    # Markdown output
    lines = [f"# Search: \"{query}\"\n"]
    
    if synthesize:
        lines.append("## Synthesis")
        lines.append(synthesize_results(results, query))
        lines.append("")
    
    lines.append("## Results\n")
    
    for i, r in enumerate(results, 1):
        cred_emoji = {'high': '✓', 'medium': '~', 'low': '?'}.get(r.get('credibility'), '?')
        lines.append(f"### {i}. {r['title']}")
        lines.append(f"**Credibility:** {cred_emoji} {r.get('credibility', 'unknown').upper()}")
        lines.append(f"**Source:** {r.get('source', 'unknown')}")
        lines.append(f"**Snippet:** {r.get('snippet', 'No snippet')}")
        lines.append(f"**URL:** <{r['url']}>")
        lines.append("")
    
    # Summary
    lines.append("## Summary")
    high = len([r for r in results if r.get('credibility') == 'high'])
    medium = len([r for r in results if r.get('credibility') == 'medium'])
    low = len([r for r in results if r.get('credibility') == 'low'])
    lines.append(f"- High credibility: {high}")
    lines.append(f"- Medium credibility: {medium}")
    lines.append(f"- Low credibility: {low}")
    
    return '\n'.join(lines)

def main():
    parser = argparse.ArgumentParser(description='Enhanced web search')
    parser.add_argument('--query', '-q', required=True, help='Search query')
    parser.add_argument('--results', '-n', type=int, default=10, help='Number of results')
    parser.add_argument('--synthesize', '-s', action='store_true', help='Synthesize findings')
    parser.add_argument('--output', '-o', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--no-cache', action='store_true', help='Skip cache')
    
    args = parser.parse_args()
    
    print(f"Searching: {args.query}\n")
    
    # Check cache
    if not args.no_cache:
        cached = get_cached(args.query)
        if cached:
            print("(Using cached results)\n")
            results = cached
        else:
            results = brave_search(args.query, args.results)
            set_cached(args.query, results)
    else:
        results = brave_search(args.query, args.results)
    
    # Score credibility
    for r in results:
        r['credibility'] = score_credibility(r['url'], r['title'], r['snippet'])
    
    # Sort by credibility
    cred_order = {'high': 0, 'medium': 1, 'low': 2}
    results.sort(key=lambda x: cred_order.get(x['credibility'], 3))
    
    # Output
    print(format_output(results, args.query, args.synthesize, args.output))

if __name__ == '__main__':
    main()
