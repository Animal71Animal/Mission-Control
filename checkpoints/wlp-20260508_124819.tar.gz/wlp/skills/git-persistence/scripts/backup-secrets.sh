#!/bin/bash
# backup-secrets.sh — Backup sensitive config files for disaster recovery
# Usage: ./backup-secrets.sh

set -e

BACKUP_DIR="$HOME/.wlp-secrets-backup"
REPO_DIR="$HOME/wlp/secrets-backup"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')

echo "🔐 Backing up secrets and config..."

# Create backup directory
mkdir -p "$BACKUP_DIR"
mkdir -p "$REPO_DIR"

# Files to backup
FILES_TO_BACKUP=(
  "$HOME/.openclaw/openclaw.json"
  "$HOME/.openclaw/cron/jobs.json"
  "$HOME/.env"
  "$HOME/wlp/projects/mission-control/.env.local"
  "$HOME/.config/gogcli/credentials.json"
  "$HOME/.local/share/com.vercel.cli/auth.json"
)

# Create encrypted archive
ARCHIVE_NAME="secrets-$TIMESTAMP.tar.gz"
ARCHIVE_PATH="$BACKUP_DIR/$ARCHIVE_NAME"

echo "📦 Creating archive..."
tar -czf "$ARCHIVE_PATH" -C "$HOME" \
  .openclaw/openclaw.json \
  .openclaw/cron/jobs.json \
  .env \
  wlp/projects/mission-control/.env.local \
  .config/gogcli/credentials.json \
  .local/share/com.vercel.cli/auth.json \
  2>/dev/null || true

# Also copy to repo for Git tracking (encrypted content only)
cp "$ARCHIVE_PATH" "$REPO_DIR/"

# Create manifest
MANIFEST="$REPO_DIR/manifest-$TIMESTAMP.txt"
echo "Backup created: $TIMESTAMP" > "$MANIFEST"
echo "Files included:" >> "$MANIFEST"
for f in "${FILES_TO_BACKUP[@]}"; do
  if [ -f "$f" ]; then
    echo "  ✓ $f" >> "$MANIFEST"
  else
    echo "  ✗ $f (not found)" >> "$MANIFEST"
  fi
done

echo ""
echo "✅ Secrets backed up:"
echo "  Local: $ARCHIVE_PATH"
echo "  Repo:  $REPO_DIR/$ARCHIVE_NAME"
echo ""
echo "⚠️  IMPORTANT:"
echo "  - Archive is NOT encrypted (stored locally)"
echo "  - Keep this backup safe"
echo "  - For recovery, run: ./restore-secrets.sh $ARCHIVE_NAME"
