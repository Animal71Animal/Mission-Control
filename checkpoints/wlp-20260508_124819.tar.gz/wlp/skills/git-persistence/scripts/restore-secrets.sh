#!/bin/bash
# restore-secrets.sh — Restore secrets from backup archive
# Usage: ./restore-secrets.sh [archive-name]

set -e

BACKUP_DIR="$HOME/.wlp-secrets-backup"
REPO_DIR="$HOME/wlp/secrets-backup"

# Find latest backup if no name provided
if [ -z "$1" ]; then
  ARCHIVE=$(ls -t "$REPO_DIR"/secrets-*.tar.gz 2>/dev/null | head -1)
  if [ -z "$ARCHIVE" ]; then
    echo "❌ No backup found in $REPO_DIR"
    echo "Usage: ./restore-secrets.sh secrets-YYYYMMDD_HHMMSS.tar.gz"
    exit 1
  fi
  echo "📦 Using latest backup: $(basename $ARCHIVE)"
else
  ARCHIVE="$REPO_DIR/$1"
  if [ ! -f "$ARCHIVE" ]; then
    echo "❌ Backup not found: $ARCHIVE"
    exit 1
  fi
fi

echo "⚠️  This will OVERWRITE existing config files!"
read -p "Continue? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
  echo "Cancelled."
  exit 0
fi

echo "📂 Extracting backup..."
tar -xzf "$ARCHIVE" -C "$HOME"

echo ""
echo "✅ Secrets restored from: $(basename $ARCHIVE)"
echo ""
echo "Next steps:"
echo "  1. Verify OpenClaw config: openclaw doctor"
echo "  2. Test channels: openclaw channels status"
echo "  3. Redeploy if needed: cd ~/wlp/projects/mission-control && ./deploy.sh"
