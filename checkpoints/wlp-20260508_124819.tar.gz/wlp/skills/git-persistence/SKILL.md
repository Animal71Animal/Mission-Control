---
name: git-persistence
description: Automatic Git commit + push + Vercel deploy workflow for WLP projects. Use whenever files are edited in any WLP project (mission-control, featured-entertainer, dj-automation, etc.) to ensure all changes are committed, pushed to GitHub, and deployed. Enforces the rule: every change → GitHub → Vercel, no exceptions.
---

# Git Persistence Workflow

**Rule:** Every file edit → commit → push → deploy. No orphaned local changes.

---

## Projects & Deploy Commands

| Project | Directory | Deploy Command | URL |
|---------|-----------|---------------|-----|
| Mission Control | `wlp/projects/mission-control` | `bash deploy.sh "msg"` | https://mission-control-cyan-omega.vercel.app |
| Featured Entertainer | `wlp/projects/featured-entertainer` | `npx vercel@latest deploy --prod --yes` | https://featured-entertainer.vercel.app |
| DJ Automation | `wlp/projects/dj-automation` | `npx vercel@latest deploy --prod --yes` | https://dj-automation-srb.vercel.app |

---

## Workflow

```
1. Edit files
2. git add -A && git commit -m "message"
3. git push origin main  (or master)
4. Deploy to Vercel
5. Share URL with user ← ALWAYS
```

For Mission Control: just run `bash deploy.sh "message"` — handles all steps.

For other projects: run git commands manually, then `npx vercel@latest deploy --prod --yes`.

---

## Commit Message Format

| Type | Format | Example |
|------|--------|---------|
| Feature | `Add [thing]: [desc]` | `Add dot.cards link to footer` |
| Fix | `Fix [component]: [desc]` | `Fix checkbox not clickable` |
| Data | `Log [type]: [details]` | `Log Uber shift Apr 14` |
| Deploy | `Deploy: [summary]` | `Deploy: footer + flyer updates` |

---

## Checklist (End of Session)

- [ ] All edits committed (`git status` shows clean)
- [ ] Pushed to GitHub
- [ ] Deployed to Vercel
- [ ] URL shared with user

---

## When Push Fails

```bash
git pull --rebase origin main
# resolve conflicts if any
git push origin main
```

If no upstream set:
```bash
git push --set-upstream origin master
```

If auth fails — GitHub token is in `.env.local` and Vercel config. Check `git remote -v` to verify remote URL includes token or use SSH.

---

## Never Do

- ❌ Deploy to Vercel without committing to GitHub first
- ❌ End session with uncommitted local changes
- ❌ Forget to share the URL after deploying

---

## Secrets Backup

```bash
~/wlp/skills/git-persistence/scripts/backup-secrets.sh   # backup
~/wlp/skills/git-persistence/scripts/restore-secrets.sh  # restore
```

Backs up: `.openclaw/openclaw.json`, cron jobs, `.env`, `.env.local`, Vercel auth.
