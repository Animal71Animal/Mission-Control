#!/usr/bin/env python3
"""
save-state.py — Snapshot current session state to wlp/sessions/current-state.json
Usage: python3 save-state.py [--notes "optional notes"]
"""

import json
import os
import sys
import subprocess
from datetime import datetime, timezone

BASE = os.path.expanduser("~/wlp")
SESSIONS_DIR = os.path.join(BASE, "sessions")
STATE_FILE = os.path.join(SESSIONS_DIR, "current-state.json")

os.makedirs(SESSIONS_DIR, exist_ok=True)

# Load existing state if any
existing = {}
if os.path.exists(STATE_FILE):
    try:
        with open(STATE_FILE) as f:
            existing = json.load(f)
    except Exception:
        pass

now_utc = datetime.now(timezone.utc)
now_str = now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
now_mdt = now_utc.strftime("%a %b %d, %-I:%M %p MDT")  # approx, no tz conversion

# Get recent git logs from active projects
recent_deploys = existing.get("recent_deploys", [])
projects = ["mission-control", "featured-entertainer", "dj-automation"]
for proj in projects:
    proj_dir = os.path.join(BASE, "projects", proj)
    if os.path.isdir(proj_dir):
        try:
            result = subprocess.run(
                ["git", "log", "--oneline", "-1"],
                cwd=proj_dir, capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                print(f"  [{proj}] {result.stdout.strip()}")
        except Exception:
            pass

notes = " ".join(sys.argv[sys.argv.index("--notes")+1:]) if "--notes" in sys.argv else existing.get("notes", "")

state = {
    "timestamp": now_str,
    "last_updated_mdt": now_mdt,
    "in_progress": existing.get("in_progress", []),
    "open_tasks": existing.get("open_tasks", []),
    "recent_deploys": recent_deploys,
    "notes": notes
}

with open(STATE_FILE, "w") as f:
    json.dump(state, f, indent=2)

print(f"\n✅ State saved to {STATE_FILE}")
print(f"   Timestamp: {now_mdt}")
print(f"   Open tasks: {len(state['open_tasks'])}")
print(f"   In progress: {len(state['in_progress'])}")
