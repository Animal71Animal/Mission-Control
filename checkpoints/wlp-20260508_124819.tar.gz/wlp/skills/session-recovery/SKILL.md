---
name: session-recovery
description: Save and restore session state across restarts and /reset. Use when starting a new session to load open work context, or at the end of a session to snapshot current state. Also use when user says "what was I working on", "pick up where we left off", or when resuming interrupted work. Writes state to wlp/sessions/current-state.json.
---

# Session Recovery

Persist and restore working context across session restarts, /reset, and container restarts.

---

## Auto-Save Schedule

| Trigger | Action |
|---------|--------|
| Every heartbeat (1h) | Silent save-state.py run |
| Session start (/new or /reset) | Save previous state + load for context |
| User says "checkpoint" | Save + full tar backup |

---

## Session Start — Load State

On startup, read state file if it exists:

```bash
cat /home/ubuntu/wlp/sessions/current-state.json 2>/dev/null
```

If it exists, load: open tasks, in-progress work, last deployed URLs, and any user context.
Brief the user: "Picking up from last session — you were working on [X]. Open tasks: [Y]."

---

## Session End / Checkpoint — Save State

Run the save script when:
- User says **"checkpoint"** or **"save state"**
- End of a productive session
- Before any risky operation

```bash
# Step 1: Save session state JSON
python3 /home/ubuntu/wlp/skills/session-recovery/scripts/save-state.py

# Step 2: Tar backup (always paired with checkpoint)
cd /home/ubuntu && tar czf "checkpoints/wlp-$(date +%Y%m%d_%H%M%S).tar.gz" --exclude='wlp/**/node_modules' --exclude='wlp/**/.git' wlp/
```

Both run together — state JSON + full file backup.
This writes state to `/home/ubuntu/wlp/sessions/current-state.json`.

---

## State File Structure

```json
{
  "timestamp": "2026-04-20T07:00:00Z",
  "last_updated_mdt": "Sun Apr 20, 1:00 AM MDT",
  "in_progress": [
    {
      "task": "Featured Entertainer flyer updates",
      "status": "complete",
      "url": "https://featured-entertainer.vercel.app"
    }
  ],
  "open_tasks": [
    "Build session-recovery skill",
    "Build deploy-validator skill"
  ],
  "recent_deploys": [
    {
      "project": "featured-entertainer",
      "url": "https://featured-entertainer.vercel.app",
      "deployed_at": "2026-04-20T05:39:00Z"
    }
  ],
  "notes": "Checkbox fix deployed. PDF + PNG flyer generated at wlp/projects/featured-entertainer/"
}
```

---

## Manual Recovery

If the state file is missing or stale, reconstruct from:

1. `memory/YYYY-MM-DD.md` — today and yesterday
2. `MEMORY.md` — long-term context
3. `git log --oneline -10` in each active project
4. `npx vercel@latest ls` — recent deployments

---

## Rules

- Always save state before ending a session with open work
- On `/new` or `/reset`, auto-check for state file before greeting
- State file is not a substitute for MEMORY.md — it's for active work context only
- Prune completed tasks from state after they're done
