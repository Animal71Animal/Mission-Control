---
name: peptide-protocol
description: Eric's peptide stack management including reconstitution protocol, dosage schedule, and persistent tracking in Mission Control. Use when Eric needs to: (1) recall exact reconstitution instructions (bac water amounts, needle sizes, mixing times), (2) verify injection dosages and timing, (3) update or track peptide intake, (4) check what compounds are in rotation and their interactions, (5) get safety protocols and bloodwork checklist, or (6) troubleshoot side effects. Always reference `/home/ubuntu/wlp/data/peptide-stack.json` as source of truth for current stack state and `/home/ubuntu/wlp/data/peptide-stack-guide.md` for compound interactions and safety.
---

# Peptide Protocol — Eric's Stack

## Quick Reference

**Current Stack (May 4, 2026 - Active):**
- **Reta** (Retratrutide GLP-1 agonist): 60u Mon 11pm
- **Tesa** (Tesamorelin GHRH analog): 20u Mon-Fri 10am
- **HCG** (Hormone): 10u Tue & Fri mornings
- **Semax** (Nootropic peptide): 5u Mon-Fri 10am (can increase to 8-10u after day 5)
- **MT1** (Melanotan I): 5u daily 10am (loading phase through May 18, then 10u 2x weekly maintenance)

**Phase:** LOADING (Weeks 1-2 for MT1) → Maintenance starts May 19

## Reconstitution Protocol

All compounds arrive as lyophilized powder. Reconstitute once, use as scheduled.

### Standard Reconstitution (5 mg / 2 mL)

**Materials needed:**
- Sterile bacteriostatic water (bac water)
- 25-gauge needle (drawing from vial)
- 30-gauge needle (injecting into peptide vial)
- Alcohol prep pads
- Sharps container

**Steps:**

1. **Prepare workspace** — Clean surface with alcohol pad
2. **Draw bac water** — Use 25G needle to draw 2 mL sterile bac water into syringe
3. **Sanitize peptide vial** — Wipe rubber cap with alcohol pad, let dry 30 seconds
4. **Inject water slowly** — Switch to 30G needle, inject bac water into vial SLOWLY (30 sec). Do NOT shake.
5. **Let settle** — Wait 2 minutes for powder to fully dissolve (should be clear)
6. **Label and store** — Write compound name + reconstitution date on vial
7. **Refrigerate** — Store at 2-8°C (fridge, NOT freezer). Stable for 30 days once reconstituted

**Needle tips:**
- 25G for drawing (larger, faster)
- 30G for injecting into vial (smaller, less tissue damage when injecting peptide)
- 30G for subq injections (standard, less pain)

### Per-Compound Reconstitution Notes

| Compound | Powder | Bac Water | Concentration | Stability | Notes |
|----------|--------|-----------|---|---|---|
| Reta | 10 mg | 2 mL | 5 mg/mL | 30 days (fridge) | Mix slowly, no shaking. Clear solution = ready. |
| Tesa | 10 mg | 2 mL | 5 mg/mL | 30 days (fridge) | Same as Reta. |
| HCG | 5000 IU | 2 mL | 2500 IU/mL | 30 days (fridge) | Slightly cloudy is OK. Clearer = fresher. |
| Semax | 10 mg | 2 mL | 5 mg/mL | 30 days (fridge) | Should be crystal clear. If cloudy, discard. |
| MT1 | 10 mg | 2 mL | 5 mg/mL | 30 days (fridge) | Should be clear to slightly yellow. Yellow = oxidation, still OK. |

**Golden rule:** Once reconstituted, all peptides are stable for 30 days in fridge. Mark the date on the vial.

## Injection Sites & Technique

### Subq vs IM
- **Subq (Subcutaneous):** Under skin, adipose tissue. Slower absorption, less pain. USE THIS for all Eric's peptides except where noted.
- **IM (Intramuscular):** Into muscle. Faster but more painful. NOT needed for Eric's stack.

### Safe Injection Sites (Subq)

**Belly (abdomen):** 2 inches out from belly button, left and right. Rotate sides daily.
- Easiest to self-inject
- Most common for peptides
- **Avoid:** Directly over belly button, ribs, or hipbones

**Thigh:** Upper outer thigh (quad area). Rotate left/right daily.
- Second choice
- Slightly harder to self-inject
- Less painful

**Upper arm (back):** Triceps area. Less common but works.
- Hardest to self-inject
- Rotate sides

**Rotating sites:** Use a different site each day to avoid lipohypertrophy (lumpy fat).

### Injection Technique (30G needle, Subq)

1. **Pinch skin** — Grab 1 inch of skin between thumb and fingers (creates a fold)
2. **Insert at 45°** — Push needle through skin at ~45-degree angle, NOT 90°
3. **Release skin** — Once needle is in, release the skin fold
4. **Inject slowly** — Push plunger smoothly over 3-5 seconds
5. **Withdraw** — Pull needle straight out
6. **Apply pressure** — Hold alcohol pad on site for 10 seconds

**Pain tips:** Cold skin = less pain. Chill site with ice for 1 min before injecting.

## Dosage Schedule (Current)

**Monday (10am stack):**
- Tesa 20u
- Semax 5u
- MT1 5u

**Monday (11pm, separate injection):**
- Reta 60u

**Tuesday (morning):**
- HCG 10u

**Tuesday (10am):**
- Tesa 20u
- Semax 5u
- MT1 5u

**Wednesday-Friday (10am):**
- Tesa 20u
- Semax 5u
- MT1 5u

**Friday (morning, separate from 10am):**
- HCG 10u

**Saturday & Sunday (10am, loading phase only):**
- MT1 5u only

**Transition Date:** May 19, 2026 — MT1 drops to maintenance (10u 2x weekly on Tue & Fri mornings with HCG).

## Dosage Protocols (Unit Conversions)

All compounds are dosed in **insulin units (u)** using a standard 100-unit insulin syringe.

| Compound | Concentration | Units | Actual Dose | Timing |
|----------|---|---|---|---|
| Reta | 5 mg/mL | 60u | 3 mg | 1x weekly (Mon 11pm) |
| Tesa | 5 mg/mL | 20u | 1 mg | 5x weekly (Mon-Fri 10am) |
| HCG | 2500 IU/mL | 10u | 250 IU | 2x weekly (Tue & Fri mornings) |
| Semax | 5 mg/mL | 5u | 250 mcg | 5x weekly (Mon-Fri 10am) |
| MT1 | 5 mg/mL | 5u (loading) | 250 mcg | Daily loading; 10u (500 mcg) 2x weekly maintenance |

**How to measure with insulin syringe:**
- Each numbered marking = 2 units (e.g., "30" line = 60 units)
- To measure 20u: pull to the "10" line
- To measure 5u: pull to the "2.5" line (halfway between 0 and 5)
- To measure 60u: pull to the "30" line

## What to Watch (Weekly Checklist)

**Week 1 (May 4-10):**
- [ ] MT1 nausea — expect it, should fade by day 4-5
- [ ] Reta appetite suppression — eat enough despite reduced hunger
- [ ] Sleep quality — Semax at 5u should not disrupt sleep
- [ ] Bowel habits — Reta can cause constipation; increase fiber/water if needed

**Week 2 (May 11-17):**
- [ ] MT1 nausea — should be mostly gone by now
- [ ] Skin darkening — MT1 should show visible change by day 10
- [ ] Semax effects — consider dose increase to 8u if effects feel mild
- [ ] Energy levels — should be high (Semax + Tesa)

**Week 3 (May 18-24):**
- [ ] Get bloodwork (lipids, glucose, liver, prolactin, testosterone, IGF-1, amylase)
- [ ] MT1 loading phase ends May 18 — prepare to drop to 10u 2x weekly May 19
- [ ] Body composition changes — first fat loss should be visible by now

**Weekly ongoing:**
- [ ] Injection site rotation (no lumps)
- [ ] Refrigerator temperature (2-8°C)
- [ ] Vial integrity (no cloudiness unless expected)

## Red Flags — Stop Immediately

1. **Severe abdominal pain** (not just nausea) → possible pancreatitis from Reta
2. **Chest pain or shortness of breath** → emergency
3. **Nausea + vomiting for >6 hours** → dehydration risk
4. **Testicular pain from HCG injection** → poor injection site
5. **New mole or existing mole changing rapidly** → skin cancer risk (MT1)
6. **Spontaneous severe headache** → possible hypertensive event

## Source Documents

- **Stack tracker:** `/home/ubuntu/wlp/data/peptide-stack.json` (current status, vials on hand, milestones)
- **Comprehensive guide:** `/home/ubuntu/wlp/data/peptide-stack-guide.md` (how they work together, interactions, safe/unsafe additions, bloodwork checklist)
- **Mission Control:** Peptide tab at https://mission-control-cyan-omega.vercel.app/peptides (live dashboard)

## Key Dates

- **May 11:** First week assessment (record how you feel, nausea level, skin changes)
- **May 15:** Semax dosage decision (increase to 8u or stay at 5u?)
- **May 18:** MT1 loading phase ends
- **May 19:** Switch MT1 to maintenance (10u Tue & Fri mornings)
- **Week 3:** Bloodwork (before any adjustments)

---

_Protocol locked in. Persistent across sessions. Always refer to peptide-stack.json as source of truth for current state._
