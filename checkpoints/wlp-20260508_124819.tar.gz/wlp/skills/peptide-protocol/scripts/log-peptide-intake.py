#!/usr/bin/env python3
"""
Log peptide intake to track compliance and side effects.
Run after injecting to record what was taken and any notes.

Usage:
  python3 log-peptide-intake.py --compound Reta --dose 60u --notes "no nausea, normal"
  python3 log-peptide-intake.py --compound MT1 --dose 5u --notes "slight nausea, expected"
  python3 log-peptide-intake.py --show-log (view recent entries)
"""

import json
import sys
from datetime import datetime
from pathlib import Path
import argparse

LOG_FILE = Path("/home/ubuntu/wlp/data/peptide-intake-log.json")

def init_log():
    """Initialize log file if it doesn't exist."""
    if not LOG_FILE.exists():
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        LOG_FILE.write_text(json.dumps({"entries": []}, indent=2))

def log_intake(compound, dose, notes=""):
    """Record a peptide injection."""
    init_log()
    
    data = json.loads(LOG_FILE.read_text())
    
    entry = {
        "timestamp": datetime.now().isoformat(),
        "compound": compound,
        "dose": dose,
        "notes": notes
    }
    
    data["entries"].append(entry)
    LOG_FILE.write_text(json.dumps(data, indent=2))
    
    print(f"✅ Logged: {compound} {dose} at {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    if notes:
        print(f"   Notes: {notes}")

def show_log(limit=10):
    """Display recent log entries."""
    init_log()
    
    data = json.loads(LOG_FILE.read_text())
    entries = data.get("entries", [])
    
    if not entries:
        print("No entries yet.")
        return
    
    print(f"\n📋 Last {limit} peptide intakes:\n")
    for entry in entries[-limit:]:
        ts = entry["timestamp"]
        compound = entry["compound"]
        dose = entry["dose"]
        notes = entry.get("notes", "—")
        
        print(f"{ts}")
        print(f"  {compound:10} | {dose:6} | {notes}")
    
    print(f"\nTotal entries: {len(entries)}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Log peptide intake")
    parser.add_argument("--compound", type=str, help="Compound name (e.g., Reta, Tesa, MT1)")
    parser.add_argument("--dose", type=str, help="Dosage (e.g., 60u, 20u)")
    parser.add_argument("--notes", type=str, default="", help="Side effects or observations")
    parser.add_argument("--show-log", action="store_true", help="Display recent entries")
    parser.add_argument("--limit", type=int, default=10, help="Number of entries to show")
    
    args = parser.parse_args()
    
    if args.show_log:
        show_log(args.limit)
    elif args.compound and args.dose:
        log_intake(args.compound, args.dose, args.notes)
    else:
        parser.print_help()
