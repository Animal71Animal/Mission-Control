# Tailscale Skill

Use this skill when: diagnosing Tailscale connectivity, restarting Tailscale, or checking the Mac node connection.

---

## Environment Facts

- **No systemd** — container uses PID 1 ≠ systemd. `systemctl` will fail.
- **Userspace networking** — must use `--tun=userspace-networking` (no TUN device)
- **SOCKS5 proxy** — starts on `localhost:1055`
- **Auth key:** `tskey-auth-kKjA4oQxxi11CNTRL-9Qyq5zNRACcgRAz1UNc4CczErGfL2a7f` (reusable)
- **Hostname:** `priscylla-abacus` (auto-increments to `-2`, `-3` etc. on re-register)
- **Startup script:** `~/scripts/tailscale-start.sh`

---

## Step 1 — Check Status

```bash
tailscale status 2>&1
```

**Healthy output** looks like:
```
100.x.x.x   priscylla-abacus-N  ericmills71@  linux  -
100.95.234.2  animal-macbook-pro  ericmills71@  macOS  -
```

**Unhealthy signs:**
- `command not found` → Tailscale not installed
- `failed to connect to local tailscaled` → daemon not running
- `Logged out.` → needs `tailscale up`

---

## Step 2 — Fix It

### If not installed:
```bash
curl -fsSL https://tailscale.com/install.sh | sh
```

### If installed but daemon not running:
```bash
pkill tailscaled 2>/dev/null; sleep 1
sudo tailscaled --tun=userspace-networking --socks5-server=localhost:1055 >> /tmp/tailscaled.log 2>&1 &
sleep 5
```

### If daemon running but logged out:
```bash
sudo tailscale up --authkey="tskey-auth-kKjA4oQxxi11CNTRL-9Qyq5zNRACcgRAz1UNc4CczErGfL2a7f" --hostname="priscylla-abacus" --accept-routes 2>&1
sleep 3
tailscale status
tailscale ip
```

### One-shot full restart script:
```bash
bash ~/scripts/tailscale-start.sh
```

---

## Step 3 — Verify Mac Connectivity

After reconnecting, verify the Mac is reachable:
```bash
tailscale ping 100.95.234.2
```

If Mac shows `offline` in status, it may just be asleep — that's normal.

---

## TOOLS.md Update

After reconnecting, update `/home/ubuntu/TOOLS.md` with the new Tailscale IP (it increments each reinstall):
```
Tailscale IP: 100.x.x.x (priscylla-abacus-N)
```

Also update `MEMORY.md` under **Infrastructure → Tailscale / Mac Node**.

---

## Keepalive Cron

Cron job `tailscale-keepalive` (ID: `6aae6ad9-ed8b-4fe6-a3ab-a522bcd3c2e4`) runs every 10 minutes.
It checks status and calls `~/scripts/tailscale-start.sh` if down.
If it had to restart, it notifies `#agent-output` on Discord.

---

## Why This Keeps Breaking

Container restarts wipe the running `tailscaled` process (no systemd to restart it).
The binaries survive apt-install but the **process does not persist** across container restarts.
Solution: keepalive cron detects and self-heals within 10 minutes.
