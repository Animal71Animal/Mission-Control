# Skill: Mission Control Token Fix
**Trigger:** User reports Mission Control data not saving, Vercel token prompt, deploy failures, or GitHub auth errors.
**Location:** `/home/ubuntu/wlp/skills/mission-control-token-fix/SKILL.md`

---

## What This Fixes

| Symptom | Root Cause |
|---------|-----------|
| Data doesn't persist across devices | GitHub PAT expired — writes silently fail, fall back to container-local only |
| "Asked for Vercel token again" | Vercel CLI auth wiped on container restart, no stored token |
| `git push` rejected | GitHub PAT expired or not embedded in remote URL |
| Deploy fails / times out | Vercel token missing or expired |
| Ableton tab missing from Creative | Dropped from `app/data/modules.ts` — re-add manually |

---

## Step 1: Diagnose

```bash
bash /home/ubuntu/wlp/scripts/check-tokens.sh
```

Read the output. If you see ❌ on GitHub PAT or Vercel token → go to Step 2.  
If both tokens are ✅ but data still isn't syncing → check Step 4.

---

## Step 2: Get Fresh Tokens (Eric's action)

**GitHub PAT**
1. https://github.com/settings/tokens → Generate new token (classic)
2. Name: `WLP Mission Control` | Expiry: No expiration | Scopes: `repo` + `workflow`
3. Copy the token

**Vercel Token**
1. https://vercel.com/account/tokens → Create Token
2. Name: `WLP Mission Control` | Expiry: No expiration
3. Copy the token

---

## Step 3: Install Tokens

```bash
# Open the secrets file and fill in both tokens
nano /home/ubuntu/wlp/secrets/tokens.env
# Set: GITHUB_TOKEN=ghp_...
# Set: VERCEL_TOKEN=vcp_...

# Run setup — validates, configures everything, pushes pending changes
bash /home/ubuntu/wlp/scripts/setup-tokens.sh
```

Setup script does all of this automatically:
- Validates both tokens
- Configures git credential helper + remote URL
- Updates Vercel CLI auth
- Sets GITHUB_TOKEN in Vercel project env vars
- Sets GitHub Actions secrets (VERCEL_TOKEN, VERCEL_ORG_ID, VERCEL_PROJECT_ID)
- Commits and pushes any pending local data files
- Updates `~/.github-pat`

---

## Step 4: Deploy

```bash
cd /home/ubuntu/wlp/projects/mission-control && ./deploy.sh
```

Expected output ends with:
```
✅ Deployment complete!
🌐 https://mission-control-cyan-omega.vercel.app
```

---

## Step 5: Verify

```bash
bash /home/ubuntu/wlp/scripts/check-tokens.sh
```

All lines should show ✅. Then open Mission Control and confirm data loads.

---

## Edge Cases

### `git push` blocked by GitHub push protection
**Symptom:** `remote: Push cannot contain secrets`  
**Cause:** Raw token accidentally committed to a tracked file (usually `.env.local`)

**Fix:**
```bash
cd /home/ubuntu/wlp/projects/mission-control

# Scrub the token from ALL history
echo "THE_LEAKED_TOKEN==>TOKEN_REMOVED" > /tmp/replace.txt
~/.local/bin/git-filter-repo --force --replace-text /tmp/replace.txt

# Re-add remote (filter-repo strips it)
git remote add origin "https://Animal71Animal:GITHUB_TOKEN@github.com/Animal71Animal/Mission-Control.git"

# Force push
git push origin main --force
```

**Prevention:** `.env.local` must NOT contain raw token values. Token goes in `secrets/tokens.env` (gitignored) and Vercel env vars.

---

### `source: not found` in scripts
**Cause:** Abacus container uses `dash` (`/bin/sh`), not bash. `source` is bash-only.  
**Fix:** Use `.` (dot) instead:
```bash
. /home/ubuntu/wlp/secrets/tokens.env   # ✅ works in dash
source /home/ubuntu/wlp/secrets/tokens.env  # ❌ fails in dash
```

---

### Ableton tab missing from Creative section
**File:** `/home/ubuntu/wlp/projects/mission-control/app/data/modules.ts`  
**Fix:** Add this line in the modules array (before the personal group):
```ts
{ href: "/ableton", icon: "🎛️", title: "Ableton", desc: "Ableton Live setup, plugin inventory, and session notes.", status: "active", group: "creative" },
```
Then commit, push, and deploy.

---

### Diverged git history / merge conflicts on JSON data files
**Cause:** GitHub API writes data directly to the repo while local container also has edits.  
**Fix:** Pull with `--no-rebase -X ours` to prefer local data, then push:
```bash
git pull origin main --no-rebase -X ours && git push origin main
```

---

## Key File Locations

| File | Purpose |
|------|---------|
| `/home/ubuntu/wlp/secrets/tokens.env` | Token store — fill this in first |
| `/home/ubuntu/wlp/scripts/setup-tokens.sh` | One-command full setup |
| `/home/ubuntu/wlp/scripts/check-tokens.sh` | Health check |
| `/home/ubuntu/wlp/projects/mission-control/deploy.sh` | Token-aware deploy |
| `/home/ubuntu/wlp/projects/mission-control/app/data/modules.ts` | Sidebar nav — add/remove tabs here |
| `/home/ubuntu/wlp/projects/mission-control/.github/workflows/deploy.yml` | Auto-deploy on git push |

---

## Vercel Project IDs (don't change these)

```
VERCEL_ORG_ID=team_9XYCDst6v1INyMkUyCYjbJ8q
VERCEL_PROJECT_ID=prj_G2UzOSZWHjtoIwFRRQnl3L0Q54Z0
```

---

*Skill created 2026-05-08 by PriScylla 🦞 after incident diagnosis.*
