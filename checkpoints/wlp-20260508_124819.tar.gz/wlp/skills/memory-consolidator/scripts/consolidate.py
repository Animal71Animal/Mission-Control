#!/usr/bin/env python3
"""
Memory Consolidator - Weekly memory maintenance
Reviews daily notes, extracts key learnings, updates MEMORY.md
"""

import os
import re
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def get_memory_files():
    """Get all daily memory files sorted by date"""
    memory_dir = Path.home() / "memory"
    if not memory_dir.exists():
        return []
    
    files = []
    for f in memory_dir.glob("*.md"):
        match = re.match(r"(\d{4}-\d{2}-\d{2})\.md", f.name)
        if match:
            files.append((datetime.strptime(match.group(1), "%Y-%m-%d"), f))
    
    return sorted(files, key=lambda x: x[0])

def extract_key_insights(content):
    """Extract key insights from daily note content"""
    insights = []
    
    # Look for decision patterns
    decision_patterns = [
        r"(?i)(decided?|decision):?\s*(.+?)(?:\n|$)",
        r"(?i)(settled on|went with|chose):?\s*(.+?)(?:\n|$)",
        r"(?i)(conclusion|outcome):?\s*(.+?)(?:\n|$)",
    ]
    
    for pattern in decision_patterns:
        matches = re.findall(pattern, content)
        for match in matches:
            insight = match[1].strip() if isinstance(match, tuple) else match.strip()
            if insight and len(insight) > 10:
                insights.append(f"Decision: {insight}")
    
    # Look for lesson patterns
    lesson_patterns = [
        r"(?i)(lesson learned?|takeaway|insight):?\s*(.+?)(?:\n|$)",
        r"(?i)(realized?|discovered?|found that):?\s*(.+?)(?:\n|$)",
    ]
    
    for pattern in lesson_patterns:
        matches = re.findall(pattern, content)
        for match in matches:
            insight = match[1].strip() if isinstance(match, tuple) else match.strip()
            if insight and len(insight) > 10:
                insights.append(f"Lesson: {insight}")
    
    # Look for completed work
    work_patterns = [
        r"(?i)(completed?|finished|deployed|shipped):?\s*(.+?)(?:\n|$)",
        r"(?i)(built|created|implemented):?\s*(.+?)(?:\n|$)",
    ]
    
    for pattern in work_patterns:
        matches = re.findall(pattern, content)
        for match in matches:
            insight = match[1].strip() if isinstance(match, tuple) else match.strip()
            if insight and len(insight) > 10:
                insights.append(f"Completed: {insight}")
    
    return insights

def update_memory_md(insights, dry_run=False):
    """Append insights to MEMORY.md"""
    memory_md = Path.home() / "MEMORY.md"
    
    if not memory_md.exists():
        log("MEMORY.md not found")
        return False
    
    if dry_run:
        log(f"Would add {len(insights)} insights to MEMORY.md")
        return True
    
    # Read current content
    content = memory_md.read_text()
    
    # Create update section
    today = datetime.now().strftime("%Y-%m-%d")
    update_section = f"\n\n## Auto-Consolidated ({today})\n\n"
    for insight in insights[:20]:  # Limit to 20 insights
        update_section += f"- {insight}\n"
    
    # Append before the last update line or at end
    if "_Update when something is worth remembering long-term._" in content:
        content = content.replace(
            "_Update when something is worth remembering long-term._",
            f"{update_section}\n_Update when something is worth remembering long-term._"
        )
    else:
        content += update_section
    
    # Backup first
    backup_path = Path.home() / f"MEMORY.md.backup.{today}"
    shutil.copy(memory_md, backup_path)
    
    # Write updated content
    memory_md.write_text(content)
    log(f"Updated MEMORY.md with {len(insights)} insights")
    return True

def archive_old_notes(days=30, dry_run=False):
    """Move old daily notes to archive"""
    memory_dir = Path.home() / "memory"
    archive_dir = memory_dir / "archive"
    
    if not memory_dir.exists():
        return 0
    
    if not dry_run:
        archive_dir.mkdir(exist_ok=True)
    
    cutoff = datetime.now() - timedelta(days=days)
    files = get_memory_files()
    
    archived = 0
    for date, filepath in files:
        if date < cutoff:
            if dry_run:
                log(f"Would archive: {filepath.name}")
            else:
                shutil.move(filepath, archive_dir / filepath.name)
                archived += 1
    
    log(f"Archived {archived} old notes (older than {days} days)")
    return archived

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Memory consolidation")
    parser.add_argument("--dry-run", action="store_true", help="Show what would happen")
    parser.add_argument("--archive-only", action="store_true", help="Only archive old notes")
    parser.add_argument("--days", type=int, default=7, help="Days to review (default: 7)")
    args = parser.parse_args()
    
    log("=" * 50)
    log("Memory Consolidation Starting")
    log("=" * 50)
    
    if args.dry_run:
        log("DRY RUN MODE - No changes will be made")
    
    # Get files to review
    files = get_memory_files()
    cutoff = datetime.now() - timedelta(days=args.days)
    recent_files = [(d, f) for d, f in files if d >= cutoff]
    
    log(f"Found {len(recent_files)} daily notes from past {args.days} days")
    
    if args.archive_only:
        archive_old_notes(dry_run=args.dry_run)
        return
    
    # Extract insights
    all_insights = []
    for date, filepath in recent_files:
        content = filepath.read_text()
        insights = extract_key_insights(content)
        if insights:
            log(f"  {filepath.name}: {len(insights)} insights")
            all_insights.extend(insights)
    
    log(f"Total insights extracted: {len(all_insights)}")
    
    # Update MEMORY.md
    if all_insights:
        update_memory_md(all_insights, dry_run=args.dry_run)
    
    # Archive old notes
    archive_old_notes(dry_run=args.dry_run)
    
    log("=" * 50)
    log("Consolidation Complete")
    log("=" * 50)

if __name__ == "__main__":
    main()
