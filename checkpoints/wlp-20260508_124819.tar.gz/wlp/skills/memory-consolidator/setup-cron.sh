#!/bin/bash
# Setup cron for memory-consolidator
# Run this on systems with cron available

echo "Setting up memory-consolidator cron job..."

# Add to crontab
crontab -l 2>/dev/null | grep -v "memory-consolidator" > /tmp/crontab.tmp || true
echo "# Memory consolidator - weekly memory maintenance (Sundays 8 PM MDT)" >> /tmp/crontab.tmp
echo "0 20 * * 0 /usr/bin/python3 /home/ubuntu/wlp/skills/memory-consolidator/scripts/consolidate.py >> /home/ubuntu/wlp/skills/memory-consolidator/consolidate.log 2>&1" >> /tmp/crontab.tmp
crontab /tmp/crontab.tmp
rm /tmp/crontab.tmp

echo "Cron job added!"
echo "Schedule: Every Sunday at 8:00 PM MDT"
crontab -l | grep -A1 "memory-consolidator"
