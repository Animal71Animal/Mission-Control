---
name: memory-consolidator
description: Weekly memory consolidation — reviews daily notes, extracts key learnings, and updates MEMORY.md with distilled wisdom. Archives old daily notes to keep the system lean.
triggers:
  - "consolidate memory"
  - "review daily notes"
  - "update long-term memory"
  - "archive old notes"
---

# Memory Consolidator

Weekly memory maintenance for long-term knowledge persistence.

## What It Does

1. **Reviews** daily notes from the past week
2. **Extracts** key decisions, learnings, and insights
3. **Updates** MEMORY.md with distilled wisdom
4. **Archives** old daily notes (30+ days) to keep workspace lean

## When to Run

- **Weekly** (recommended: Sunday evenings)
- After intense work periods
- When MEMORY.md feels stale
- Before major new projects

## Usage

```bash
# Manual consolidation
python3 ~/wlp/skills/memory-consolidator/scripts/consolidate.py

# Dry run (see what would change)
python3 ~/wlp/skills/memory-consolidator/scripts/consolidate.py --dry-run

# Archive old notes only
python3 ~/wlp/skills/memory-consolidator/scripts/consolidate.py --archive-only
```

## Process

### 1. Review Phase
- Scans `memory/YYYY-MM-DD.md` files from past 7 days
- Identifies: decisions, lessons, project updates, important context

### 2. Extraction Phase
- Pulls key insights worth remembering long-term
- Filters out: routine logs, transient tasks, noise

### 3. Integration Phase
- Appends to `MEMORY.md` under appropriate sections
- Updates timestamps
- Maintains curated structure

### 4. Archive Phase
- Moves daily notes older than 30 days to `memory/archive/`
- Compresses if needed
- Keeps recent notes accessible

## Output

```
📊 Memory Consolidation Report

Reviewed: 7 daily notes (Apr 12-18)
Extracted: 12 key insights
Updated: MEMORY.md (3 new entries)
Archived: 5 old notes (moved to memory/archive/)

Key additions:
  ✓ Peptide stack reordered (HCG Week 1, Selank Week 2)
  ✓ BeatSource sync now grabs Top 10 + New Releases
  ✓ Archived 4 unused skills
  ✓ Mission Control v2 deployed with Git persistence
```

## Cron Schedule

Runs automatically every **Sunday at 8 PM MDT**:
```
0 20 * * 0 /usr/bin/python3 /home/ubuntu/wlp/skills/memory-consolidator/scripts/consolidate.py
```

## Safety

- Always dry-run first
- Creates backup before modifying MEMORY.md
- Git commit after changes (via git-persistence)
