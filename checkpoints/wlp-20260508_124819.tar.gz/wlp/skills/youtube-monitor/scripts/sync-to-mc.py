#!/usr/bin/env python3
"""
Sync YouTube OpenClaw search results to Mission Control
Reads from ~/wlp/ops/youtube-openclaw-videos.json
Formats and merges into openclaw-episodes.json
Pushes to GitHub
"""

import json
import os
import sys
from datetime import datetime
from urllib.request import urlopen, Request
from urllib.error import URLError

# ============ CONFIG ============
FOUND_VIDEOS_FILE = os.path.expanduser("~/wlp/ops/youtube-openclaw-videos.json")
MC_DIR = os.path.expanduser("~/wlp/projects/mission-control")
EPISODES_FILE = os.path.join(MC_DIR, "public/data/openclaw-episodes.json")
LOG_FILE = os.path.expanduser("~/wlp/logs/youtube-sync.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_REPO = "Animal71Animal/Mission-Control"
GITHUB_BRANCH = "main"
GITHUB_API = f"https://api.github.com/repos/{GITHUB_REPO}/contents/public/data/openclaw-episodes.json"
# ================================

def log(message):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")

def load_found_videos():
    """Load videos from youtube-openclaw-videos.json"""
    if not os.path.exists(FOUND_VIDEOS_FILE):
        log(f"INFO: {FOUND_VIDEOS_FILE} not found")
        return []
    
    try:
        with open(FOUND_VIDEOS_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        log(f"ERROR loading found videos: {e}")
        return []

def load_existing_episodes():
    """Load existing episodes from local file"""
    if not os.path.exists(EPISODES_FILE):
        return {"episodes": [], "last_updated": None, "total": 0}
    
    try:
        with open(EPISODES_FILE, 'r') as f:
            data = json.load(f)
            if isinstance(data, list):
                return {"episodes": data, "last_updated": None, "total": len(data)}
            return data
    except Exception as e:
        log(f"ERROR loading existing episodes: {e}")
        return {"episodes": [], "last_updated": None, "total": 0}

def format_video_as_episode(video, index):
    """Convert found video to OcEpisode format"""
    return {
        "id": f"yt-{video['video_id'][:12]}",
        "episodeNumber": index + 1,
        "title": video.get("title", "Unknown"),
        "url": video.get("url", ""),
        "channel": video.get("channel", "Unknown"),
        "publishedDate": video.get("found_at", datetime.now().isoformat())[:10],
        "summary": f"Video about OpenClaw from {video.get('channel', 'Unknown channel')}",
        "keyTakeaways": [],
        "skillsMentioned": ["OpenClaw"],
        "toolsCovered": ["OpenClaw"],
        "priscyllaTake": f"Auto-discovered: {video.get('metadata', '')}",
        "completed": False
    }

def merge_episodes(new_videos, existing_data):
    """Merge new videos with existing episodes, newest first"""
    existing_ids = {ep["url"] for ep in existing_data.get("episodes", [])}
    
    # Filter out duplicates
    unique_new = []
    seen_urls = set()
    for v in new_videos:
        url = v.get("url", "")
        if url and url not in existing_ids and url not in seen_urls:
            unique_new.append(v)
            seen_urls.add(url)
    
    if not unique_new:
        log("No new videos to add")
        return existing_data
    
    # Format new videos as episodes
    new_episodes = [format_video_as_episode(v, i) for i, v in enumerate(unique_new)]
    
    # Merge: new first, then existing
    merged = new_episodes + existing_data.get("episodes", [])
    
    # Re-number episodes
    for i, ep in enumerate(merged):
        ep["episodeNumber"] = i + 1
    
    result = {
        "episodes": merged,
        "last_updated": datetime.now().isoformat(),
        "total": len(merged)
    }
    
    log(f"Merged {len(new_episodes)} new videos, total now {len(merged)}")
    return result

def save_local(data):
    """Save episodes to local file"""
    try:
        with open(EPISODES_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        log(f"Saved locally to {EPISODES_FILE}")
        return True
    except Exception as e:
        log(f"ERROR saving local: {e}")
        return False

def push_to_github(data):
    """Push episodes.json to GitHub"""
    if not GITHUB_TOKEN:
        log("WARN: No GITHUB_TOKEN, skipping GitHub push")
        return False
    
    try:
        # Fetch current file to get SHA
        req = Request(GITHUB_API, method="GET")
        req.add_header("Authorization", f"Bearer {GITHUB_TOKEN}")
        req.add_header("Accept", "application/vnd.github+json")
        
        with urlopen(req, timeout=10) as response:
            current = json.loads(response.read())
            sha = current.get("sha", "")
        
        # Prepare new content
        import base64
        content_b64 = base64.b64encode(
            json.dumps(data, indent=2).encode('utf-8')
        ).decode('utf-8')
        
        # Push update
        push_data = {
            "message": f"chore: auto-sync OpenClaw YouTube videos ({len(data['episodes'])} total)",
            "content": content_b64,
            "sha": sha,
            "branch": GITHUB_BRANCH
        }
        
        req = Request(GITHUB_API, method="PUT")
        req.add_header("Authorization", f"Bearer {GITHUB_TOKEN}")
        req.add_header("Accept", "application/vnd.github+json")
        req.add_header("Content-Type", "application/json")
        
        with urlopen(req, json.dumps(push_data).encode('utf-8'), timeout=10) as response:
            if response.status == 200:
                log("Pushed to GitHub successfully")
                return True
            else:
                log(f"GitHub push failed with status {response.status}")
                return False
    
    except URLError as e:
        log(f"ERROR pushing to GitHub: {e}")
        return False
    except Exception as e:
        log(f"ERROR: {e}")
        return False

def main():
    log("=== YouTube → Mission Control Sync ===")
    
    # Load found videos
    found_videos = load_found_videos()
    if not found_videos:
        log("No found videos to sync")
        return
    
    log(f"Found {len(found_videos)} videos in youtube-openclaw-videos.json")
    
    # Load existing episodes
    existing = load_existing_episodes()
    log(f"Existing {existing['total']} episodes in MC")
    
    # Merge
    merged = merge_episodes(found_videos, existing)
    
    # Save locally
    if save_local(merged):
        # Push to GitHub
        if push_to_github(merged):
            log("✅ Sync complete")
        else:
            log("⚠️  Saved locally but GitHub push failed")
    else:
        log("❌ Failed to save")

if __name__ == "__main__":
    main()
