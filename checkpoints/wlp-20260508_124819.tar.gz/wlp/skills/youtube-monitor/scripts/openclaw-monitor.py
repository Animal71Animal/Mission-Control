#!/usr/bin/env python3
"""
OpenClaw YouTube Monitor
Monitors OpenClaw's YouTube channel for new videos
Runs once daily at noon MDT
Saves to mission-control/public/data/openclaw-episodes.json
"""

import json
import sys
import os
import re
import requests
from datetime import datetime, timedelta

# ============ CONFIG ============
SUPADATA_API_KEY = "sd_b4e03cefc86907e9c2e7f9d8284510a9"
SUPADATA_BASE_URL = "https://api.supadata.ai/v1"

# OpenClaw YouTube channel
# Using @openclaw handle - will resolve at runtime
CHANNEL_HANDLE = "openclaw"

# Output paths
OUTPUT_FILE = "/home/ubuntu/wlp/projects/mission-control/public/data/openclaw-episodes.json"
PENDING_FILE = os.path.expanduser("~/.openclaw-pending.json")
LOG_FILE = "/home/ubuntu/wlp/logs/openclaw-monitor.log"
# =================================

def resolve_channel_id(handle):
    """Resolve YouTube @handle to channel ID using Supadata"""
    url = f"{SUPADATA_BASE_URL}/youtube/channel?id=@{handle}"
    headers = {"x-api-key": SUPADATA_API_KEY}
    try:
        response = requests.get(url, headers=headers, timeout=30)
        if response.status_code == 200:
            data = response.json()
            return data.get("id", "")
        else:
            log(f"Supadata API error: {response.status_code} - {response.text}")
    except Exception as e:
        log(f"Error resolving channel ID: {e}")
    return ""

# =================================

def log(message):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")

def fetch_rss():
    """Fetch and parse YouTube RSS feed"""
    try:
        response = requests.get(RSS_URL, timeout=30)
        response.raise_for_status()
        return response.text
    except Exception as e:
        log(f"Error fetching RSS: {e}")
        return None

def parse_rss(content):
    """Parse RSS content and extract video entries"""
    videos = []
    entries = re.findall(r'<entry>(.*?)</entry>', content, re.DOTALL)
    
    for entry in entries:
        video_id_match = re.search(r'<yt:videoId>(.*?)</yt:videoId>', entry)
        if not video_id_match:
            continue
        video_id = video_id_match.group(1)
        
        title_match = re.search(r'<title>(.*?)</title>', entry)
        title = title_match.group(1) if title_match else "Unknown"
        
        published_match = re.search(r'<published>(.*?)</published>', entry)
        published = published_match.group(1) if published_match else ""
        
        videos.append({
            "video_id": video_id,
            "title": title,
            "published": published,
            "url": f"https://www.youtube.com/watch?v={video_id}"
        })
    
    return videos

def fetch_transcript(video_id):
    """Fetch transcript from Supadata API"""
    url = f"{SUPADATA_BASE_URL}/transcript?url=https://www.youtube.com/watch?v={video_id}&text=true"
    headers = {"x-api-key": SUPADATA_API_KEY}
    
    try:
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code == 404:
            return {"error": "no_transcript", "message": "Transcript not available"}
        if response.status_code == 429:
            log(f"API rate limit hit for {video_id}")
            return {"error": "rate_limited", "message": "Rate limited"}
        response.raise_for_status()
        data = response.json()
        if "text" not in data and "content" in data:
            data["text"] = data["content"]
        return data
    except Exception as e:
        log(f"Error fetching transcript for {video_id}: {e}")
        return {"error": "exception", "message": str(e)}

def process_transcript(transcript_data, video_info):
    """Process transcript into episode format"""
    text = transcript_data.get("text", "")
    if not text:
        return None
    
    # Simple summary - first 300 chars
    summary = text[:300] + "..." if len(text) > 300 else text
    
    # Extract key points (simple heuristic)
    sentences = re.split(r'[.!?]+', text)
    key_takeaways = []
    for sentence in sentences[:5]:
        sentence = sentence.strip()
        if 20 < len(sentence) < 150:
            key_takeaways.append(sentence)
    
    return {
        "summary": summary,
        "keyTakeaways": key_takeaways[:5] or ["Key insights from the video"],
        "topicBreakdown": [],
        "toolsCovered": [],
        "topics": []
    }

def load_existing():
    """Load existing episodes"""
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r') as f:
            return json.load(f)
    return []

def save_episodes(episodes):
    """Save episodes to output file"""
    with open(OUTPUT_FILE, 'w') as f:
        json.dump(episodes, f, indent=2)
    log(f"Saved {len(episodes)} episodes to {OUTPUT_FILE}")

def update_episode(episode_data, video_info, episodes):
    """Update or create episode entry - newest at top"""
    existing_idx = None
    for i, ep in enumerate(episodes):
        if ep.get("url", "").endswith(video_info["video_id"]):
            existing_idx = i
            break
    
    episode_entry = {
        "id": f"openclaw-{video_info['video_id'][:8]}",
        "title": video_info["title"],
        "url": video_info["url"],
        "publishedDate": video_info["published"][:10] if video_info["published"] else datetime.now().strftime("%Y-%m-%d"),
        "summary": episode_data.get("summary", ""),
        "keyTakeaways": episode_data.get("keyTakeaways", []),
        "topicBreakdown": episode_data.get("topicBreakdown", []),
        "toolsCovered": episode_data.get("toolsCovered", []),
        "topics": episode_data.get("topics", [])
    }
    
    if existing_idx is not None:
        episodes[existing_idx] = episode_entry
        log(f"Updated: {episode_entry['title']}")
    else:
        episodes.insert(0, episode_entry)  # Newest at top
        log(f"Added: {episode_entry['title']}")
    
    return episodes

def main():
    log("=== OpenClaw YouTube Monitor ===")
    
    if SUPADATA_API_KEY == "YOUR_API_KEY_HERE":
        log("ERROR: Please set your SUPADATA_API_KEY")
        sys.exit(1)
    
    # Resolve channel ID from handle
    global RSS_URL
    channel_id = resolve_channel_id(CHANNEL_HANDLE)
    if not channel_id:
        log(f"ERROR: Could not resolve channel ID for @{CHANNEL_HANDLE}")
        log("Please check the handle or provide channel ID directly")
        sys.exit(1)
    
    RSS_URL = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
    log(f"Monitoring channel: {channel_id}")
    
    # Load existing episodes
    episodes = load_existing()
    log(f"Loaded {len(episodes)} existing episodes")
    
    # Fetch RSS
    log("Fetching RSS feed...")
    rss_content = fetch_rss()
    if not rss_content:
        log("Failed to fetch RSS")
        sys.exit(1)
    
    videos = parse_rss(rss_content)
    log(f"Found {len(videos)} videos")
    
    # Find new videos
    existing_ids = set()
    for ep in episodes:
        url = ep.get("url", "")
        if "watch?v=" in url:
            existing_ids.add(url.split("watch?v=")[1])
    
    new_videos = [v for v in videos if v["video_id"] not in existing_ids]
    log(f"New videos to process: {len(new_videos)}")
    
    # Process each new video
    for video in new_videos:
        log(f"Processing: {video['title'][:60]}...")
        
        transcript = fetch_transcript(video["video_id"])
        
        if transcript and not transcript.get("error"):
            episode_data = process_transcript(transcript, video)
            if episode_data:
                episodes = update_episode(episode_data, video, episodes)
        else:
            log(f"No transcript available: {video['title']}")
            # Add placeholder
            placeholder = {
                "summary": f"Transcript pending. {video['title']}",
                "keyTakeaways": ["Transcript being processed"],
                "topicBreakdown": [],
                "toolsCovered": [],
                "topics": []
            }
            episodes = update_episode(placeholder, video, episodes)
    
    # Save episodes
    save_episodes(episodes)
    log("=== Done ===")

if __name__ == "__main__":
    main()
