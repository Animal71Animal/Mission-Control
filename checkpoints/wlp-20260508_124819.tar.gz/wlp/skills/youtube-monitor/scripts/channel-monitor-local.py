#!/usr/bin/env python3
"""
YouTube Channel Monitor - Tom Bilyeu (LOCAL VERSION)
Run this on your local machine to avoid IP blocking

Setup:
1. Install Python 3.8+
2. pip install requests
3. Set your API key below
4. Run: python3 channel-monitor-local.py

This script will:
- Check Tom Bilyeu's channel for new videos
- Fetch transcripts using Supadata API
- Generate summaries and topic breakdowns
- Upload results to your Mission Control
"""

import json
import sys
import os
import re
import requests
from datetime import datetime, timedelta

# ============ CONFIG ============
# Get your API key from: https://supadata.ai
SUPADATA_API_KEY = "sd_b4e03cefc86907e9c2e7f9d8284510a9"

# Supadata API base URL
SUPADATA_BASE_URL = "https://api.supadata.ai/v1"

# Your Mission Control update endpoint (or save locally and upload)
# Option 1: Save to file and manually upload
LOCAL_OUTPUT_FILE = os.path.expanduser("~/tom-bilyeu-episodes.json")

# Option 2: Auto-upload via SSH (uncomment and configure)
# REMOTE_USER = "ubuntu"
# REMOTE_HOST = "your-server.com"
# REMOTE_PATH = "/home/ubuntu/wlp/projects/mission-control/public/data/live-episodes.json"
# SSH_KEY = os.path.expanduser("~/.ssh/id_rsa")

CHANNEL_ID = "UCnYMOamNKLGVlJgRUbamveA"
RSS_URL = f"https://www.youtube.com/feeds/videos.xml?channel_id={CHANNEL_ID}"
PENDING_FILE = os.path.expanduser("~/.tom-bilyeu-pending.json")
LOG_FILE = os.path.expanduser("~/.tom-bilyeu-monitor.log")
# =================================

def log(message):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")

def fetch_rss():
    """Fetch and parse YouTube RSS feed"""
    try:
        response = requests.get(RSS_URL, timeout=30)
        response.raise_for_status()
        return response.text
    except Exception as e:
        log(f"Error fetching RSS: {e}")
        return None

def parse_rss(content):
    """Parse RSS content and extract video entries"""
    videos = []
    entries = re.findall(r'<entry>(.*?)</entry>', content, re.DOTALL)
    
    for entry in entries:
        video_id_match = re.search(r'<yt:videoId>(.*?)</yt:videoId>', entry)
        if not video_id_match:
            continue
        video_id = video_id_match.group(1)
        
        title_match = re.search(r'<title>(.*?)</title>', entry)
        title = title_match.group(1) if title_match else "Unknown"
        
        published_match = re.search(r'<published>(.*?)</published>', entry)
        published = published_match.group(1) if published_match else ""
        
        is_live = "LIVE" in title.upper()
        
        videos.append({
            "video_id": video_id,
            "title": title,
            "published": published,
            "is_live": is_live,
            "url": f"https://www.youtube.com/watch?v={video_id}"
        })
    
    return videos

def fetch_transcript(video_id):
    """Fetch transcript from Supadata API"""
    url = f"{SUPADATA_BASE_URL}/transcript?url=https://www.youtube.com/watch?v={video_id}&text=true"
    headers = {"x-api-key": SUPADATA_API_KEY}
    
    try:
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code == 404:
            return {"error": "no_transcript", "message": "Transcript not available"}
        if response.status_code == 429:
            log(f"API rate limit hit for {video_id}, will retry later")
            return {"error": "rate_limited", "message": "Rate limited"}
        response.raise_for_status()
        data = response.json()
        # Supadata returns transcript in 'text' field
        if "text" not in data and "content" in data:
            data["text"] = data["content"]
        return data
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 403:
            log(f"API rate limit or IP blocked for {video_id}")
        return {"error": "api_error", "message": str(e)}
    except Exception as e:
        log(f"Error fetching transcript for {video_id}: {e}")
        return {"error": "exception", "message": str(e)}

def process_transcript(transcript_data, video_info):
    """Process transcript into episode format"""
    text = transcript_data.get("text", "")
    if not text:
        return None
    
    # Split into chunks for topic breakdown
    words = text.split()
    chunk_size = 200
    chunks = []
    
    for i in range(0, len(words), chunk_size):
        chunk_words = words[i:i+chunk_size]
        chunk_text = " ".join(chunk_words)
        minutes = (i // chunk_size) * 2
        timestamp = f"{minutes:02d}:00"
        
        chunks.append({
            "timestamp": timestamp,
            "title": f"Segment at {timestamp}",
            "synopsis": chunk_text[:250] + "..." if len(chunk_text) > 250 else chunk_text,
            "keyPoints": extract_key_points(chunk_text, 3)
        })
    
    # Generate summary
    summary_text = " ".join(words[:150])
    summary = summary_text[:300] + "..." if len(summary_text) > 300 else summary_text
    
    key_takeaways = extract_key_points(text, 5)
    
    expanded_takeaways = []
    for takeaway in key_takeaways[:4]:
        expanded_takeaways.append({
            "title": takeaway,
            "detail": f"This concept emphasizes {takeaway.lower()} as a critical element for success."
        })
    
    return {
        "summary": summary,
        "keyTakeaways": key_takeaways,
        "expandedTakeaways": expanded_takeaways,
        "topicBreakdown": chunks[:8],
        "toolsCovered": extract_tools(text),
        "topics": extract_topics(text)
    }

def extract_key_points(text, max_points=3):
    """Extract key points from text"""
    sentences = re.split(r'[.!?]+', text)
    key_points = []
    
    for sentence in sentences:
        sentence = sentence.strip()
        if any(word in sentence.lower() for word in ['important', 'key', 'must', 'need', 'should', 'critical', 'essential', 'powerful']):
            if 30 < len(sentence) < 140 and sentence not in key_points:
                key_points.append(sentence)
        if len(key_points) >= max_points:
            break
    
    if len(key_points) < max_points:
        for sentence in sentences:
            sentence = sentence.strip()
            if 40 < len(sentence) < 120 and sentence not in key_points:
                key_points.append(sentence)
            if len(key_points) >= max_points:
                break
    
    return key_points if key_points else ["Key insights from the episode"]

def extract_tools(text):
    """Extract tools/frameworks mentioned"""
    tools = []
    tool_keywords = ['framework', 'system', 'method', 'process', 'technique', 'strategy']
    
    for keyword in tool_keywords:
        matches = re.findall(rf'\b\w+\s+{keyword}\b|\b{keyword}\s+\w+\b', text.lower())
        for match in matches[:2]:
            tool = match.title()
            if tool not in tools:
                tools.append(tool)
    
    return tools[:5]

def extract_topics(text):
    """Extract main topics"""
    topics = []
    topic_keywords = ['mindset', 'business', 'success', 'failure', 'growth', 'leadership', 'money', 'wealth']
    
    for keyword in topic_keywords:
        if keyword in text.lower():
            topics.append(keyword.title())
    
    return topics[:5]

def load_pending():
    """Load pending transcripts list"""
    if os.path.exists(PENDING_FILE):
        with open(PENDING_FILE, 'r') as f:
            return json.load(f)
    return []

def save_pending(pending):
    """Save pending transcripts list"""
    with open(PENDING_FILE, 'w') as f:
        json.dump(pending, f, indent=2)

def load_existing_episodes():
    """Load existing episodes from local file or create new"""
    if os.path.exists(LOCAL_OUTPUT_FILE):
        with open(LOCAL_OUTPUT_FILE, 'r') as f:
            return json.load(f)
    return []

def save_episodes(episodes):
    """Save episodes to local file"""
    with open(LOCAL_OUTPUT_FILE, 'w') as f:
        json.dump(episodes, f, indent=2)
    log(f"Saved {len(episodes)} episodes to {LOCAL_OUTPUT_FILE}")

def update_episode(episode_data, video_info, episodes):
    """Update or create episode entry"""
    existing_idx = None
    for i, ep in enumerate(episodes):
        if ep.get("url", "").endswith(video_info["video_id"]):
            existing_idx = i
            break
    
    episode_entry = {
        "id": f"live-{video_info['video_id'][:8]}" if existing_idx is None else episodes[existing_idx]["id"],
        "episodeNumber": len(episodes) + 1 if existing_idx is None else episodes[existing_idx]["episodeNumber"],
        "title": video_info["title"],
        "url": video_info["url"],
        "publishedDate": video_info["published"][:10] if video_info["published"] else datetime.now().strftime("%Y-%m-%d"),
        "duration": "Unknown",
        "isLive": video_info["is_live"],
        "summary": episode_data.get("summary", ""),
        "keyTakeaways": episode_data.get("keyTakeaways", []),
        "expandedTakeaways": episode_data.get("expandedTakeaways", []),
        "toolsCovered": episode_data.get("toolsCovered", []),
        "codeSnippets": [],
        "relatedVideos": [],
        "topics": episode_data.get("topics", []),
        "topicBreakdown": episode_data.get("topicBreakdown", [])
    }
    
    if existing_idx is not None:
        episodes[existing_idx] = episode_entry
        log(f"Updated: {episode_entry['title']}")
    else:
        episodes.insert(0, episode_entry)
        log(f"Added: {episode_entry['title']}")
    
    return episodes

def process_pending(episodes):
    """Process pending transcripts (retry after delay)"""
    pending = load_pending()
    now = datetime.now()
    still_pending = []
    
    for item in pending:
        video_id = item["video_id"]
        added_date = datetime.fromisoformat(item["added"])
        
        if (now - added_date).days >= 2:
            log(f"Retrying: {item['title']}")
            transcript = fetch_transcript(video_id)
            
            if transcript and not transcript.get("error"):
                video_info = {
                    "video_id": video_id,
                    "title": item["title"],
                    "published": item["published"],
                    "url": item["url"],
                    "is_live": item.get("is_live", False)
                }
                episode_data = process_transcript(transcript, video_info)
                if episode_data:
                    episodes = update_episode(episode_data, video_info, episodes)
                    continue
            else:
                log(f"Still no transcript: {item['title']}")
        
        still_pending.append(item)
    
    save_pending(still_pending)
    return episodes

def upload_to_server():
    """Upload episodes file to server via SCP (optional)"""
    try:
        import subprocess
        # Uncomment and configure for auto-upload
        # cmd = f"scp -i {SSH_KEY} {LOCAL_OUTPUT_FILE} {REMOTE_USER}@{REMOTE_HOST}:{REMOTE_PATH}"
        # subprocess.run(cmd, shell=True, check=True)
        # log("Uploaded to server")
        pass
    except Exception as e:
        log(f"Upload failed: {e}")

def main():
    log("=== Tom Bilyeu Channel Monitor (Local) ===")
    
    if SUPADATA_API_KEY == "YOUR_API_KEY_HERE":
        log("ERROR: Please set your SUPADATA_API_KEY in the script")
        sys.exit(1)
    
    # Load existing episodes
    episodes = load_existing_episodes()
    log(f"Loaded {len(episodes)} existing episodes")
    
    # Process pending
    log("Processing pending transcripts...")
    episodes = process_pending(episodes)
    
    # Fetch RSS
    log("Fetching RSS feed...")
    rss_content = fetch_rss()
    if not rss_content:
        log("Failed to fetch RSS")
        sys.exit(1)
    
    videos = parse_rss(rss_content)
    log(f"Found {len(videos)} videos")
    
    # Find new videos (check both URL and video ID)
    existing_urls = {ep.get("url", "") for ep in episodes}
    existing_ids = set()
    for ep in episodes:
        url = ep.get("url", "")
        if "watch?v=" in url:
            existing_ids.add(url.split("watch?v=")[1])
    pending = load_pending()
    pending_ids = {p["video_id"] for p in pending}
    
    new_videos = [v for v in videos if v["url"] not in existing_urls and v["video_id"] not in existing_ids and v["video_id"] not in pending_ids]
    log(f"New videos to process: {len(new_videos)}")
    
    # Process each new video
    for video in new_videos:
        log(f"Processing: {video['title'][:60]}...")
        
        transcript = fetch_transcript(video["video_id"])
        
        if transcript and transcript.get("error") == "no_transcript":
            log(f"No transcript yet, adding to pending")
            pending.append({
                "video_id": video["video_id"],
                "title": video["title"],
                "published": video["published"],
                "url": video["url"],
                "is_live": video["is_live"],
                "added": datetime.now().isoformat()
            })
            save_pending(pending)
            
            # Create placeholder
            placeholder = {
                "summary": f"Transcript pending - will retry in 48 hours. {video['title']}",
                "keyTakeaways": ["Transcript being processed"],
                "expandedTakeaways": [],
                "topicBreakdown": [],
                "toolsCovered": [],
                "topics": []
            }
            episodes = update_episode(placeholder, video, episodes)
            
        elif transcript:
            episode_data = process_transcript(transcript, video)
            if episode_data:
                episodes = update_episode(episode_data, video, episodes)
        else:
            log(f"Failed to fetch transcript")
    
    # Save episodes
    save_episodes(episodes)
    
    # Optional: Upload to server
    # upload_to_server()
    
    log("=== Done ===")
    log(f"Output file: {LOCAL_OUTPUT_FILE}")
    log("Upload this file to your Mission Control server to update the episodes list")

if __name__ == "__main__":
    main()
