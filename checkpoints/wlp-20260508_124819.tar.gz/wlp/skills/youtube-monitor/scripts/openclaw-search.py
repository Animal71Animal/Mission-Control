#!/usr/bin/env python3
"""
OpenClaw YouTube Monitor - Search for OpenClaw mentions
Uses requests + BeautifulSoup for reliable parsing
"""

import json
import os
import sys
import re
import subprocess
import requests
from datetime import datetime

# ============ CONFIG ============
FOUND_VIDEOS_FILE = os.path.expanduser("~/wlp/ops/youtube-openclaw-videos.json")
LOG_FILE = os.path.expanduser("~/wlp/logs/youtube-monitor.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
# ================================

def log(message):
    """Log to file and stdout"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")

def search_youtube(query="OpenClaw", max_results=20):
    """Search YouTube and extract clean video data"""
    videos = []
    
    try:
        log(f"Searching YouTube for: {query}")
        
        search_url = f"https://www.youtube.com/results?search_query={query}&sp=CAISBAgB"
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        
        response = requests.get(search_url, headers=headers, timeout=30)
        response.raise_for_status()
        
        html = response.text
        
        # Extract ytInitialData JSON from script tag
        match = re.search(r'var ytInitialData = ({.*?});</script>', html, re.DOTALL)
        
        if not match:
            log("Could not find ytInitialData in page")
            return None
        
        try:
            yt_data = json.loads(match.group(1))
        except json.JSONDecodeError as e:
            log(f"Failed to parse ytInitialData: {e}")
            return None
        
        # Navigate to video results
        try:
            contents = yt_data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
        except KeyError:
            log("Could not navigate to video results in JSON")
            return None
        
        for section in contents:
            if "itemSectionRenderer" not in section:
                continue
            
            items = section["itemSectionRenderer"].get("contents", [])
            
            for item in items:
                if "videoRenderer" not in item:
                    continue
                
                video = item["videoRenderer"]
                
                video_id = video.get("videoId")
                if not video_id:
                    continue
                
                # Extract title
                title_runs = video.get("title", {}).get("runs", [])
                title = title_runs[0].get("text", "Unknown") if title_runs else "Unknown"
                
                # Extract channel
                byline = video.get("longBylineText", {}).get("simpleText")
                if not byline:
                    byline_runs = video.get("longBylineText", {}).get("runs", [])
                    byline = byline_runs[0].get("text", "Unknown") if byline_runs else "Unknown"
                
                channel = byline if byline else "Unknown"
                
                # Extract view count and published time
                metadata_rows = video.get("metadataRowContainer", {}).get("metadataRowContainerRenderer", {}).get("rows", [])
                metadata = ""
                for row in metadata_rows[:2]:
                    row_renderer = row.get("metadataRowRenderer", {})
                    text = row_renderer.get("title", {}).get("simpleText", "")
                    contents_text = row_renderer.get("contents", [{}])[0].get("simpleText", "")
                    if contents_text:
                        metadata += f"{text} {contents_text} · " if text else f"{contents_text} · "
                
                metadata = metadata.rstrip(" · ")
                
                videos.append({
                    "video_id": video_id,
                    "title": title,
                    "channel": channel,
                    "metadata": metadata,
                    "url": f"https://www.youtube.com/watch?v={video_id}",
                    "found_at": datetime.now().isoformat()
                })
                
                log(f"  Found: {title[:60]} by {channel}")
                
                if len(videos) >= max_results:
                    break
            
            if len(videos) >= max_results:
                break
        
        return videos if videos else None
    
    except Exception as e:
        log(f"ERROR: Search failed: {e}")
        import traceback
        log(traceback.format_exc())
        return None

def load_existing_videos():
    """Load previously found videos"""
    if os.path.exists(FOUND_VIDEOS_FILE):
        try:
            with open(FOUND_VIDEOS_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            log(f"Error loading existing videos: {e}")
    return []

def save_videos(videos):
    """Save videos to file"""
    try:
        with open(FOUND_VIDEOS_FILE, 'w') as f:
            json.dump(videos, f, indent=2)
        log(f"Saved {len(videos)} videos to {FOUND_VIDEOS_FILE}")
    except Exception as e:
        log(f"Error saving videos: {e}")

def find_new_videos(current, existing):
    """Find videos not yet in the existing list"""
    if current is None:
        return []
    existing_ids = {v.get("video_id") for v in existing}
    new = [v for v in current if v.get("video_id") not in existing_ids]
    return new

def main():
    log("=== OpenClaw YouTube Monitor ===")
    
    # Load existing
    existing = load_existing_videos()
    log(f"Loaded {len(existing)} existing videos")
    
    # Search
    results = search_youtube("OpenClaw", max_results=20)
    
    if results is None:
        log("Search failed, exiting")
        sys.exit(1)
    
    if not results:
        log("No videos found")
        sys.exit(0)
    
    log(f"Found {len(results)} total videos")
    
    # Find new
    new_videos = find_new_videos(results, existing)
    
    if new_videos:
        log(f"Found {len(new_videos)} NEW videos mentioning OpenClaw:")
        for v in new_videos:
            log(f"  - {v['title'][:70]} by {v['channel']}")
            log(f"    {v['url']}")
        
        # Merge and save
        all_videos = new_videos + existing
        save_videos(all_videos[:100])  # Keep newest 100
        
        # Sync to Mission Control
        log("Syncing to Mission Control...")
        try:
            result = subprocess.run(
                ["/usr/bin/python3", "/home/ubuntu/wlp/skills/youtube-monitor/scripts/sync-to-mc.py"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                log("Sync complete")
            else:
                log(f"Sync failed: {result.stderr}")
        except Exception as e:
            log(f"Error running sync: {e}")
    else:
        log("No new videos found")
    
    log("=== Done ===")

if __name__ == "__main__":
    main()
