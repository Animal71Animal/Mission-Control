# Supadata API Notes

## Authentication
- Header: `x-api-key: sd_b4e03cefc86907e9c2e7f9d8284510a9`
- Base URL: `https://api.supadata.ai/v1`

## Endpoints

### Search Videos
```
GET /youtube/search?query=OpenClaw&type=video&maxResults=50
```

Response:
```json
{
  "query": "OpenClaw",
  "results": [
    {
      "type": "video",
      "id": "VIDEO_ID",
      "title": "...",
      "description": "...",
      "thumbnail": "...",
      "duration": 2383,
      "viewCount": 7910,
      "uploadDate": "16 hours ago",
      "channel": {
        "id": "...",
        "name": "Traversy Media",
        "thumbnail": "..."
      }
    }
  ]
}
```

### Fetch Transcript
```
GET /transcript?url=https://www.youtube.com/watch?v=VIDEO_ID&text=true
```

Response:
```json
{
  "text": "Full transcript text..."
}
```

## Rate Limits
- Be nice: add delays every 5 videos
- 429 response = rate limited, back off

## Error Handling
- 404 = no transcript available
- 429 = rate limited
- Always handle gracefully, add placeholder if transcript fails
