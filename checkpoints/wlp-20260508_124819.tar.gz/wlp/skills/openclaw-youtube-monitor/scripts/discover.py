#!/usr/bin/env python3
"""
OpenClaw Video Discovery
Searches YouTube for the last 50 videos about OpenClaw
Saves to mission-control/public/data/openclaw-episodes.json
"""

import json
import sys
import os
import re
import requests
from datetime import datetime, timedelta

# ============ CONFIG ============
SUPADATA_API_KEY = "sd_b4e03cefc86907e9c2e7f9d8284510a9"
SUPADATA_BASE_URL = "https://api.supadata.ai/v1"

# Output paths
OUTPUT_FILE = "/home/ubuntu/wlp/projects/mission-control/public/data/openclaw-episodes.json"
LOG_FILE = "/home/ubuntu/wlp/logs/openclaw-discovery.log"
# =================================

def log(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_msg = f"[{timestamp}] {message}"
    print(log_msg)
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, 'a') as f:
        f.write(log_msg + "\n")

def search_youtube_videos(query, max_results=50):
    """Search YouTube for videos using Supadata search API"""
    url = f"{SUPADATA_BASE_URL}/youtube/search"
    headers = {"x-api-key": SUPADATA_API_KEY}
    params = {
        "query": query,
        "type": "video",
        "maxResults": max_results
    }
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        if response.status_code == 200:
            data = response.json()
            results = data.get("results", [])
            # Convert to consistent format
            videos = []
            for r in results:
                if r.get("type") == "video":
                    videos.append({
                        "videoId": r.get("id"),
                        "title": r.get("title"),
                        "description": r.get("description"),
                        "channel": r.get("channel", {}).get("name", "Unknown"),
                        "published": r.get("uploadDate", ""),
                        "thumbnail": r.get("thumbnail"),
                        "duration": r.get("duration"),
                        "viewCount": r.get("viewCount")
                    })
            return videos
        else:
            log(f"Search API error: {response.status_code} - {response.text}")
    except Exception as e:
        log(f"Error searching YouTube: {e}")
    return []

def fetch_transcript(video_id):
    """Fetch transcript from Supadata API"""
    url = f"{SUPADATA_BASE_URL}/transcript?url=https://www.youtube.com/watch?v={video_id}&text=true"
    headers = {"x-api-key": SUPADATA_API_KEY}
    
    try:
        response = requests.get(url, headers=headers, timeout=60)
        if response.status_code == 404:
            return {"error": "no_transcript", "message": "Transcript not available"}
        if response.status_code == 429:
            log(f"API rate limit hit for {video_id}")
            return {"error": "rate_limited", "message": "Rate limited"}
        response.raise_for_status()
        data = response.json()
        if "text" not in data and "content" in data:
            data["text"] = data["content"]
        return data
    except Exception as e:
        log(f"Error fetching transcript for {video_id}: {e}")
        return {"error": "exception", "message": str(e)}

def generate_summary(text, video_info):
    """Generate a comprehensive summary from transcript"""
    if not text or len(text) < 100:
        return {
            "summary": f"Transcript not available for: {video_info['title']}",
            "keyTakeaways": ["No transcript available"],
            "toolsCovered": [],
            "skillsMentioned": [],
            "priscyllaTake": "Unable to analyze - no transcript"
        }
    
    # Extract first 500 chars for summary
    summary = text[:500] + "..." if len(text) > 500 else text
    
    # Extract key sentences (heuristic: sentences with important keywords)
    sentences = re.split(r'[.!?]+', text)
    key_takeaways = []
    important_keywords = ['feature', 'update', 'new', 'tool', 'skill', 'agent', 'automation', 'workflow', 'integration', 'api', 'setup', 'configure', 'tutorial', 'guide', 'tip', 'trick', 'best practice']
    
    for sentence in sentences:
        sentence = sentence.strip()
        if 30 < len(sentence) < 200:
            lower = sentence.lower()
            if any(kw in lower for kw in important_keywords):
                key_takeaways.append(sentence)
        if len(key_takeaways) >= 5:
            break
    
    if not key_takeaways:
        # Fallback: just take first few meaningful sentences
        for sentence in sentences:
            sentence = sentence.strip()
            if 40 < len(sentence) < 180:
                key_takeaways.append(sentence)
            if len(key_takeaways) >= 3:
                break
    
    # Extract tools/skills mentioned
    tools_covered = []
    skills_mentioned = []
    
    tool_patterns = [
        r'\b(OpenClaw)\b',
        r'\b(Claude)\b',
        r'\b(GPT)\b',
        r'\b(Anthropic)\b',
        r'\b(Discord)\b',
        r'\b(Telegram)\b',
        r'\b(Slack)\b',
        r'\b(WhatsApp)\b',
        r'\b(browser)\b',
        r'\b(automation)\b',
        r'\b(workflow)\b',
        r'\b(integration)\b',
        r'\b(API)\b',
        r'\b(skill)\b',
        r'\b(tool)\b',
        r'\b(agent)\b',
        r'\b(model)\b',
        r'\b(LLM)\b',
        r'\b(AI)\b',
    ]
    
    text_lower = text.lower()
    for pattern in tool_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for match in matches:
            clean_match = match.strip()
            if clean_match and clean_match not in tools_covered and len(clean_match) > 2:
                tools_covered.append(clean_match)
    
    # Deduplicate and limit
    tools_covered = list(dict.fromkeys(tools_covered))[:10]
    skills_mentioned = [t for t in tools_covered if t.lower() in ['skill', 'tool', 'agent', 'workflow', 'automation', 'integration']]
    
    # Generate Priscylla's take
    priscylla_take = generate_priscylla_take(text, video_info, key_takeaways, tools_covered)
    
    return {
        "summary": summary,
        "keyTakeaways": key_takeaways[:5] or ["Key insights from the video"],
        "toolsCovered": tools_covered,
        "skillsMentioned": skills_mentioned,
        "priscyllaTake": priscylla_take
    }

def generate_priscylla_take(text, video_info, takeaways, tools):
    """Generate Priscylla's opinion on the video"""
    title_lower = video_info['title'].lower()
    text_lower = text.lower()
    
    # Determine video type
    is_tutorial = any(word in title_lower for word in ['tutorial', 'guide', 'how to', 'setup', 'beginner', 'crash course'])
    is_update = any(word in title_lower for word in ['update', 'new', 'changed', 'just', 'latest'])
    is_review = any(word in title_lower for word in ['review', 'explained', 'what is', 'overview'])
    
    opinions = []
    
    if is_tutorial:
        opinions.append("This is a solid tutorial for getting started with OpenClaw.")
        if len(takeaways) >= 3:
            opinions.append("Good step-by-step coverage with practical examples.")
        else:
            opinions.append("A bit light on details, but covers the basics.")
    
    if is_update:
        opinions.append("Worth watching to stay current on OpenClaw features.")
        if 'browser' in text_lower or 'voice' in text_lower:
            opinions.append("Highlights some genuinely useful new capabilities.")
    
    if is_review:
        opinions.append("Good overview for understanding OpenClaw's current state.")
    
    if len(tools) > 5:
        opinions.append("Covers a wide range of tools and integrations.")
    elif len(tools) > 2:
        opinions.append("Touches on some useful tools and workflows.")
    else:
        opinions.append("Light on specific tool coverage.")
    
    if 'tip' in title_lower or 'trick' in title_lower:
        opinions.append("Has some actionable tips you can apply immediately.")
    
    # Add recommendation
    if is_tutorial and len(takeaways) >= 3:
        opinions.append("**Recommendation:** Watch this if you're new to OpenClaw or setting up your first agent.")
    elif is_update:
        opinions.append("**Recommendation:** Skim this to catch up on recent changes.")
    else:
        opinions.append("**Recommendation:** Worth a watch if the topic aligns with your current projects.")
    
    return " ".join(opinions)

def load_existing():
    """Load existing episodes"""
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r') as f:
            data = json.load(f)
            if isinstance(data, dict) and "episodes" in data:
                return data["episodes"]
            return data
    return []

def save_episodes(episodes):
    """Save episodes to output file"""
    output_data = {
        "episodes": episodes,
        "last_updated": datetime.now().isoformat(),
        "total": len(episodes)
    }
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, 'w') as f:
        json.dump(output_data, f, indent=2)
    log(f"Saved {len(episodes)} episodes to {OUTPUT_FILE}")

def update_episode(episode_data, video_info, episodes):
    """Update or create episode entry - newest at top"""
    video_id = video_info.get("videoId") or video_info.get("id", "")
    existing_idx = None
    for i, ep in enumerate(episodes):
        if ep.get("url", "").endswith(video_id):
            existing_idx = i
            break
    
    episode_entry = {
        "id": f"yt-{video_id}",
        "episodeNumber": len(episodes) + 1,
        "title": video_info["title"],
        "url": f"https://www.youtube.com/watch?v={video_id}",
        "channel": video_info.get("channel", "Unknown"),
        "publishedDate": video_info.get("published", datetime.now().strftime("%Y-%m-%d")),
        "summary": episode_data.get("summary", ""),
        "keyTakeaways": episode_data.get("keyTakeaways", []),
        "toolsCovered": episode_data.get("toolsCovered", []),
        "skillsMentioned": episode_data.get("skillsMentioned", []),
        "priscyllaTake": episode_data.get("priscyllaTake", ""),
        "completed": False
    }
    
    if existing_idx is not None:
        # Preserve episode number and completed status
        episode_entry["episodeNumber"] = episodes[existing_idx].get("episodeNumber", len(episodes) + 1)
        episode_entry["completed"] = episodes[existing_idx].get("completed", False)
        episodes[existing_idx] = episode_entry
        log(f"Updated: {episode_entry['title'][:60]}...")
    else:
        episodes.insert(0, episode_entry)
        log(f"Added: {episode_entry['title'][:60]}...")
    
    return episodes

def main():
    log("=== OpenClaw Video Discovery ===")
    
    # Load existing episodes
    episodes = load_existing()
    log(f"Loaded {len(episodes)} existing episodes")
    
    # Search for OpenClaw videos
    log("Searching YouTube for OpenClaw videos...")
    search_results = search_youtube_videos("OpenClaw", max_results=50)
    log(f"Found {len(search_results)} videos from search")
    
    if not search_results:
        log("No videos found. Exiting.")
        sys.exit(0)
    
    # Process each video
    processed = 0
    skipped = 0
    
    for video in search_results:
        video_id = video.get("videoId", "")
        if not video_id:
            continue
        
        # Check if already exists
        existing_ids = [ep.get("url", "").split("watch?v=")[-1] for ep in episodes]
        if video_id in existing_ids:
            log(f"Skipping (already exists): {video.get('title', '')[:60]}...")
            skipped += 1
            continue
        
        log(f"Processing: {video.get('title', '')[:60]}...")
        
        # Fetch transcript
        transcript = fetch_transcript(video_id)
        
        if transcript and not transcript.get("error"):
            episode_data = generate_summary(transcript.get("text", ""), video)
            episodes = update_episode(episode_data, video, episodes)
            processed += 1
        else:
            log(f"No transcript available: {video.get('title', '')[:60]}...")
            # Add placeholder
            placeholder = {
                "summary": f"Transcript pending. {video.get('title', '')}",
                "keyTakeaways": ["Transcript being processed"],
                "toolsCovered": [],
                "skillsMentioned": [],
                "priscyllaTake": "Unable to analyze - no transcript available"
            }
            episodes = update_episode(placeholder, video, episodes)
            processed += 1
        
        # Rate limiting - be nice to the API
        if processed % 5 == 0:
            log(f"Progress: {processed} processed, {skipped} skipped")
    
    # Save episodes
    save_episodes(episodes)
    log(f"=== Done === Processed: {processed}, Skipped: {skipped}, Total: {len(episodes)}")

if __name__ == "__main__":
    main()
