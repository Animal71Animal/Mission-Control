---
name: openclaw-youtube-monitor
description: Discover, summarize, and persist OpenClaw-related YouTube videos to Mission Control. Use when the user asks to run OpenClaw video automation, check for new OpenClaw videos, update the OpenClaw video library, or any request involving fetching OpenClaw YouTube content with summaries, key takeaways, tools covered, and Priscylla's take.
---

# OpenClaw YouTube Monitor

Discovers the latest OpenClaw videos from YouTube, fetches transcripts, generates summaries with key takeaways, tools/skills mentioned, and Priscylla's opinion — then persists everything to Mission Control's JSON via GitHub API.

## Workflow

1. **Search** — Query Supadata API for last 50 "OpenClaw" videos
2. **Filter** — Skip already-persisted videos (by video ID)
3. **Transcribe** — Fetch transcript via Supadata
4. **Summarize** — Extract summary, key takeaways, tools, skills
5. **Opinion** — Generate Priscylla's take on the video
6. **Persist** — Save to `public/data/openclaw-episodes.json` via GitHub API
7. **Deploy** — Push to GitHub, deploy to Vercel

## Scripts

- `scripts/discover.py` — Main discovery script (run this)
- `scripts/openclaw-monitor.py` — Legacy channel-specific monitor (deprecated)

## Usage

```bash
python3 /home/ubuntu/wlp/skills/openclaw-youtube-monitor/scripts/discover.py
```

## Key Behaviors

- **Preserves completed status** — When updating existing episodes, retains `completed` field
- **Server-side persistence** — All video state (done/important) saves to GitHub JSON
- **Newest first** — Inserts new episodes at top of array
- **Idempotent** — Safe to re-run; skips existing videos, updates changed ones

## References

- `references/api-notes.md` — Supadata API details and response formats
