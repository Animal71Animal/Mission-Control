# Infrastructure Repair Skill

Use this skill when: git repos are dirty/behind, cron jobs are missing or misconfigured, Tailscale is down, or after any container restart.

---

## PART 1: Fix Git Repos

```bash
# Check status
cd /home/ubuntu/wlp/projects/mission-control && git status
cd /home/ubuntu/wlp/projects/featured-entertainer && git status

# Stage, commit, push (mission-control)
cd /home/ubuntu/wlp/projects/mission-control
git add .
git commit -m "Auto-commit: infrastructure repair (YYYY-MM-DD)"
git push origin main

# Stage, commit, push (featured-entertainer — note: uses master not main)
cd /home/ubuntu/wlp/projects/featured-entertainer
git add .
git commit -m "Auto-commit: cleanup (YYYY-MM-DD)"
git push origin master
```

**Notes:**
- mission-control → branch `main`
- featured-entertainer → branch `master`
- If push fails with auth error, check git remote: `git remote -v`

---

## PART 2: Verify / Fix Cron Jobs

### Check existing cron jobs (OpenClaw scheduler — NOT system crontab)

```bash
openclaw cron list
```

### Expected cron jobs (as of 2026-04-22)

| Name | Schedule | Target | Purpose |
|------|----------|--------|---------|
| tailscale-keepalive | `*/10 * * * *` MDT | main | Restart Tailscale if down |
| night-creative | `30 1 * * *` MDT | isolated | Autonomous creative work |
| dream-cycle | `0 3 * * *` MDT | isolated | Memory optimization |
| morning-worker | `0 6 * * *` MDT | isolated | Task execution |
| morning-briefing | `0 10 * * *` MDT | isolated | Daily briefing + voice |
| data-integrity-check | `0 2 * * *` MDT | main | Data integrity |
| checkpoint-manager-auto | `30 3 * * *` MDT | main | Checkpoint management |
| openclaw-youtube-monitor | `0 21 * * *` MDT | isolated | YouTube scraping |
| beatsource-weekly-sync | `0 14 * * 5` MDT | isolated | Beatsource sync (Fridays) |
| cron-monitor-weekly | `0 9 * * 0` MDT | main | Cron health check (Sundays) |

**NOTE:** tom-bilyeu-monitor and peter-diamandis-monitor were intentionally removed on 2026-04-17.

### Edit cron schedule directly (if openclaw CLI doesn't support edit)

The cron jobs are stored in `~/.openclaw/cron/jobs.json`. Edit with Python:

```python
import json, time

with open('/home/ubuntu/.openclaw/cron/jobs.json', 'r') as f:
    d = json.load(f)

# Example: fix tailscale-keepalive schedule
for job in d['jobs']:
    if job['name'] == 'tailscale-keepalive':
        job['schedule']['expr'] = '*/10 * * * *'
        job['updatedAtMs'] = int(time.time() * 1000)

with open('/home/ubuntu/.openclaw/cron/jobs.json', 'w') as f:
    json.dump(d, f, indent=2)
```

Then restart gateway: `openclaw gateway restart`

### Add a missing cron job

```bash
openclaw cron add \
  --name "job-name" \
  --schedule "*/10 * * * *" \
  --tz "America/Denver" \
  --target main \
  --message "Your prompt here"
```

---

## PART 3: Tailscale

### Check status
```bash
tailscale status 2>&1
pgrep -a tailscaled
```

### Start Tailscale (after container restart)
```bash
bash /home/ubuntu/scripts/tailscale-start.sh
```

**⚠️ Known issue (2026-04-22):** The `tailscale` binary may not be installed in the container. If `tailscale: command not found`:
- Check if binary exists: `find / -name "tailscale" -type f 2>/dev/null | grep -v proc`
- If missing, it needs to be reinstalled. See `wlp/skills/tailscale/SKILL.md` for the full setup process.
- The tailscale-keepalive cron will fail silently until the binary is restored.

---

## PART 4: Verification Checklist

```bash
# 1. Git repos clean?
cd /home/ubuntu/wlp/projects/mission-control && git status
cd /home/ubuntu/wlp/projects/featured-entertainer && git status
# Expected: "nothing to commit, working tree clean"

# 2. Cron jobs present?
openclaw cron list
# Expected: all jobs listed with ok/idle/error status

# 3. Tailscale running?
pgrep -a tailscaled && tailscale status
# Expected: daemon PID + IP address shown
```

---

## Troubleshooting Checklist

Run this skill when you see any of:
- `git status` shows modified/untracked files
- Cron jobs missing from `openclaw cron list`
- `tailscale status` errors or connection failures
- Morning briefing / night-creative / dream-cycle not running
- Discord #agent-output reports Tailscale down

**After container restart:** Always run the tailscale-start.sh script first, then verify crons are loaded.
