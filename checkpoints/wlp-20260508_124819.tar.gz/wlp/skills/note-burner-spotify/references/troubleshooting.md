# Troubleshooting Guide

## Common Issues

### "No Burner app not found"
**Problem:** Script can't launch No Burner  
**Fix:** 
- Verify No Burner is installed in `/Applications`
- Try opening it manually once to complete setup
- Check app name in Activity Monitor

### "Could not find first Add button"
**Problem:** Playwright can't locate Spotify's Add button  
**Fix:** 
- No Burner's Spotify UI may use different selectors
- Run `scripts/debug_ui.py` to snapshot current page structure
- Update selectors in `no_burner_ui.py` based on actual UI

### "Could not set output folder"
**Problem:** File path input not found or not writable  
**Fix:**
- No Burner may use a native file picker, not a text input
- Manual intervention required for folder selection
- Consider hardcoding output folder in No Burner settings

### "Conversion timeout"
**Problem:** Conversion takes longer than expected  
**Fix:**
- Increase `CONVERSION_WAIT_SECONDS` in `config.py`
- Check if No Burner has a queue or is processing in background
- Verify output disk has space

### Spotify login expired
**Problem:** Session cookies no longer valid  
**Fix:**
- Delete `spotify_cookies.json`
- Run script once manually - it will prompt for Spotify login
- New cookies will be saved automatically

### Headless mode issues
**Problem:** Script works but GUI automation is unreliable  
**Fix:**
- Always run with `headless=False` to see what's happening
- If running headless is needed, increase wait times
- Consider VNC instead if remote access is needed

## Debug Mode

Run with debug logging:
```bash
DEBUG=1 python3 scripts/run_download.py
```

Snapshot page structure:
```bash
python3 scripts/debug_ui.py
```

This will print all visible elements and their selectors.

## Testing Individual Steps

```bash
# Test just launching No Burner
python3 -c "from no_burner_ui import launch_no_burner; launch_no_burner()"

# Test browser connectivity
python3 scripts/spotify_auth.py
```