# Dancer Playlist URLs

Record dancer Spotify collaborative playlist URLs here.

## Format
```
Dancer Name | Playlist URL | Output Folder | Status
```

## Active Dancers

| Dancer | Playlist URL | Output Folder | Status |
|--------|-------------|---------------|--------|
| | | | |

## Setup Instructions

1. Create collaborative playlist in Spotify (dancer + you as collaborators)
2. Share invite link with dancer
3. Dancer adds songs they want to the playlist
4. Add playlist URL above
5. Set output folder path on iMac

## Finding Playlist URLs

1. Open playlist in Spotify web player
2. Click **...** (three dots) → **Share** → **Copy link**
3. Paste URL above (format: `https://open.spotify.com/playlist/...`)

## Output Folder Structure

Recommended path format:
```
/Users/eric/Music/SRB-Dancers/[Dancer Name]/
```

Example:
```
/Users/eric/Music/SRB-Dancers/Madison Blair/
/Users/eric/Music/SRB-Dancers/Kade Rivers/
/Users/eric/Music/SRB-Dancers/Aria Vale/
```