---
name: note-burner-spotify
description: Automates NoteBurner Spotify Music Converter on macOS iMac. Use when Eric needs to download collaborative Spotify playlists for dancers without manual intervention. Handles launching NoteBurner, authenticating Spotify, navigating to dancer playlists, clicking Add buttons, setting output folders, and running conversion. Triggers when: (1) dancer adds songs to a Spotify playlist, (2) weekly download scheduled, (3) new dancer setup needed, (4) download workflow fails.
---

# NoteBurner Spotify Automation

## Overview

NoteBurner Spotify Music Converter is a macOS desktop app that downloads Spotify playlists as MP3/AAC/FLAC/WAV/AIFF/ALAC files. It opens Spotify Web Player automatically, and you click Add to queue tracks, then Convert.

This skill automates that manual workflow using Playwright browser automation. Script runs on iMac via launchd on schedule.

## Workflow

1. Launch NoteBurner → auto-opens Spotify Web Player
2. Sign in to Spotify (stored cookies reused)
3. Navigate to dancer's collaborative playlist URL
4. Click "Add" icon (bottom right of Spotify web player)
5. Select tracks and click "Add" to confirm
6. Click "Convert" button
7. Wait for completion → repeat for next dancer
8. Find converted files via History → Folder icon

## Requirements

- macOS iMac (local execution)
- Python 3.8+ with `playwright` installed (`pip3 install playwright && playwright install chromium`)
- NoteBurner Spotify Music Converter installed ($44.95, free trial available)
- Spotify account with access to all dancer collaborative playlists
- Dancer playlist URLs and output folder mappings in `config.py`

## Setup

### One-time installation on iMac:

```bash
# Install Playwright
pip3 install playwright
playwright install chromium

# Download NoteBurner from https://www.noteburner.com/sp-music-converter-mac.html
```

### Configuration:

Edit `scripts/config.py`:
- Dancer names, playlist URLs, output folder paths
- Spotify cookie session (for persistent auto-login)

### Schedule (launchd):

```bash
cp scripts/com.wlp.note-burner-download.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.wlp.note-burner-download.plist
```

## File Structure

```
note-burner-spotify/
├── SKILL.md
├── scripts/
│   ├── config.py              # Dancer config: names, URLs, folders
│   ├── run_download.py       # Main entry point
│   ├── spotify_auth.py        # Cookie-based Spotify auth
│   ├── note_burner_ui.py      # UI automation (from official tutorial)
│   ├── debug_ui.py            # Snapshot page structure for debugging
│   └── com.wlp.note-burner-download.plist  # launchd scheduler
└── references/
    ├── dancer-playlists.md    # Playlist URL storage
    └── troubleshooting.md     # Common issues and fixes
```

## Workflow Details (from NoteBurner Tutorial)

1. **Launch**: NoteBurner opens Spotify Web Player automatically
2. **Sign In**: Click "Sign In" icon (bottom left) → enter Spotify credentials
3. **Settings**: Click Settings icon → choose output format (MP3/AAC/etc), quality (320kbps), output folder
4. **Add Tracks**: On Spotify web player, find playlist → click "Add" icon (bottom right) → select tracks → click "Add" to confirm
5. **Convert**: Click "Convert" button
6. **Find Files**: Click "History" → hover track → click Folder icon

## Security Notes

- Store Spotify credentials securely; do not commit to version control
- Cookie-based auth preferred (persistent session, no password storage)
- Output folders should be local to iMac, not network paths