#!/bin/bash
# Launcher for test_one_dancer.py

cd ~/wlp/skills/note-burner-spotify/scripts
python3 test_one_dancer.py
