#!/usr/bin/env python3
"""
Single Dancer Test — PyAutoGUI Automation
==========================================
Tests automation on ONE dancer so you can debug the workflow
"""

import sys
import time
from pathlib import Path

try:
    import pyautogui
except ImportError:
    print("ERROR: pyautogui not installed. Run: pip3 install pyautogui")
    sys.exit(1)

from config import DANCERS, CONVERSION_WAIT_SECONDS

# Button coordinates
BUTTON_COORDS = {
    'spotify_add': (382, 397),              # + button in Spotify
    'noteburner_add': (397, 394),           # Add button in NoteBurner main window
    'settings': (332, 399),                 # Settings/gear button
    'settings_folder_field': (1447, 683),   # Click to open folder field in Settings
    'settings_close': (1473, 292),          # Close button on Settings window
    'convert': (1571, 322),                 # Convert button
}

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.1


def click(x, y, delay=0.5, label=""):
    """Click at coordinates with label."""
    if label:
        print(f"    → Clicking {label} at ({x}, {y})")
    pyautogui.click(x, y)
    time.sleep(delay)


def open_address_bar():
    """Focus address bar (Cmd+L)."""
    pyautogui.hotkey('cmd', 'l')
    time.sleep(0.5)


# Get first dancer from config
first_dancer = list(DANCERS.items())[0]
dancer_name, config = first_dancer
playlist_url = config.get("playlist_url", "")
output_folder = config.get("output_folder", "")

print("=" * 60)
print(f"Testing: {dancer_name}")
print("=" * 60)
print(f"URL: {playlist_url}")
print(f"Output: {output_folder}")
print()

input("Make sure NoteBurner is visible. Press Enter to start...")
print()

try:
    print("[1] Opening playlist URL...")
    open_address_bar()
    time.sleep(0.3)
    # Type the URL directly
    print(f"    Typing URL...")
    for char in playlist_url:
        pyautogui.write(char)
        time.sleep(0.01)
    time.sleep(0.3)
    pyautogui.press('enter')
    print("    ✓ Navigated to playlist")
    print("    Waiting 8 seconds for playlist to load...")
    time.sleep(8)
    
    print("[2] Clicking + button in Spotify...")
    click(*BUTTON_COORDS['spotify_add'], label="+ (Spotify)")
    print("    ✓ Clicked")
    
    print("[3] Clicking Add in NoteBurner...")
    click(*BUTTON_COORDS['noteburner_add'], label="Add (NoteBurner)")
    print("    ✓ Clicked")
    
    print("[4] Opening Settings...")
    click(*BUTTON_COORDS['settings'], label="Settings")
    print("    ✓ Clicked")
    time.sleep(1)
    
    print("[5] Clicking folder field...")
    click(*BUTTON_COORDS['settings_folder_field'], label="Folder field")
    print("    ✓ Clicked")
    time.sleep(0.5)
    
    print("[6] Setting output folder...")
    print(f"    Typing: {output_folder}")
    pyautogui.hotkey('cmd', 'a')
    time.sleep(0.2)
    for char in output_folder:
        pyautogui.write(char)
        time.sleep(0.02)
    print("    ✓ Typed")
    time.sleep(0.5)
    
    print("[7] Closing Settings...")
    click(*BUTTON_COORDS['settings_close'], label="Settings close")
    print("    ✓ Clicked")
    time.sleep(1)
    
    print("[8] Clicking Convert...")
    click(*BUTTON_COORDS['convert'], label="Convert")
    print("    ✓ Clicked")
    time.sleep(2)
    
    print(f"[9] Waiting for conversion ({CONVERSION_WAIT_SECONDS}s)...")
    for i in range(CONVERSION_WAIT_SECONDS):
        if i % 10 == 0:
            print(f"    {i}s...")
        time.sleep(1)
    
    print()
    print("=" * 60)
    print("DONE - Check if files appeared in the folder")
    print("=" * 60)
    
except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
