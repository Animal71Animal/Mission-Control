#!/usr/bin/env python3
"""
NoteBurner Spotify Downloader — Main Runner
============================================
Flow:
1. Launch NoteBurner → its embedded Spotify browser opens (stays logged in)
2. For each dancer:
   a. Navigate to playlist URL in NoteBurner's Spotify browser
   b. Click + (Add) button in NoteBurner's UI
   c. Wait for tracks to load in NoteBurner
   d. Click Convert in NoteBurner's UI
   e. Wait for conversion to complete
   f. Files save to dancer's output folder (NoteBurner's output path is pre-set)
3. Report results
"""

import sys
import time
import subprocess
import socket
import json
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("ERROR: Playwright not installed. Run: pip3 install playwright && playwright install chromium")
    raise

from config import DANCERS, CONVERSION_WAIT_SECONDS


def wait_for_cdp_port(port, timeout=30):
    """Wait for CDP port to become available."""
    start = time.time()
    for p in [port, 9223, 9333]:
        while time.time() - start < timeout:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                result = sock.connect_ex(('localhost', p))
                sock.close()
                if result == 0:
                    return p
            except Exception:
                pass
            time.sleep(1)
    return None


def launch_note_burner_with_cdp():
    """
    Launch NoteBurner with remote debugging enabled.
    This lets us control its embedded Chromium browser via CDP.
    """
    CDP_PORT = 9222
    
    # Kill existing NoteBurner instances
    subprocess.run(["pkill", "-f", "NoteBurner"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)
    
    # Launch NoteBurner with debug port
    subprocess.Popen(
        ["open", "-a", "NoteBurner Spotify Music Converter", "--args", f"--remote-debugging-port={CDP_PORT}"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    
    # Wait for CDP to be ready
    port = wait_for_cdp_port(CDP_PORT, timeout=20)
    if port is None:
        return None, None
    
    print(f"  -> Found CDP port {CDP_PORT}")
    time.sleep(3)  # Give NoteBurner more time to initialize
    
    # Connect to NoteBurner's browser
    playwright = sync_playwright().start()
    try:
        browser = playwright.chromium.connect_over_cdp(f"http://localhost:{port}")
        print(f"  -> Connected to NoteBurner on port {port}")
        time.sleep(2)  # Wait for browser to settle
        
        print(f"  -> Contexts available: {len(browser.contexts)}")
        if not browser.contexts:
            print(f"  -> No contexts yet, waiting...")
            for i in range(10):
                time.sleep(1)
                if browser.contexts:
                    print(f"  -> Context appeared after {i+1}s")
                    break
        
        # Use existing context + page (don't create new ones)
        if browser.contexts:
            context = browser.contexts[0]
            time.sleep(1)
            pages = context.pages
            print(f"  -> Pages in context: {len(pages)}")
            
            if pages:
                page = pages[0]  # Use existing Spotify page
                print(f"  -> Using existing Spotify page")
                time.sleep(2)
            else:
                print(f"  -> No pages found, waiting for Spotify to load...")
                for i in range(15):
                    time.sleep(1)
                    pages = context.pages
                    if pages:
                        page = pages[0]
                        print(f"  -> Spotify page loaded after {i+1}s")
                        break
                else:
                    print(f"  -> Spotify page did not load")
                    return playwright, None
        else:
            print(f"  -> No contexts available")
            return playwright, None
        
        return playwright, (context, page, browser)
    except Exception as e:
        print(f"  -> CDP error: {e}")
        import traceback
        traceback.print_exc()
        return playwright, None


def click_note_burner_button(button_name, offset_x=0, offset_y=0):
    """
    Click a button in NoteBurner by name using AppleScript.
    offset_x/y are relative to button center if name fails.
    """
    script = f'''
    tell application "System Events"
        tell process "NoteBurner Spotify Music Converter"
            set frontmost to true
            delay 0.3
            
            -- Try to find button by name
            repeat with btn in buttons of window 1
                set btnName to name of btn
                if btnName contains "{button_name}" then
                    click btn
                    return "clicked " & btnName
                end if
            end repeat
            
            -- Fallback: click by relative position
            tell window 1
                set wSize to size
                set wPos to position
                set btnX to (item 1 of wPos) + (item 1 of wSize) / 2 + {offset_x}
                set btnY to (item 2 of wPos) + (item 2 of wSize) - {abs(offset_y)} + {offset_y}
            end tell
            click at {{btnX, btnY}}
            return "clicked by position"
        end tell
    end tell
    '''
    try:
        result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=10)
        output = result.stdout.strip()
        print(f"    {output}")
        return True
    except Exception as e:
        print(f"    AppleScript error: {e}")
        return False


def navigate_page_and_add(page, playlist_url, output_folder):
    """
    For each dancer:
    1. Navigate to their playlist in NoteBurner's browser
    2. Click + (Add) to queue tracks
    3. Set output folder
    4. Click Convert
    """
    # Navigate to playlist
    print(f"    Navigating to playlist...")
    page.goto(playlist_url, wait_until="networkidle", timeout=30000)
    time.sleep(3)
    
    # Click the + (Add) button in NoteBurner's Spotify web player
    # Selector based on NoteBurner tutorial: bottom-right "Add" icon
    add_selectors = [
        "button[aria-label='Add to Your Library']",
        "[aria-label='Add to Your Library']",
        "button[aria-label*='Add']",
        ".add-to-library-button",
        "button[data-testid='add-to-library']",
    ]
    
    clicked = False
    for selector in add_selectors:
        try:
            elem = page.wait_for_selector(selector, timeout=3)
            if elem:
                elem.click()
                clicked = True
                print("    Clicked + (Add) in Spotify")
                break
        except Exception:
            continue
    
    if not clicked:
        # Fallback: click first visible track's + button
        try:
            page.evaluate('''
                var btns = document.querySelectorAll("[aria-label*='Add'], .add-button");
                if (btns.length > 0) { btns[0].click(); }
            ''')
            clicked = True
            print("    Clicked + via JS fallback")
        except Exception:
            pass
    
    time.sleep(2)
    
    # Click Add in NoteBurner (the big blue Add button at bottom)
    print("    Clicking Add in NoteBurner...")
    click_note_burner_button("Add", offset_y=-80)
    time.sleep(2)
    
    # Click Convert in NoteBurner
    print("    Clicking Convert...")
    click_note_burner_button("Convert", offset_y=-50)
    time.sleep(2)


def run_download():
    """Main download workflow."""
    print("=" * 60)
    print("NoteBurner Spotify Downloader — Starting")
    print("=" * 60)
    print(f"Dancers configured: {len(DANCERS)}")
    print()
    
    # Launch NoteBurner with CDP debug port
    print("[1/4] Launching NoteBurner with debug port...")
    playwright, connection = launch_note_burner_with_cdp()
    
    if connection is None:
        print("CDP failed — falling back to manual mode...")
        print()
        print("FALLBACK MODE: Please log into Spotify manually in NoteBurner")
        print("Run: open -a 'NoteBurner Spotify Music Converter' --args --remote-debugging-port=9222")
        print()
        return False
    
    context, page = connection
    print("  -> NoteBurner browser connected")
    print()
    
    completed = []
    failed = []
    
    for dancer_name, config in DANCERS.items():
        playlist_url = config.get("playlist_url", "")
        output_folder = config.get("output_folder", "")
        
        if not playlist_url or not output_folder:
            print(f"SKIP  {dancer_name}: missing config")
            continue
        
        Path(output_folder).mkdir(parents=True, exist_ok=True)
        
        print(f"--- {dancer_name} ---")
        
        try:
            navigate_page_and_add(page, playlist_url, output_folder)
            print(f"  -> COMPLETE")
            completed.append(dancer_name)
        except Exception as e:
            print(f"  -> FAILED: {e}")
            failed.append((dancer_name, str(e)))
        
        print()
    
    # Save cookies for next time
    try:
        cookies = context.cookies()
        Path(Path(__file__).parent / "spotify_cookies.json").write_text(
            json.dumps(cookies, indent=2)
        )
        print("  -> Saved Spotify session")
    except Exception:
        pass
    
    context.close()
    playwright.stop()
    
    print("=" * 60)
    print(f"RESULTS: {len(completed)}/{len(DANCERS)} completed")
    for name in completed:
        print(f"  ✓ {name}")
    for name, err in failed:
        print(f"  ✗ {name}: {err}")
    print("=" * 60)
    
    return len(failed) == 0


if __name__ == "__main__":
    success = run_download()
    sys.exit(0 if success else 1)
