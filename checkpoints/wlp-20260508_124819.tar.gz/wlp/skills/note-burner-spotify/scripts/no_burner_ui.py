"""
NoteBurner UI Interaction Module
================================
Handles all NoteBurner UI automation based on official tutorial workflow.
NoteBurner opens Spotify web player automatically on launch.
"""

import time
from pathlib import Path


def launch_note_burner():
    """Launch the NoteBurner application on macOS."""
    import subprocess
    try:
        # NoteBurner Spotify Music Converter for Mac
        subprocess.run(["open", "-a", "NoteBurner Spotify Music Converter"], timeout=10)
        print("    Launched 'NoteBurner Spotify Music Converter'")
    except subprocess.TimeoutExpired:
        raise Exception("NoteBurner app not found. Is it installed?")
    except FileNotFoundError:
        try:
            # Try alternative app name
            subprocess.run(["open", "-a", "NoteBurner"], timeout=10)
            print("    Launched 'NoteBurner'")
        except Exception as e:
            raise Exception(f"NoteBurner app not found: {e}")


def sign_in_to_spotify(page):
    """
    Click 'Sign In' icon on NoteBurner interface to authenticate with Spotify.
    According to tutorial: 'Sign In' icon is at bottom left corner.
    """
    sign_in_selectors = [
        "button:has-text('Sign In')",
        "[aria-label*='Sign In']",
        ".sign-in-btn",
        "button[aria-label='Sign In']",
    ]
    
    for selector in sign_in_selectors:
        try:
            page.wait_for_selector(selector, timeout=5)
            page.click(selector)
            print("    Clicked 'Sign In'")
            return True
        except Exception:
            continue
    
    print("    Note: Sign In button not found (may already be signed in)")
    return False


def open_settings(page):
    """
    Click Settings icon to configure output format, quality, and folder.
    Tutorial says: 'Click the Settings icon to choose the output format'
    """
    settings_selectors = [
        "button[aria-label='Settings']",
        "[aria-label*='Settings']",
        "button:has-text('Settings')",
        ".settings-btn",
        "[data-testid='settings']",
        "button[title='Settings']",
    ]
    
    for selector in settings_selectors:
        try:
            page.wait_for_selector(selector, timeout=5)
            page.click(selector)
            print("    Clicked Settings")
            return True
        except Exception:
            continue
    
    print("    WARNING: Settings button not found")
    return False


def navigate_to_playlist(page, playlist_url):
    """Navigate browser to Spotify playlist URL."""
    print(f"    Navigating to: {playlist_url[:60]}...")
    page.goto(playlist_url, wait_until="networkidle", timeout=30000)
    time.sleep(2)  # Let playlist fully load


def add_tracks_to_note_burner(page):
    """
    Click the 'Add' icon at bottom right of Spotify web player.
    Per tutorial: 'Find out a playlist on the Spotify web player window, 
    then click the "Add" icon at the bottom right corner.'
    
    Then select tracks and click 'Add' to confirm.
    """
    try:
        page.set_default_timeout(5000)
        
        # Step 1: Click "Add" icon at bottom right of Spotify web player
        add_icon_selectors = [
            "button[aria-label='Add']",
            "button[aria-label*='Add to']",
            "[aria-label*='Add']",
            ".add-btn",
            "button:has-text('Add')",
        ]
        
        clicked = False
        for selector in add_icon_selectors:
            try:
                page.wait_for_selector(selector, timeout=3)
                page.click(selector)
                clicked = True
                print("    Clicked 'Add' icon")
                break
            except Exception:
                continue
        
        if not clicked:
            print("    WARNING: Could not find 'Add' icon")
        
        time.sleep(1)
        
        # Step 2: If a track selection list appeared, click "Add" to confirm
        # Tutorial says: 'Choose the Spotify music tracks you want to convert, 
        # and click "Add"'
        confirm_selectors = [
            "button:has-text('Add')",
            "button:has-text('Add Selected')",
            ".confirm-add-btn",
            "[data-testid='confirm-add']",
        ]
        
        for selector in confirm_selectors:
            try:
                page.wait_for_selector(selector, timeout=3)
                page.click(selector)
                print("    Clicked 'Add' to confirm tracks")
                break
            except Exception:
                continue
        
    except Exception as e:
        print(f"    Note: Add interaction issue: {e}")
    finally:
        page.set_default_timeout(30000)


def set_output_folder(page, output_path):
    """
    Set the output folder in NoteBurner Settings.
    
    Per tutorial: In output settings, you can change the output folder.
    """
    print(f"    Setting output folder: {output_path}")
    
    # Look for folder input in Settings
    folder_selectors = [
        "input[placeholder*='folder']",
        "input[placeholder*='path']",
        "input[placeholder*='save']",
        "input[placeholder*='output']",
        ".output-folder input",
        "[data-testid='output-folder']",
        "button:has-text('Browse')",
        "button:has-text('Choose Folder')",
    ]
    
    for selector in folder_selectors:
        try:
            elem = page.wait_for_selector(selector, timeout=3)
            if elem:
                elem.fill(output_path)
                print("    Filled output path")
                return
        except Exception:
            continue
    
    # If no direct input found, try clicking Browse then filling
    try:
        browse_btn = page.wait_for_selector("button:has-text('Browse')", timeout=5)
        if browse_btn:
            browse_btn.click()
            time.sleep(1)
            for selector in folder_selectors:
                try:
                    elem = page.wait_for_selector(selector, timeout=3)
                    if elem:
                        elem.fill(output_path)
                        print("    Filled output path after Browse")
                        return
                except Exception:
                    continue
    except Exception:
        pass
    
    print("    WARNING: Could not set output folder automatically")


def start_conversion(page):
    """
    Click the 'Convert' button to start downloading.
    
    Per tutorial: 'After the customization is done, click the "Convert" button 
    to start the conversion.'
    """
    convert_selectors = [
        "button:has-text('Convert')",
        "button[aria-label='Convert']",
        "[aria-label='Convert']",
        ".convert-btn",
        "[data-testid='convert']",
        "button >> text=Convert",
    ]
    
    for selector in convert_selectors:
        try:
            page.wait_for_selector(selector, timeout=5)
            page.click(selector)
            print("    Started conversion")
            return
        except Exception:
            continue
    
    raise Exception("Could not find Convert button")


def wait_for_conversion_complete(page, timeout=120):
    """
    Wait for NoteBurner conversion to complete.
    
    Per tutorial: After conversion, find files via History.
    Look for completion indicators or check for history update.
    """
    print(f"    Waiting up to {timeout}s for conversion to complete...")
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        try:
            # Check for completion - convert button should be available again
            # or look for "History" button which indicates conversion done
            done_indicators = [
                "text=History",
                "button:has-text('History')",
                "text=Complete",
                "text=Done",
            ]
            
            for indicator in done_indicators:
                try:
                    page.wait_for_selector(indicator, timeout=2)
                    elapsed = int(time.time() - start_time)
                    print(f"    Conversion complete ({elapsed}s)")
                    return
                except Exception:
                    pass
            
            # Check if Convert button is clickable again (conversion done)
            try:
                convert_btn = page.query_selector("button:has-text('Convert')")
                if convert_btn and convert_btn.is_enabled():
                    elapsed = int(time.time() - start_time)
                    print(f"    Conversion complete ({elapsed}s)")
                    return
            except Exception:
                pass
            
        except Exception:
            pass
        
        time.sleep(5)
    
    elapsed = int(time.time() - start_time)
    print(f"    WARNING: Conversion did not complete within {timeout}s")


def open_history_find_folder(page):
    """
    Per tutorial: 'After conversion, you can find the converted Spotify audio files 
    by clicking History, hovering over the music list, and clicking the Folder icon.'
    """
    # Click History button
    history_selectors = [
        "button:has-text('History')",
        "[aria-label='History']",
        ".history-btn",
    ]
    
    for selector in history_selectors:
        try:
            page.wait_for_selector(selector, timeout=5)
            page.click(selector)
            print("    Opened History")
            time.sleep(1)
            break
        except Exception:
            continue
    
    # Click Folder icon on the track (hover then click folder)
    folder_selectors = [
        "[aria-label='Open Folder']",
        "[aria-label*='Folder']",
        "button[title*='Folder']",
        ".folder-icon",
    ]
    
    for selector in folder_selectors:
        try:
            elem = page.wait_for_selector(selector, timeout=5)
            elem.hover()
            time.sleep(0.5)
            elem.click()
            print("    Clicked Folder icon")
            return
        except Exception:
            continue
    
    print("    Note: Folder icon not found in history view")


def click_add_in_note_burner():
    """
    Click the Add button in NoteBurner's window using AppleScript.
    The Add button adds currently displayed Spotify tracks to the conversion queue.
    """
    script = '''
    tell application "System Events"
        tell process "NoteBurner Spotify Music Converter"
            set frontmost to true
            delay 0.5
            
            -- Try each button in the main window
            repeat with btn in buttons of window 1
                set btnName to name of btn
                if btnName contains "Add" then
                    click btn
                    return "clicked Add button"
                end if
            end repeat
            
            -- Fallback: click by position (Add is typically lower right)
            -- Get window bounds and click near bottom-right
            set wBounds to size of window 1
            set wPos to position of window 1
            set x to (item 1 of wPos) + (item 1 of wBounds) - 80
            set y to (item 2 of wPos) + (item 2 of wBounds) - 60
            click at {x, y}
            return "clicked by position"
        end tell
    end tell
    '''
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=10
        )
        output = result.stdout.strip()
        if "clicked" in output.lower():
            print(f"    {output}")
            return True
        else:
            print(f"    Add button: {output}")
            return False
    except Exception as e:
        print(f"    AppleScript error: {e}")
        return False



def click_convert_in_note_burner():
    """
    Click the Convert button in NoteBurner's window using AppleScript.
    """
    script = '''
    tell application "System Events"
        tell process "NoteBurner Spotify Music Converter"
            set frontmost to true
            delay 0.5
            
            -- Find and click the Convert button
            repeat with btn in buttons of window 1
                set btnName to name of btn
                if btnName contains "Convert" then
                    click btn
                    return "clicked Convert button"
                end if
            end repeat
            
            -- Fallback: click by position (Convert is typically center-bottom)
            set wBounds to size of window 1
            set wPos to position of window 1
            set x to (item 1 of wPos) + (item 1 of wBounds) / 2
            set y to (item 2 of wPos) + (item 2 of wBounds) - 50
            click at {x, y}
            return "clicked Convert by position"
        end tell
    end tell
    '''
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=10
        )
        output = result.stdout.strip()
        if "clicked" in output.lower():
            print(f"    {output}")
            return True
        else:
            print(f"    Convert button: {output}")
            return False
    except Exception as e:
        print(f"    AppleScript error: {e}")
        return False