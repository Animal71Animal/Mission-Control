"""
Spotify Authentication Helper — NoteBurner CDP Edition
=====================================================
NoteBurner opens an embedded Chromium with Spotify Web Player.
We try to connect to it via Chrome DevTools Protocol (CDP).
If NoteBurner was launched with --remote-debugging-port=9222, CDP works.
If not, we fall back to the browser launched separately.
"""

import subprocess
import time
import socket
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("ERROR: Playwright not installed. Run: pip3 install playwright && playwright install chromium")
    raise


CDP_PORT = 9222


def is_cdp_available(port):
    """Check if CDP endpoint is responding."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('localhost', port))
        sock.close()
        return result == 0
    except Exception:
        return False


def get_browser_context():
    """
    Try two approaches:
    1. Connect to NoteBurner's embedded browser via CDP (if debug port open)
    2. Fall back to launching a separate Chrome browser
    """
    # Approach 1: Try CDP — NoteBurner with debug port
    if is_cdp_available(CDP_PORT):
        print(f"  -> CDP port {CDP_PORT} is open — connecting to NoteBurner browser...")
        try:
            playwright = sync_playwright().start()
            browser = playwright.chromium.connect_over_cdp(f"http://localhost:{CDP_PORT}")
            contexts = browser.contexts
            if contexts:
                context = contexts[0]
            else:
                context = browser.new_context()
            print("  -> Connected to NoteBurner browser")
            return context
        except Exception as e:
            print(f"  -> CDP connect failed: {e}")

    # Approach 2: Fall back — launch NoteBurner normally, use separate Chrome
    print("  -> Launching NoteBurner...")
    try:
        subprocess.Popen(
            ["open", "-a", "NoteBurner Spotify Music Converter"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except Exception as e:
        raise Exception(f"Failed to launch NoteBurner: {e}")

    time.sleep(5)

    # Now launch our own Chrome for Spotify control
    print("  -> Starting Chrome for Spotify control...")
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()

    # Give user time to log into Spotify
    page = context.new_page()
    page.goto("https://open.spotify.com", wait_until="networkidle", timeout=60000)
    print()
    print("=" * 60)
    print("MANUAL STEP: Log into Spotify in the Chrome window")
    print("Wait 45 seconds...")
    print("=" * 60)
    page.wait_for_timeout(45)

    return context
