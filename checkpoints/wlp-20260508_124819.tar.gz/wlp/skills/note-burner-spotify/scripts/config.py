"""
No Burner Spotify Downloader — Dancer Configuration
====================================================
Fill in dancer names, Spotify playlist URLs, and output folders.
This file should NOT be committed to version control if it contains sensitive data.
"""

# Dancer configurations: name -> {playlist_url, output_folder}
# Leave playlist_url empty string if not yet set.
# output_folder should be an absolute path on the iMac.

DANCERS = {
    "Baby Primary": {
        "playlist_url": "https://open.spotify.com/playlist/7J9XLFYwHGFdeGm1BgqW5T?si=db00d270c5964e3b",
        "output_folder": "/Users/animal/music/SRB Dancers/Baby Primary",
    },
    "Allie Primary": {
        "playlist_url": "https://open.spotify.com/playlist/2zXPJi3RtxFurDUbjjWHWm?si=9edb3ec76f544a6e",
        "output_folder": "/Users/animal/music/SRB Dancers/Allie Primary",
    },
    "Amity Primary": {
        "playlist_url": "https://open.spotify.com/playlist/7BLeoxEQhmO6rFpOJPNzqy?si=6360b4a8aad8409d",
        "output_folder": "/Users/animal/music/SRB Dancers/Amity Primary",
    },
    "Athena Primary": {
        "playlist_url": "https://open.spotify.com/playlist/62Jb3goHY41N26v2VWIlk3?si=63c012da484441b3",
        "output_folder": "/Users/animal/music/SRB Dancers/Athena Primary",
    },
    "Ava Primary": {
        "playlist_url": "https://open.spotify.com/playlist/234hxDAlPriT6rGDp7Fmgq?si=de34b8db8ef74b1c",
        "output_folder": "/Users/animal/music/SRB Dancers/Ava Primary",
    },
    "Brittany Primary": {
        "playlist_url": "https://open.spotify.com/playlist/1YenCfmO4AWRkLF5wKZVGq?si=292e6799a57340f8",
        "output_folder": "/Users/animal/music/SRB Dancers/Brittany Primary",
    },
    "Brooke Primary": {
        "playlist_url": "https://open.spotify.com/playlist/652NW4S1mSWo4bjsdca266?si=5f1bd18a56d64d81",
        "output_folder": "/Users/animal/music/SRB Dancers/Brooke Primary",
    },
    "Dakota Primary": {
        "playlist_url": "https://open.spotify.com/playlist/1VbGnDnXxkPyicj1rJC4Ws?si=275d435076f34dc6",
        "output_folder": "/Users/animal/music/SRB Dancers/Dakota Primary",
    },
    "Genesis Primary": {
        "playlist_url": "https://open.spotify.com/playlist/4fYi2eLPu99U6HOQENGazP?si=3907b7bd6081424f",
        "output_folder": "/Users/animal/music/SRB Dancers/Genesis Primary",
    },
    "Georgia Primary": {
        "playlist_url": "https://open.spotify.com/playlist/49a1sXxwyRPnBi0zxITOGq?si=d82d70c2449d43d8",
        "output_folder": "/Users/animal/music/SRB Dancers/Georgia Primary",
    },
    "Kiki Primary": {
        "playlist_url": "https://open.spotify.com/playlist/2VfJjf22vOaXoar9dZmk58?si=4610cf6373da4138",
        "output_folder": "/Users/animal/music/SRB Dancers/Kiki Primary",
    },
    "Kitty Primary": {
        "playlist_url": "https://open.spotify.com/playlist/7hB2PbkE8acAP6UOuY0gxe?si=e3685b57025548c1",
        "output_folder": "/Users/animal/music/SRB Dancers/Kitty Primary",
    },
    "Kody Primary": {
        "playlist_url": "https://open.spotify.com/playlist/0Veol5itY1F0VYTqsH54tb?si=9707c18746394752",
        "output_folder": "/Users/animal/music/SRB Dancers/Kody Primary",
    },
    "London Primary": {
        "playlist_url": "https://open.spotify.com/playlist/4WwyuGubkQGh32dTV9BEQA?si=85f147c2f846460f",
        "output_folder": "/Users/animal/music/SRB Dancers/London Primary",
    },
    "Lotus Primary": {
        "playlist_url": "https://open.spotify.com/playlist/253Sc6aiElNEmZs0bInM6x?si=a38b8ea8e79f42f6",
        "output_folder": "/Users/animal/music/SRB Dancers/Lotus Primary",
    },
    "Milan Primary": {
        "playlist_url": "https://open.spotify.com/playlist/486ZVfP6oHWANkvbNzsDxo?si=341e913a1bef4d5c",
        "output_folder": "/Users/animal/music/SRB Dancers/Milan Primary",
    },
    "Natasha Primary": {
        "playlist_url": "https://open.spotify.com/playlist/6G2aALAYvGfYujgJJF4Y2X?si=ded58896df4e4a8a",
        "output_folder": "/Users/animal/music/SRB Dancers/Natasha Primary",
    },
    "Quinn Primary": {
        "playlist_url": "https://open.spotify.com/playlist/655Z5Qaff8nnmrQez5sqpI?si=fe82a54215874b7c",
        "output_folder": "/Users/animal/music/SRB Dancers/Quinn Primary",
    },
    "Ruby Primary": {
        "playlist_url": "https://open.spotify.com/playlist/62dNukq50Hev2Nh1I2mHYj?si=169d1c1db0e148ec",
        "output_folder": "/Users/animal/music/SRB Dancers/Ruby Primary",
    },
    "Selene Primary": {
        "playlist_url": "https://open.spotify.com/playlist/1jc9T9ogfltRL7aO8D3H3V?si=519432f9e7e14f73",
        "output_folder": "/Users/animal/music/SRB Dancers/Selene Primary",
    },
    "Shiva Primary": {
        "playlist_url": "https://open.spotify.com/playlist/0a2T3tBpEH5glHFcdPZBeo?si=00b9264fe4724129",
        "output_folder": "/Users/animal/music/SRB Dancers/Shiva Primary",
    },
    "Skylar Primary": {
        "playlist_url": "https://open.spotify.com/playlist/7rCQT73q9fR91K4pX7ELhW?si=3e8e7fbbc1134ef8",
        "output_folder": "/Users/animal/music/SRB Dancers/Skylar Primary",
    },
    "Suki Primary": {
        "playlist_url": "https://open.spotify.com/playlist/0E1iH3lbAAyJdIjuEnnMVP?si=acdedf0b50a54238",
        "output_folder": "/Users/animal/music/SRB Dancers/Suki Primary",
    },
    "Tiana Primary": {
        "playlist_url": "https://open.spotify.com/playlist/0lwV4l5ALgkDoSmxBaqtGq?si=4a2c28ba91b1491b",
        "output_folder": "/Users/animal/music/SRB Dancers/Tiana Primary",
    },
}

# No Burner settings
NO_BURNER_APP_NAME = "No Burner"  # or "No Burner Spotify Downloader"
CONVERSION_WAIT_SECONDS = 120  # seconds to wait for conversion to complete per dancer

# Spotify session
# Option 1: Cookie file (more persistent)
SPOTIFY_COOKIE_FILE = "spotify_cookies.json"

# Option 2: Username/password (less preferred)
SPOTIFY_EMAIL = ""
SPOTIFY_PASSWORD = ""

# If playlist is private/collaborative, you may need to be logged in.
# The script will use the cookie file if it exists, otherwise fall back to credentials.
