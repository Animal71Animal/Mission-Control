#!/usr/bin/env python3
"""
Spotify Playlist Downloader via YT-DLP
=====================================
Downloads all tracks from Spotify playlists using yt-dlp's YouTube Music support
"""

import sys
import time
from pathlib import Path
from urllib.parse import urlparse, parse_qs

try:
    from yt_dlp import YoutubeDL
except ImportError:
    print("ERROR: yt-dlp not installed")
    sys.exit(1)

from config import DANCERS, CONVERSION_WAIT_SECONDS


def extract_playlist_id(url):
    """Extract Spotify playlist ID from URL."""
    # Format: https://open.spotify.com/playlist/PLAYLIST_ID?si=...
    if "playlist/" in url:
        pid = url.split("playlist/")[1].split("?")[0]
        return pid
    return None


def download_spotify_playlist(playlist_url, output_folder):
    """
    Download entire Spotify playlist as MP3s using yt-dlp.
    Uses YouTube Music as audio source.
    """
    playlist_id = extract_playlist_id(playlist_url)
    if not playlist_id:
        raise Exception(f"Invalid Spotify URL: {playlist_url}")
    
    # Format the URL for yt-dlp (works with Spotify playlists)
    spotify_url = f"https://open.spotify.com/playlist/{playlist_id}"
    
    # yt-dlp options for MP3 download
    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'outtmpl': str(Path(output_folder) / '%(title)s - %(uploader)s.%(ext)s'),
        'quiet': False,
        'no_warnings': False,
        'socket_timeout': 30,
        'ignoreerrors': True,  # Skip tracks that fail
    }
    
    print(f"    Downloading from: {spotify_url}")
    
    try:
        with YoutubeDL(ydl_opts) as ydl:
            # Download the entire playlist
            info = ydl.extract_info(spotify_url, download=True)
            
            # Count downloaded files
            if isinstance(info, dict) and 'entries' in info:
                downloaded = len([e for e in info['entries'] if e is not None])
                print(f"    Downloaded {downloaded} tracks")
                return downloaded
            else:
                print(f"    Downloaded tracks")
                return 1
                
    except Exception as e:
        raise Exception(f"Download failed: {e}")


def run_download():
    """Main download workflow."""
    print("=" * 60)
    print("Spotify Playlist Downloader (via yt-dlp)")
    print("=" * 60)
    print(f"Dancers configured: {len(DANCERS)}")
    print()
    
    completed = []
    failed = []
    total_tracks = 0
    
    for dancer_name, config in DANCERS.items():
        playlist_url = config.get("playlist_url", "")
        output_folder = config.get("output_folder", "")
        
        if not playlist_url or not output_folder:
            print(f"SKIP  {dancer_name}: missing config")
            continue
        
        # Create output folder
        Path(output_folder).mkdir(parents=True, exist_ok=True)
        
        print(f"--- {dancer_name} ---")
        
        try:
            tracks = download_spotify_playlist(playlist_url, output_folder)
            total_tracks += tracks
            print(f"  ✓ COMPLETE")
            completed.append(dancer_name)
            
        except Exception as e:
            print(f"  ✗ FAILED: {e}")
            failed.append((dancer_name, str(e)))
        
        print()
        time.sleep(2)  # Brief pause between downloads
    
    # Report
    print("=" * 60)
    print(f"RESULTS: {len(completed)}/{len(DANCERS)} completed")
    print(f"Total tracks downloaded: {total_tracks}")
    for name in completed:
        print(f"  ✓ {name}")
    if failed:
        for name, err in failed:
            print(f"  ✗ {name}: {err}")
    print("=" * 60)
    
    return len(failed) == 0


if __name__ == "__main__":
    success = run_download()
    sys.exit(0 if success else 1)
