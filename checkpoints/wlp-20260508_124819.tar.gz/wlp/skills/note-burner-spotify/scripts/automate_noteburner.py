#!/usr/bin/env python3
"""
NoteBurner Spotify Downloader — CORRECTED PyAutoGUI Automation
==============================================================
Uses actual UI coordinates calibrated from Eric's screen
"""

import sys
import time
import subprocess
from pathlib import Path

try:
    import pyautogui
except ImportError:
    print("ERROR: pyautogui not installed. Run: pip3 install pyautogui")
    sys.exit(1)

from config import DANCERS, CONVERSION_WAIT_SECONDS

# CORRECTED button coordinates (from actual UI walkthrough)
BUTTON_COORDS = {
    'url_bar': (957, 165),              # URL address bar in Spotify
    'spotify_plus': (1671, 741),        # + button (purple circle)
    'add_button': (1315, 466),          # Green "Add" button in modal
    'settings_button': (482, 982),      # Settings gear icon
    'three_dot_button': (1318, 717),    # 3-dot button next to output path
    'settings_close': (1352, 368),      # X button to close Settings
    'convert_button': (1443, 399),      # Convert button
}

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.1


def launch_noteburner():
    """Launch NoteBurner and wait for Spotify to load."""
    print("Launching NoteBurner...")
    subprocess.Popen(['open', '-a', 'NoteBurner Spotify Music Converter'])
    print("  Waiting 20 seconds for NoteBurner + Spotify to load...")
    time.sleep(20)
    print("  ✓ Ready")


def click(x, y, delay=0.5, label=""):
    """Click at coordinates with label."""
    if label:
        print(f"    → Clicking {label} at ({x}, {y})")
    pyautogui.click(x, y)
    time.sleep(delay)


def process_dancer(dancer_name, playlist_url, output_folder):
    """Process one dancer: open playlist, add, set output, convert."""
    print(f"  [1] Clicking URL bar...")
    click(*BUTTON_COORDS['url_bar'], label="URL bar")
    time.sleep(0.3)
    
    print(f"  [2] Typing URL...")
    for char in playlist_url:
        pyautogui.write(char)
        time.sleep(0.01)
    time.sleep(0.3)
    
    print(f"  [3] Pressing Enter...")
    pyautogui.press('enter')
    print(f"    Waiting 8s for playlist to load...")
    time.sleep(8)
    
    print(f"  [4] Clicking + button...")
    click(*BUTTON_COORDS['spotify_plus'], label="+ (Spotify)")
    time.sleep(1)
    
    print(f"  [5] Clicking green 'Add' button...")
    click(*BUTTON_COORDS['add_button'], label="Add")
    print(f"    Waiting for songs to load...")
    time.sleep(2)
    
    print(f"  [6] Clicking Settings...")
    click(*BUTTON_COORDS['settings_button'], label="Settings")
    time.sleep(1)
    
    print(f"  [7] Clicking 3-dot button (opens Finder)...")
    click(*BUTTON_COORDS['three_dot_button'], label="3-dot")
    time.sleep(1)
    
    print(f"  [8] Opening 'Go to Folder' dialog (Cmd+Shift+G)...")
    pyautogui.hotkey('cmd', 'shift', 'g')
    time.sleep(1)
    
    print(f"  [9] Typing output folder path...")
    for char in output_folder:
        pyautogui.write(char)
        time.sleep(0.01)
    time.sleep(0.3)
    
    print(f"  [10] Pressing Enter to select folder...")
    pyautogui.press('enter')
    print(f"    Waiting for Finder to close...")
    time.sleep(2)
    
    print(f"  [11] Closing Settings (X button)...")
    click(*BUTTON_COORDS['settings_close'], label="X")
    time.sleep(1)
    
    print(f"  [12] Clicking Convert...")
    click(*BUTTON_COORDS['convert_button'], label="Convert")
    time.sleep(2)
    
    print(f"  [13] Waiting for conversion (~{CONVERSION_WAIT_SECONDS}s, ~2min per song)...")
    for i in range(0, CONVERSION_WAIT_SECONDS, 30):
        remaining = CONVERSION_WAIT_SECONDS - i
        print(f"    {remaining}s remaining...")
        time.sleep(30)
    
    print(f"  ✓ {dancer_name} complete")


def run_download():
    """Main automation loop."""
    print("=" * 70)
    print("NoteBurner Spotify Downloader — CORRECTED PyAutoGUI Automation")
    print("=" * 70)
    print(f"Dancers configured: {len(DANCERS)}")
    print()
    
    # Launch NoteBurner
    launch_noteburner()
    print()
    
    input("Press Enter to start automation (make sure you're ready)...")
    print()
    
    completed = []
    failed = []
    
    for dancer_name, config in DANCERS.items():
        playlist_url = config.get("playlist_url", "")
        output_folder = config.get("output_folder", "")
        
        if not playlist_url or not output_folder:
            print(f"SKIP  {dancer_name}: missing config")
            continue
        
        Path(output_folder).mkdir(parents=True, exist_ok=True)
        
        print(f"--- {dancer_name} ---")
        
        try:
            process_dancer(dancer_name, playlist_url, output_folder)
            completed.append(dancer_name)
        except Exception as e:
            print(f"  ✗ FAILED: {e}")
            failed.append((dancer_name, str(e)))
        
        print()
    
    # Report
    print("=" * 70)
    print(f"RESULTS: {len(completed)}/{len(DANCERS)} completed")
    for name in completed:
        print(f"  ✓ {name}")
    if failed:
        print()
        for name, err in failed:
            print(f"  ✗ {name}: {err}")
    print("=" * 70)
    
    return len(failed) == 0


if __name__ == "__main__":
    success = run_download()
    sys.exit(0 if success else 1)
