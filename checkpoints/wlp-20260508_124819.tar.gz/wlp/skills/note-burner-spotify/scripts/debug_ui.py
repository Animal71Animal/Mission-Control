#!/usr/bin/env python3
"""
Debug UI Script — Snapshots No Burner/Spotify page structure for selector debugging.
Run this to see current page elements when button selectors aren't working.
"""

import json
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("ERROR: Install playwright first: pip3 install playwright && playwright install chromium")
    exit(1)


def snapshot_page(url="https://open.spotify.com"):
    """Open a URL and print all visible elements and their selectors."""
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=False)
    context = browser.contexts[0]
    page = context.new_page()
    
    print(f"Opening {url}...")
    page.goto(url, wait_until="networkidle")
    input("Log into Spotify, navigate to a playlist, then press Enter here...")
    
    print("\n" + "=" * 60)
    print("PAGE STRUCTURE SNAPSHOT")
    print("=" * 60)
    
    # Get all buttons
    buttons = page.query_selector_all("button")
    print(f"\nButtons found: {len(buttons)}")
    for i, btn in enumerate(buttons):
        try:
            text = btn.inner_text().strip()[:50]
            aria = btn.get_attribute("aria-label") or ""
            data_test = btn.get_attribute("data-testid") or ""
            print(f"  [{i}] text='{text}' | aria='{aria}' | data-testid='{data_test}'")
        except Exception as e:
            print(f"  [{i}] <error: {e}>")
    
    # Get all inputs
    inputs = page.query_selector_all("input")
    print(f"\nInputs found: {len(inputs)}")
    for i, inp in enumerate(inputs):
        try:
            placeholder = inp.get_attribute("placeholder") or ""
            inp_type = inp.get_attribute("type") or "text"
            value = inp.get_attribute("value") or ""
            print(f"  [{i}] type={inp_type} | placeholder='{placeholder}' | value='{value[:30]}'")
        except Exception as e:
            print(f"  [{i}] <error: {e}>")
    
    print("\n" + "=" * 60)
    
    # Save full DOM snapshot
    snapshot_file = Path(__file__).parent.parent / "ui-snapshot.json"
    snapshot_file.write_text(json.dumps({
        "url": page.url,
        "title": page.title(),
        "buttons": [
            {"text": b.inner_text().strip()[:100], "aria": b.get_attribute("aria-label"), "data-testid": b.get_attribute("data-testid")}
            for b in buttons
        ],
    }, indent=2))
    print(f"Full snapshot saved to: {snapshot_file}")
    
    browser.close()


if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else "https://open.spotify.com"
    snapshot_page(url)