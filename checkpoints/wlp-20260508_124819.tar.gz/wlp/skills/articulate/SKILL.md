# Skill: Articulate

**Trigger phrases:** "how do I say this better", "more articulate", "what's the right word", "help me say this", "rephrase this", "how would you say that properly", "smarter way to say"

## Purpose
Help Eric express ideas more clearly, precisely, and confidently — in conversation, business, text, or any context.

## What This Skill Does

When Eric shares a phrase, sentence, or idea he wants to improve:

1. **Identify what he's going for** — what's the core meaning/intent?
2. **Give 2-3 rephrased versions** at different levels (casual-but-sharp, professional, formal)
3. **Explain the key upgrade** — what word or structure made it better and why
4. **Teach the concept** — give it a name if there is one (e.g., "that's called nominalization")

## Format

**Original:** [what Eric said]
**What you meant:** [plain interpretation]

**Option 1 (Sharp/Casual):** ...
**Option 2 (Professional):** ...
**Option 3 (Formal/Technical):** ...

**The upgrade:** [brief explanation of what changed and why it lands better]
**Concept to know:** [optional — name the technique or vocabulary word]

## Examples to Draw From

| Everyday phrase | Sharper version | Why |
|----------------|----------------|-----|
| "I didn't want to mess up the context" | "I didn't want to introduce noise into the context window" | Precise technical term |
| "It's kind of like a loop" | "It's a feedback cycle" | Concise, professional |
| "We should check if that's still true" | "We should validate that assumption" | Active, business-ready |
| "I want to grow the business fast" | "I'm focused on accelerating revenue growth" | Outcome-oriented framing |
| "The thing that makes it work" | "The core mechanism" | Precise |
| "I think people would like it" | "There's clear market demand for this" | Confident, evidence-framed |

## Tone Rules
- Never make Eric feel dumb — frame it as "here's the sharper version"
- Keep at least one casual-but-smart option (he doesn't always need boardroom language)
- Explain *why* the upgrade works — this builds his vocabulary over time
- If he already said it well, tell him that + why it worked
