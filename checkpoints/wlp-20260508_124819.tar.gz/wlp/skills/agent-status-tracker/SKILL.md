# Skill: Agent Status Tracker

**Owner:** Clawdia (Operations)  
**Version:** 2.0 (SQLite)  
**Last Updated:** 2026-04-22  
**Status:** ✅ Production

---

## Overview

Tracks all 8 WLP agents' task status with full audit trail. 
**Source of truth:** SQLite (`mission-control.db`)  
**Backup:** Daily JSON export → GitHub  
**Legacy:** `agent-status.json` kept in sync for older consumers

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   PriScylla / Subagents              │
│              (update-agent-status.py)                │
└──────────────────────┬──────────────────────────────┘
                       │ atomic write
                       ▼
┌─────────────────────────────────────────────────────┐
│         mission-control.db (SQLite)                  │
│  ┌──────────────────┐  ┌────────────────────────┐   │
│  │ agent_status_log │  │ agent_current_state    │   │
│  │ (audit trail)    │  │ (live state, 1 row/    │   │
│  │  every change    │  │  agent, upserted)      │   │
│  └──────────────────┘  └────────────────────────┘   │
└──────┬──────────────────────────┬───────────────────┘
       │ daily backup             │ API reads
       ▼                          ▼
┌──────────────┐     ┌─────────────────────────────┐
│  GitHub      │     │  Mission Control (Vercel)   │
│  backups/    │     │  /api/agent-status          │
│  agent-status│     │  (SQLite → JSON response)   │
└──────────────┘     └─────────────────────────────┘
                               │ fallback
                               ▼
                      ┌──────────────────┐
                      │ agent-status.json│
                      │ (legacy mirror)  │
                      └──────────────────┘
```

---

## Database Schema

**Location:** `/home/ubuntu/wlp/projects/mission-control/mission-control.db`

### Table: `agent_status_log`
Immutable audit trail. One row per status change.

| Column     | Type    | Notes                    |
|------------|---------|--------------------------|
| id         | INTEGER | PK, autoincrement        |
| timestamp  | TEXT    | UTC ISO-8601             |
| agent_name | TEXT    | lowercase (e.g. clawdia) |
| task_name  | TEXT    | Can be NULL              |
| status     | TEXT    | idle/in-progress/blocked/completed |
| blockers   | TEXT    | JSON array string        |
| updated_by | TEXT    | script/subagent/migration |

### Table: `agent_current_state`
Live state. One row per agent, upserted on every update.

| Column             | Type    | Notes                    |
|--------------------|---------|--------------------------|
| agent_name         | TEXT    | PK, lowercase            |
| total_completed    | INTEGER | Cumulative completed tasks |
| total_assigned     | INTEGER | Cumulative assigned tasks  |
| current_task       | TEXT    | NULL when idle           |
| current_status     | TEXT    | idle/in-progress/blocked/completed |
| current_progress   | INTEGER | 0–100                    |
| blockers           | TEXT    | JSON array string        |
| availability_status| TEXT    | available/in-progress/blocked |
| next_deadline      | TEXT    | ISO-8601 or NULL         |
| last_updated       | TEXT    | UTC ISO-8601             |

**Indexes:** `agent_name` on both tables, `timestamp` on log.

---

## Files

| File | Purpose |
|------|---------|
| `/home/ubuntu/wlp/scripts/update-agent-status.py` | Main update script (source of truth writer) |
| `/home/ubuntu/wlp/scripts/init-agent-status-db.py` | Schema init + JSON migration (run once) |
| `/home/ubuntu/wlp/scripts/backup-agent-status.sh` | Daily backup → GitHub |
| `/home/ubuntu/wlp/projects/mission-control/app/api/agent-status/route.ts` | API route (SQLite → JSON) |
| `/home/ubuntu/wlp/data/agent-status.json` | Legacy mirror (kept in sync) |
| `/home/ubuntu/wlp/projects/mission-control/backups/agent-status/` | Daily backup files |

---

## Usage

### Update Agent Status

```bash
python3 /home/ubuntu/wlp/scripts/update-agent-status.py \
  [agent-name] [task-name] [status] [blockers] [updated_by]
```

**Examples:**
```bash
# Mark task in progress
python3 update-agent-status.py clawdia "Deploy v2" in-progress ""

# Mark task blocked
python3 update-agent-status.py barnaby "DOE deal" blocked "Contract review pending"

# Mark task completed
python3 update-agent-status.py coral "Suno Research" completed ""

# Multiple blockers (pipe-separated)
python3 update-agent-status.py shelly "Track release" blocked "No TikTok handle|Suno API down"

# With updated_by attribution
python3 update-agent-status.py langostino "Brand audit" in-progress "" "subagent-langostino"
```

**Valid agents:** langostino, homard, clawdia, shelly, rockwell, barnaby, sebastian, coral  
**Valid statuses:** idle, in-progress, blocked, completed

### Run Backup Manually

```bash
bash /home/ubuntu/wlp/scripts/backup-agent-status.sh
```

### Initialize DB (first-time or new container)

```bash
python3 /home/ubuntu/wlp/scripts/init-agent-status-db.py
```

Safe to re-run — idempotent. Migrates from JSON if tables are empty.

### Query the DB Directly

```python
import sqlite3
conn = sqlite3.connect('/home/ubuntu/wlp/projects/mission-control/mission-control.db')

# Live state
rows = conn.execute('SELECT * FROM agent_current_state ORDER BY agent_name').fetchall()

# Audit trail (last 7 days)
logs = conn.execute("""
    SELECT * FROM agent_status_log
    WHERE timestamp >= datetime('now', '-7 days')
    ORDER BY timestamp DESC
""").fetchall()
conn.close()
```

---

## Cron Configuration

> ⚠️ `crontab` is not available in the Abacus container. Use Abacus cron jobs or trigger manually.

Ideal cron expression (if/when system cron available):
```
0 7 * * * /home/ubuntu/wlp/scripts/backup-agent-status.sh >> /home/ubuntu/wlp/logs/backup-agent-status.log 2>&1
```

**Manual trigger:**
```bash
bash /home/ubuntu/wlp/scripts/backup-agent-status.sh
```

**Abacus cron:** Schedule via OpenClaw heartbeat or session cron to call `backup-agent-status.sh` daily.

---

## Backup Format

Daily backup at `backups/agent-status/agent-status-log-YYYY-MM-DD.json`:

```json
{
  "generated": "2026-04-22T07:00:00Z",
  "current_state": [ /* 8 rows from agent_current_state */ ],
  "audit_log_30d": [ /* all log entries from past 30 days */ ]
}
```

Files older than 30 days are auto-pruned.

---

## API Response Format

`GET /api/agent-status` returns:

```json
{
  "source": "sqlite",
  "agents": {
    "clawdia": {
      "name": "Clawdia",
      "discipline": "Operations",
      "status": "idle",
      "totalTasksCompleted": 2,
      "totalTasksAssigned": 2,
      "currentTask": null,
      "blockers": [],
      "lastUpdated": "2026-04-22T06:00:17Z",
      "availabilityStatus": "available"
    }
  },
  "teamStats": {
    "totalTasksCompleted": 12,
    "totalTasksAssigned": 12,
    "tasksInProgress": 0,
    "blockedTasks": 1,
    "teamAvailability": "medium",
    "lastTeamUpdate": "2026-04-22T06:00:17Z"
  }
}
```

`"source": "json-fallback"` indicates SQLite was unavailable and JSON was used.

---

## Graceful Degradation

The API route has a 2-layer fallback:
1. **SQLite** (primary) — reads `agent_current_state` via `better-sqlite3`
2. **JSON file** (fallback) — reads `agent-status.json` if SQLite unavailable

The Python script also keeps `agent-status.json` in sync after every write.

---

## Atomicity

The update script writes log + state in a single SQLite transaction:

```python
with conn:  # auto-commit or rollback
    conn.execute("INSERT INTO agent_status_log ...")
    conn.execute("INSERT OR REPLACE INTO agent_current_state ...")
```

If either write fails, both are rolled back. No partial states.

---

## Persistence

SQLite is the durable source of truth:
- Survives JSON file corruption
- Audit trail persists across all status changes
- Git history provides offsite backup (daily)
- `init-agent-status-db.py` can re-migrate from JSON if DB is lost

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| "Database not found" | Run `init-agent-status-db.py` |
| "Unknown agent" | Check spelling — must match 8 known agents |
| API returns `json-fallback` | `better-sqlite3` not installed in Vercel env; JSON fallback is working correctly |
| Push fails in backup | Check GitHub token in git remote URL: `git remote -v` |
| JSON out of sync | Run `python3 update-agent-status.py [agent] "sync" idle` to trigger a re-sync |
