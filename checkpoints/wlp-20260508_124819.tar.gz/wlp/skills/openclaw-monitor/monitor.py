#!/usr/bin/env python3
"""
OpenClaw YouTube Monitor
Searches YouTube for new OpenClaw videos, generates AI summaries,
commits results directly to GitHub so Mission Control updates live.
"""

import json
import os
import sys
import base64
import urllib.request
import urllib.parse
import re
from datetime import datetime, timezone

# ── Config ─────────────────────────────────────────────────────────────────
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN") or open(os.path.expanduser("~/.openclaw/github-token"), "r").read().strip() if os.path.exists(os.path.expanduser("~/.openclaw/github-token")) else None
ABACUS_API_KEY = os.environ.get("ABACUSAI_API_KEY", "")
GITHUB_REPO = "Animal71Animal/Mission-Control"
GITHUB_BRANCH = "main"
DATA_FILE = "public/data/openclaw-episodes.json"
GITHUB_API = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{DATA_FILE}"

SEARCH_QUERIES = [
    "openclaw ai assistant",
    "openclaw agent",
    "openclaw telegram bot",
]

PYTHON_BIN = "/opt/computersetup/.pyenv/versions/3.11.6/bin/python3"

# ── GitHub helpers ──────────────────────────────────────────────────────────
def gh_headers():
    h = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json",
    }
    if GITHUB_TOKEN:
        h["Authorization"] = f"Bearer {GITHUB_TOKEN}"
    return h

def fetch_episodes():
    req = urllib.request.Request(f"{GITHUB_API}?ref={GITHUB_BRANCH}", headers=gh_headers())
    try:
        with urllib.request.urlopen(req) as r:
            data = json.loads(r.read())
        content = json.loads(base64.b64decode(data["content"]).decode("utf-8"))
        return content, data["sha"]
    except Exception as e:
        print(f"[fetch] Error or file not found: {e}")
        return {"episodes": [], "last_checked": None}, None

def save_episodes(episodes_data, sha, msg):
    content_b64 = base64.b64encode(json.dumps(episodes_data, indent=2).encode()).decode()
    body = {
        "message": msg,
        "content": content_b64,
        "branch": GITHUB_BRANCH,
    }
    if sha:
        body["sha"] = sha

    data = json.dumps(body).encode()
    req = urllib.request.Request(GITHUB_API, data=data, headers=gh_headers(), method="PUT")
    try:
        with urllib.request.urlopen(req) as r:
            print(f"[github] Saved: {r.status}")
            return True
    except Exception as e:
        print(f"[github] Save error: {e}")
        return False

# ── YouTube search via Playwright ───────────────────────────────────────────
def search_youtube(query):
    """Use Playwright to search YouTube and return video results."""
    script = f"""
import sys
sys.path.insert(0, '/opt/computersetup/.pyenv/versions/3.11.6/lib/python3.11/site-packages')
from playwright.sync_api import sync_playwright
import json, re

results = []
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    q = {json.dumps(query)}
    page.goto(f"https://www.youtube.com/results?search_query={{urllib.parse.quote(q)}}&sp=CAI%253D", timeout=30000)
    page.wait_for_timeout(3000)
    
    # Get video items
    items = page.query_selector_all("ytd-video-renderer")[:10]
    for item in items:
        try:
            title_el = item.query_selector("#video-title")
            title = title_el.inner_text().strip() if title_el else ""
            href = title_el.get_attribute("href") if title_el else ""
            
            meta = item.query_selector("#metadata-line")
            meta_text = meta.inner_text() if meta else ""
            
            desc_el = item.query_selector("#description-text")
            desc = desc_el.inner_text().strip() if desc_el else ""
            
            channel_el = item.query_selector("#channel-name a")
            channel = channel_el.inner_text().strip() if channel_el else ""
            
            if href and "watch?v=" in href:
                vid_id = re.search(r"v=([^&]+)", href)
                if vid_id:
                    results.append({{
                        "id": vid_id.group(1),
                        "title": title,
                        "url": f"https://www.youtube.com{{href}}",
                        "channel": channel,
                        "description": desc,
                        "meta": meta_text,
                    }})
        except: pass
    
    browser.close()

print(json.dumps(results))
"""
    import tempfile, subprocess
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        # Fix the urllib import in the script
        script = "import urllib.parse\n" + script
        f.write(script)
        fname = f.name
    
    try:
        result = subprocess.run(
            [PYTHON_BIN, fname],
            capture_output=True, text=True, timeout=60
        )
        if result.stdout.strip():
            return json.loads(result.stdout.strip())
    except Exception as e:
        print(f"[playwright] Error: {e}")
    finally:
        os.unlink(fname)
    return []

# ── AI Summary generation ────────────────────────────────────────────────────
def generate_summary(video):
    """Call Abacus RouteLLM to generate summary, skills, and take."""
    prompt = f"""You are PriScylla, an AI assistant for Wicked Liquid Productions. 
Analyze this YouTube video about OpenClaw and generate a concise report.

Video: {video['title']}
Channel: {video.get('channel', 'Unknown')}
Description: {video.get('description', 'No description available')}

Generate a JSON response with these exact fields:
{{
  "summary": "2-3 sentence summary of what the video covers",
  "skills_mentioned": ["skill1", "skill2"],  
  "tools_covered": ["tool1", "tool2"],
  "key_takeaways": ["takeaway1", "takeaway2", "takeaway3"],
  "priscylla_take": "1-2 sentence personal take on why this matters for WLP"
}}

Only include skills/tools actually mentioned. Be concise and practical."""

    try:
        body = json.dumps({
            "model": "abacus/claude-haiku-4-5",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 600,
        }).encode()

        req = urllib.request.Request(
            "https://routellm.abacus.ai/v1/v1/chat/completions",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {ABACUS_API_KEY}",
            }
        )
        with urllib.request.urlopen(req, timeout=30) as r:
            resp = json.loads(r.read())
            content = resp["choices"][0]["message"]["content"]
            # Extract JSON from response
            match = re.search(r'\{[\s\S]+\}', content)
            if match:
                return json.loads(match.group())
    except Exception as e:
        print(f"[ai] Error generating summary: {e}")
    
    return {
        "summary": video.get("description", "No summary available")[:200],
        "skills_mentioned": [],
        "tools_covered": [],
        "key_takeaways": [],
        "priscylla_take": "Review this video manually for relevance."
    }

# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M')}] OpenClaw YouTube Monitor starting...")

    # Load existing episodes
    episodes_data, sha = fetch_episodes()
    existing_ids = {ep["id"] for ep in episodes_data.get("episodes", [])}
    print(f"[monitor] Existing episodes: {len(existing_ids)}")

    new_episodes = []

    for query in SEARCH_QUERIES:
        print(f"[search] Query: '{query}'")
        results = search_youtube(query)
        print(f"[search] Found {len(results)} results")

        for video in results:
            vid_id = video["id"]
            if vid_id in existing_ids:
                print(f"[skip] Already tracked: {video['title'][:50]}")
                continue

            # Filter for OpenClaw relevance
            title_lower = video["title"].lower()
            desc_lower = video.get("description", "").lower()
            if not any(kw in title_lower or kw in desc_lower for kw in ["openclaw", "open claw", "claw ai"]):
                print(f"[skip] Not relevant: {video['title'][:50]}")
                continue

            print(f"[new] Processing: {video['title'][:60]}")
            ai_data = generate_summary(video)

            ep_num = len(episodes_data.get("episodes", [])) + len(new_episodes) + 1
            episode = {
                "id": f"oc-{vid_id}",
                "episodeNumber": ep_num,
                "title": video["title"],
                "url": video["url"],
                "channel": video.get("channel", "Unknown"),
                "publishedDate": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
                "discoveredDate": datetime.now(timezone.utc).isoformat(),
                "duration": "Unknown",
                "summary": ai_data.get("summary", ""),
                "keyTakeaways": ai_data.get("key_takeaways", []),
                "skillsMentioned": ai_data.get("skills_mentioned", []),
                "toolsCovered": ai_data.get("tools_covered", []),
                "priscyllaTake": ai_data.get("priscylla_take", ""),
                "expandedTakeaways": [
                    {"title": t[:60], "detail": t}
                    for t in ai_data.get("key_takeaways", [])
                ],
            }
            new_episodes.append(episode)
            existing_ids.add(vid_id)
            print(f"[added] {video['title'][:60]}")

    if new_episodes:
        episodes_data["episodes"] = new_episodes + episodes_data.get("episodes", [])
        episodes_data["last_checked"] = datetime.now(timezone.utc).isoformat()
        episodes_data["total"] = len(episodes_data["episodes"])

        msg = f"feat: add {len(new_episodes)} new OpenClaw video(s) from YouTube monitor"
        if save_episodes(episodes_data, sha, msg):
            print(f"[done] Added {len(new_episodes)} new episode(s) to Mission Control")
        else:
            print("[error] Failed to save to GitHub")
    else:
        # Still update last_checked
        episodes_data["last_checked"] = datetime.now(timezone.utc).isoformat()
        save_episodes(episodes_data, sha, "chore: update OpenClaw monitor last_checked")
        print("[done] No new OpenClaw videos found")

if __name__ == "__main__":
    main()
