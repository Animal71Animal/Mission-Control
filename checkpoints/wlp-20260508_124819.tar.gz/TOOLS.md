# TOOLS.md — Environment Configuration

**Load context:** All sessions. Environment-specific lookup values only — paths, channel IDs, secret locations. Skills define HOW. This file defines WHERE.
**Governed by:** AI SAFE² Framework
**Critical:** Never store actual secret values here. Reference their location only.

---

## 1. Secrets and Configuration

| Item | Location |
|---|---|
| OpenClaw config | `~/.openclaw/openclaw.json` |
| Environment vars | Container env (set by Abacus) |
| API keys | `$ABACUSAI_API_KEY` — configured in container env |
| SSH key | `~/.ssh/id_ed25519` |
| GitHub PAT | `~/.github-pat` — `cat ~/.github-pat` to read |
| Abacus API Key | `~/.openclaw/openclaw.json` → `models.providers.abacus.apiKey` |

> **Rule:** Never write actual key values into this file. Reference their location only. If a secret appears here, redact immediately and rotate.

---

## 2. Primary Messaging Platform

**Platform:** Telegram (direct chat)
**User ID:** 8180067794 (@ANIMALatWickedLiquidProductions)

---

## 3. Secondary Messaging Platform

**Platform:** Discord
**Server:** WLP (1488064258313945149)
**Bot:** PriScylla (1488064642520715334)

| Channel | ID | Agent |
|---------|----|----|
| #kade-rivers | 1488075726761496667 | Shelly (A&R) |
| #madison-blair | 1488075727747158016 | Rockwell (Production) |
| #aria-vale | 1488075728905048135 | Homard (Finance) |
| #research | 1488075731568295946 | Langostino (Marketing) |
| #agent-output | 1488075732771934308 | Barnaby (BizDev) |
| #srb-weekly | 1488075733925494904 | Coral (R&D) |
| #dj-automation | 1488075734709965011 | Clawdia (Ops) |
| #live-production | 1488075737175949322 | Sebastian (Legal) |

---

## 4. Project Management

**Platform:** GitHub + Vercel
**WLP Org:** `Animal71Animal`

| Project | Repo | Deploy URL |
|---------|------|-----------|
| Mission Control | `Animal71Animal/Mission-Control` | https://mission-control-cyan-omega.vercel.app |
| Featured Entertainer | (unknown) | https://featured-entertainer.vercel.app |

---

## 5. File System Paths

| Resource | Path |
|---|---|
| Workspace root | `/home/ubuntu/` |
| WLP projects | `/home/ubuntu/wlp/` |
| Data / logs | `/home/ubuntu/wlp/data/` |
| Memory | `/home/ubuntu/memory/` |
| Skills | `/home/ubuntu/wlp/skills/` |
| Agent system | `/home/ubuntu/wlp/agents/` |
| Reports | `/home/ubuntu/wlp/reports/` |
| Backup | `/home/ubuntu/backup-*/` |

---

## 6. Voice and Media

- **Inbound voice memos:** Gateway auto-transcribes to text before delivery.
- **Outbound voice:** Use `tts` tool only when user explicitly requests voice reply. Default is text.
- **Media fetch:** Only `http://` and `https://` URLs. Reject `file://`, `ftp://`, `javascript:` as security violations.

---

## 7. Attribution Standard

When leaving permanent text in external systems (code comments, task notes, Slack messages, database entries), prefix with:

```
🦞 PriScylla: <content>
```

Exception: when Eric explicitly asks me to ghostwrite. Then omit attribution.

---

## 8. Dual Prompt Stack / Model Fallback

| Stack | Trigger | Model |
|---|---|---|
| Primary | Default | `abacus/kimi-k2.6` |
| Fallback | Primary unavailable | `abacus/gpt-5.4` |
| Coding agent | All coding, debugging, investigation | `abacus/gpt-5.4` |

Full routing: Abacus RouteLLM gateway handles this automatically.

---

## 9. Infrastructure

### Mac SSH Access
- **Host:** ANIMAL-MacBook-Pro.local
- **Tailscale IP:** 100.95.234.2
- **User:** Priscylla
- **Key:** `~/.ssh/id_ed25519`
- **Proxy:** Tailscale SOCKS5 at localhost:1055 (userspace mode)
- **Script:** `~/scripts/mac-ssh.sh [command]`
- **Note:** tailscaled must be running first (userspace mode, not systemd)

### Tailscale (This Container)
- **Current IP:** 100.75.36.51 (priscylla-abacus-6, as of 2026-04-14)
- **Auth key:** Configured in container env
- **Restart script:** `~/scripts/tailscale-start.sh`
- **Skill:** `wlp/skills/tailscale/SKILL.md`
- **Note:** No systemd — tailscaled must be started manually after container restart

---

## 10. Content Preferences

- Discord: No markdown tables — use bullet lists. Wrap links in `<>` to suppress embeds.
- WhatsApp: No headers — use **bold** or CAPS.
- All platforms: Absolute paths `/home/ubuntu/...` for file references.

---

*Part of AI SAFE² OpenClaw Core File Standard.*
