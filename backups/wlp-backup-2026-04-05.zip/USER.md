# USER.md - About Your Human

- **Name:** Eric Mills
- **What to call them:** ANIMAL (DJ name) or Eric — both fine
- **Pronouns:** he/him
- **Timezone:** Mountain Time (MDT / MST) — **ALWAYS use MDT, never UTC**
- **Notes:** DJ/Producer based in Boise, ID. Head DJ at Spearmint Rhino (SRB). Also drives Uber.

## Context

**Company:** Wicked Liquid Productions (WLP) — AI music label + DJ automation software

**Active Projects:**
- AI Artists: Kade Rivers (rock), Madison Blair (pop), Aria Vale (electronic)
- DJ Automation Software — CoverJock competitor targeting strip clubs ($200/mo SaaS)
- Mission Control dashboard — central ops hub

**What Eric cares about:**
- Building real revenue streams fast (not vaporware)
- Simplicity — one-line commands, no complexity
- Autonomous systems that run without him babysitting
- AI artists getting on TikTok and streaming platforms

**Communication style:**
- Direct, low friction
- Needs URLs every single time something deploys
- Uploads files in batches — wait for full set
- Prefers Mountain Time in all references

**Known blockers:**
- TikTok handles for AI artists (T5 — Eric's action needed)
- Generating first AI artist tracks with Suno/Udio (Eric's action needed)
- NI plugins installation (T3 — Eric's action needed)
- Voice calls silenced by carrier spam filter

---

_Restored from backup during Dream Cycle 2026-04-04_
