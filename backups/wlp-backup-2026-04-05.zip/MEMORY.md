# MEMORY.md — Long-Term Memory (PriScylla 🦞)

**Last updated:** 2026-04-05 (Dream Cycle)

---

## Identity

- **Name:** PriScylla 🦞
- **Human:** ANIMAL / Eric Mills — DJ/Producer, Boise ID, Head DJ at Spearmint Rhino + Uber driver
- **Company:** Wicked Liquid Productions (WLP)
- **Eric's timezone:** Mountain Time (MDT) — **ALWAYS use MDT, never UTC**
- **Eric's email:** ericmills71@gmail.com | Phone: +15616662109

---

## Mission Control v2 Architecture

### ✅ Stable

```
Mission Control
├── Vercel (hosting + serverless API)
│   ├── Static data: public/data/*.json (committed to GitHub)
│   └── Personal Tasks: GitHub Contents API (live read/write)
└── Abacus (source of truth)
    ├── SQLite: mission-control.db (108KB) @ /home/ubuntu/wlp/projects/mission-control/
    └── Source: public/data/*.json
```

**GitHub token:** `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` (in `.env.local` + Vercel env)
**Repo:** `Animal71Animal/Mission-Control`
**Deploy:** Always manual — `npx vercel@latest deploy --prod --yes` (Vercel auto-deploy broken)

### URLs
| Resource | URL |
|----------|-----|
| Mission Control | https://mission-control-cyan-omega.vercel.app |
| DJ Automation | https://dj-automation-srb.vercel.app |
| DOE Pitch Deck | https://my-9qag5ejfh-ericmills71-8100s-projects.vercel.app |

Password for all protected resources: `wlp2025`

---

## DJ Automation Software

Working codebase: FastAPI + python-vlc + React + SQLite. At `wlp/projects/dj-automation/`.

- Schedule tab built (SRB preset one-click)
- Mac Quick Start Guide: `QUICKSTART-MAC.md`
- **Status:** Demo-ready. Eric to install + test at home.
- **Revenue target:** 10 clubs × $200/month = $2K MRR

---

## AI Artists Roster

| Artist | Genre | Status |
|--------|-------|--------|
| Kade Rivers | Rock | Production Plan Ready |
| Madison Blair | Pop | Strategy Update Ready |
| Aria Vale | Electronic | Strategy Plan Ready |

- Plans in `wlp/projects/ai-artists/`
- Suno/Udio prompts ready. Blocked on: Eric generating first tracks.
- DistroKid → Spotify takes 5-7 days after tracks generated.

---

## YouTube Monitoring System

| Channel | Script | Runs |
|---------|--------|------|
| Peter Diamandis | `peter-diamandis-monitor.py` | Every 6h |
| Tom Bilyeu | `tom-bilyeu-monitor.py` | Every 6h |

- **Always use Playwright** — YouTube RSS blocked from cloud IPs
- Python: `/opt/computersetup/.pyenv/versions/3.11.6/bin/python3`

---

## Infrastructure

### Tailscale / Mac Node
- priscylla-abacus Tailscale IP: `100.121.174.62`
- Eric-MacBook: paired + connected via launchd service
- Keepalive cron: every 10min (ID: bcd6fd60-ed44-400c-bf0b-33e1efac6d5c)

### Cron Schedule (Mountain Time)
| Job | Time (MDT) | Purpose |
|-----|------------|---------|
| night-creative | 1:30 AM | Autonomous creative work |
| dream-cycle | 3:00 AM | Memory optimization |
| morning-worker | 6:00 AM | Task execution |
| morning-briefing | 10:00 AM | Daily briefing + voice |
| tom-bilyeu-monitor | Every 6h | YouTube monitoring |
| peter-diamandis-monitor | Every 6h | YouTube monitoring |
| tailscale-keepalive | Every 10min | Mac node connection |

### Voice / Vapi
- Calls created (201) but end in `silence-timed-out` — carrier spam blocking suspected
- Vapi number: +13414419784 (labeled "PriScylla" in Eric's contacts)

### Discord — WLP Operations
- Server: WLP Operations (ID: 1488064258313945149)
- Bot: PriScylla (ID: 1488064642520715334)

| Channel | ID | Purpose |
|---------|----|---------|
| #kade-rivers | 1488075726761496667 | AI artist |
| #madison-blair | 1488075727747158016 | AI artist |
| #aria-vale | 1488075728905048135 | AI artist |
| #research | 1488075731568295946 | Research (Flash model) |
| #agent-output | 1488075732771934308 | Autonomous job reports |
| #srb-weekly | 1488075733925494904 | SRB tips data |
| #dj-automation | 1488075734709965011 | DJ automation dev |
| #live-production | 1488075737175949322 | Live PA/Ableton |

### Default Model
- Global default: `abacus/gemini-3-flash-preview` (set 2026-03-31)
- Streaming: enabled

---

## 8-Agent System (Static Disciplines)

| Agent | Discipline | Color |
|-------|------------|-------|
| Langostino | Marketing | #9b5de5 |
| Homard | Finance | #00bbf9 |
| Clawdia | Operations | #fee440 |
| Shelly | A&R/Artists | #00f5d4 |
| Rockwell | Production | #f15bb5 |
| Barnaby | Business Dev | #f15b5b |
| Sebastian | Legal/Admin | #f19b5b |
| Coral | R&D/Innovation | #5bf166 |

---

## Eric's Firm Preferences
- **Always give URL after ANY deployment** — no exceptions
- **Playwright first** for web scraping
- **Mountain Time only** — never UTC in conversation
- Simplest path always wins
- Uploads files in batches — wait for full set before responding
- Autonomous execution > reactive assistance

---

## Key Lessons
- YouTube RSS blocked from cloud — use Playwright
- Flight search automation (browser) failed — use APIs (Kiwi.com, Amadeus)
- Google Drive: service account only sees explicitly shared folders
- Vercel auto-deploy broken — always deploy manually
- `system.run` on Mac node blocked by platform policy (use `system.which` invoke instead)
- Tailscale must be restarted if container restarts: `sudo tailscaled --tun=userspace-networking ...`

---

## Skills Inventory
| Skill | Location | Status |
|-------|----------|--------|
| autonomous-employee | `wlp/skills/autonomous-employee/` | ✅ Active |
| narrative-tracker | `wlp/skills/narrative-tracker/` | ✅ Active |
| obsidian-wlp | `wlp/skills/obsidian-wlp/` | ✅ Active |
| youtube-monitor | `wlp/skills/youtube-monitor/` | ✅ Active |
| morning-briefing | `wlp/skills/morning-briefing/` | ✅ Active |
| capability-evolver | `wlp/skills/capability-evolver/` | ✅ Present |
| humanizer | `wlp/skills/humanizer/` | ✅ Present |
| playwright | `wlp/skills/playwright/` | ✅ Present |
| unified-artist-assets | `wlp/skills/unified-artist-assets/` | ✅ Present |

---

## Workspace State (2026-04-05)
- Workspace recovery complete — IDENTITY.md, USER.md, TOOLS.md populated
- `wlp/` fully present: projects/, skills/, data/, ops/, dream-reports/
- No BOOTSTRAP.md — already cleaned

## Open Opportunities (Night Creative 2026-04-05)
1. **SRB Beta Pilot** — Eric should get informal approval to run DJ Automation at SRB during slow nights. Zero cost, generates case study + testimonial.
2. **Influencer Licensing** — In 90-day plan but completely unoperationalized. Needs `wlp/projects/influencer-licensing/`. B2B royalty-free tracks via Suno/Udio → Pond5/Musicbed.
3. **PRO Registration** — Madison Blair released music without ASCAP/BMI/SoundExchange. Leaking royalties retroactively. ASCAP = $50 one-time. Fix ASAP.

---

_Update when something is worth remembering long-term._
