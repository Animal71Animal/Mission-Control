#!/bin/bash
# GOG (Google OAuth Gateway) Setup Script
# Run this once to authenticate gog with your Google account
# Usage: bash gog-setup.sh

export PATH="$PATH:/home/ubuntu/.local/bin"

echo "=== GOG Setup ==="
echo ""

# Check if gog is installed
if ! command -v gog &>/dev/null; then
    echo "Installing gog..."
    curl -sL https://github.com/steipete/gogcli/releases/download/v0.12.0/gogcli_0.12.0_linux_amd64.tar.gz -o /tmp/gog.tar.gz
    tar xzf /tmp/gog.tar.gz -C /tmp
    cp /tmp/gog /home/ubuntu/.local/bin/gog
    chmod +x /home/ubuntu/.local/bin/gog
    echo "gog installed OK"
fi

# Set credentials
echo "Loading credentials..."
gog auth credentials /home/ubuntu/wlp/archive/2026-03-23/google_client_secret.json
echo "Credentials loaded."
echo ""

# Auth
echo "Starting Google OAuth flow..."
echo "A browser window will open. Sign in with ericmills71@gmail.com"
echo ""
gog auth add ericmills71@gmail.com --services gmail,calendar,drive,contacts,sheets,docs

echo ""
echo "Verifying..."
gog auth list

echo ""
echo "=== Setup Complete ==="
echo "Test commands:"
echo "  gog calendar events primary --from $(date -u +%Y-%m-%dT00:00:00Z) --to $(date -u -d '+7 days' +%Y-%m-%dT00:00:00Z)"
echo "  gog drive search 'type:pdf' --max 5"
echo "  gog gmail search 'newer_than:1d' --max 5"
