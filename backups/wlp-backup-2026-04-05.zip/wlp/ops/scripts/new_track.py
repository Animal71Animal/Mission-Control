#!/usr/bin/env python3
"""
new_track.py — ANIMAL Production Intake
Creates a properly named project folder and logs the track.

Usage:
  python3 new_track.py
  python3 new_track.py --title "Neon Roads" --bpm 128 --key "A Minor" --genre "Synthwave"
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

BASE    = Path(__file__).parent
PROD    = BASE / "01_Production"
LOG     = BASE / "track_log.json"
DATE    = datetime.now().strftime("%Y%m%d")
TODAY   = datetime.now().strftime("%Y-%m-%d")

STAGES  = ["idea", "generating", "assembling", "mixing", "mastered", "registered", "distributed", "archived"]

def slugify(text):
    return re.sub(r"[^\w\s-]", "", text).strip().replace(" ", "_")

def load_log():
    if LOG.exists():
        return json.loads(LOG.read_text())
    return {"tracks": []}

def save_log(data):
    LOG.write_text(json.dumps(data, indent=2))

def create_track(title, bpm, key, genre, notes=""):
    key_slug   = key.replace(" ", "").replace("#", "sharp").replace("b", "flat")
    folder_name = f"ANIMAL - {title} - {bpm}BPM - {key_slug} - v1 - {DATE}"
    track_dir   = PROD / folder_name

    if track_dir.exists():
        print(f"⚠️  Folder already exists: {track_dir}")
        return

    # Create folder structure
    for sub in ["Audio_Files", "Project_Files", "Exports"]:
        (track_dir / sub).mkdir(parents=True)

    # Create proof log
    proof = track_dir / "proof.txt"
    proof.write_text(f"""TRACK: {title}
DATE CREATED: {TODAY}
BPM: {bpm}
KEY: {key}
GENRE: {genre}

--- AI GENERATION LOG ---
(Record your Suno/Udio prompts and seed numbers here)

Prompt 1:
Seed:
Notes:

--- HUMAN EDITS LOG ---
(Document every human decision you make)

Date | Action | Notes
{TODAY} | Track created | Initial setup

--- COPYRIGHT NOTES ---
Human contributions:
- [ ] Curation (which outputs selected + why)
- [ ] Arrangement (structural edits made)
- [ ] Performance (human-recorded elements)
- [ ] Production (mixing/EQ decisions)

PRO Registration: [ ] Pending  [ ] Filed  [ ] Complete
ISRC: 
UPC:
""")

    # Log the track
    data  = load_log()
    entry = {
        "id":         len(data["tracks"]) + 1,
        "title":      title,
        "artist":     "ANIMAL",
        "bpm":        bpm,
        "key":        key,
        "genre":      genre,
        "stage":      "idea",
        "created":    TODAY,
        "folder":     folder_name,
        "notes":      notes,
        "streams":    0,
        "revenue":    0.0,
        "isrc":       "",
        "upc":        "",
        "pro_filed":  False,
        "distributed": False,
        "platforms":  [],
        "sync_pitches": [],
    }
    data["tracks"].append(entry)
    save_log(data)

    print(f"\n✅  Track created: {folder_name}")
    print(f"   📁 {track_dir}")
    print(f"   📝 proof.txt ready to log prompts + human edits")
    print(f"   📊 Logged to track_log.json (ID #{entry['id']})")
    print(f"\n   Next: Open Audio_Files/ and drop in your Suno/Udio exports.")
    return entry

def list_tracks(stage=None):
    data = load_log()
    tracks = data["tracks"]
    if stage:
        tracks = [t for t in tracks if t["stage"] == stage]
    if not tracks:
        print("No tracks found.")
        return
    print(f"\n{'ID':>3}  {'Title':<30} {'BPM':>5} {'Key':<12} {'Genre':<18} {'Stage':<14} {'Created'}")
    print("-" * 105)
    for t in tracks:
        print(f"{t['id']:>3}  {t['title']:<30} {t['bpm']:>5} {t['key']:<12} {t['genre']:<18} {t['stage']:<14} {t['created']}")

def advance_stage(track_id):
    data = load_log()
    for t in data["tracks"]:
        if t["id"] == track_id:
            idx = STAGES.index(t["stage"])
            if idx < len(STAGES) - 1:
                old = t["stage"]
                t["stage"] = STAGES[idx + 1]
                save_log(data)
                print(f"✅  '{t['title']}' advanced: {old} → {t['stage']}")
            else:
                print(f"'{t['title']}' is already at final stage: {t['stage']}")
            return
    print(f"Track ID {track_id} not found.")

def main():
    parser = argparse.ArgumentParser(description="ANIMAL Track Intake System")
    parser.add_argument("--title",   help="Track title")
    parser.add_argument("--bpm",     type=int, help="BPM")
    parser.add_argument("--key",     help="Key (e.g. 'A Minor', 'C Major')")
    parser.add_argument("--genre",   help="Genre")
    parser.add_argument("--notes",   default="", help="Optional notes")
    parser.add_argument("--list",    action="store_true", help="List all tracks")
    parser.add_argument("--stage",   help="Filter list by stage")
    parser.add_argument("--advance", type=int, metavar="ID", help="Advance track to next stage")
    args = parser.parse_args()

    if args.list or args.stage:
        list_tracks(args.stage)
        return

    if args.advance:
        advance_stage(args.advance)
        return

    # Interactive mode
    if not args.title:
        print("\n🎵  ANIMAL — New Track Intake\n")
        title = input("Track title: ").strip()
        bpm   = int(input("BPM: ").strip() or "120")
        key   = input("Key (e.g. A Minor, C Major): ").strip() or "Unknown"
        genre = input("Genre: ").strip() or "Unknown"
        notes = input("Notes (optional): ").strip()
    else:
        title = args.title
        bpm   = args.bpm or 120
        key   = args.key or "Unknown"
        genre = args.genre or "Unknown"
        notes = args.notes

    create_track(title, bpm, key, genre, notes)

if __name__ == "__main__":
    main()
