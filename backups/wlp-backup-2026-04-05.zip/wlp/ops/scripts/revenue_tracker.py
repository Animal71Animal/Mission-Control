#!/usr/bin/env python3
"""
revenue_tracker.py — ANIMAL Revenue & Royalty Tracker
Tracks streaming, sync licensing, royalties, and per-track performance.

Usage:
  python3 revenue_tracker.py                    # Dashboard
  python3 revenue_tracker.py --add-income       # Log revenue
  python3 revenue_tracker.py --add-sync         # Log sync pitch
  python3 revenue_tracker.py --report           # Monthly report
  python3 revenue_tracker.py --track-stats ID   # Per-track breakdown
"""

import argparse
import json
from datetime import datetime, date
from pathlib import Path

BASE     = Path(__file__).parent
LOG      = BASE / "track_log.json"
REV_FILE = BASE / "revenue_log.json"
TODAY    = date.today().isoformat()

INCOME_TYPES = [
    "streaming",       # Spotify, Apple Music, YouTube Music
    "sync",            # TV, film, ads, games
    "licensing",       # Direct license deals
    "royalty_pro",     # ASCAP / BMI / SESAC royalties
    "royalty_master",  # Master recording royalties
    "direct_sale",     # Bandcamp, direct downloads
    "other",
]

PLATFORMS = [
    "Spotify", "Apple Music", "YouTube Music", "Amazon Music",
    "Tidal", "Deezer", "Pandora", "DistroKid", "Bandcamp",
    "ASCAP", "BMI", "SESAC", "Sync Deal", "Other"
]

# ── File helpers ─────────────────────────────────────────────────────────────

def load_revenue():
    if REV_FILE.exists():
        return json.loads(REV_FILE.read_text())
    return {"entries": [], "sync_pitches": [], "goals": {"monthly_target": 500.0, "yearly_target": 6000.0}}

def save_revenue(data):
    REV_FILE.write_text(json.dumps(data, indent=2))

def load_tracks():
    if LOG.exists():
        return json.loads(LOG.read_text()).get("tracks", [])
    return []

# ── Revenue entry ─────────────────────────────────────────────────────────────

def add_income(interactive=True, **kwargs):
    data = load_revenue()
    tracks = load_tracks()

    if interactive:
        print("\n💰  ANIMAL — Log Revenue\n")
        print("Income type:")
        for i, t in enumerate(INCOME_TYPES, 1):
            print(f"  {i}. {t}")
        type_idx = int(input("\nSelect type (number): ").strip()) - 1
        income_type = INCOME_TYPES[type_idx]

        print("\nPlatform:")
        for i, p in enumerate(PLATFORMS, 1):
            print(f"  {i}. {p}")
        plat_idx = int(input("Select platform (number): ").strip()) - 1
        platform = PLATFORMS[plat_idx]

        amount  = float(input("Amount ($): ").strip())
        period  = input("Period (e.g. 'March 2026', leave blank for today): ").strip() or TODAY

        if tracks:
            print("\nLink to a track? (Enter ID or 0 to skip)")
            for t in tracks:
                print(f"  {t['id']}. {t['title']}")
            track_id = int(input("Track ID: ").strip() or "0")
        else:
            track_id = 0

        notes = input("Notes (optional): ").strip()
    else:
        income_type = kwargs.get("income_type", "other")
        platform    = kwargs.get("platform", "Other")
        amount      = float(kwargs.get("amount", 0))
        period      = kwargs.get("period", TODAY)
        track_id    = kwargs.get("track_id", 0)
        notes       = kwargs.get("notes", "")

    entry = {
        "id":          len(data["entries"]) + 1,
        "date":        TODAY,
        "period":      period,
        "type":        income_type,
        "platform":    platform,
        "amount":      amount,
        "track_id":    track_id,
        "notes":       notes,
    }
    data["entries"].append(entry)

    # Update track revenue in track_log
    if track_id:
        tdata = json.loads(LOG.read_text()) if LOG.exists() else {"tracks": []}
        for t in tdata["tracks"]:
            if t["id"] == track_id:
                t["revenue"] = round(t.get("revenue", 0) + amount, 2)
                t["streams"] = t.get("streams", 0)
        LOG.write_text(json.dumps(tdata, indent=2))

    save_revenue(data)
    print(f"\n✅  Logged: ${amount:.2f} from {platform} ({income_type})")
    return entry

# ── Sync pitch tracker ────────────────────────────────────────────────────────

def add_sync_pitch():
    data   = load_revenue()
    tracks = load_tracks()

    print("\n🎬  ANIMAL — Log Sync Pitch\n")
    target  = input("Pitched to (company/show/ad/game): ").strip()
    use_case = input("Use case (TV show, ad, trailer, game, etc.): ").strip()
    amount  = float(input("Deal value ($ if known, 0 if pending): ").strip() or "0")

    status_opts = ["pitched", "in_review", "accepted", "rejected", "deal_closed"]
    print("Status:", " | ".join(f"{i+1}.{s}" for i,s in enumerate(status_opts)))
    status = status_opts[int(input("Select: ").strip() or "1") - 1]

    if tracks:
        print("\nTrack pitched:")
        for t in tracks:
            print(f"  {t['id']}. {t['title']}")
        track_id = int(input("Track ID: ").strip() or "0")
    else:
        track_id = 0

    notes = input("Notes: ").strip()

    pitch = {
        "id":        len(data["sync_pitches"]) + 1,
        "date":      TODAY,
        "target":    target,
        "use_case":  use_case,
        "amount":    amount,
        "status":    status,
        "track_id":  track_id,
        "notes":     notes,
        "updated":   TODAY,
    }
    data["sync_pitches"].append(pitch)
    save_revenue(data)
    print(f"\n✅  Sync pitch logged: {target} — {status}")

# ── Dashboard ─────────────────────────────────────────────────────────────────

def dashboard():
    data   = load_revenue()
    tracks = load_tracks()
    entries = data.get("entries", [])
    pitches = data.get("sync_pitches", [])
    goals   = data.get("goals", {})

    total = sum(e["amount"] for e in entries)
    month = datetime.now().strftime("%Y-%m")
    mtd   = sum(e["amount"] for e in entries if e["date"].startswith(month))

    # By type
    by_type = {}
    for e in entries:
        by_type[e["type"]] = by_type.get(e["type"], 0) + e["amount"]

    # By platform
    by_plat = {}
    for e in entries:
        by_plat[e["platform"]] = by_plat.get(e["platform"], 0) + e["amount"]

    # Top tracks
    track_rev = {}
    for e in entries:
        if e["track_id"]:
            track_rev[e["track_id"]] = track_rev.get(e["track_id"], 0) + e["amount"]

    monthly_goal = goals.get("monthly_target", 500)
    yearly_goal  = goals.get("yearly_target", 6000)

    print("\n" + "="*60)
    print("  💰  ANIMAL — REVENUE DASHBOARD")
    print("="*60)
    print(f"\n  Total Earned (All Time):  ${total:>10,.2f}")
    print(f"  This Month:               ${mtd:>10,.2f}  /  ${monthly_goal:,.0f} goal  ({mtd/monthly_goal*100:.0f}%)")
    print(f"  Yearly Goal Progress:     ${total:>10,.2f}  /  ${yearly_goal:,.0f}  ({total/yearly_goal*100:.0f}%)")

    if by_type:
        print("\n  ── BY SOURCE ──────────────────────────────────")
        for k, v in sorted(by_type.items(), key=lambda x: -x[1]):
            print(f"  {k:<20} ${v:>10,.2f}")

    if by_plat:
        print("\n  ── BY PLATFORM ────────────────────────────────")
        for k, v in sorted(by_plat.items(), key=lambda x: -x[1]):
            print(f"  {k:<20} ${v:>10,.2f}")

    if track_rev:
        print("\n  ── TOP TRACKS ─────────────────────────────────")
        track_map = {t["id"]: t["title"] for t in tracks}
        for tid, rev in sorted(track_rev.items(), key=lambda x: -x[1])[:5]:
            print(f"  #{tid} {track_map.get(tid,'Unknown'):<25} ${rev:,.2f}")

    if pitches:
        print("\n  ── SYNC PITCHES ───────────────────────────────")
        open_p   = [p for p in pitches if p["status"] in ("pitched","in_review")]
        closed_p = [p for p in pitches if p["status"] == "deal_closed"]
        print(f"  Total Pitches: {len(pitches)}  |  Open: {len(open_p)}  |  Deals Closed: {len(closed_p)}")
        sync_rev = sum(p["amount"] for p in closed_p)
        print(f"  Sync Revenue:  ${sync_rev:,.2f}")
        if open_p:
            print(f"\n  Open Pitches:")
            for p in open_p[:5]:
                print(f"    → {p['target']} ({p['use_case']}) — {p['status']}")

    print("\n  ── CATALOG ────────────────────────────────────")
    stage_counts = {}
    for t in tracks:
        s = t.get("stage","unknown")
        stage_counts[s] = stage_counts.get(s,0)+1
    for s,c in stage_counts.items():
        print(f"  {s:<20} {c} tracks")
    print(f"  {'TOTAL':<20} {len(tracks)} tracks")
    print("\n" + "="*60)

# ── Monthly report ────────────────────────────────────────────────────────────

def monthly_report():
    data    = load_revenue()
    entries = data.get("entries", [])
    month   = datetime.now().strftime("%Y-%m")
    m_label = datetime.now().strftime("%B %Y")

    m_entries = [e for e in entries if e["date"].startswith(month)]
    total = sum(e["amount"] for e in m_entries)

    print(f"\n📊  Revenue Report — {m_label}")
    print("-" * 50)
    if not m_entries:
        print("No revenue logged this month yet.")
        return

    print(f"{'Date':<12} {'Platform':<18} {'Type':<18} {'Amount':>10}")
    print("-" * 60)
    for e in m_entries:
        print(f"{e['date']:<12} {e['platform']:<18} {e['type']:<18} ${e['amount']:>9,.2f}")
    print("-" * 60)
    print(f"{'TOTAL':<48} ${total:>9,.2f}")

# ── Per-track stats ───────────────────────────────────────────────────────────

def track_stats(track_id):
    data   = load_revenue()
    tracks = load_tracks()
    track  = next((t for t in tracks if t["id"] == track_id), None)
    if not track:
        print(f"Track ID {track_id} not found.")
        return

    entries = [e for e in data["entries"] if e["track_id"] == track_id]
    total   = sum(e["amount"] for e in entries)

    print(f"\n🎵  Track: {track['title']}")
    print(f"   BPM: {track['bpm']} | Key: {track['key']} | Genre: {track['genre']}")
    print(f"   Stage: {track['stage']} | Created: {track['created']}")
    print(f"   Total Revenue: ${total:,.2f}")
    if entries:
        print(f"\n   Revenue Log:")
        for e in entries:
            print(f"     {e['date']} | {e['platform']:<15} | {e['type']:<15} | ${e['amount']:.2f}")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="ANIMAL Revenue Tracker")
    parser.add_argument("--add-income",  action="store_true")
    parser.add_argument("--add-sync",    action="store_true")
    parser.add_argument("--report",      action="store_true")
    parser.add_argument("--track-stats", type=int, metavar="ID")
    parser.add_argument("--set-goal",    type=float, metavar="MONTHLY")
    args = parser.parse_args()

    if args.add_income:
        add_income()
    elif args.add_sync:
        add_sync_pitch()
    elif args.report:
        monthly_report()
    elif args.track_stats:
        track_stats(args.track_stats)
    elif args.set_goal:
        data = load_revenue()
        data["goals"]["monthly_target"] = args.set_goal
        data["goals"]["yearly_target"]  = args.set_goal * 12
        save_revenue(data)
        print(f"✅  Monthly goal set to ${args.set_goal:,.0f} (${args.set_goal*12:,.0f}/yr)")
    else:
        dashboard()

if __name__ == "__main__":
    main()
