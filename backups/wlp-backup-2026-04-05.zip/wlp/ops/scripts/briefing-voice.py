#!/opt/computersetup/.pyenv/versions/3.11.6/bin/python3
import os
import json
import requests
import datetime

# Configuration
VAPI_API_KEY = "f0ec8e4d-960e-442e-a272-cbf085fb034b"
ASSISTANT_ID = "6405f588-149e-44a5-b49f-52457a21c7fa"
PHONE_NUMBER_ID = "9b73e616-70dd-4524-becf-f615d67d4b2e"
DEST_PHONE = "+15616662109"

import subprocess as _sp
_mdt_date = _sp.check_output(["date", "+%Y-%m-%d"], env={**os.environ, "TZ": "America/Denver"}).decode().strip()
BRIEFING_FILE = f"/home/ubuntu/wlp/ops/briefings/briefing-{_mdt_date}.json"

def trigger_call():
    if not os.path.exists(BRIEFING_FILE):
        print(f"Error: Briefing file {BRIEFING_FILE} not found.")
        return

    with open(BRIEFING_FILE, 'r') as f:
        data = json.load(f)

    # Extract data
    temp = data.get('weather', {}).get('current', {}).get('temperature_2m', 'unknown')
    tasks = data.get('tasks', {}).get('open', 0)
    flights = data.get('flights', {}).get('top_prices', [])
    
    # Conversion to Fahrenheit
    temp_f = round((temp * 9/5) + 32) if isinstance(temp, (int, float)) else temp
    
    # Flight string
    flight_msg = ""
    if flights:
        prices = ", ".join([f"${p}" for p in flights[:3]])
        flight_msg = f" The three cheapest flights for your Raleigh trip are currently {prices}."

    speech = f"Good morning Eric. It's time for your Wicked Liquid briefing. The weather in Boise is currently {temp_f} degrees and clear. You have {tasks} open tasks in your queue.{flight_msg} Would you like to hear more details?"

    url = "https://api.vapi.ai/call/phone"
    headers = {
        "Authorization": f"Bearer {VAPI_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "assistantId": ASSISTANT_ID,
        "phoneNumberId": PHONE_NUMBER_ID,
        "customer": {
            "number": DEST_PHONE
        },
        "assistantOverrides": {
            "firstMessage": speech
        }
    }

    response = requests.post(url, json=payload, headers=headers)
    print(f"Vapi response: {response.status_code}")

if __name__ == "__main__":
    trigger_call()
