#!/bin/bash
# Morning Briefing Wrapper - runs both data generation and voice call

export TZ=America/Denver

# Generate briefing data
bash /home/ubuntu/wlp/ops/scripts/morning-briefing.sh

# Trigger voice call (use full pyenv Python path)
/opt/computersetup/.pyenv/versions/3.11.6/bin/python3 /home/ubuntu/wlp/ops/scripts/briefing-voice.py

# Rebuild and deploy Mission Control
cd /home/ubuntu/wlp/projects/mission-control
npm run build 2>&1 | tail -5
npx vercel@latest deploy --prod --yes 2>&1 | tail -5
