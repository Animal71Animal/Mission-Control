#!/bin/bash
# Start tailscaled in userspace mode and bring up the interface
# Used by supervisord for auto-restart on container restart

mkdir -p /var/lib/tailscale /run/tailscale

exec sudo tailscaled \
  --tun=userspace-networking \
  --state=/var/lib/tailscale/tailscaled.state \
  --socket=/run/tailscale/tailscaled.sock
