#!/usr/bin/env python3
"""
dashboard.py — ANIMAL Master Dashboard
One command to see everything: tracks, revenue, 90-day plan, sync pitches.

Usage:
  python3 dashboard.py
"""
import subprocess, sys
from pathlib import Path

BASE = Path(__file__).parent

def run(script, *args):
    subprocess.run([sys.executable, BASE / script, *args])

print("\n" + "🦞 "*20)
print("  ANIMAL — PRODUCTION COMMAND CENTER")
print("🦞 "*20)

run("90_day_plan.py")
run("revenue_tracker.py")
run("new_track.py", "--list")
