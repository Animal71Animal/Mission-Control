#!/bin/bash
# Run morning briefing manually or via external scheduler
# Usage: ./morning-briefing.sh

export TZ=America/Denver

BRIEFING_DIR="/home/ubuntu/wlp/ops/briefings"
mkdir -p "$BRIEFING_DIR"

DATE=$(date +%Y-%m-%d)
TIME=$(date +%H:%M)
TIMESTAMP=$(date -u +%Y-%m-%dT%H:%M:%SZ)

# Get weather for Boise
WEATHER=$(curl -s "https://api.open-meteo.com/v1/forecast?latitude=43.6166&longitude=-116.2008&current=temperature_2m,relative_humidity_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=America/Denver" 2>/dev/null || echo '{}')

# Get open task count
TASKS_FILE="/home/ubuntu/wlp/ops/tasks.json"
OPEN_TASKS=$(cat "$TASKS_FILE" 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('open', [])))" 2>/dev/null || echo "0")

# Get top 3 flight prices
FLIGHTS_JSON=$(/usr/bin/python3 /home/ubuntu/wlp/ops/scripts/flight_check.py 2>/dev/null || echo '{"top_prices": []}')
FLIGHTS=$(echo "$FLIGHTS_JSON" | python3 -c "import sys,json; d=json.load(sys.stdin); print(','.join(str(p) for p in d.get('top_prices', [])))")

# Build briefing
cat > "$BRIEFING_DIR/briefing-${DATE}.json" << EOF
{
  "date": "$DATE",
  "time": "$TIME",
  "timestamp": "$TIMESTAMP",
  "timezone": "America/Denver",
  "weather": $WEATHER,
  "tasks": {
    "open": $OPEN_TASKS
  },
  "flights": {
    "top_prices": [$FLIGHTS]
  },
  "generated_by": "morning-briefing"
}
EOF

echo "✓ Briefing generated: $BRIEFING_DIR/briefing-${DATE}.json"
echo "  Open tasks: $OPEN_TASKS"
