#!/bin/bash
# GOG Auth Completion Script
export PATH="$PATH:/home/ubuntu/.local/bin"
export GOG_KEYRING_PASSWORD="wlp2025"

echo "Completing Google OAuth..."

# Use the auth code from the redirect URL
gog auth add ericmills71@gmail.com \
  --services calendar,drive,gmail,sheets \
  --manual \
  --auth-url "http://127.0.0.1:33587/oauth2/callback?state=zJ9FIPkI0pLH8mmWVdcb5RxDNa9a1wkloNSzrxCwi2o&iss=https://accounts.google.com&code=4/0Aci98E92-cWKazEucLw8Wms2FpvrDDdnBH-2cRFVgx07XQK_W-hvmJdeO5F1nSFHquxq0g&scope=email%20https://www.googleapis.com/auth/spreadsheets%20https://www.googleapis.com/auth/gmail.settings.sharing%20https://www.googleapis.com/auth/gmail.settings.basic%20https://www.googleapis.com/auth/drive%20https://www.googleapis.com/auth/directory.readonly%20https://www.googleapis.com/auth/contacts.other.readonly%20https://www.googleapis.com/auth/contacts%20https://www.googleapis.com/auth/calendar%20https://www.googleapis.com/auth/gmail.modify%20https://www.googleapis.com/auth/userinfo.email%20openid&authuser=0&prompt=consent"

echo ""
echo "Verifying auth..."
gog auth list
