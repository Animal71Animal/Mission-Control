#!/usr/bin/env python3
"""
Flight price checker: BOI → RDU
Depart: Apr 7, 2026 | Return: Apr 12, 2026
Uses SerpApi Google Flights
"""

import os
import sys
import json
import urllib.request
import urllib.parse
from datetime import datetime
from pathlib import Path

# Load .env
env_file = Path.home() / ".env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "")
ORIGIN = "BOI"
DESTINATION = "RDU"
DEPART_DATE = "2026-04-07"
RETURN_DATE = "2026-04-12"

def search_flights():
    params = urllib.parse.urlencode({
        "engine": "google_flights",
        "departure_id": ORIGIN,
        "arrival_id": DESTINATION,
        "outbound_date": DEPART_DATE,
        "return_date": RETURN_DATE,
        "currency": "USD",
        "hl": "en",
        "type": "1",  # round trip
        "api_key": SERPAPI_KEY,
    })
    url = f"https://serpapi.com/search?{params}"
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())

def fmt(flight):
    dep = flight.get("departure_airport", {})
    arr = flight.get("arrival_airport", {})
    return f"{dep.get('time','?')} → {arr.get('time','?')}"

def main():
    if not SERPAPI_KEY:
        print("❌ SERPAPI_KEY not set")
        sys.exit(1)

    data = search_flights()

    # Best flights (cheapest highlighted options)
    best = data.get("best_flights", [])
    other = data.get("other_flights", [])
    all_flights = best + other

    if not all_flights:
        # Return empty prices if no flights found
        print(json.dumps({"top_prices": []}))
        sys.exit(0)

    # Sort by price
    all_flights.sort(key=lambda x: x.get("price", 9999))

    # Extract top 3 prices for briefing
    top_prices = [f.get("price") for f in all_flights[:3] if f.get("price")]
    
    # Output JSON for briefing script
    print(json.dumps({"top_prices": top_prices}))

if __name__ == "__main__":
    main()
