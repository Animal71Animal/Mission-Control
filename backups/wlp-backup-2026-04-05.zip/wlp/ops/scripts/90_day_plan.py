#!/usr/bin/env python3
"""
90_day_plan.py — ANIMAL 90-Day Catalog Build Plan
Start: April 12, 2026  |  End: July 10, 2026
Target: 40+ professional tracks released. Revenue flowing. System running.

Usage:
  python3 90_day_plan.py              # Today's dashboard + tasks
  python3 90_day_plan.py --week 1     # Show specific week
  python3 90_day_plan.py --check TASK # Mark a task complete
  python3 90_day_plan.py --all        # Full 90-day overview
"""

import argparse
import json
from datetime import date, datetime, timedelta
from pathlib import Path

BASE       = Path(__file__).parent
STATE_FILE = BASE / "90day_state.json"
START      = date(2026, 4, 12)
END        = date(2026, 7, 10)
TOTAL_DAYS = (END - START).days + 1

# ── Phase definitions ─────────────────────────────────────────────────────────

PHASES = [
    {
        "phase":    1,
        "name":     "Foundation",
        "weeks":    "1–2",
        "dates":    "Apr 12 – Apr 25",
        "goal":     "Infrastructure locked. First 10 tracks generated. Workflow dialed in.",
        "target_tracks": 10,
        "weeks_range": (1, 2),
        "tasks": [
            {"id": "P1-01", "task": "Set up dedicated music email (e.g. ANIMALmusic@gmail.com)"},
            {"id": "P1-02", "task": "Subscribe to Suno Pro or Premier ($10–30/mo)"},
            {"id": "P1-03", "task": "Subscribe to Lalal.ai for stem separation"},
            {"id": "P1-04", "task": "Set up DistroKid account (choose Musician Plus)"},
            {"id": "P1-05", "task": "Apply to ASCAP or BMI (takes 2–4 weeks to process)"},
            {"id": "P1-06", "task": "Generate first 30 tracks in Suno — keep best 10"},
            {"id": "P1-07", "task": "Download stems for top 10 via Lalal.ai"},
            {"id": "P1-08", "task": "Assemble first 3 tracks in GarageBand/Logic"},
            {"id": "P1-09", "task": "Log all 10 tracks using new_track.py"},
            {"id": "P1-10", "task": "Create artwork for first 3 tracks (Midjourney or Canva)"},
            {"id": "P1-11", "task": "Build your Prompt Library — 20 core prompts by genre"},
            {"id": "P1-12", "task": "Complete file naming system for all existing projects"},
        ]
    },
    {
        "phase":    2,
        "name":     "Production",
        "weeks":    "3–4",
        "dates":    "Apr 26 – May 9",
        "goal":     "25 tracks generated. First 5 ready for release. PRO registered.",
        "target_tracks": 25,
        "weeks_range": (3, 4),
        "tasks": [
            {"id": "P2-01", "task": "Generate 50 more tracks — keep best 15 (cumulative: 25)"},
            {"id": "P2-02", "task": "Assemble and mix 5 release-ready tracks"},
            {"id": "P2-03", "task": "Register first batch with ASCAP/BMI (once approved)"},
            {"id": "P2-04", "task": "Add copyright metadata to all exported WAVs"},
            {"id": "P2-05", "task": "Export final WAVs to 02_Masters/ with proper naming"},
            {"id": "P2-06", "task": "Create artwork for 5 release-ready tracks"},
            {"id": "P2-07", "task": "Upload first 2 tracks to DistroKid — schedule for Week 5"},
            {"id": "P2-08", "task": "Open ChatGPT Plus — write release descriptions + keywords"},
            {"id": "P2-09", "task": "Document human contributions in proof.txt for each track"},
            {"id": "P2-10", "task": "Identify top 3 sync licensing libraries to pitch to"},
        ]
    },
    {
        "phase":    3,
        "name":     "First Release",
        "weeks":    "5–6",
        "dates":    "May 10 – May 23",
        "goal":     "First tracks LIVE. Revenue clock starts. 35 tracks in pipeline.",
        "target_tracks": 35,
        "weeks_range": (5, 6),
        "tasks": [
            {"id": "P3-01", "task": "Release Track 1 & 2 — post across all socials"},
            {"id": "P3-02", "task": "Release Track 3 & 4 — 3 days apart for algorithm benefit"},
            {"id": "P3-03", "task": "Pitch 3 tracks to sync licensing libraries (Musicbed, Artlist, etc)"},
            {"id": "P3-04", "task": "Generate 30 more tracks — keep best 10 (cumulative: 35)"},
            {"id": "P3-05", "task": "Analyze first streaming data — which genre is winning?"},
            {"id": "P3-06", "task": "Double down: generate 20 more in your winning genre"},
            {"id": "P3-07", "task": "Log first revenue entries in revenue_tracker.py"},
            {"id": "P3-08", "task": "Set up YouTube Music channel for AI instrumentals"},
            {"id": "P3-09", "task": "Create Bandcamp page for direct sales / licensing"},
            {"id": "P3-10", "task": "Submit 3 tracks to Spotify playlist curators (via SubmitHub)"},
        ]
    },
    {
        "phase":    4,
        "name":     "Scale",
        "weeks":    "7–8",
        "dates":    "May 24 – Jun 6",
        "goal":     "Release cadence locked (2/week). 40+ tracks in catalog. Sync pipeline active.",
        "target_tracks": 40,
        "weeks_range": (7, 8),
        "tasks": [
            {"id": "P4-01", "task": "Release 2 tracks per week — maintain consistent cadence"},
            {"id": "P4-02", "task": "Generate your remaining tracks to hit 40+ in log"},
            {"id": "P4-03", "task": "Follow up on sync pitches from Phase 3"},
            {"id": "P4-04", "task": "Submit to 5 more sync libraries"},
            {"id": "P4-05", "task": "Set up monthly revenue report (revenue_tracker.py --report)"},
            {"id": "P4-06", "task": "Build a 'genre bundle' — 5-pack for licensing (Rock, EDM, etc)"},
            {"id": "P4-07", "task": "Register all released tracks with ASCAP/BMI"},
            {"id": "P4-08", "task": "Reach out to 3 content creators / YouTubers for sync use"},
            {"id": "P4-09", "task": "Explore Pond5, AudioJungle, Epidemic Sound for uploads"},
            {"id": "P4-10", "task": "Review and update MEMORY.md / track_log.json — what's working?"},
        ]
    },
    {
        "phase":    5,
        "name":     "Optimize",
        "weeks":    "9–10",
        "dates":    "Jun 7 – Jun 20",
        "goal":     "Revenue data clear. Double down on winners. Passive income building.",
        "target_tracks": 45,
        "weeks_range": (9, 10),
        "tasks": [
            {"id": "P5-01", "task": "Pull streaming report — identify top 5 earners"},
            {"id": "P5-02", "task": "Generate 20 more tracks in top-performing genres"},
            {"id": "P5-03", "task": "Pitch top earners to TV/film music supervisors directly"},
            {"id": "P5-04", "task": "Set pricing for direct licensing page (Bandcamp/website)"},
            {"id": "P5-05", "task": "Collect first PRO royalties (ASCAP/BMI payout timeline)"},
            {"id": "P5-06", "task": "Explore NFT or exclusive licensing for standout tracks"},
            {"id": "P5-07", "task": "Build 'themed EP' — 5 cohesive tracks for EP release"},
            {"id": "P5-08", "task": "Schedule social content 2 weeks ahead using posts scheduler"},
            {"id": "P5-09", "task": "Review sync pitches — close any pending deals"},
            {"id": "P5-10", "task": "Update 90_day_state.json — log key learnings and wins"},
        ]
    },
    {
        "phase":    6,
        "name":     "Harvest",
        "weeks":    "11–13",
        "dates":    "Jun 21 – Jul 10",
        "goal":     "50+ tracks live. Recurring revenue. Rinse-and-repeat system documented.",
        "target_tracks": 50,
        "weeks_range": (11, 13),
        "tasks": [
            {"id": "P6-01", "task": "Release EP — 5-track bundle with unified branding"},
            {"id": "P6-02", "task": "Run 90-day full revenue report — total earned, per track"},
            {"id": "P6-03", "task": "Document your winning prompt formulas in Prompt Library"},
            {"id": "P6-04", "task": "Automate: set octane_sync.py cron + sync pitch reminders"},
            {"id": "P6-05", "task": "Identify your 3 best genres — commit to catalog expansion"},
            {"id": "P6-06", "task": "Pitch catalog to music licensing agents / publishers"},
            {"id": "P6-07", "task": "Set 90-day goals for next cycle (Jul 11 – Oct 8)"},
            {"id": "P6-08", "task": "Archive completed campaign in 07_Archive/"},
            {"id": "P6-09", "task": "Update track_log.json — mark all completed tracks as archived"},
            {"id": "P6-10", "task": "Celebrate. You built a catalog. Now scale it. 🦞"},
        ]
    },
]

WEEKLY_RHYTHM = """
  WEEKLY RHYTHM (recommended 8–12 hrs/week)
  ─────────────────────────────────────────
  Mon    Generate session — 30+ prompts, no judging
  Tue    Curate + download stems from best outputs
  Wed    Assemble + mix 1–2 tracks in DAW
  Thu    Admin — artwork, metadata, DistroKid upload
  Fri    Release day — post, share, pitch
  Sat    Analyze last week's data. Plan next week.
  Sun    Rest or creative exploration
"""

# ── State management ──────────────────────────────────────────────────────────

def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    # Initialize
    all_tasks = {}
    for phase in PHASES:
        for task in phase["tasks"]:
            all_tasks[task["id"]] = {"done": False, "date": None}
    state = {"tasks": all_tasks, "notes": [], "wins": []}
    save_state(state)
    return state

def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2))

# ── Helpers ───────────────────────────────────────────────────────────────────

def day_number():
    today = date.today()
    if today < START:
        return 0
    if today > END:
        return TOTAL_DAYS
    return (today - START).days + 1

def current_week():
    d = day_number()
    if d <= 0:
        return 0
    return min(13, (d - 1) // 7 + 1)

def days_remaining():
    today = date.today()
    if today >= END:
        return 0
    return (END - today).days

def current_phase():
    w = current_week()
    for p in PHASES:
        lo, hi = p["weeks_range"]
        if lo <= w <= hi:
            return p
    return PHASES[-1]

def phase_progress(state):
    results = []
    for p in PHASES:
        total = len(p["tasks"])
        done  = sum(1 for t in p["tasks"] if state["tasks"].get(t["id"], {}).get("done"))
        results.append((p["phase"], p["name"], done, total))
    return results

# ── Dashboard ─────────────────────────────────────────────────────────────────

def dashboard():
    state  = load_state()
    today  = date.today()
    daynum = day_number()
    week   = current_week()
    dr     = days_remaining()

    print("\n" + "="*60)
    print("  🎯  ANIMAL — 90-DAY CATALOG BUILD")
    print(f"  Apr 12, 2026  →  Jul 10, 2026")
    print("="*60)

    if today < START:
        days_to_start = (START - today).days
        print(f"\n  🚀  Starts in {days_to_start} days — {START.strftime('%B %d, %Y')}")
        print(f"\n  Use this time to:")
        print(f"  • Set up accounts (Suno, DistroKid, ASCAP/BMI)")
        print(f"  • Study prompt formulas from the book")
        print(f"  • Build your first Prompt Library")
    elif today > END:
        print(f"\n  ✅  90-Day Plan COMPLETE — {END.strftime('%B %d, %Y')}")
        print(f"  Time to run your final report and plan the next cycle!")
    else:
        print(f"\n  📅  Day {daynum} of {TOTAL_DAYS}  |  Week {week} of 13  |  {dr} days remaining")

        # Progress bar
        pct  = daynum / TOTAL_DAYS
        bars = int(pct * 40)
        print(f"\n  Progress: [{'█'*bars}{'░'*(40-bars)}] {pct*100:.0f}%\n")

        # Current phase
        cp = current_phase()
        print(f"  📌  Phase {cp['phase']}: {cp['name']}  ({cp['dates']})")
        print(f"  🎯  Goal: {cp['goal']}")
        print(f"  🎵  Track target: {cp['target_tracks']} tracks")

    # Overall task progress
    print("\n  ── PHASE PROGRESS ─────────────────────────────────")
    for ph_num, ph_name, done, total in phase_progress(state):
        bar = "✅" if done == total else ("🔄" if done > 0 else "⬜")
        print(f"  {bar} Phase {ph_num}: {ph_name:<15} {done}/{total} tasks")

    # Upcoming tasks in current phase
    if today >= START and today <= END:
        cp = current_phase()
        pending = [t for t in cp["tasks"] if not state["tasks"].get(t["id"], {}).get("done")]
        if pending:
            print(f"\n  ── NEXT UP (Phase {cp['phase']}: {cp['name']}) ────────────────────")
            for t in pending[:5]:
                print(f"  ⬜  [{t['id']}] {t['task']}")
            if len(pending) > 5:
                print(f"        ... and {len(pending)-5} more  (use --week {week})")

    # Quick wins already logged
    if state.get("wins"):
        print(f"\n  ── WINS 🏆 ─────────────────────────────────────────")
        for w in state["wins"][-3:]:
            print(f"  ✨  {w}")

    print(f"\n{WEEKLY_RHYTHM}")
    print("="*60)

# ── Week view ─────────────────────────────────────────────────────────────────

def show_week(week_num):
    state = load_state()
    phase = None
    for p in PHASES:
        lo, hi = p["weeks_range"]
        if lo <= week_num <= hi:
            phase = p
            break
    if not phase:
        print(f"Week {week_num} not found.")
        return

    week_start = START + timedelta(weeks=week_num-1)
    week_end   = week_start + timedelta(days=6)

    print(f"\n🗓  Week {week_num} — {week_start.strftime('%b %d')} to {week_end.strftime('%b %d, %Y')}")
    print(f"   Phase {phase['phase']}: {phase['name']}")
    print(f"   Goal: {phase['goal']}\n")
    print(f"   Tasks:")
    for t in phase["tasks"]:
        done = state["tasks"].get(t["id"], {}).get("done", False)
        box  = "✅" if done else "⬜"
        print(f"   {box}  [{t['id']}] {t['task']}")

# ── All phases ────────────────────────────────────────────────────────────────

def show_all():
    state = load_state()
    print("\n" + "="*65)
    print("  📋  ANIMAL — FULL 90-DAY PLAN")
    print(f"  Apr 12 → Jul 10, 2026  |  Target: 50+ tracks  |  Revenue flowing")
    print("="*65)
    for p in PHASES:
        done  = sum(1 for t in p["tasks"] if state["tasks"].get(t["id"], {}).get("done"))
        total = len(p["tasks"])
        print(f"\n  ── Phase {p['phase']}: {p['name'].upper()} — Weeks {p['weeks']} ({p['dates']}) ──")
        print(f"     Goal: {p['goal']}")
        print(f"     Track target: {p['target_tracks']}  |  Tasks: {done}/{total} done\n")
        for t in p["tasks"]:
            done_flag = state["tasks"].get(t["id"], {}).get("done", False)
            box = "✅" if done_flag else "⬜"
            print(f"     {box}  [{t['id']}] {t['task']}")
    print(f"\n{WEEKLY_RHYTHM}")

# ── Check off task ────────────────────────────────────────────────────────────

def check_task(task_id):
    state = load_state()
    task_id = task_id.upper()
    if task_id not in state["tasks"]:
        print(f"Task ID '{task_id}' not found. Example: P1-01")
        return
    state["tasks"][task_id]["done"] = True
    state["tasks"][task_id]["date"] = date.today().isoformat()
    save_state(state)

    # Find task name
    for p in PHASES:
        for t in p["tasks"]:
            if t["id"] == task_id:
                print(f"✅  Checked off: [{task_id}] {t['task']}")
                return

# ── Log a win ─────────────────────────────────────────────────────────────────

def log_win(text):
    state = load_state()
    entry = f"{date.today().isoformat()} — {text}"
    state.setdefault("wins", []).append(entry)
    save_state(state)
    print(f"🏆  Win logged: {text}")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="ANIMAL 90-Day Plan")
    parser.add_argument("--week",  type=int, metavar="N",    help="Show specific week")
    parser.add_argument("--check", type=str, metavar="TASK", help="Check off a task (e.g. P1-01)")
    parser.add_argument("--win",   type=str, metavar="TEXT", help="Log a win")
    parser.add_argument("--all",   action="store_true",      help="Show full 90-day plan")
    args = parser.parse_args()

    if args.week:
        show_week(args.week)
    elif args.check:
        check_task(args.check)
    elif args.win:
        log_win(args.win)
    elif args.all:
        show_all()
    else:
        dashboard()

if __name__ == "__main__":
    main()
