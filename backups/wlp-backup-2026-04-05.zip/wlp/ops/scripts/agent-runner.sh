#!/bin/bash
# WLP Agent Cron Jobs
# 
# Schedule (Mountain Time - MST/MDT):
# - 6:00 AM  - Morning Worker (daily briefing, task review)
# - 2:00 AM  - Night Worker (autonomous tasks, research)
# - 10:00 AM - Morning Briefing for ANIMAL
#
# UTC equivalents:
# - 6:00 AM MDT = 12:00 UTC (summer)
# - 6:00 AM MST = 13:00 UTC (winter)
# - 2:00 AM MDT = 08:00 UTC (summer)
# - 2:00 AM MST = 09:00 UTC (winter)
# - 10:00 AM MDT = 16:00 UTC (summer)
# - 10:00 AM MST = 17:00 UTC (winter)

export TZ=America/Denver
BRIEFING_DIR="/home/ubuntu/wlp/ops/briefings"
mkdir -p "$BRIEFING_DIR"

DATE=$(date +%Y-%m-%d)
TIME=$(date +%H:%M)
AGENT="$1"

case "$AGENT" in
  morning-worker)
    # 6 AM - Morning Worker tasks
    echo "[$TIME] Morning Worker starting..." >> "$BRIEFING_DIR/agent.log"
    # Task review, daily prep
    /home/ubuntu/wlp/ops/scripts/morning-briefing.sh >> "$BRIEFING_DIR/agent.log" 2>&1
    echo "[$TIME] Morning Worker complete" >> "$BRIEFING_DIR/agent.log"
    ;;
    
  night-worker)
    # 2 AM - Night Worker tasks
    echo "[$TIME] Night Worker starting..." >> "$BRIEFING_DIR/agent.log"
    # Research, data cleanup, background tasks
    # Add: Playlist research, competitor analysis, etc.
    echo "[$TIME] Night Worker complete" >> "$BRIEFING_DIR/agent.log"
    ;;
    
  *)
    echo "Usage: $0 {morning-worker|night-worker}"
    exit 1
    ;;
esac
