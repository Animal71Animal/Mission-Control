#!/bin/bash
# GOG Auth with provided code
export PATH="$PATH:/home/ubuntu/.local/bin"
export GOG_KEYRING_PASSWORD="wlp2025"

echo "Completing Google OAuth with provided redirect URL..."

# Complete auth with the full redirect URL
gog auth add ericmills71@gmail.com \
  --services calendar,drive,gmail,sheets \
  --manual \
  --auth-url "http://127.0.0.1:8085/oauth2/callback?state=vuLRMNLmVKGSaDlIXDVddk6fMps7_LU0gmbDYpli81w&iss=https://accounts.google.com&code=4/0Aci98E8JaqTXqShh2QE3y84gSeGZmifJlR-czKmCSJa56Jl0berZVhcGd42cX_oskSbhGA&scope=email%20https://www.googleapis.com/auth/spreadsheets%20https://www.googleapis.com/auth/drive%20https://www.googleapis.com/auth/directory.readonly%20https://www.googleapis.com/auth/contacts.other.readonly%20https://www.googleapis.com/auth/contacts%20https://www.googleapis.com/auth/calendar%20https://www.googleapis.com/auth/gmail.settings.sharing%20https://www.googleapis.com/auth/gmail.settings.basic%20https://www.googleapis.com/auth/gmail.modify%20https://www.googleapis.com/auth/userinfo.email%20openid&authuser=0&prompt=consent"

echo ""
echo "Verifying auth..."
gog auth list

echo ""
echo "Testing calendar access..."
gog calendar events primary --from $(date -u +%Y-%m-%dT00:00:00Z) --to $(date -u -d '+7 days' +%Y-%m-%dT00:00:00Z) --max 5
