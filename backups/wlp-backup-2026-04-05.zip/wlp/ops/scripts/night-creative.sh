#!/bin/bash
# Night Creative Mode — 2 AM MST autonomous execution
# Identifies gaps, executes creative high-impact work
# Usage: ./night-creative.sh (or via cron)

set -e

WORK_DIR="/home/ubuntu"
REPORT_DIR="$WORK_DIR/wlp/ops/daily-reports"
DATE=$(date +%Y-%m-%d)
START_TIME=$(date +%H:%M:%S)

mkdir -p "$REPORT_DIR"

# Run the night creative logic (Python-driven for flexibility)
python3 << 'PYTHON_EOF'
import json
import os
from pathlib import Path
from datetime import datetime

work_dir = Path("/home/ubuntu")
report_file = work_dir / "wlp/ops/daily-reports" / f"{datetime.now().strftime('%Y-%m-%d')}-night.md"

# Identify gaps
gaps = []

# Gap 1: Mission Control refactoring incomplete
markdown_component_exists = (work_dir / "app/components/MarkdownPage.tsx").exists()
if not markdown_component_exists:
    gaps.append({
        "priority": "HIGH",
        "title": "Complete Mission Control refactoring",
        "description": "Artist pages done; markdown pages (3) + home modules (11) still pending",
        "impact": "Makes codebase lean, maintainable, scalable",
        "estimated_time": "30 minutes"
    })

# Gap 2: API routes not consolidated
route_files = list((work_dir / "app/api").glob("**/route.ts"))
if len(route_files) > 10:
    gaps.append({
        "priority": "MEDIUM",
        "title": "Review API routes for consolidation",
        "description": f"{len(route_files)} route files — likely repetitive patterns",
        "impact": "Reduce boilerplate, improve consistency",
        "estimated_time": "45 minutes"
    })

# Gap 3: Shared styles utility
if not (work_dir / "app/styles/common.ts").exists():
    gaps.append({
        "priority": "LOW",
        "title": "Extract shared styles utility",
        "description": "Tesla, Unfiltered, WLP dashboard have inline styles — consolidate",
        "impact": "Reduce duplication, easier theme changes",
        "estimated_time": "20 minutes"
    })

# Generate report
report = f"""# Night Creative Report — {datetime.now().strftime('%Y-%m-%d %H:%M MST')}

## Identified Gaps (Unstated Opportunities)

"""

for i, gap in enumerate(gaps, 1):
    report += f"""
### {i}. {gap['title']} [{gap['priority']}]
**Description:** {gap['description']}
**Impact:** {gap['impact']}
**Est. Time:** {gap['estimated_time']}

"""

report += f"""
## Recommended Action

**HIGH priority gap identified:** Complete Mission Control refactoring
- Extract markdown pages → reusable `MarkdownPage` component
- Extract home modules → `app/data/modules.ts`
- Both are low-effort, high-impact wins that unlock the full refactoring

**Estimated time:** 30 minutes (matches your original preference)

---

**Generated:** {datetime.now().isoformat()}
**Mode:** Night Creative (autonomous)
**Status:** Gap analysis complete. Ready for implementation.
"""

Path(report_file).write_text(report)
print(f"✓ Night creative report: {report_file}")

PYTHON_EOF

echo ""
echo "✓ Night Creative mode complete"
echo "  Report: $REPORT_DIR/$DATE-night.md"
echo "  Next: Check report for identified opportunities"
