# Autonomous Schedule Setup

## Times (Mountain Standard Time - MST / UTC-6)

```
2 AM MST (8 AM UTC)  → Night Creative Mode
3 AM MST (9 AM UTC)  → Dream Cycle (Memory optimization)
6 AM MST (12 PM UTC) → Morning Worker Mode
10 AM MST (4 PM UTC) → Morning Briefing (Vapi call + JSON)
```

## Crontab Entries

Add these to `crontab -e`:

```bash
# 2 AM MST — Night Creative
0 8 * * * /home/ubuntu/wlp/ops/scripts/night-creative.sh >> /tmp/openclaw/night-creative.log 2>&1

# 3 AM MST — Dream Cycle
30 9 * * * openclaw executive --task "dream-cycle" >> /tmp/openclaw/dream-cycle.log 2>&1

# 6 AM MST — Morning Worker
0 12 * * * openclaw executive --task "morning-worker" >> /tmp/openclaw/morning-worker.log 2>&1

# 10 AM MST — Morning Briefing
0 17 * * * /home/ubuntu/wlp/ops/scripts/morning-briefing.sh >> /tmp/openclaw/morning-briefing.log 2>&1
```

## Setup Instructions

```bash
# 1. Create log directory
mkdir -p /tmp/openclaw

# 2. Make scripts executable
chmod +x /home/ubuntu/wlp/ops/scripts/night-creative.sh
chmod +x /home/ubuntu/wlp/ops/scripts/morning-briefing.sh

# 3. Install cron jobs
crontab -e
# (paste entries above)

# 4. Verify
crontab -l | grep -E "night-creative|morning-briefing"
```

## For Testing (Manual Triggers)

```bash
# Test night creative (2 AM logic)
/home/ubuntu/wlp/ops/scripts/night-creative.sh

# Test morning briefing (10 AM logic)
/home/ubuntu/wlp/ops/scripts/morning-briefing.sh

# View logs
tail -f /tmp/openclaw/night-creative.log
tail -f /tmp/openclaw/morning-briefing.log
```

---

**Status:** Scripts ready. Cron entries documented above.
**Next:** User runs crontab setup on their server (host, not container).
