#!/bin/bash
# Wait for tailscaled socket then bring tailscale up
# Run after tailscale-start.sh is running

sleep 5
until [ -S /run/tailscale/tailscaled.sock ]; do
  echo "Waiting for tailscaled socket..."
  sleep 2
done

sudo tailscale up --hostname=priscylla-abacus
echo "Tailscale up — IP: $(sudo tailscale ip -4 2>/dev/null)"
