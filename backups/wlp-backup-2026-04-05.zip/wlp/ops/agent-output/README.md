# Agent Output

Discord channel: #agent-output (Model: Kimi K2.5)

## Contents
- Night-creative reports (2 AM)
- Morning-worker reports (6 AM)
- Dream-cycle summaries
- Autonomous job logs
