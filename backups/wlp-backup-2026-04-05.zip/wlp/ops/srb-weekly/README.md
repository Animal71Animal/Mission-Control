# SRB Weekly

Discord channel: #srb-weekly (Model: Kimi K2.5)

## Contents
- Monday weekly SRB summaries
- Trend analysis
- Top earner reports
- Month-over-month comparisons
