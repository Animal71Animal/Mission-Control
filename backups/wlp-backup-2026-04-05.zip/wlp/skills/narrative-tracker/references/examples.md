# Example: Narrative Output

## Session Narrative — 2026-03-24 01:45

### Topics
- Narrative Tracker skill creation
- OpenClaw Video #05 patterns
- Session compression techniques
- Sub-agent architecture

### Decisions Made
- Use Python for compressor (portability)
- Implement pattern-based extraction (not LLM-based, for speed)
- Create both --compress and --narrative modes
- Store output in ./memory/ directory structure
- Include cron script for automation

### Action Items / Next Steps
- [ ] Test compressor on real session logs
- [ ] Add to HEARTBEAT.md for automatic processing
- [ ] Consider QMD integration for semantic search
- [ ] Document for ANIMAL's workflow

---

## Session Narrative — 2026-03-23 18:30

### Topics
- SRB Tips data entry
- Google Sheets integration
- Weekly tip workflow

### Decisions Made
- Manual entry is faster than automation for this volume
- Use copy-paste from Sheets to SRB
- Batch process on Mondays

### Action Items / Next Steps
- [ ] Complete T1 task (SRB Tips data)
- [ ] Review T2 (briefing skill conversion)

---

# Example: Compressed Session

**Original** (fictional example):

```
Hi! How can I help you today?

Hey, I need to set up a new skill.

Great! I'd be happy to help with that. What kind of skill?

A narrative tracker thing.

OK, let me think about that. So you want to track narratives?

Yeah, like from that video.

Got it. I'll start building it.

[30 lines of implementation discussion]

OK, I think that works.

Great! Thanks!

No problem! Let me know if you need anything else.
```

**Compressed**:

```
Request: Set up narrative tracker skill (Video #05 pattern)

Implementation:
- Python-based compressor
- Pattern-based extraction
- Two modes: --compress and --narrative
- Output to ./memory/
- Cron automation included

Decisions:
- Pattern-based over LLM (speed)
- Python for portability
- ./memory/ directory structure
```
