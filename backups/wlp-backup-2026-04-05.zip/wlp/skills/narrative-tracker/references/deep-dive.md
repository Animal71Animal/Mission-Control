# Narrative Tracker — Reference Guide

## The Context Compaction Problem

From OpenClaw Video #05, the creator identified a critical issue:

> "OpenClaw's context compaction creates summaries of summaries — the agent starts sharp and gets progressively dumber as information gets compressed repeatedly. By session end, you're working with a summary of a summary of a summary."

This isn't a bug — it's how context windows work. But it means:
- Early session decisions get lost or mangled
- Technical details degrade into vague descriptions
- The agent loses track of "why" choices were made

## The Dual Sub-Agent Solution

Instead of fighting compaction, the creator built two specialized sub-agents:

### Compressor Sub-Agent
**Job**: Remove conversational noise while preserving signal

**Input**: Raw session log (greetings, filler, dead-ends, solutions)
**Output**: Clean log (decisions, code, URLs, key facts only)

**Key insight**: Humans need conversational padding. The memory system doesn't.

### Narrative Tracker Sub-Agent
**Job**: Maintain running notes on project direction

**Input**: Session content
**Output**: Structured narrative with:
- What we designed
- What we're doing
- What we've been working on

**Key insight**: A coherent story survives better than raw logs.

## Implementation Details

### Decision Extraction

The script looks for these linguistic patterns:

```
"decided to..."
"agreed on..."
"chose..."
"will use..."
"going with..."
"settled on..."
"priority is..."
"next step is..."
```

### Action Item Extraction

```
"need to..."
"should..."
"must..."
"TODO:"
"ACTION:"
"task is..."
```

### Topic Extraction

```
Headers (# ## ###)
Bold text (**topic**)
"working on..."
"project..."
"regarding..."
```

## Comparison: Native vs. Narrative Tracker

| Aspect | Native Compaction | Narrative Tracker |
|--------|-------------------|-------------------|
| What it keeps | Summary of everything | Only signal, no noise |
| Decision preservation | Degrades over time | Explicitly extracted |
| Action tracking | Lost in summaries | Structured checklist |
| Context window usage | Grows with summaries | Shrinks with compression |
| Searchability | Poor (summaries) | Excellent (structured) |

## Real-World Usage

### Coding Project Example

**Session 1**: Architecture decisions, tech stack chosen, initial setup
→ Narrative: "Decided on Next.js + Supabase. Action: Set up auth."

**Session 2** (next day): Read narrative, remember decisions, continue building
→ No need to re-discuss tech stack

**Session 3**: Bug fixes, edge cases discovered
→ Narrative updated: "Found edge case with auth. Decided to use JWT."

### Research Project Example

**Session 1**: Literature review, sources found
→ Narrative: "Reviewed 5 papers on X. Key finding: Y. Action: Find Z."

**Session 2**: Follow up on action, new sources
→ Narrative builds cumulative knowledge

## Integration with Other Skills

### With QMD (Query Markdown Documents)

```bash
# Index narrative for semantic search
qmd index memory/narrative.md

# Query: "What did we decide about auth?"
qmd search "authentication decisions"
```

### With Continuity Skill

```
Heartbeat: Run narrative-tracker on yesterday's sessions
Result: Updated narrative.md with decisions
Next session: Read narrative.md for context
```

### With BiteRover

```
BRV curate: Add key decisions to BiteRover context tree
Sync: narrative.md → cloud storage
```

## Advanced Patterns

### Per-Project Narratives

```bash
# Different narrative files per project
python3 narrative-tracker.py --full \
    --output-dir ./projects/alpha/memory/ \
    --session-name "alpha-$(date +%Y-%m-%d)"
```

### Decision-Only Extraction

```bash
# Extract just decisions for executive summary
python3 narrative-tracker.py --narrative < session.md | 
    grep "^### Decisions" -A 20 > decisions-only.md
```

### Diff Between Sessions

```bash
# See what changed between sessions
diff <(python3 narrative-tracker.py --narrative < session1.md) \
     <(python3 narrative-tracker.py --narrative < session2.md)
```

## Limitations

1. **Language-dependent**: Pattern matching works best on English
2. **Implicit decisions missed**: Only catches explicit decision language
3. **No semantic understanding**: Doesn't "understand" content, just extracts patterns
4. **Requires clean input**: Works best on structured session logs

## Future Enhancements

Potential improvements:
- LLM-based semantic compression (vs. pattern-based)
- Automatic cross-reference linking
- Sentiment analysis for decision confidence
- Integration with vector databases
- Multi-language support
