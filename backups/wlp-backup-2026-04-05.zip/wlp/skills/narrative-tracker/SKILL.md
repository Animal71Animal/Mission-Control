---
name: narrative-tracker
description: Lossless session compression and narrative tracking using dual sub-agent pattern with dream cycle memory optimization. Use when preserving session continuity across long-running or multi-session work, extracting decisions and action items, implementing Video #05 "Narrative Tracker Sub-Agent" pattern, or running nightly memory maintenance (dream cycle). Triggers on session compression, narrative tracking, decision extraction, memory bloat prevention, or scheduled nightly memory optimization.
---

# Narrative Tracker

Implements the dual sub-agent pattern from OpenClaw Video #05 with dream cycle memory optimization from Video #36. Solves context compaction degradation through intelligent compression and nightly memory maintenance.

## Three-Tier Architecture

Following Video #36's memory management pattern:

| Tier | Content | Loaded | Cost |
|------|---------|--------|------|
| **Tier 1** | SOUL.md, IDENTITY.md, AGENTS.md | Every turn | High |
| **Tier 2** | narrative.md (indexed by QMD) | On query | Zero |
| **Tier 3** | Compressed session files | On demand | Zero |

## Dual Sub-Agent Pattern (Video #05)

Instead of relying on OpenClaw's native compaction (which creates "summaries of summaries"), this skill uses two dedicated sub-agents:

1. **Compressor Sub-Agent**: Removes conversational noise while preserving signal
2. **Narrative Tracker Sub-Agent**: Maintains running notes on decisions, actions, and direction

## Dream Cycle (Video #36)

Nightly silent cron job that:
1. Reviews daily session logs
2. Compresses redundant memories
3. Moves details from Tier 1 → Tier 2 searchable storage
4. Prevents memory bloat before it degrades performance

## Usage Patterns

### Pattern 1: Compress a Session (Lossless)

Remove filler while keeping decisions, code, URLs, and key facts:

```bash
python3 scripts/narrative-tracker.py --compress < session_log.md > compressed.md
```

What gets removed:
- Greetings ("Hi", "Hello", "Good morning")
- Acknowledgments ("Got it", "OK", "Thanks")
- Filler phrases ("Let me check", "One moment")
- Empty lines and redundant spacing

What gets preserved:
- All code blocks
- Decisions and action items
- URLs and references
- Technical details
- Questions and answers

### Pattern 2: Generate Narrative Notes

Extract the story of what happened:

```bash
python3 scripts/narrative-tracker.py --narrative < session_log.md
```

Output includes:
- **Topics**: Main themes discussed
- **Decisions Made**: "Decided to...", "Chose...", "Going with..."
- **Action Items**: "Need to...", "Should...", "Will..."

### Pattern 3: Full Pipeline (Recommended)

Run both compression and narrative tracking:

```bash
python3 scripts/narrative-tracker.py --full \
    --output-dir ./memory/ \
    --session-name "project-alpha" \
    < session_log.md
```

This creates:
- `memory/project-alpha-compressed.md` — Clean session log
- `memory/narrative.md` — Running narrative with all sessions

### Pattern 4: Automated Cron Processing

Process recent sessions automatically:

```bash
# Add to HEARTBEAT.md or crontab:
./scripts/narrative-tracker-cron.sh 24  # Process last 24 hours
```

## Sub-Agent Spawn Pattern

To use this as a true sub-agent (background task):

```
Spawn a sub-agent to compress this session and update the narrative log.
Use the narrative-tracker skill with --full mode.
Output to ./memory/
```

The sub-agent will:
1. Read the current session log
2. Compress it (remove noise, keep signal)
3. Extract decisions and action items
4. Append to the running narrative.md
5. Report back with summary statistics

## Dream Cycle Implementation (Nightly Memory Optimization)

From Video #36: Run nightly to prevent memory bloat before it degrades agent performance.

### What the Dream Cycle Does

1. **Audit Tier 1 files** — Check if SOUL.md, MEMORY.md, AGENTS.md have grown too large
2. **Compress daily sessions** — Remove conversational noise, keep decisions and code
3. **Migrate to Tier 2** — Move details from loaded-every-turn files to QMD-indexed storage
4. **Update narrative.md** — Append today's key decisions and action items
5. **Generate morning brief** — Prepare "previously on..." recap for next session

### Running the Dream Cycle

```bash
# Manual run
./scripts/dream-cycle.sh

# Automated (add to crontab for 3 AM — after autonomous employee runs)
0 9 * * * /home/ubuntu/wlp/skills/narrative-tracker/scripts/dream-cycle.sh
```

### Bloat Detection Thresholds

| File | Healthy | Bloated | Action |
|------|---------|---------|--------|
| SOUL.md | < 2,000 chars | > 5,000 chars | Compress to narrative |
| MEMORY.md | < 3,000 chars | > 7,000 chars | Migrate to tier 2 |
| AGENTS.md | < 1,500 chars | > 3,000 chars | Archive old conventions |

## Integration with OpenClaw Memory

Recommended file structure:

```
memory/
├── narrative.md              # Running narrative (auto-generated, Tier 2)
├── sessions/
│   ├── 2026-03-24-compressed.md
│   └── 2026-03-23-compressed.md
├── decisions.md              # Extracted decisions only
└── bloat-report.md           # Dream cycle audit log
```

## When to Use

- **Long coding sessions**: Preserve architecture decisions without bloat
- **Multi-day projects**: Maintain continuity across daily sessions
- **Research workflows**: Track what was learned and what to follow up on
- **Client work**: Document decisions made for future reference
- **Debugging sessions**: Keep the solution path, discard the dead ends

## When NOT to Use

- Short sessions (< 10 messages) — overhead not worth it
- Casual chats — only for work sessions with decisions
- When you need full verbatim logs (legal/compliance contexts)

## Context Compaction Mitigation (Video #05 Enhancement)

Native OpenClaw context compaction degrades over time — summaries of summaries lose signal. These enhancements prevent degradation:

### Manual Compaction Trigger (/compact)

Run before context fills to preserve working memory:

```bash
# Check current context usage
python3 scripts/context-check.py

# Manual compaction
python3 scripts/narrative-tracker.py --compact
```

What `/compact` does:
1. Compresses current session in-place
2. Archives removed content to `memory/compacted/`
3. Preserves all decisions, code, URLs
4. Returns freed context tokens

### Auto-Trigger at 50% Context

Enable automatic compaction when context exceeds threshold:

```bash
# Add to session startup (AGENTS.md or HEARTBEAT.md)
python3 scripts/context-monitor.py --threshold 50 --auto-compact
```

Behavior:
- Monitors context usage every 10 messages
- At 50% full: warns user
- At 75% full: auto-compacts with notification
- At 90% full: forces new session spawn

### Sub-Agent Isolation for Tasks

For complex multi-step tasks, isolate context by spawning sub-agents:

```
Spawn a sub-agent to handle [specific task].
Use narrative-tracker to compress results before returning.
Preserve only: decisions made, code written, URLs found.
```

Benefits:
- Parent session stays lean
- Sub-agent can use full context for its task
- Only compressed results return to parent
- No degradation from nested compaction

### Context Budget Management

Track usage across sessions:

```bash
# View context budget report
python3 scripts/context-budget.py

Output:
  Session tokens used: 12,450 / 25,000 (50%)
  Compression savings: 8,200 tokens
  Estimated sessions remaining: 3
  Recommendation: Compact now or spawn sub-agent
```

## Tips

- Run `--full` at end of each significant session
- Review `narrative.md` at start of new session for context
- The narrative file becomes your "previously on..." recap
- Combine with QMD (Query Markdown Documents) for searchable memory
- **Compact proactively** — don't wait for degradation
- **Spawn sub-agents** for isolated complex tasks
- **Monitor context budget** — treat it like memory management
