#!/usr/bin/env python3
"""
context-check.py - Check current context usage and compaction status
Usage:
    python3 context-check.py
    python3 context-check.py --compact  # Trigger manual compaction
"""

import argparse
import json
import os
import sys
from pathlib import Path

SESSIONS_DIR = Path.home() / ".openclaw/agents/main/sessions"
CONTEXT_LIMIT = 25000  # Approximate token limit


def get_latest_session():
    """Find the most recent session file."""
    if not SESSIONS_DIR.exists():
        return None
    
    sessions = list(SESSIONS_DIR.glob("*.jsonl"))
    if not sessions:
        return None
    
    return max(sessions, key=lambda p: p.stat().st_mtime)


def estimate_tokens(text: str) -> int:
    """Rough token estimation (4 chars per token)."""
    return len(text) // 4


def analyze_session(session_file: Path):
    """Analyze session file for context usage."""
    try:
        with open(session_file, "r") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error reading session: {e}")
        return None
    
    total_chars = 0
    message_count = 0
    user_chars = 0
    assistant_chars = 0
    
    for line in lines:
        try:
            data = json.loads(line)
            if data.get("type") == "message":
                msg = data.get("message", {})
                content = msg.get("content", [])
                for c in content:
                    text = c.get("text", "")
                    total_chars += len(text)
                    message_count += 1
                    
                    if msg.get("role") == "user":
                        user_chars += len(text)
                    elif msg.get("role") == "assistant":
                        assistant_chars += len(text)
        except:
            continue
    
    estimated_tokens = total_chars // 4
    usage_percent = (estimated_tokens / CONTEXT_LIMIT) * 100
    
    return {
        "file": session_file.name,
        "messages": message_count,
        "total_chars": total_chars,
        "estimated_tokens": estimated_tokens,
        "usage_percent": usage_percent,
        "user_chars": user_chars,
        "assistant_chars": assistant_chars,
        "remaining_tokens": CONTEXT_LIMIT - estimated_tokens
    }


def print_report(stats: dict):
    """Print formatted context report."""
    print("=== Context Usage Report ===")
    print(f"Session: {stats['file']}")
    print(f"Messages: {stats['messages']}")
    print()
    print(f"Estimated tokens: {stats['estimated_tokens']:,} / {CONTEXT_LIMIT:,}")
    print(f"Usage: {stats['usage_percent']:.1f}%")
    print(f"Remaining: {stats['remaining_tokens']:,} tokens")
    print()
    
    # Visual bar
    filled = int(stats['usage_percent'] / 2)
    bar = "█" * filled + "░" * (50 - filled)
    print(f"[{bar}] {stats['usage_percent']:.0f}%")
    print()
    
    # Status
    if stats['usage_percent'] < 50:
        print("Status: ✅ Healthy")
        print("Recommendation: Continue working normally")
    elif stats['usage_percent'] < 75:
        print("Status: ⚠️  Elevated")
        print("Recommendation: Consider compacting soon")
    elif stats['usage_percent'] < 90:
        print("Status: 🔴 High")
        print("Recommendation: Compact now or spawn sub-agent")
    else:
        print("Status: 🚨 Critical")
        print("Recommendation: Compact immediately or start new session")
    
    print()
    print(f"User content: {stats['user_chars']:,} chars")
    print(f"Assistant content: {stats['assistant_chars']:,} chars")


def main():
    parser = argparse.ArgumentParser(description="Check context usage")
    parser.add_argument("--compact", action="store_true", help="Trigger compaction")
    args = parser.parse_args()
    
    session_file = get_latest_session()
    if not session_file:
        print("No session file found")
        return 1
    
    stats = analyze_session(session_file)
    if not stats:
        return 1
    
    print_report(stats)
    
    if args.compact:
        print("\n=== Triggering Compaction ===")
        # Call narrative-tracker.py --compact
        import subprocess
        result = subprocess.run([
            sys.executable,
            str(Path(__file__).parent / "narrative-tracker.py"),
            "--compact",
            "--input", str(session_file)
        ])
        return result.returncode
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
