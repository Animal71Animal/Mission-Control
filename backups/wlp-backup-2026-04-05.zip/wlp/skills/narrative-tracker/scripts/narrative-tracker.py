#!/usr/bin/env python3
"""
narrative-tracker.py - Lossless compression and narrative tracking for OpenClaw sessions.

This script implements the dual sub-agent pattern from Video #05:
1. Compressor: Removes conversational noise while preserving signal
2. Narrative Tracker: Maintains running notes on decisions and direction

Usage:
    python3 narrative-tracker.py --compress <session_log.md> > compressed.md
    python3 narrative-tracker.py --narrative <session_log.md> >> narrative.md
    python3 narrative-tracker.py --full <session_log.md> --output-dir ./memory/
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path


def extract_decisions(text: str) -> list:
    """Extract decision points from session text."""
    decisions = []
    
    # Pattern: "decided to", "agreed on", "chose", "will use", "going with"
    decision_patterns = [
        r'(?i)(?:decided?|agreed|chose|opted|selected)\s+(?:to|for|on)\s+([^\.\n]+)',
        r'(?i)(?:will|going to|plan to)\s+(?:use|implement|build|create|set up)\s+([^\.\n]+)',
        r'(?i)(?:settled on|going with|using)\s+([^\.\n]+)',
        r'(?i)(?:priority|focus|next step)[s:]?\s+([^\.\n]+)',
    ]
    
    for pattern in decision_patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            decision = match.group(1).strip()
            # Clean up the decision text
            decision = re.sub(r'\s+', ' ', decision)
            if len(decision) > 10 and len(decision) < 200:
                decisions.append(decision)
    
    return list(dict.fromkeys(decisions))  # Remove duplicates while preserving order


def extract_action_items(text: str) -> list:
    """Extract action items and tasks from session text."""
    actions = []
    
    # Pattern: "need to", "should", "TODO", "task", "action item"
    action_patterns = [
        r'(?i)(?:need|should|must|will)\s+(?:to\s+)?([^\.\n]{10,150})',
        r'(?i)(?:TODO|FIXME|ACTION):?\s*([^\.\n]+)',
        r'(?i)(?:task|action item)[s:]?\s+([^\.\n]{10,150})',
    ]
    
    for pattern in action_patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            action = match.group(1).strip()
            action = re.sub(r'\s+', ' ', action)
            if len(action) > 10:
                actions.append(action)
    
    return list(dict.fromkeys(actions))


def extract_topics(text: str) -> list:
    """Extract main topics/themes discussed."""
    topics = []
    
    # Look for headers, project names, or emphasized topics
    topic_patterns = [
        r'(?i)(?:working on|building|project|focus)[s:]?\s+([^\.\n]{5,100})',
        r'(?i)(?:regarding|about|concerning)\s+([^\.\n]{5,80})',
        r'\*\*([^\*]{3,50})\*\*',  # Bold text
        r'#{1,3}\s+(.+)',  # Markdown headers
    ]
    
    for pattern in topic_patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            topic = match.group(1).strip()
            topic = re.sub(r'\s+', ' ', topic)
            if len(topic) > 3 and len(topic) < 100:
                topics.append(topic)
    
    return list(dict.fromkeys(topics))[:10]  # Limit to top 10


def compress_session(text: str) -> str:
    """
    Lossless compression: Remove conversational noise, preserve signal.
    Keeps: decisions, action items, code blocks, key facts, URLs
    Removes: greetings, filler, redundant acknowledgments
    """
    lines = text.split('\n')
    compressed = []
    in_code_block = False
    
    noise_patterns = [
        re.compile(r'^(hi|hello|hey|good morning|good afternoon|good evening)[\s!]*$', re.IGNORECASE),
        re.compile(r'^(thanks|thank you|appreciate it|got it|ok|okay|sure|yes|no)[\s!]*$', re.IGNORECASE),
        re.compile(r'^(great|awesome|cool|nice|perfect|excellent)[\s!]*$', re.IGNORECASE),
        re.compile(r'^(let me|i will|i\'ll|going to|about to)\s+(check|look|see|try|do)', re.IGNORECASE),
        re.compile(r'^(one moment|just a sec|give me a moment|brb)', re.IGNORECASE),
    ]
    
    for line in lines:
        stripped = line.strip()
        
        # Preserve code blocks
        if stripped.startswith('```'):
            in_code_block = not in_code_block
            compressed.append(line)
            continue
        
        if in_code_block:
            compressed.append(line)
            continue
        
        # Skip empty lines (but keep some for structure)
        if not stripped:
            if compressed and compressed[-1].strip():
                compressed.append('')  # Keep single blank line
            continue
        
        # Skip noise patterns
        is_noise = any(pattern.match(stripped) for pattern in noise_patterns)
        if is_noise:
            continue
        
        # Skip very short lines that are just acknowledgments
        if len(stripped) < 15 and stripped.rstrip('!.?') in ['Got it', 'OK', 'Okay', 'Sure', 'Yes', 'No']:
            continue
        
        compressed.append(line)
    
    return '\n'.join(compressed)


def generate_narrative(text: str, timestamp: str = None) -> str:
    """
    Generate narrative notes: what we designed, what we're doing, what we've been working on.
    """
    if timestamp is None:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    decisions = extract_decisions(text)
    actions = extract_action_items(text)
    topics = extract_topics(text)
    
    narrative = f"""## Session Narrative — {timestamp}

### Topics
{chr(10).join(f'- {t}' for t in topics[:5]) if topics else '- (No clear topics identified)'}

### Decisions Made
{chr(10).join(f'- {d}' for d in decisions[:8]) if decisions else '- (No explicit decisions recorded)'}

### Action Items / Next Steps
{chr(10).join(f'- [ ] {a}' for a in actions[:8]) if actions else '- (No action items identified)'}

---
"""
    return narrative


def process_full(text: str, output_dir: str, session_name: str = None):
    """Run both compression and narrative tracking, save to files."""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y-%m-%d')
    if session_name is None:
        session_name = f"session-{timestamp}"
    
    # Compress
    compressed = compress_session(text)
    compressed_file = output_path / f"{session_name}-compressed.md"
    compressed_file.write_text(compressed)
    print(f"Compressed: {compressed_file}", file=sys.stderr)
    
    # Generate narrative
    narrative = generate_narrative(text, timestamp)
    narrative_file = output_path / "narrative.md"
    
    # Append to narrative.md
    if narrative_file.exists():
        existing = narrative_file.read_text()
        narrative_file.write_text(narrative + '\n' + existing)
    else:
        narrative_file.write_text(narrative)
    
    print(f"Narrative: {narrative_file}", file=sys.stderr)
    
    return {
        'compressed': str(compressed_file),
        'narrative': str(narrative_file),
        'decisions_count': len(extract_decisions(text)),
        'actions_count': len(extract_action_items(text)),
    }


def main():
    parser = argparse.ArgumentParser(description='Narrative Tracker - Session compression and narrative tracking')
    parser.add_argument('input', nargs='?', type=argparse.FileType('r'), default=sys.stdin,
                        help='Input file (default: stdin)')
    parser.add_argument('--compress', action='store_true', help='Output compressed session only')
    parser.add_argument('--narrative', action='store_true', help='Output narrative notes only')
    parser.add_argument('--full', action='store_true', help='Run full pipeline (compress + narrative)')
    parser.add_argument('--output-dir', '-o', default='./memory', help='Output directory for full mode')
    parser.add_argument('--session-name', '-n', help='Session name for output files')
    
    args = parser.parse_args()
    
    text = args.input.read()
    
    if args.compress:
        print(compress_session(text))
    elif args.narrative:
        print(generate_narrative(text))
    elif args.full:
        result = process_full(text, args.output_dir, args.session_name)
        print(f"Processed: {result['decisions_count']} decisions, {result['actions_count']} actions")
    else:
        # Default: output narrative
        print(generate_narrative(text))


if __name__ == '__main__':
    main()
