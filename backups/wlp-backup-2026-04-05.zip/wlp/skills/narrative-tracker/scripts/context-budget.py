#!/usr/bin/env python3
"""
context-budget.py - Track context budget across sessions
Usage:
    python3 context-budget.py
"""

import json
import sys
from pathlib import Path
from datetime import datetime, timedelta

SESSIONS_DIR = Path.home() / ".openclaw/agents/main/sessions"
CONTEXT_LIMIT = 25000


def analyze_all_sessions():
    """Analyze all recent sessions."""
    if not SESSIONS_DIR.exists():
        return []
    
    sessions = []
    for session_file in SESSIONS_DIR.glob("*.jsonl"):
        # Skip old/deleted sessions
        if ".reset" in session_file.name or ".deleted" in session_file.name:
            continue
        
        try:
            stats = session_file.stat()
            age_days = (datetime.now().timestamp() - stats.st_mtime) / 86400
            
            # Count tokens
            total_chars = 0
            message_count = 0
            with open(session_file, "r") as f:
                for line in f:
                    try:
                        data = json.loads(line)
                        if data.get("type") == "message":
                            message_count += 1
                            msg = data.get("message", {})
                            for c in msg.get("content", []):
                                total_chars += len(c.get("text", ""))
                    except:
                        continue
            
            tokens = total_chars // 4
            sessions.append({
                "file": session_file.name[:20] + "...",
                "tokens": tokens,
                "messages": message_count,
                "age_days": age_days,
                "size_mb": stats.st_size / (1024 * 1024)
            })
        except:
            continue
    
    return sorted(sessions, key=lambda x: x["age_days"])


def main():
    print("=== Context Budget Report ===")
    print()
    
    sessions = analyze_all_sessions()
    if not sessions:
        print("No sessions found")
        return 1
    
    # Current session (most recent)
    current = sessions[-1]
    
    print(f"Current Session: {current['file']}")
    print(f"  Messages: {current['messages']}")
    print(f"  Tokens: {current['tokens']:,} / {CONTEXT_LIMIT:,}")
    print(f"  Usage: {(current['tokens'] / CONTEXT_LIMIT) * 100:.1f}%")
    print()
    
    # Today's total
    today_tokens = sum(s["tokens"] for s in sessions if s["age_days"] < 1)
    print(f"Today's Total Usage: {today_tokens:,} tokens")
    print(f"  Across {len([s for s in sessions if s['age_days'] < 1])} sessions")
    print()
    
    # Weekly trend
    week_tokens = sum(s["tokens"] for s in sessions if s["age_days"] < 7)
    daily_avg = week_tokens / 7 if week_tokens > 0 else 0
    print(f"7-Day Average: {daily_avg:,.0f} tokens/day")
    print()
    
    # Estimates
    remaining = CONTEXT_LIMIT - current["tokens"]
    avg_session = sum(s["tokens"] for s in sessions[-5:]) / min(5, len(sessions))
    
    if avg_session > 0:
        sessions_remaining = remaining / avg_session
        print(f"Estimated Sessions Remaining: {sessions_remaining:.1f}")
    
    print()
    
    # Recommendation
    usage_pct = (current["tokens"] / CONTEXT_LIMIT) * 100
    if usage_pct < 50:
        print("Status: ✅ Healthy")
        print("Recommendation: Continue working normally")
    elif usage_pct < 75:
        print("Status: ⚠️  Elevated")
        print("Recommendation: Compact before next major task")
    else:
        print("Status: 🔴 High")
        print("Recommendation: Compact now or use sub-agent isolation")
    
    print()
    print("Recent Sessions:")
    for s in sessions[-5:]:
        bar = "█" * int((s["tokens"] / CONTEXT_LIMIT) * 20)
        print(f"  {s['file'][:25]:25} {s['tokens']:>6,} tokens [{bar:<20}]")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
