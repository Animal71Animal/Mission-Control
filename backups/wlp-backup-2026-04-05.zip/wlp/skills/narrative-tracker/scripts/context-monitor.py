#!/usr/bin/env python3
"""
context-monitor.py - Monitor context usage and auto-compact at thresholds
Usage:
    python3 context-monitor.py --threshold 50
    python3 context-monitor.py --threshold 50 --auto-compact
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

SESSIONS_DIR = Path.home() / ".openclaw/agents/main/sessions"
CONTEXT_LIMIT = 25000
CHECK_INTERVAL = 10  # Check every 10 messages


def count_messages(session_file: Path) -> int:
    """Count messages in session."""
    count = 0
    try:
        with open(session_file, "r") as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if data.get("type") == "message":
                        count += 1
                except:
                    continue
    except:
        pass
    return count


def estimate_tokens(session_file: Path) -> int:
    """Estimate tokens in session."""
    total_chars = 0
    try:
        with open(session_file, "r") as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if data.get("type") == "message":
                        msg = data.get("message", {})
                        for c in msg.get("content", []):
                            total_chars += len(c.get("text", ""))
                except:
                    continue
    except:
        pass
    return total_chars // 4


def get_latest_session():
    """Find most recent session."""
    if not SESSIONS_DIR.exists():
        return None
    sessions = list(SESSIONS_DIR.glob("*.jsonl"))
    if not sessions:
        return None
    return max(sessions, key=lambda p: p.stat().st_mtime)


def check_and_notify(usage_percent: float, threshold: float):
    """Check thresholds and print warnings."""
    if usage_percent >= 90:
        print("🚨 CRITICAL: Context at 90%+")
        print("Action required: Start new session immediately")
        return "critical"
    elif usage_percent >= 75:
        print("🔴 HIGH: Context at 75%+")
        print("Recommendation: Compact now or spawn sub-agent")
        return "high"
    elif usage_percent >= threshold:
        print(f"⚠️  ELEVATED: Context at {usage_percent:.1f}%")
        print("Recommendation: Consider compacting soon")
        return "elevated"
    return "ok"


def trigger_compaction():
    """Trigger narrative-tracker compaction."""
    import subprocess
    result = subprocess.run([
        sys.executable,
        str(Path(__file__).parent / "narrative-tracker.py"),
        "--compact"
    ], capture_output=True, text=True)
    return result.returncode == 0


def main():
    parser = argparse.ArgumentParser(description="Monitor context usage")
    parser.add_argument("--threshold", type=float, default=50, help="Warning threshold %")
    parser.add_argument("--auto-compact", action="store_true", help="Auto-compact at 75%")
    parser.add_argument("--once", action="store_true", help="Check once and exit")
    args = parser.parse_args()
    
    session_file = get_latest_session()
    if not session_file:
        print("No session found")
        return 1
    
    print(f"Monitoring: {session_file.name}")
    print(f"Threshold: {args.threshold}%")
    print(f"Auto-compact: {'enabled' if args.auto_compact else 'disabled'}")
    print()
    
    last_message_count = 0
    
    while True:
        current_count = count_messages(session_file)
        
        # Only check every N new messages
        if current_count - last_message_count >= CHECK_INTERVAL or args.once:
            tokens = estimate_tokens(session_file)
            usage = (tokens / CONTEXT_LIMIT) * 100
            
            status = check_and_notify(usage, args.threshold)
            
            # Auto-compact at 75% if enabled
            if args.auto_compact and usage >= 75 and status == "high":
                print("\nAuto-compacting...")
                if trigger_compaction():
                    print("✅ Compaction complete")
                    # Recalculate
                    tokens = estimate_tokens(session_file)
                    usage = (tokens / CONTEXT_LIMIT) * 100
                    print(f"New usage: {usage:.1f}%")
                else:
                    print("❌ Compaction failed")
            
            last_message_count = current_count
            
            if args.once:
                break
        
        if args.once:
            break
            
        time.sleep(5)  # Check every 5 seconds
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
