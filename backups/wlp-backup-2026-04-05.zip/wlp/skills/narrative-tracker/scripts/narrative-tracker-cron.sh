#!/bin/bash
#
# narrative-tracker-cron.sh - Run narrative tracking on recent sessions
# 
# Add to HEARTBEAT.md or run via cron for automatic session processing.
#
# Usage:
#   ./narrative-tracker-cron.sh [hours_ago]
#
# Example:
#   ./narrative-tracker-cron.sh 24  # Process sessions from last 24 hours

HOURS_AGO="${1:-24}"
OUTPUT_DIR="${NARRATIVE_DIR:-./memory/narrative}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Find session logs modified in last N hours
# Adjust pattern to match your session log naming
find ~/.openclaw/sessions -name "*.md" -mtime -"$HOURS_AGO"h 2>/dev/null | while read -r session_file; do
    session_name=$(basename "$session_file" .md)
    echo "Processing: $session_name"
    
    python3 "$SCRIPT_DIR/narrative-tracker.py" --full \
        --output-dir "$OUTPUT_DIR" \
        --session-name "$session_name" \
        < "$session_file"
done

echo "Narrative tracking complete. Output: $OUTPUT_DIR"
