# unified-artist-assets

## Description
Manage and track AI artist assets across WLP. Provides a single source of truth for artist completion status, asset locations, and production readiness.

## When to Use
- When onboarding a new AI artist
- When checking what assets are complete vs pending
- When preparing artist for release
- When auditing artist portfolio

## Capabilities
- Track: logos, photos, bios, social links, music files, press kits, brand guidelines
- Status: complete, pending, missing, needs-update
- View: individual artist dashboard or roster overview
- Export: asset checklist for external use

## Usage
Ask PriScylla to "check artist assets for [name]" or "show artist roster status"
