---
name: capability-evolver
description: Self-improvement engine for OpenClaw agents. Analyzes session logs, memory files, and runtime patterns to identify recurring failures, inefficiencies, and capability gaps — then proposes or applies fixes (new skills, memory corrections, workflow improvements). Use when asked to "evolve", "self-improve", "analyze failures", "find patterns in logs", "what am I bad at", "improve yourself", or during periodic maintenance heartbeats. Also triggers on "capability evolver", "evolve skills", or "self-audit".
---

# Capability Evolver

Analyze your own runtime history to get better over time. No external dependencies — just session logs, memory files, and self-awareness.

## Trigger

Run when:
- User says "evolve", "self-improve", "analyze your failures", "what are you bad at"
- During periodic maintenance (heartbeat or cron)
- After a particularly rough session with many errors
- User asks "what should we fix/improve"

## How It Works

### Phase 1: Gather Evidence

Scan these sources for patterns:

1. **Session logs** — `~/.openclaw/agents/<agentId>/sessions/*.jsonl`
   - Extract tool call failures (toolResult with errors)
   - Find repeated retry patterns (same tool called 3+ times in sequence)
   - Identify long sessions (high token/cost burn relative to output)
2. **Memory files** — `~/memory/*.md` + `~/MEMORY.md`
   - Look for "BROKEN", "doesn't work", "workaround", "TODO", "hack"
   - Find stale entries (referenced tools/services no longer active)
3. **Skill files** — `~/skills/*/SKILL.md`
   - Check for skills that reference missing scripts or broken paths
   - Identify skills not triggered in recent sessions (dead weight)

Use `scripts/analyze.sh` for automated evidence gathering:

```bash
bash ~/skills/capability-evolver/scripts/analyze.sh [--days 7] [--verbose]
```

### Phase 2: Classify Findings

Categorize each finding:

| Category | Description | Priority |
|----------|-------------|----------|
| **recurring-failure** | Same error appears in 3+ sessions | 🔴 High |
| **workaround-debt** | Known broken thing with documented workaround | 🟡 Medium |
| **missing-skill** | Repeated manual workflow that could be a skill | 🟡 Medium |
| **stale-memory** | Outdated info in MEMORY.md or memory files | 🟢 Low |
| **dead-skill** | Skill exists but never triggers | 🟢 Low |
| **cost-hotspot** | Sessions burning excessive tokens for simple tasks | 🟡 Medium |

### Phase 3: Propose Fixes

For each finding, generate a concrete proposal:

- **recurring-failure** → Skill update, memory note, or workaround script
- **workaround-debt** → Proper fix or documented "won't fix" with reason
- **missing-skill** → Draft SKILL.md skeleton (use skill-creator)
- **stale-memory** → Specific lines to update/remove in MEMORY.md
- **dead-skill** → Remove or update trigger description
- **cost-hotspot** → Identify cause (retries? wrong approach? model overkill?)

### Phase 4: Apply

Two modes:

**Review mode (default):** Present findings + proposals to user, apply only what's approved.

**Auto mode (`--auto`):** Apply low-risk fixes automatically (stale-memory cleanup, dead-skill flagging). Always require approval for code changes or skill modifications.

## Output Format

Present findings as a concise report:

```
## Evolution Report — YYYY-MM-DD

### 🔴 High Priority
- [recurring-failure] Browser tool fails on cloud server (12 occurrences across 5 sessions)
  → Proposal: Add fallback pattern to MEMORY.md standing rules

### 🟡 Medium Priority
- [missing-skill] Morning briefing rebuilt from scratch 3 times
  → Proposal: Convert to proper SKILL.md with script

### 🟢 Low Priority
- [stale-memory] MEMORY.md references "Bland AI" but we switched to Vapi
  → Proposal: Remove Bland AI references (lines 45-47)

### Stats
- Sessions analyzed: 14
- Date range: 2026-03-12 to 2026-03-20
- Total findings: 6 (2 high, 2 medium, 2 low)
```

## Manual Evolution (No Script)

If the analysis script isn't available or you prefer manual inspection:

1. List recent sessions:
   ```bash
   AGENT_ID=$(grep 'agent=' <<< "agent=main" | cut -d= -f2)
   for f in ~/.openclaw/agents/$AGENT_ID/sessions/*.jsonl; do
     date=$(head -1 "$f" | jq -r '.timestamp' | cut -dT -f1)
     errs=$(jq -r 'select(.type=="message") | .message.content[]? | select(.type=="toolResult") | select(.content? | test("error|Error|ERROR|failed|Failed")) | .content' "$f" 2>/dev/null | wc -l)
     echo "$date errors=$errs $(basename $f)"
   done | sort -r | head -20
   ```

2. Search for error patterns:
   ```bash
   rg -c "error|Error|failed|ENOENT|ETIMEDOUT|rate.limit" ~/.openclaw/agents/$AGENT_ID/sessions/*.jsonl | sort -t: -k2 -rn | head -10
   ```

3. Find repeated tool failures:
   ```bash
   for f in ~/.openclaw/agents/$AGENT_ID/sessions/*.jsonl; do
     jq -r 'select(.type=="message") | .message.content[]? | select(.type=="toolCall") | .name' "$f" 2>/dev/null
   done | sort | uniq -c | sort -rn | head -15
   ```

4. Scan memory for debt markers:
   ```bash
   rg -n "BROKEN|broken|doesn't work|workaround|TODO|hack|FIXME|temporary" ~/MEMORY.md ~/memory/*.md 2>/dev/null
   ```

## Integration with Heartbeats

Add to `HEARTBEAT.md` for periodic self-improvement:

```markdown
# Capability Evolver (weekly, Saturday)
- Run: bash ~/skills/capability-evolver/scripts/analyze.sh --days 7
- If findings exist, summarize and note in memory/YYYY-MM-DD.md
- Only alert user for 🔴 High Priority items
```

## Safety

- Never modify skills or code without user approval (unless `--auto` for low-risk only)
- Never delete memory — only propose edits
- All changes tracked in `memory/YYYY-MM-DD.md` under "## Evolution" heading
- If unsure whether something is a real pattern or a one-off, flag it as "needs more data"
