#!/bin/bash
# analyze.sh - Automated evidence gathering for capability evolution
# Usage: bash analyze.sh [--days 7] [--verbose]

set -e

DAYS=7
VERBOSE=false
AGENT_ID="main"
MEMORY_DIR="/home/ubuntu/memory"
WLP_CORE="/home/ubuntu/wlp/core"
SKILLS_DIR="/home/ubuntu/wlp/skills"
SESSIONS_DIR="/home/ubuntu/.openclaw/agents/$AGENT_ID/sessions"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --days)
            DAYS="$2"
            shift 2
            ;;
        --verbose)
            VERBOSE=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

echo "=== Capability Evolver Analysis ==="
echo "Analyzing last $DAYS days..."
echo ""

# Check if sessions directory exists
if [ ! -d "$SESSIONS_DIR" ]; then
    echo "Error: Sessions directory not found: $SESSIONS_DIR"
    exit 1
fi

# Find recent sessions
echo "--- Recent Sessions ---"
find "$SESSIONS_DIR" -name "*.jsonl" -mtime -$DAYS ! -name "*.reset*" ! -name "*.deleted*" | while read f; do
    date=$(head -1 "$f" 2>/dev/null | jq -r '.timestamp' 2>/dev/null | cut -dT -f1 || echo "unknown")
    size=$(wc -c < "$f")
    echo "  $date - $(basename $f) ($size bytes)"
done
echo ""

# Count errors in recent sessions
echo "--- Error Patterns ---"
find "$SESSIONS_DIR" -name "*.jsonl" -mtime -$DAYS ! -name "*.reset*" ! -name "*.deleted*" | while read f; do
    errs=$(jq -r 'select(.type=="message") | .message.content[]? | select(.type=="toolResult") | select(.content? | test("error|Error|ERROR|failed|Failed|ENOENT|ETIMEDOUT")) | .content' "$f" 2>/dev/null | wc -l)
    if [ "$errs" -gt 0 ]; then
        echo "  $(basename $f): $errs errors"
    fi
done | sort -t: -k2 -rn | head -10
echo ""

# Find repeated tool calls
echo "--- Tool Usage Patterns ---"
find "$SESSIONS_DIR" -name "*.jsonl" -mtime -$DAYS ! -name "*.reset*" ! -name "*.deleted*" | while read f; do
    jq -r 'select(.type=="message") | .message.content[]? | select(.type=="toolCall") | .name' "$f" 2>/dev/null
done | sort | uniq -c | sort -rn | head -15 | while read count tool; do
    echo "  $tool: $count calls"
done
echo ""

# Scan memory for debt markers
echo "--- Memory Debt Markers ---"
if [ -f "$WLP_CORE/MEMORY.md" ]; then
    grep -n "BROKEN\|broken\|doesn't work\|workaround\|TODO\|hack\|FIXME\|temporary" "$WLP_CORE/MEMORY.md" 2>/dev/null | head -10 | while read line; do
        echo "  MEMORY.md: $line"
    done
fi

for f in "$MEMORY_DIR"/*.md; do
    if [ -f "$f" ]; then
        grep -n "BROKEN\|broken\|doesn't work\|workaround\|TODO\|hack\|FIXME\|temporary" "$f" 2>/dev/null | head -5 | while read line; do
            echo "  $(basename $f): $line"
        done
    fi
done
echo ""

# Check skill health
echo "--- Skill Health Check ---"
for skill_dir in "$SKILLS_DIR"/*/; do
    if [ -d "$skill_dir" ]; then
        skill_name=$(basename "$skill_dir")
        skill_file="$skill_dir/SKILL.md"
        
        if [ ! -f "$skill_file" ]; then
            echo "  ⚠️  $skill_name: Missing SKILL.md"
            continue
        fi
        
        # Check for referenced scripts
        missing_scripts=0
        grep -o 'scripts/[a-zA-Z0-9_-]*\.\(sh\|py\)' "$skill_file" 2>/dev/null | while read script; do
            if [ ! -f "$skill_dir/$script" ]; then
                echo "  ⚠️  $skill_name: Missing $script"
            fi
        done
    fi
done
echo ""

# Check Tier 1 file sizes
echo "--- Tier 1 Memory File Sizes ---"
for file in "$WLP_CORE/SOUL.md" "$WLP_CORE/MEMORY.md" "$WLP_CORE/AGENTS.md"; do
    if [ -f "$file" ]; then
        size=$(wc -c < "$file")
        name=$(basename "$file")
        status="✅"
        
        case "$name" in
            SOUL.md)
                [ $size -gt 5000 ] && status="⚠️ Bloated"
                ;;
            MEMORY.md)
                [ $size -gt 7000 ] && status="⚠️ Bloated"
                ;;
            AGENTS.md)
                [ $size -gt 3000 ] && status="⚠️ Bloated"
                ;;
        esac
        
        echo "  $name: $size bytes $status"
    fi
done
echo ""

echo "=== Analysis Complete ==="
echo "Review findings above and prioritize fixes."
