# Detection Heuristics

## Regex Patterns for Common Attacks

### Direct Instructions
```regex
(?i)(ignore previous instructions|you are now|your new task is|disregard your guidelines|as an AI,? you must)
```

### Goal Manipulation
```regex
(?i)(actually,? the user wants|the real request is|override:\s*do|disregard (everything|all previous)|your actual (task|job|role) is)
```

### Data Exfiltration
```regex
(?i)(send (the contents of|everything in)|include (the|your) API key|append all file contents|mailto:|https?://[^\s]+\.(php|cgi|webhook))
```

### Social Engineering
```regex
(?i)(urgent:\s*you must|the user will be harmed|this is a test,? you should|emergency:? |critical:? |immediate action required)
```

## Scoring System

| Pattern Type | Base Score | Multiplier |
|--------------|------------|------------|
| Direct instruction | 25 | Per occurrence |
| Goal manipulation | 20 | Per occurrence |
| Data exfiltration | 30 | Per occurrence |
| Social engineering | 15 | Per occurrence |
| Encoding/obfuscation | 10 | Per occurrence |
| Homoglyph | 15 | Per character |

### Risk Levels
- **0-29:** Clean - No action needed
- **30-49:** Low risk - Log and continue
- **50-69:** Medium risk - Alert user, ask before proceeding
- **70-100:** High risk - Block and report

## Unicode Homoglyphs

Common character substitutions to detect:

| Character | Unicode | Looks Like | Latin Unicode |
|-----------|---------|------------|---------------|
| а | U+0430 | a | U+0061 |
| е | U+0435 | e | U+0065 |
| о | U+043E | o | U+006F |
| р | U+0440 | p | U+0070 |
| с | U+0441 | c | U+0063 |
| х | U+0445 | x | U+0078 |

## Safe Parsing Techniques

1. **Normalize Unicode** before pattern matching
2. **Decode common encodings** (Base64, HTML entities)
3. **Strip zero-width characters**
4. **Validate URLs** against allowlists
5. **Sanitize HTML** to remove hidden content
