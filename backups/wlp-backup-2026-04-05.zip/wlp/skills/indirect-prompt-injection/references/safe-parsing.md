# Safe Parsing Techniques

## Content Sanitization Pipeline

### Step 1: Unicode Normalization
```python
import unicodedata

def normalize_unicode(text: str) -> str:
    # NFKC normalization handles compatibility characters
    return unicodedata.normalize('NFKC', text)
```

### Step 2: Strip Zero-Width Characters
```python
ZERO_WIDTH_CHARS = [
    '\u200B',  # Zero Width Space
    '\u200C',  # Zero Width Non-Joiner
    '\u200D',  # Zero Width Joiner
    '\uFEFF',  # Zero Width No-Break Space
    '\u2060',  # Word Joiner
]

def strip_zero_width(text: str) -> str:
    for char in ZERO_WIDTH_CHARS:
        text = text.replace(char, '')
    return text
```

### Step 3: Decode Common Encodings
```python
import base64
import html

def decode_content(text: str) -> str:
    # Try Base64
    try:
        decoded = base64.b64decode(text).decode('utf-8')
        return decoded
    except:
        pass
    
    # Try HTML entities
    try:
        return html.unescape(text)
    except:
        pass
    
    return text
```

### Step 4: URL Validation
```python
from urllib.parse import urlparse

ALLOWED_DOMAINS = [
    'example.com',
    'trusted-site.org',
]

def is_safe_url(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.netloc in ALLOWED_DOMAINS
```

### Step 5: HTML Sanitization
```python
from html.parser import HTMLParser

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.text = []
        self.skip = False
    
    def handle_starttag(self, tag, attrs):
        # Skip hidden elements
        if tag in ['script', 'style', 'meta']:
            self.skip = True
    
    def handle_endtag(self, tag):
        self.skip = False
    
    def handle_data(self, data):
        if not self.skip:
            self.text.append(data)
    
    def get_text(self):
        return ' '.join(self.text)

def extract_visible_text(html: str) -> str:
    parser = TextExtractor()
    parser.feed(html)
    return parser.get_text()
```

## Best Practices

1. **Treat all external content as untrusted**
2. **Parse, don't execute** - Extract data, don't run commands
3. **Fail closed** - When in doubt, reject the content
4. **Log everything** - Track what was sanitized and why
5. **Rate limit** - Prevent abuse through volume

## Example: Full Pipeline

```python
def sanitize_content(raw_content: str) -> dict:
    """Full sanitization pipeline."""
    
    # Step 1: Normalize
    text = normalize_unicode(raw_content)
    
    # Step 2: Strip zero-width
    text = strip_zero_width(text)
    
    # Step 3: Decode encodings
    text = decode_content(text)
    
    # Step 4: Extract visible text if HTML
    if '<' in text and '>' in text:
        text = extract_visible_text(text)
    
    # Step 5: Scan for injection patterns
    analysis = analyze_content(text)
    
    return {
        'sanitized': text,
        'analysis': analysis,
        'safe': analysis['risk_score'] < 30
    }
```
