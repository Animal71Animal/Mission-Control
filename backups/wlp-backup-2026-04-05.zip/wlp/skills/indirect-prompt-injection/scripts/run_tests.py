#!/usr/bin/env python3
"""
run_tests.py - Test suite for indirect prompt injection detection
"""

import subprocess
import sys
from pathlib import Path

def main():
    script_dir = Path(__file__).parent
    sanitize_script = script_dir / "sanitize.py"
    
    if not sanitize_script.exists():
        print("Error: sanitize.py not found")
        return 1
    
    return subprocess.run([sys.executable, str(sanitize_script), "--test"]).returncode

if __name__ == "__main__":
    sys.exit(main())
