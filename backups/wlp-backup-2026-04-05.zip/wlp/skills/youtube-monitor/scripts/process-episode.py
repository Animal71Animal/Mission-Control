#!/opt/computersetup/.pyenv/versions/3.11.6/bin/python3
"""
YouTube Transcript Processor
Fetches transcripts via Supadata API and generates episode summaries
"""

import json
import sys
import os
import re
from datetime import datetime

# Supadata API endpoint
SUPADATA_API_URL = "https://api.supadata.ai/v1/transcript"

def fetch_transcript(video_id, api_key):
    """Fetch transcript from Supadata API"""
    import urllib.request
    import urllib.parse
    
    url = f"{SUPADATA_API_URL}?videoId={video_id}"
    headers = {
        "x-api-key": api_key
    }
    
    req = urllib.request.Request(url, headers=headers)
    
    try:
        with urllib.request.urlopen(req) as response:
            data = json.loads(response.read().decode())
            return data
    except Exception as e:
        print(f"Error fetching transcript: {e}", file=sys.stderr)
        return None

def process_transcript(transcript_data, video_info):
    """Process transcript into episode format"""
    
    # Extract full text
    full_text = " ".join([segment.get("text", "") for segment in transcript_data.get("content", [])])
    
    # Generate topic breakdown based on timestamps
    segments = transcript_data.get("content", [])
    topic_breakdown = []
    
    # Group segments into ~10 minute chunks for topic breakdown
    chunk_size = 10 * 60  # 10 minutes in seconds
    current_chunk = []
    current_start = 0
    
    for segment in segments:
        start = segment.get("start", 0)
        text = segment.get("text", "")
        
        if start - current_start > chunk_size and current_chunk:
            # Process chunk
            chunk_text = " ".join(current_chunk)
            minutes = int(current_start // 60)
            timestamp = f"{minutes:02d}:00"
            
            topic_breakdown.append({
                "timestamp": timestamp,
                "title": f"Segment at {timestamp}",
                "synopsis": chunk_text[:200] + "..." if len(chunk_text) > 200 else chunk_text,
                "keyPoints": extract_key_points(chunk_text)
            })
            
            current_chunk = []
            current_start = start
        
        current_chunk.append(text)
    
    # Process final chunk
    if current_chunk:
        chunk_text = " ".join(current_chunk)
        minutes = int(current_start // 60)
        timestamp = f"{minutes:02d}:00"
        
        topic_breakdown.append({
            "timestamp": timestamp,
            "title": f"Segment at {timestamp}",
            "synopsis": chunk_text[:200] + "..." if len(chunk_text) > 200 else chunk_text,
            "keyPoints": extract_key_points(chunk_text)
        })
    
    # Generate summary from first and last parts
    summary_text = " ".join([s.get("text", "") for s in segments[:50]])
    summary = summary_text[:300] + "..." if len(summary_text) > 300 else summary_text
    
    # Extract key takeaways
    key_takeaways = extract_key_points(full_text, max_points=5)
    
    # Generate expanded takeaways
    expanded_takeaways = []
    for takeaway in key_takeaways[:4]:
        expanded_takeaways.append({
            "title": takeaway,
            "detail": f"This point emphasizes the importance of {takeaway.lower()} in the broader context of the discussion."
        })
    
    return {
        "summary": summary,
        "keyTakeaways": key_takeaways,
        "expandedTakeaways": expanded_takeaways,
        "topicBreakdown": topic_breakdown[:7]  # Limit to 7 topics
    }

def extract_key_points(text, max_points=3):
    """Extract key points from text"""
    # Simple extraction based on sentence structure
    sentences = re.split(r'[.!?]+', text)
    key_points = []
    
    for sentence in sentences:
        sentence = sentence.strip()
        # Look for sentences that seem important (contain key words)
        if any(word in sentence.lower() for word in ['important', 'key', 'must', 'need', 'should', 'always', 'never', 'critical', 'essential']):
            if len(sentence) > 20 and len(sentence) < 150:
                key_points.append(sentence)
        if len(key_points) >= max_points:
            break
    
    # If not enough key points, take first few sentences
    if len(key_points) < max_points:
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 30 and len(sentence) < 120 and sentence not in key_points:
                key_points.append(sentence)
            if len(key_points) >= max_points:
                break
    
    return key_points if key_points else ["Key discussion points from the episode"]

def update_episode_file(episode_data, video_id):
    """Update the live-episodes.json file"""
    data_file = "/home/ubuntu/wlp/projects/mission-control/public/data/live-episodes.json"
    
    # Read existing episodes
    episodes = []
    if os.path.exists(data_file):
        with open(data_file, 'r') as f:
            episodes = json.load(f)
    
    # Check if episode already exists
    existing = None
    for i, ep in enumerate(episodes):
        if ep.get("url", "").endswith(video_id):
            existing = i
            break
    
    # Build episode entry
    episode_entry = {
        "id": f"live-{len(episodes)+1:03d}" if existing is None else episodes[existing]["id"],
        "episodeNumber": len(episodes)+1 if existing is None else episodes[existing]["episodeNumber"],
        "title": episode_data.get("title", "Live Episode"),
        "url": f"https://www.youtube.com/watch?v={video_id}",
        "publishedDate": datetime.now().strftime("%Y-%m-%d"),
        "duration": episode_data.get("duration", "Unknown"),
        "summary": episode_data.get("summary", ""),
        "keyTakeaways": episode_data.get("keyTakeaways", []),
        "expandedTakeaways": episode_data.get("expandedTakeaways", []),
        "toolsCovered": episode_data.get("toolsCovered", []),
        "codeSnippets": episode_data.get("codeSnippets", []),
        "relatedVideos": episode_data.get("relatedVideos", []),
        "topics": episode_data.get("topics", []),
        "topicBreakdown": episode_data.get("topicBreakdown", [])
    }
    
    if existing is not None:
        episodes[existing] = episode_entry
    else:
        episodes.insert(0, episode_entry)  # Add to beginning
    
    # Write back
    with open(data_file, 'w') as f:
        json.dump(episodes, f, indent=2)
    
    print(f"Updated episode: {episode_entry['title']}")
    return episode_entry

def main():
    if len(sys.argv) < 2:
        print("Usage: process-episode.py <youtube_video_id> [episode_title]", file=sys.stderr)
        sys.exit(1)
    
    video_id = sys.argv[1]
    episode_title = sys.argv[2] if len(sys.argv) > 2 else "Live Episode"
    
    api_key = "sd_b4e03cefc86907e9c2e7f9d8284510a9"
    
    print(f"Fetching transcript for video: {video_id}")
    
    # Fetch transcript
    transcript_data = fetch_transcript(video_id, api_key)
    if not transcript_data:
        print("Failed to fetch transcript", file=sys.stderr)
        sys.exit(1)
    
    print(f"Transcript fetched: {len(transcript_data.get('content', []))} segments")
    
    # Process into episode format
    video_info = {"title": episode_title}
    episode_data = process_transcript(transcript_data, video_info)
    episode_data["title"] = episode_title
    
    # Update episode file
    update_episode_file(episode_data, video_id)
    
    print("Episode processed successfully!")

if __name__ == "__main__":
    main()
