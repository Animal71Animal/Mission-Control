#!/opt/computersetup/.pyenv/versions/3.11.6/bin/python3
"""
Tom Bilyeu YouTube Channel Monitor — Playwright-based (no RSS)
RSS is blocked from cloud servers; uses Playwright to scrape channel page directly.

Usage:
    python3 channel-monitor.py
"""

import json
import sys
import os
import re
import time
import subprocess
from datetime import datetime

# ============ CONFIG ============
CHANNEL_URL = "https://www.youtube.com/@TomBilyeu/videos"
DATA_FILE = "/home/ubuntu/wlp/projects/mission-control/public/data/live-episodes.json"
LOG_FILE = "/home/ubuntu/wlp/logs/youtube-monitor.log"
MISSION_CONTROL_DIR = "/home/ubuntu/wlp/projects/mission-control"
# ================================

def log(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    msg = f"[{timestamp}] {message}"
    print(msg)
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, 'a') as f:
        f.write(msg + "\n")

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE) as f:
            return json.load(f)
    return []

def save_data(episodes):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, 'w') as f:
        json.dump(episodes, f, indent=2)

def scrape_channel():
    """Scrape channel page for latest videos using Playwright"""
    from playwright.sync_api import sync_playwright
    videos = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-setuid-sandbox"])
        page = browser.new_page()
        page.goto(CHANNEL_URL, wait_until="networkidle", timeout=30000)
        time.sleep(4)
        items = page.locator('ytd-rich-item-renderer').all()
        for item in items[:15]:
            try:
                href = item.locator('a#video-title-link').get_attribute('href')
                title = item.locator('#video-title').inner_text().strip()
                video_id = re.search(r'v=([^&]+)', href or "")
                if not video_id: continue
                url = f"https://www.youtube.com{href}"
                videos.append({"video_id": video_id.group(1), "title": title, "url": url, "is_live": "LIVE" in title.upper()})
            except: pass
        browser.close()
    return videos

def scrape_episode(video_id):
    """Scrape individual episode for description and chapters"""
    from playwright.sync_api import sync_playwright
    result = {"description": "", "chapters": [], "title": ""}
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-setuid-sandbox"])
            page = browser.new_page()
            page.goto(f"https://www.youtube.com/watch?v={video_id}", wait_until="networkidle", timeout=30000)
            time.sleep(4)
            page.evaluate("window.scrollTo(0, 600)")
            time.sleep(1)
            try:
                result["title"] = page.title().replace(" - YouTube", "").strip()
            except: pass
            try:
                page.get_by_role("button", name="...more").click(timeout=5000)
                time.sleep(2)
            except: pass
            try:
                desc = page.locator('#description-inline-expander').inner_text(timeout=5000)
                result["description"] = desc
                result["chapters"] = [(ts.strip(), t.strip()) for ts, t in re.findall(r'(\d+:\d+(?::\d+)?)\s+(.+)', desc) if len(t.strip()) > 2]
            except: pass
            browser.close()
    except Exception as e:
        log(f"Playwright error for {video_id}: {e}")
    return result

def build_episode_data(video_info, scraped):
    """Build structured episode data from scraped content"""
    desc = scraped.get("description", "")
    chapters = scraped.get("chapters", [])

    # Better description cleaning
    desc_clean = re.sub(r'https?://\S+', '', desc)
    desc_clean = re.sub(r'[@#]\w+', '', desc_clean)
    desc_clean = re.sub(r'\n{3,}', '\n\n', desc_clean).strip()
    
    # Remove sponsor lines and channel metadata
    lines = desc_clean.split('\n')
    content_lines = []
    for line in lines:
        line = line.strip()
        # Skip sponsor/discount lines
        if re.search(r'\d+%\s*off|discount|code\s*\w+|visit\s+\w+\.(com|net|org)', line, re.IGNORECASE):
            continue
        # Skip social media CTAs
        if line.lower() in ['instagram', 'facebook', 'twitter', 'linkedin', 'twitch', 'discord', 'show less', 'show transcript']:
            continue
        # Skip subscriber counts
        if re.search(r'\d+\.?\d*\s*[MK]?\s*subscribers', line, re.IGNORECASE):
            continue
        content_lines.append(line)
    
    desc_clean = '\n'.join(content_lines)
    desc_clean = re.sub(r'\n{3,}', '\n\n', desc_clean).strip()

    paragraphs = [p.strip() for p in desc_clean.split('\n\n') if p.strip() and len(p.strip()) > 40]
    summary = (paragraphs[0][:400] + "...") if paragraphs and len(paragraphs[0]) > 400 else (paragraphs[0] if paragraphs else "No summary available.")

    sentences = re.split(r'(?<=[.!?])\s+', desc_clean)
    takeaways = [s.strip() for s in sentences if 40 < len(s.strip()) < 150][:5]
    if not takeaways: takeaways = ["See full episode for key insights"]

    expanded = [{"title": t[:60] + "..." if len(t) > 60 else t, "detail": t} for t in takeaways[:4]]
    
    # Build topic breakdown from chapters
    topic_breakdown = []
    for ts, ct in chapters[:10]:
        topic_breakdown.append({
            "timestamp": ts,
            "title": ct,
            "synopsis": f"Discussion of {ct}.",
            "keyPoints": [f"Key insights on {ct} at {ts}"]
        })
    
    topic_keywords = ['mindset', 'business', 'success', 'leadership', 'money', 'wealth', 'health', 'ai', 'technology', 'politics', 'war', 'economy', 'science', 'psychology']
    topics = [k.title() for k in topic_keywords if k in desc_clean.lower()][:6]

    return {
        "summary": summary,
        "keyTakeaways": takeaways,
        "expandedTakeaways": expanded,
        "topicBreakdown": topic_breakdown,
        "toolsCovered": [],
        "topics": topics
    }

def deploy():
    log("Deploying Mission Control...")
    result = subprocess.run(["npx", "vercel@latest", "--prod", "--yes"], cwd=MISSION_CONTROL_DIR, capture_output=True, text=True, timeout=300)
    log("Deploy successful" if result.returncode == 0 else f"Deploy failed: {result.stderr[:200]}")

def main():
    log("=== Tom Bilyeu Monitor Start ===")

    episodes = load_data()
    existing_urls = {e.get("url", "") for e in episodes}
    log(f"Existing episodes: {len(episodes)}")

    log("Scraping channel page...")
    videos = scrape_channel()
    log(f"Found {len(videos)} videos")

    new_videos = [v for v in videos if v["url"] not in existing_urls]
    log(f"New videos: {len(new_videos)}")

    if not new_videos:
        log("No new videos. Done.")
        return

    for video in new_videos:
        log(f"Processing: {video['title'][:60]}")
        scraped = scrape_episode(video["video_id"])
        if scraped.get("title") and len(scraped["title"]) > 5:
            video["title"] = scraped["title"]
        episode_data = build_episode_data(video, scraped)
        entry = {
            "id": f"live-{video['video_id'][:8]}",
            "episodeNumber": len(episodes) + 1,
            "title": video["title"],
            "url": video["url"],
            "publishedDate": datetime.now().strftime("%Y-%m-%d"),
            "duration": "Unknown",
            "isLive": video["is_live"],
            **episode_data
        }
        episodes.insert(0, entry)
        log(f"  ✓ Added")

    for i, ep in enumerate(episodes):
        ep["episodeNumber"] = len(episodes) - i

    save_data(episodes)
    log(f"Saved {len(episodes)} episodes")
    deploy()
    log("=== Monitor Complete ===")

if __name__ == "__main__":
    main()
