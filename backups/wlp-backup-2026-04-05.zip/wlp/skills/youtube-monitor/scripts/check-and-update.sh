#!/bin/bash
# YouTube Monitor - Check for new Tom Bilyeu live episodes
# Runs Mon/Wed/Fri mornings

CHANNEL_ID="UCnYMOamNKLGVlJgRUbamveA"
RSS_URL="https://www.youtube.com/feeds/videos.xml?channel_id=${CHANNEL_ID}"
DATA_FILE="/home/ubuntu/wlp/projects/mission-control/public/data/live-episodes.json"
LOG_FILE="/home/ubuntu/wlp/logs/youtube-monitor.log"
FIRECRAWL_API_KEY="${FIRECRAWL_API_KEY}"

mkdir -p "$(dirname "$LOG_FILE")"

echo "=== YouTube Monitor Run: $(date) ===" >> "$LOG_FILE"
echo "Checking RSS feed..." >> "$LOG_FILE"

# Fetch RSS feed
RSS_CONTENT=$(curl -s "$RSS_URL")

# Parse for live show entries (titles containing "LIVE" or "Live")
LIVE_ENTRIES=$(echo "$RSS_CONTENT" | grep -oP '<entry>.*?<title>.*?(LIVE|Live).*?</title>.*?</entry>' | head -5)

if [ -z "$LIVE_ENTRIES" ]; then
    echo "No live episodes found in RSS feed" >> "$LOG_FILE"
    exit 0
fi

# Process each live entry
echo "$LIVE_ENTRIES" | while read -r entry; do
    VIDEO_ID=$(echo "$entry" | grep -oP '<yt:videoId>\K[^<]+')
    TITLE=$(echo "$entry" | grep -oP '<title>\K[^<]+')
    PUBLISHED=$(echo "$entry" | grep -oP '<published>\K[^<]+')
    URL="https://www.youtube.com/watch?v=${VIDEO_ID}"
    
    echo "Found live episode: $TITLE" >> "$LOG_FILE"
    
    # Check if already in data file
    if grep -q "$VIDEO_ID" "$DATA_FILE" 2>/dev/null; then
        echo "Episode already tracked: $VIDEO_ID" >> "$LOG_FILE"
        continue
    fi
    
    echo "New episode detected: $VIDEO_ID" >> "$LOG_FILE"
    
    # Generate summary using Firecrawl
    echo "Generating summary..." >> "$LOG_FILE"
    
    SUMMARY_DATA=$(curl -s -X POST "https://api.firecrawl.dev/v1/scrape" \
        -H "Authorization: Bearer ${FIRECRAWL_API_KEY}" \
        -H "Content-Type: application/json" \
        -d "{
            \"url\": \"${URL}\",
            \"formats\": [\"markdown\"],
            \"onlyMainContent\": true
        }" 2>/dev/null)
    
    # Extract key information (simplified - would use LLM in production)
    SUMMARY=$(echo "$SUMMARY_DATA" | grep -oP '"markdown":"\K[^"]+' | head -c 500)
    
    # Get next episode number
    NEXT_EP=$(($(cat "$DATA_FILE" | grep -o '"episodeNumber":[0-9]*' | grep -o '[0-9]*' | sort -n | tail -1) + 1))
    
    # Create new episode entry
    NEW_ENTRY=$(cat <<EOF
  {
    "id": "live-$(printf '%03d' $NEXT_EP)",
    "episodeNumber": $NEXT_EP,
    "title": "$TITLE",
    "url": "$URL",
    "publishedDate": "$PUBLISHED",
    "duration": "TBD",
    "summary": "$SUMMARY",
    "keyTakeaways": [],
    "toolsCovered": [],
    "codeSnippets": [],
    "relatedVideos": []
  }
EOF
)
    
    # Update JSON file
    if [ -s "$DATA_FILE" ]; then
        # Add to existing array
        TEMP_FILE=$(mktemp)
        jq ". += [$NEW_ENTRY]" "$DATA_FILE" > "$TEMP_FILE" && mv "$TEMP_FILE" "$DATA_FILE"
    else
        # Create new array
        echo "[$NEW_ENTRY]" > "$DATA_FILE"
    fi
    
    echo "Added episode $NEXT_EP to tracking" >> "$LOG_FILE"
    
    # Trigger redeploy
    echo "Triggering Mission Control redeploy..." >> "$LOG_FILE"
    cd /home/ubuntu/wlp/projects/mission-control && npx vercel@latest --prod --yes >> "$LOG_FILE" 2>&1
    
done

echo "Monitor run complete" >> "$LOG_FILE"
