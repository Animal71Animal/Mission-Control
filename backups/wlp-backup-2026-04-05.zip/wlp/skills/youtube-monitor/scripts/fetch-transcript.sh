#!/bin/bash
# YouTube Transcript Fetcher using Supadata API

VIDEO_ID="$1"
API_KEY="sd_b4e03cefc86907e9c2e7f9d8284510a9"

if [ -z "$VIDEO_ID" ]; then
    echo "Usage: $0 <youtube_video_id>"
    exit 1
fi

# Fetch transcript from Supadata API
curl -s "https://api.supadata.ai/v1/transcript?videoId=${VIDEO_ID}" \
    -H "x-api-key: ${API_KEY}"
