# YouTube Channel Monitor Skill
# Monitors a YouTube channel, scrapes episode data via Playwright, generates summaries, and updates Mission Control

## Overview
This skill monitors a YouTube channel for new content, scrapes episode descriptions and chapter timestamps using Playwright, generates structured summaries, and updates the Mission Control dashboard automatically.

## How It Works

1. **RSS Feed Polling** — Checks the channel's YouTube RSS feed for new videos
2. **Playwright Scraping** — Opens each new video page, expands the description, and extracts chapter timestamps
3. **Structured Output** — Formats data into `live-episodes.json` with summary, key takeaways, topic breakdown with timestamps
4. **Mission Control Update** — Updates the JSON file and redeploys Mission Control via Vercel

## Setup For a New Channel

### Step 1 — Find the Channel ID

```bash
curl -s "https://www.youtube.com/@CHANNELHANDLE" | grep -oP 'UC[^"]{22}' | head -1
```

Example:
```bash
curl -s "https://www.youtube.com/@TomBilyeu" | grep -oP 'UC[^"]{22}' | head -1
# Returns: UCnYMOamNKLGVlJgRUbamveA
```

### Step 2 — Verify RSS Feed Works

```bash
curl -s "https://www.youtube.com/feeds/videos.xml?channel_id=CHANNEL_ID" | head -20
```

### Step 3 — Create the Monitor Script

Copy `/home/ubuntu/wlp/skills/youtube-monitor/scripts/channel-monitor.py` and update:

```python
CHANNEL_ID = "YOUR_CHANNEL_ID_HERE"
DATA_FILE = "/home/ubuntu/wlp/projects/mission-control/public/data/YOUR-EPISODES-FILE.json"
```

### Step 4 — Create the Data File

Create an empty JSON array:
```bash
echo "[]" > /home/ubuntu/wlp/projects/mission-control/public/data/YOUR-EPISODES-FILE.json
```

### Step 5 — Add a Page Section in Mission Control

In the relevant Mission Control page, add a fetch call:
```typescript
fetch("/data/YOUR-EPISODES-FILE.json").then(r => r.json()).catch(() => [])
```

### Step 6 — Run Manually to Test

```bash
/opt/computersetup/.pyenv/versions/3.11.6/bin/python3 /path/to/channel-monitor.py
```

### Step 7 — Create the Cron Job

```bash
openclaw cron create --name "channel-monitor-NAME" --cron "0 */6 * * *" --tz "America/Denver" --system-event "channel-monitor-NAME" --session main
```

---

## Playwright Scraping Process (for each video)

```python
from playwright.sync_api import sync_playwright
import time, re

def scrape_episode(video_id):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-setuid-sandbox"])
        page = browser.new_page()
        page.goto(f"https://www.youtube.com/watch?v={video_id}", wait_until="networkidle", timeout=30000)
        time.sleep(4)
        page.evaluate("window.scrollTo(0, 600)")
        time.sleep(1)
        
        # Expand description
        try:
            page.get_by_role("button", name="...more").click(timeout=5000)
            time.sleep(2)
        except: pass
        
        # Get full description
        desc = page.locator('#description-inline-expander').inner_text(timeout=5000)
        
        # Extract chapters from description
        chapters = re.findall(r'(\d+:\d+)\s+(.+)', desc)
        
        browser.close()
        return desc, chapters
```

---

## Data Structure (live-episodes.json)

```json
[
  {
    "id": "live-VIDEOID",
    "episodeNumber": 1,
    "title": "Episode Title",
    "url": "https://www.youtube.com/watch?v=VIDEO_ID",
    "publishedDate": "YYYY-MM-DD",
    "duration": "1:30:00",
    "isLive": false,
    "summary": "Short summary of the episode...",
    "keyTakeaways": [
      "Key point 1",
      "Key point 2"
    ],
    "expandedTakeaways": [
      {
        "title": "Takeaway Title",
        "detail": "Detailed explanation..."
      }
    ],
    "toolsCovered": ["Tool 1", "Tool 2"],
    "topics": ["Topic 1", "Topic 2"],
    "topicBreakdown": [
      {
        "timestamp": "0:00",
        "title": "Section Title",
        "synopsis": "What happens in this section...",
        "keyPoints": [
          "Key point 1",
          "Key point 2"
        ]
      }
    ]
  }
]
```

---

## Scripts Reference

| Script | Purpose |
|--------|---------|
| `channel-monitor.py` | Server-side monitor (uses Playwright) |
| `channel-monitor-local.py` | Local machine version |
| `fetch-transcript.sh` | Supadata transcript fetch (requires non-cloud IP) |
| `process-episode.py` | Transcript processor |

---

## Active Channels

| Channel | Handle | Channel ID | Data File | Cron Job |
|---------|--------|------------|-----------|----------|
| Tom Bilyeu | @TomBilyeu | UCnYMOamNKLGVlJgRUbamveA | live-episodes.json | tom-bilyeu-monitor (every 6h) |

---

## Notes

- **Playwright works from the server** — no IP blocking issues
- **Transcript availability** — Live streams often have no captions for 24-48h after airing. Script adds them to pending queue and retries after 2 days.
- **Supadata API key** — `sd_b4e03cefc86907e9c2e7f9d8284510a9` (free tier, 100 credits)
- **Description-based summaries** — When no transcript, use YouTube description + chapters. Works well for channels that write detailed descriptions.
- **Always redeploy Mission Control** after updating JSON files: `cd /home/ubuntu/wlp/projects/mission-control && npx vercel@latest --prod --yes`
