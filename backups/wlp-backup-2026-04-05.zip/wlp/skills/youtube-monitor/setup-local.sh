#!/bin/bash
# One-command setup for Tom Bilyeu YouTube monitor
# Run this on your local Mac

echo "=== Setting up Tom Bilyeu YouTube Monitor ==="

# Create the script
cat > ~/tom-bilyeu-monitor.py << 'PYTHON_EOF'
#!/usr/bin/env python3
import json, os, re, requests
from datetime import datetime, timedelta

API_KEY = "sd_b4e03cefc86907e9c2e7f9d8284510a9"
CHANNEL_ID = "UCnYMOamNKLGVlJgRUbamveA"
OUTPUT_FILE = os.path.expanduser("~/tom-bilyeu-episodes.json")
PENDING_FILE = os.path.expanduser("~/.tom-bilyeu-pending.json")

def fetch_rss():
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={CHANNEL_ID}"
    return requests.get(url, timeout=30).text

def parse_rss(content):
    videos = []
    for entry in re.findall(r'<entry>(.*?)</entry>', content, re.DOTALL):
        vid = re.search(r'<yt:videoId>(.*?)</yt:videoId>', entry)
        if not vid: continue
        title = re.search(r'<title>(.*?)</title>', entry)
        published = re.search(r'<published>(.*?)</published>', entry)
        videos.append({
            "video_id": vid.group(1),
            "title": title.group(1) if title else "Unknown",
            "published": published.group(1) if published else "",
            "is_live": "LIVE" in (title.group(1) if title else "").upper(),
            "url": f"https://www.youtube.com/watch?v={vid.group(1)}"
        })
    return videos

def fetch_transcript(video_id):
    url = f"https://api.supadata.ai/v1/transcript?url=https://www.youtube.com/watch?v={video_id}&text=true"
    try:
        r = requests.get(url, headers={"x-api-key": API_KEY}, timeout=60)
        if r.status_code == 404: return {"error": "no_transcript"}
        return r.json()
    except: return None

def process_text(text):
    words = text.split()
    summary = " ".join(words[:150])[:300] + "..."
    
    chunks = []
    for i in range(0, min(len(words), 1600), 200):
        chunk = " ".join(words[i:i+200])
        mins = (i // 200) * 2
        chunks.append({
            "timestamp": f"{mins:02d}:00",
            "title": f"Segment at {mins:02d}:00",
            "synopsis": chunk[:250] + "..." if len(chunk) > 250 else chunk,
            "keyPoints": [chunk[:100] + "..."] if len(chunk) > 100 else [chunk]
        })
    
    sentences = re.split(r'[.!?]+', text)
    takeaways = [s.strip() for s in sentences if 40 < len(s.strip()) < 120][:5]
    
    return {
        "summary": summary,
        "keyTakeaways": takeaways if takeaways else ["Key insights from episode"],
        "expandedTakeaways": [{"title": t, "detail": f"Important: {t}"} for t in takeaways[:3]],
        "topicBreakdown": chunks[:8]
    }

def main():
    print("Fetching Tom Bilyeu channel...")
    rss = fetch_rss()
    videos = parse_rss(rss)
    print(f"Found {len(videos)} videos")
    
    episodes = json.load(open(OUTPUT_FILE)) if os.path.exists(OUTPUT_FILE) else []
    existing = {ep.get("url", "") for ep in episodes}
    
    new_count = 0
    for video in videos[:5]:  # Process last 5 videos
        if video["url"] in existing:
            continue
            
        print(f"Processing: {video['title'][:50]}...")
        transcript = fetch_transcript(video["video_id"])
        
        if transcript and not transcript.get("error"):
            data = process_text(transcript.get("text", ""))
            episodes.insert(0, {
                "id": f"live-{video['video_id'][:8]}",
                "episodeNumber": len(episodes) + 1,
                "title": video["title"],
                "url": video["url"],
                "publishedDate": video["published"][:10] if video["published"] else datetime.now().strftime("%Y-%m-%d"),
                **data,
                "toolsCovered": [],
                "topics": []
            })
            new_count += 1
        else:
            print(f"  No transcript available yet")
    
    with open(OUTPUT_FILE, 'w') as f:
        json.dump(episodes, f, indent=2)
    
    print(f"\nAdded {new_count} new episodes")
    print(f"Saved to: {OUTPUT_FILE}")
    print("\nUpload this file to your Mission Control:")
    print("  /home/ubuntu/wlp/projects/mission-control/public/data/live-episodes.json")

if __name__ == "__main__":
    main()
PYTHON_EOF

# Make executable
chmod +x ~/tom-bilyeu-monitor.py

echo ""
echo "=== Setup Complete ==="
echo ""
echo "To run the monitor:"
echo "  python3 ~/tom-bilyeu-monitor.py"
echo ""
echo "Or make it run automatically every 6 hours:"
echo "  crontab -e"
echo "  Add this line:"
echo "  0 */6 * * * /usr/bin/python3 ~/tom-bilyeu-monitor.py"
echo ""
