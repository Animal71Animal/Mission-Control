---
name: autonomous-employee
description: Autonomous task execution for proactive business operations. Two modes: (1) 6 AM mode - check tasks.json, complete 1-3 writing/research tasks, document results; (2) 2 AM mode - think outside the box, identify unstated opportunities/gaps, execute creative high-impact work not on any list. Triggers on scheduled heartbeats or explicit requests like "run autonomous task", "morning employee duty", or "nightly creative task".
---

# Autonomous Employee

Execute meaningful tasks autonomously without waiting for approval. Two modes: structured morning work (6 AM) and creative night work (2 AM).

---

## Mode 1: Morning Worker (6 AM MDT)

**Purpose:** Clear writing and research tasks from the backlog.

### Process

1. **Read tasks.json** — Identify writing/research tasks
2. **Select 1-3 tasks** — Prioritize by value and fit
3. **Execute** — Complete each task fully
4. **Document** — Create summary report of all work done

### Task Selection Criteria

Prefer:
- Writing tasks (drafts, bios, descriptions, scripts)
- Research tasks (competitor analysis, tool research, best practices)
- Documentation tasks (organizing, summarizing, explaining)

Avoid:
- Tasks requiring external approval
- Tasks needing real-time human input
- Setup/installation tasks

### Morning Report Format

Create document at `wlp/ops/daily-reports/YYYY-MM-DD-morning.md`:

```markdown
# Morning Autonomous Work — YYYY-MM-DD

## Tasks Completed

### 1. [Task Name]
**Source:** tasks.json T[#] or self-identified
**What:** [Description]
**Output:** [File/location]
**Time:** ~[X] minutes

### 2. [Task Name]
...

### 3. [Task Name]
...

## Summary
- **Total tasks:** X
- **Total time:** ~XX minutes
- **Goals advanced:** [Which business goals this moves]
- **Next steps:** [What this unlocks]
```

---

## Mode 2: Night Creative (2 AM MDT)

**Purpose:** Think outside the box. Do what isn't on any list.

### Process

1. **Absorb context** — Read ANIMAL.md, MEMORY.md, recent narrative, projects/
2. **Identify gaps** — What should exist but doesn't? What's the obvious next step nobody wrote down?
3. **Create value** — Build, research, or document something new
4. **Report** — Brief morning summary of what was created and why

### Creative Prompts

Ask yourself:
- What's the biggest unsolved problem in the business right now?
- What would make tomorrow 10% easier?
- What research would change our strategy?
- What documentation doesn't exist but should?
- What can I prototype in 60 minutes?
- What are competitors doing that we haven't considered?

### Valid Creative Work

- Draft a new project proposal
- Research a tool or competitor thoroughly
- Create templates or frameworks
- Write a strategic analysis
- Build a proof-of-concept
- Document a process that lives only in your head
- Identify and research a new opportunity

### Night Report Format

Send brief message to primary channel:

```
🌙 Night Creative Complete — YYYY-MM-DD

**Created:** [What was built/drafted/researched]
**Why:** [The gap or opportunity identified]
**Location:** [Where to find the work]
**Impact:** [How this moves us forward]
```

---

## Shared Rules

### Always Do
- Work autonomously without asking
- Complete tasks fully (no partial work)
- Document everything
- Report honestly (even if you failed)

### Never Do
- Send external communications without prior approval
- Spend money or commit to paid services
- Delete/overwrite without backup
- Work on low-value tasks when high-value exists

### Safety Override

If unsure whether a task is appropriate:
- **Morning mode:** Skip it, pick a clearer task
- **Night mode:** Document the idea instead of executing

---

## Scripts

### Morning Runner (6 AM MDT = 12 PM UTC)
```bash
0 12 * * * /home/ubuntu/wlp/skills/autonomous-employee/scripts/run-morning-tasks.sh
```

### Night Runner (2 AM MDT = 8 AM UTC)
```bash
0 8 * * * /home/ubuntu/wlp/skills/autonomous-employee/scripts/run-night-creative.sh
```

Both scripts trigger heartbeats that load this skill and execute the appropriate mode.
