#!/bin/bash
# Autonomous Employee — Morning Task Runner (6 AM MDT / 12 PM UTC)
# Checks tasks.json, completes 1-3 writing/research tasks

LOG_FILE="/home/ubuntu/wlp/logs/autonomous-morning-$(date +%Y%m%d).log"
mkdir -p "$(dirname "$LOG_FILE")"

echo "=== Morning Autonomous Run: $(date) ===" >> "$LOG_FILE"
echo "Mode: Task execution from tasks.json" >> "$LOG_FILE"
echo "Preference: Writing and research tasks" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
echo "Agent will read tasks.json and select 1-3 tasks to complete." >> "$LOG_FILE"
echo "Report will be saved to: wlp/ops/daily-reports/$(date +%Y-%m-%d)-morning.md" >> "$LOG_FILE"
