#!/bin/bash
# Autonomous Employee - Nightly Task Runner
# Triggers at 2 AM MDT (8 AM UTC) via cron

LOG_FILE="/home/ubuntu/wlp/logs/autonomous-$(date +%Y%m%d).log"
mkdir -p "$(dirname "$LOG_FILE")"

echo "=== Autonomous Employee Run: $(date) ===" >> "$LOG_FILE"

# Send heartbeat message to trigger agent
# The agent will read HEARTBEAT.md and execute autonomous duties

echo "Heartbeat sent. Agent should wake and execute nightly task." >> "$LOG_FILE"
echo "Check memory/YYYY-MM-DD.md for results." >> "$LOG_FILE"
