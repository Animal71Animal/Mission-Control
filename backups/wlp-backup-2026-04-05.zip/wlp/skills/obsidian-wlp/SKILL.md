---
name: obsidian-wlp
description: Wicked Liquid Productions Obsidian integration. Use when reading from or writing to the WLP Obsidian vault, syncing OpenClaw memory with Obsidian notes, implementing the Video #28 markdown-first philosophy, or enabling QMD semantic search across WLP knowledge base. Triggers on Obsidian-related requests, vault access, note creation, or knowledge base queries.
---

# Obsidian WLP Integration

Custom Obsidian integration for Wicked Liquid Productions. Implements the markdown-first philosophy from Video #28 (50 Days) with QMD semantic search.

## Core Philosophy (Video #28)

> "Storing everything in Obsidian plain-text files from day one prevents lock-in and enables any future tool to use your data."

**The Rule:** If it matters, it lives in Obsidian first. OpenClaw reads from there.

---

## Vault Structure

```
WLP-Vault/
├── 00-Inbox/               # Capture everything here first
├── 01-Projects/
│   ├── AI-Artists/
│   ├── DJ-Automation/
│   ├── Live-PA/
│   └── TikTok/
├── 02-Areas/
│   ├── Music-Production/
│   ├── Business-Ops/
│   └── Marketing/
├── 03-Resources/
│   ├── Plugins/
│   ├── Samples/
│   └── Contacts/
├── 04-Archive/
└── 99-Daily/               # Daily notes (YYYY-MM-DD.md)
```

---

## Integration Patterns

### Pattern 1: Daily Note Sync

OpenClaw writes to `99-Daily/YYYY-MM-DD.md`:
- Morning briefing notes
- Autonomous task results
- Decisions and action items

```bash
# Auto-generated daily note template
---
date: YYYY-MM-DD
tags: [daily, openclaw]
---

# YYYY-MM-DD

## Morning Brief
...

## Autonomous Work
...

## Decisions
...

## Action Items
- [ ] ...
```

### Pattern 2: Project Note Creation

When starting new work, create project note in `01-Projects/`:

```bash
./scripts/create-project-note.sh "AI-Artists" "Kade-Rivers-Spotify"
```

### Pattern 3: Inbox Capture

Quick capture anything for later processing:

```bash
./scripts/inbox-capture.sh "Idea for TikTok series: Behind the decks at SRB"
```

### Pattern 4: QMD Semantic Search

Query across entire vault with natural language:

```bash
# Search for all decisions about plugins
./scripts/vault-query.sh "What plugins did we decide to install?"

# Find all tasks related to Kade
./scripts/vault-query.sh "What are the open tasks for Kade Rivers?"
```

---

## QMD Integration (Video #36)

QMD (Query Markdown Documents) indexes the vault for semantic search:

### Setup
```bash
# Install QMD (if not already)
# QMD uses BM25 + vector hybrid ranking

# Index the vault
./scripts/index-vault.sh
```

### Nightly Index Update
Add to dream cycle (3 AM):
```bash
# Re-index vault after daily notes are written
./scripts/index-vault.sh --incremental
```

---

## OpenClaw → Obsidian Workflows

### Autonomous Employee Output

Morning worker (6 AM) writes results to:
- `99-Daily/YYYY-MM-DD-morning.md`
- `01-Projects/[project]/[task]-results.md`

Night creative (2 AM) writes to:
- `00-Inbox/ideas-YYYY-MM-DD.md` (for review)
- `01-Projects/[project]/research-YYYY-MM-DD.md`

### Narrative Tracker Output

Compressed sessions go to:
- `04-Archive/sessions/YYYY-MM-DD-compressed.md`

Narrative summary goes to:
- `99-Daily/narrative.md` (running log)

---

## Scripts

| Script | Purpose |
|--------|---------|
| `create-project-note.sh` | Create new project note from template |
| `inbox-capture.sh` | Quick capture to inbox |
| `vault-query.sh` | QMD semantic search |
| `index-vault.sh` | Re-index vault for search |
| `sync-daily-note.sh` | Push OpenClaw daily note to Obsidian |

---

## When to Use This Skill

**Use for:**
- Creating or updating Obsidian notes
- Querying the WLP knowledge base
- Implementing markdown-first workflows
- Syncing OpenClaw output to Obsidian

**Don't use for:**
- General file operations outside the vault
- Non-WLP vaults

---

## References

- Video #28 (50 Days): Markdown-first philosophy
- Video #36: QMD semantic search
- Obsidian skill (ClawHub): Official Obsidian CLI integration
