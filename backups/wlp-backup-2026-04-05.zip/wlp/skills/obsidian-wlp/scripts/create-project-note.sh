#!/bin/bash
# Create a new project note in the WLP Obsidian vault

VAULT_DIR="${WLP_VAULT_DIR:-$HOME/WLP-Vault}"
PROJECT=$1
NOTE_NAME=$2
DATE=$(date +%Y-%m-%d)

if [ -z "$PROJECT" ] || [ -z "$NOTE_NAME" ]; then
    echo "Usage: create-project-note.sh <project-folder> <note-name>"
    echo "Example: create-project-note.sh AI-Artists Kade-Rivers-Spotify"
    exit 1
fi

PROJECT_DIR="$VAULT_DIR/01-Projects/$PROJECT"
mkdir -p "$PROJECT_DIR"

NOTE_FILE="$PROJECT_DIR/$NOTE_NAME.md"

cat > "$NOTE_FILE" << EOF
---
date: $DATE
project: $PROJECT
tags: [project, $PROJECT]
status: active
---

# $(echo $NOTE_NAME | tr '-' ' ' | sed 's/\b\w/\u&/g')

Created: $DATE

## Objective

[What we're trying to accomplish]

## Context

[Background information]

## Decisions

- 

## Action Items

- [ ] 

## Notes

[Ongoing notes and updates]

## Related

- 
EOF

echo "Created: $NOTE_FILE"
