#!/bin/bash
# QMD semantic search across WLP vault
# Requires QMD to be installed

VAULT_DIR="${WLP_VAULT_DIR:-$HOME/WLP-Vault}"
QUERY="$1"

if [ -z "$QUERY" ]; then
    echo "Usage: vault-query.sh 'your search query'"
    exit 1
fi

# Check if QMD is available
if ! command -v qmd &> /dev/null; then
    echo "QMD not found. Using grep fallback..."
    
    # Fallback: simple grep across markdown files
    cd "$VAULT_DIR"
    grep -ri "$QUERY" --include="*.md" -l 2>/dev/null | head -10
    exit 0
fi

# QMD search
qmd search "$QUERY" --vault "$VAULT_DIR" --limit 10
