#!/bin/bash
# Quick capture to Obsidian inbox

VAULT_DIR="${WLP_VAULT_DIR:-$HOME/WLP-Vault}"
INBOX_DIR="$VAULT_DIR/00-Inbox"
DATE=$(date +%Y-%m-%d)
TIME=$(date +%H:%M)

mkdir -p "$INBOX_DIR"

# Capture from argument or stdin
if [ -n "$1" ]; then
    CONTENT="$1"
else
    CONTENT=$(cat)
fi

# Create daily inbox file if it doesn't exist
INBOX_FILE="$INBOX_DIR/inbox-$DATE.md"

if [ ! -f "$INBOX_FILE" ]; then
    cat > "$INBOX_FILE" << EOF
---
date: $DATE
tags: [inbox, capture]
---

# Inbox — $DATE

EOF
fi

# Append capture
echo "- [$TIME] $CONTENT" >> "$INBOX_FILE"

echo "Captured to: $INBOX_FILE"
