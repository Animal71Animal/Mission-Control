#!/bin/bash
# Sync OpenClaw daily note to Obsidian vault

VAULT_DIR="${WLP_VAULT_DIR:-$HOME/WLP-Vault}"
DAILY_DIR="$VAULT_DIR/99-Daily"
DATE=$(date +%Y-%m-%d)

mkdir -p "$DAILY_DIR"

# Source files from OpenClaw
SOURCE_NOTE="/home/ubuntu/memory/$DATE.md"
SOURCE_MORNING="/home/ubuntu/wlp/ops/daily-reports/$DATE-morning.md"

OUTPUT_FILE="$DAILY_DIR/$DATE.md"

# Start daily note
cat > "$OUTPUT_FILE" << EOF
---
date: $DATE
tags: [daily, openclaw]
---

# $DATE

EOF

# Add memory content if exists
if [ -f "$SOURCE_NOTE" ]; then
    echo "" >> "$OUTPUT_FILE"
    echo "## Session Notes" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
    cat "$SOURCE_NOTE" >> "$OUTPUT_FILE"
fi

# Add morning report if exists
if [ -f "$SOURCE_MORNING" ]; then
    echo "" >> "$OUTPUT_FILE"
    echo "## Autonomous Work" >> "$OUTPUT_FILE"
    echo "" >> "$OUTPUT_FILE"
    cat "$SOURCE_MORNING" >> "$OUTPUT_FILE"
fi

echo "Synced to: $OUTPUT_FILE"
