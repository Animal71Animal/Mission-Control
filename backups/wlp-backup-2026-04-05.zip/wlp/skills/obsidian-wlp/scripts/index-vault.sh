#!/bin/bash
# Index WLP vault for QMD semantic search

VAULT_DIR="${WLP_VAULT_DIR:-$HOME/WLP-Vault}"
INDEX_DIR="$VAULT_DIR/.qmd-index"

mkdir -p "$INDEX_DIR"

# Check if QMD is available
if ! command -v qmd &> /dev/null; then
    echo "QMD not installed. Skipping index."
    echo "Install from: https://github.com/yourselfhosted/qmd"
    exit 0
fi

if [ "$1" == "--incremental" ]; then
    echo "Incremental index update..."
    qmd index "$VAULT_DIR" --output "$INDEX_DIR" --incremental
else
    echo "Full vault reindex..."
    qmd index "$VAULT_DIR" --output "$INDEX_DIR"
fi

echo "Index complete: $INDEX_DIR"
