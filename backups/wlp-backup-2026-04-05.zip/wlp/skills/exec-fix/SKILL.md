# Exec Fix — Restoring Shell Access on OpenClaw

Use when: `exec` tool returns errors like `SYSTEM_RUN_DENIED`, `approval requires an existing canonical cwd`, or `exec host=node requires a node that supports system.run`.

## Root Cause

OpenClaw 2026.3.x changed the exec security model. The `full` profile no longer grants unrestricted shell access. You must explicitly set `security` and `ask` in the config AND set exec approvals on the host.

## Fix: Gateway Config

Edit `~/.openclaw/openclaw.json` and ensure the `tools` section has:

```json
"tools": {
  "exec": {
    "security": "full",
    "ask": "off"
  }
}
```

### Important Notes

- **Do NOT set `"host": "node"`** unless you want ALL exec routed to a connected node. If set, you lose cloud/sandbox exec entirely.
- Omitting `host` = default routing (sandbox/gateway). Use `host` parameter per-call to target nodes.
- **`tools.exec.host` does NOT hot-reload.** If you set it wrong, you need a full gateway restart to fix it.
- On Abacus Claw (cloud-hosted): use the dashboard Stop/Start button. There is no `openclaw gateway restart` from inside the container.

## Fix: Exec Approvals (Node Host)

If exec is routed to a node (Mac, companion app), the node also needs approvals configured.

1. Check current approvals:
   ```bash
   openclaw approvals get
   ```

2. If `Defaults` shows `none` and `Allowlist` is `0`, create an approvals file:
   ```bash
   cat > /tmp/approvals.json << 'EOF'
   {
     "version": 1,
     "defaults": {
       "security": "full",
       "ask": "off"
     },
     "agents": {}
   }
   EOF
   openclaw approvals set --file /tmp/approvals.json
   ```

3. Verify:
   ```bash
   openclaw approvals get
   ```
   Should show: `Defaults: security=full, ask=off`

4. **Restart the node process** after changing approvals — it won't pick up changes live.

## Fix: Gateway Restart (Abacus Claw)

If `tools.exec.host` was set wrong and cached:

1. Log into https://abacus.ai
2. Find your Claw instance
3. Click **Stop** then **Start** (NOT Hard Reset — that wipes everything)
4. Reconnect any nodes after restart

## Fix: Gateway Restart (Self-Hosted)

```bash
openclaw gateway restart
```

Or if using a LaunchAgent/systemd:
```bash
# macOS
launchctl kickstart -k gui/$(id -u)/ai.openclaw.gateway
# Linux
systemctl restart openclaw-gateway
```

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `SYSTEM_RUN_DENIED: approval requires an existing canonical cwd` | Exec approvals empty or `ask` not off | Set approvals with `security=full, ask=off` |
| `exec host=node requires a node that supports system.run` | `host` set to `node` but no node connected, or node doesn't have `system.run` | Remove `host` from config, restart gateway |
| `exec host not allowed (requested X; configure tools.exec.host=Y)` | Config locked to a specific host | Remove `host` key or change it, restart gateway |
| Config change not taking effect | `tools.exec.host` doesn't hot-reload | Full gateway restart required |

## Old PriScylla Gateway Conflict

If you have a previous OpenClaw instance running on the same machine (e.g., old local install):

1. Check: `ps aux | grep openclaw-gateway | grep -v grep`
2. Kill it: `kill <PID>`
3. Prevent restart: `launchctl unload ~/Library/LaunchAgents/ai.openclaw.gateway.plist`

Two gateways fighting over the same Telegram bot token will cause message routing failures, dropped messages, and connection flakiness.

## Running Commands on Mac Node

The `exec` tool with `host=node` is blocked by Abacus Claw's runtime. Use the CLI instead:

```bash
openclaw nodes run --node ANIMAL-MacBook --raw "your command here" --security full --ask off --json
```

Parse output with:
```bash
... | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(d['payload']['stdout'])"
```

For file delivery to Mac, base64 encode on cloud, decode on Mac:
```bash
ENCODED=$(base64 -w0 /tmp/file.txt)
openclaw nodes run --node ANIMAL-MacBook --raw "echo '${ENCODED}' | base64 -d > /path/on/mac" ...
```

## Gateway Restart Recovery Checklist

After any Abacus Claw gateway restart (Stop/Start):
1. Tailscale is wiped — reinstall: `curl -fsSL https://tailscale.com/install.sh | sh`
2. Create socket dir: `mkdir -p /home/ubuntu/.tailscale`
3. Start daemon: `tailscaled --state=/home/ubuntu/.tailscale/state --socket=/home/ubuntu/.tailscale/tailscaled.sock --tun=userspace-networking > /tmp/tailscaled.log 2>&1 &`
4. Auth: `tailscale --socket=/home/ubuntu/.tailscale/tailscaled.sock up --authkey <KEY> --hostname priscylla-cloud`
5. Eric reconnects node from Mac: `OPENCLAW_GATEWAY_TOKEN="7e21cc57621a16ed30" openclaw node run --host <TAILSCALE_IP> --port 18789 --tls --tls-fingerprint 54e8b39a8d9776126c82eb5f1b30ca2747c0a95eddb8555e0c9241c6931ca938 --display-name "ANIMAL-MacBook" &`
6. Eric must also have `sudo tailscaled` running in a separate terminal tab

## Reference

- Reddit fix thread: https://www.reddit.com/r/openclaw/comments/1rl13sb/
- Exec approvals docs: https://docs.openclaw.ai/tools/exec-approvals
- Config docs: https://docs.openclaw.ai/gateway/configuration
