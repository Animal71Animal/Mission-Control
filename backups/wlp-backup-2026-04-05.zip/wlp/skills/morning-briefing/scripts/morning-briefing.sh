#!/bin/bash
# morning-briefing.sh - Daily morning briefing generator
# Triggered by cron at 10 AM MST (17:00 UTC)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WLP_DIR="/home/ubuntu/wlp"
DATA_DIR="$WLP_DIR/data"
OPS_DIR="$WLP_DIR/ops"
BRIEFINGS_DIR="$OPS_DIR/briefings"

# Ensure directories exist
mkdir -p "$BRIEFINGS_DIR"

# Date setup
DATE=$(date +%Y-%m-%d)
TIME=$(date +%H:%M)
TIMESTAMP=$(date -u +%Y-%m-%dT%H:%M:%SZ)

echo "=== Morning Briefing Generator ==="
echo "Date: $DATE"
echo "Time: $TIME UTC"
echo ""

# Weather (Open-Meteo API)
echo "Fetching weather..."
WEATHER_JSON=$(curl -s "https://api.open-meteo.com/v1/forecast?latitude=43.6137&longitude=-116.2023&current=temperature_2m,relative_humidity_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=America/Denver&forecast_days=1" 2>/dev/null || echo '{}')

CURRENT_TEMP=$(echo "$WEATHER_JSON" | jq -r '.current.temperature_2m // "N/A"')
HUMIDITY=$(echo "$WEATHER_JSON" | jq -r '.current.relative_humidity_2m // "N/A"')
HIGH=$(echo "$WEATHER_JSON" | jq -r '.daily.temperature_2m_max[0] // "N/A"')
LOW=$(echo "$WEATHER_JSON" | jq -r '.daily.temperature_2m_min[0] // "N/A"')
WEATHER_CODE=$(echo "$WEATHER_JSON" | jq -r '.current.weather_code // 0')

# Weather code to condition mapping
case $WEATHER_CODE in
    0) CONDITION="Clear sky" ;;
    1|2|3) CONDITION="Partly cloudy" ;;
    45|48) CONDITION="Foggy" ;;
    51|53|55) CONDITION="Drizzle" ;;
    61|63|65) CONDITION="Rain" ;;
    71|73|75) CONDITION="Snow" ;;
    95|96|99) CONDITION="Thunderstorm" ;;
    *) CONDITION="Unknown" ;;
esac

echo "  Temp: $CURRENT_TEMP°F, Humidity: $HUMIDITY%, Condition: $CONDITION"
echo "  High: $HIGH°F, Low: $LOW°F"
echo ""

# News (Brave Search API - if key exists)
echo "Fetching news..."
if [ -n "$BRAVE_API_KEY" ]; then
    NEWS_JSON=$(curl -s "https://api.search.brave.com/res/v1/news/search?q=technology+music+business&count=3" \
        -H "Accept: application/json" \
        -H "X-Subscription-Token: $BRAVE_API_KEY" 2>/dev/null || echo '{}')
    NEWS_COUNT=$(echo "$NEWS_JSON" | jq -r '.results | length // 0')
else
    NEWS_JSON='{}'
    NEWS_COUNT=0
    echo "  Warning: BRAVE_API_KEY not set"
fi
echo "  Found $NEWS_COUNT news items"
echo ""

# Tasks
echo "Counting tasks..."
if [ -f "$OPS_DIR/tasks.json" ]; then
    OPEN_TASKS=$(jq -r '.open | length // 0' "$OPS_DIR/tasks.json" 2>/dev/null || echo 0)
    HIGH_PRIORITY=$(jq -r '[.open[] | select(.priority == "high")] | length // 0' "$OPS_DIR/tasks.json" 2>/dev/null || echo 0)
else
    OPEN_TASKS=0
    HIGH_PRIORITY=0
fi
echo "  Open: $OPEN_TASKS, High priority: $HIGH_PRIORITY"
echo ""

# Build briefing JSON
BRIEFING_FILE="$BRIEFINGS_DIR/briefing-$DATE.json"

cat > "$BRIEFING_FILE" << EOF
{
  "date": "$DATE",
  "time": "$TIME",
  "timestamp": "$TIMESTAMP",
  "weather": {
    "temp_f": $CURRENT_TEMP,
    "humidity_percent": $HUMIDITY,
    "condition": "$CONDITION",
    "high_f": $HIGH,
    "low_f": $LOW
  },
  "news": $NEWS_JSON,
  "tasks": {
    "open": $OPEN_TASKS,
    "high_priority": $HIGH_PRIORITY
  },
  "generated_by": "morning-briefing.sh",
  "version": "1.0.0"
}
EOF

echo "Briefing saved to: $BRIEFING_FILE"
echo ""

# Optional: Push to Surge (if configured)
if [ -n "$SURGE_ENDPOINT" ] && [ -n "$SURGE_AUTH_TOKEN" ]; then
    echo "Pushing to Surge..."
    curl -s -X POST "$SURGE_ENDPOINT/api/briefing" \
        -H "Authorization: Bearer $SURGE_AUTH_TOKEN" \
        -H "Content-Type: application/json" \
        -d "@$BRIEFING_FILE" 2>/dev/null && echo "  Success" || echo "  Failed"
else
    echo "Surge push skipped (not configured)"
fi

echo ""

# Trigger Vapi voice call (if configured)
if [ -n "$VAPI_API_KEY" ] && [ -n "$VAPI_PHONE" ]; then
    echo "Triggering Vapi voice call..."
    python3 "$SCRIPT_DIR/briefing-voice.py" --briefing-file "$BRIEFING_FILE" 2>&1 && echo "  Call initiated" || echo "  Call failed"
else
    echo "Vapi call skipped (not configured)"
fi

echo ""
echo "=== Briefing Complete ==="

# Output JSON for potential further processing
cat "$BRIEFING_FILE"
