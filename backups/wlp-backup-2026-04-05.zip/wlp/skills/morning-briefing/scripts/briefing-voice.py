#!/usr/bin/env python3
"""
briefing-voice.py - Vapi TTS integration for morning briefing
Triggers a phone call that reads the briefing aloud

Usage:
    python3 briefing-voice.py --briefing-file /path/to/briefing.json
    python3 briefing-voice.py --dry-run  # Test without calling
"""

import argparse
import json
import os
import sys
from datetime import datetime

# Configuration
VAPI_API_KEY = os.getenv("VAPI_API_KEY")
VAPI_PHONE = os.getenv("VAPI_PHONE", "+1-208-555-0100")  # ANIMAL's number
VAPI_VOICE_ID = os.getenv("VAPI_VOICE_ID", "nova")  # ElevenLabs Nova


def load_briefing(filepath: str) -> dict:
    """Load briefing JSON."""
    with open(filepath) as f:
        return json.load(f)


def build_script(briefing: dict) -> str:
    """Build the voice script from briefing data."""
    
    # Weather section
    weather = briefing.get("weather", {})
    temp = weather.get("temp_f", "N/A")
    condition = weather.get("condition", "unknown")
    high = weather.get("high_f", "N/A")
    low = weather.get("low_f", "N/A")
    humidity = weather.get("humidity_percent", "N/A")
    
    weather_text = f"Currently {temp} degrees and {condition} in Boise. High of {high}, low of {low}. Humidity {humidity} percent."
    
    # News section (if available)
    news = briefing.get("news", {})
    news_results = news.get("results", [])
    
    if news_results:
        headlines = [n.get("title", "") for n in news_results[:3]]
        news_text = "Top news: " + ". ".join(headlines)
    else:
        news_text = ""
    
    # Tasks section
    tasks = briefing.get("tasks", {})
    open_count = tasks.get("open", 0)
    high_priority = tasks.get("high_priority", 0)
    
    if high_priority > 0:
        tasks_text = f"You have {open_count} open tasks, including {high_priority} high priority items."
    else:
        tasks_text = f"You have {open_count} open tasks."
    
    # Build full script
    date_str = briefing.get("date", datetime.now().strftime("%Y-%m-%d"))
    
    script = f"""Good morning ANIMAL. It's {date_str}.

{weather_text}

{news_text}

{tasks_text}

Have a productive day. PriScylla out."""
    
    return script.strip()


def make_vapi_call(script: str, dry_run: bool = False) -> dict:
    """Trigger Vapi voice call."""
    
    if dry_run:
        print("=== DRY RUN ===")
        print("Would call Vapi with:")
        print(f"  Phone: {VAPI_PHONE}")
        print(f"  Voice: {VAPI_VOICE_ID}")
        print(f"  Script length: {len(script)} chars")
        print("\nScript:")
        print(script)
        return {"status": "dry_run", "success": True}
    
    if not VAPI_API_KEY:
        print("Error: VAPI_API_KEY not set", file=sys.stderr)
        return {"status": "error", "error": "VAPI_API_KEY not set"}
    
    # Vapi API call
    import urllib.request
    import urllib.error
    
    payload = {
        "assistant": {
            "firstMessage": script
            # Voice is configured in Vapi dashboard, not via API
        },
        "phoneNumber": {
            "number": VAPI_PHONE
        }
    }
    
    req = urllib.request.Request(
        "https://api.vapi.ai/call",
        data=json.dumps(payload).encode(),
        headers={
            "Authorization": f"Bearer {VAPI_API_KEY}",
            "Content-Type": "application/json"
        },
        method="POST"
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode())
            print(f"Vapi call initiated: {result.get('id', 'unknown')}")
            return {"status": "success", "call_id": result.get("id")}
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        print(f"Vapi error: {e.code} - {error_body}", file=sys.stderr)
        return {"status": "error", "error": error_body}
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return {"status": "error", "error": str(e)}


def main():
    parser = argparse.ArgumentParser(description="Vapi TTS for morning briefing")
    parser.add_argument("--briefing-file", "-b", type=str, 
                        default=f"/home/ubuntu/wlp/ops/briefings/briefing-{datetime.now().strftime('%Y-%m-%d')}.json",
                        help="Path to briefing JSON file")
    parser.add_argument("--dry-run", "-d", action="store_true",
                        help="Print script without calling Vapi")
    
    args = parser.parse_args()
    
    # Load briefing
    if not os.path.exists(args.briefing_file):
        print(f"Error: Briefing file not found: {args.briefing_file}", file=sys.stderr)
        sys.exit(1)
    
    briefing = load_briefing(args.briefing_file)
    
    # Build script
    script = build_script(briefing)
    
    # Make call
    result = make_vapi_call(script, dry_run=args.dry_run)
    
    # Output result as JSON
    print(json.dumps(result, indent=2))
    
    return 0 if result.get("success") or result.get("status") == "dry_run" else 1


if __name__ == "__main__":
    sys.exit(main())
