---
name: morning-briefing
description: Deliver daily morning briefings with weather, tasks, flight prices, and business updates. Triggers at 10 AM MDT via scheduled heartbeat or explicit request like "run morning briefing", "daily briefing", or "what's on my plate today".
---

# Morning Briefing

Deliver a concise, actionable daily briefing for ANIMAL (Eric Mills). Weather, tasks, flight prices, and key business updates.

---

## Briefing Components

### 1. Weather (Boise, ID)
- Current temperature and conditions
- High/low for the day
- Source: Open-Meteo API (coordinates: 43.6166°N, 116.2008°W)

### 2. Task Overview
- Open task count from tasks.json
- Highlight high-priority items
- Note any overdue tasks

### 3. Flight Prices (Raleigh Trip)
- Top 3 cheapest flight prices
- Source: flight_check.py output

### 4. Business Context
- Recent decisions from narrative.md
- Active project status
- Upcoming deadlines from calendar

---

## Delivery Methods

### Method 1: Voice Call (Primary)
Trigger Vapi voice call to Eric's phone:
```bash
python3 /home/ubuntu/wlp/ops/scripts/briefing-voice.py
```

Voice script generates natural speech:
- "Good morning Eric. It's time for your Wicked Liquid briefing..."
- Weather in Fahrenheit
- Task count
- Flight prices if available
- "Would you like to hear more details?"

### Method 2: Text/Markdown Report
Generate written briefing:
```bash
bash /home/ubuntu/wlp/ops/scripts/morning-briefing.sh
```

Output: `wlp/ops/briefings/briefing-YYYY-MM-DD.json`

### Method 3: Mission Control Dashboard
Briefing data auto-populates:
- Weather widget
- Task counter
- Flight price tracker
- Recent activity feed

---

## Scripts

### morning-briefing.sh
Generates JSON briefing data:
- Fetches weather from Open-Meteo
- Counts open tasks
- Gets flight prices
- Saves to `wlp/ops/briefings/`

### briefing-voice.py
Triggers Vapi phone call:
- Converts briefing data to natural speech
- Calls Eric at +15616662109
- Uses ElevenLabs "Nova" voice
- Assistant ID: 6405f588-149e-44a5-b49f-52457a21c7fa

---

## Schedule

**Daily at 10 AM MDT (4 PM UTC)**

The skill runs via wrapper script:
```bash
/home/ubuntu/wlp/ops/scripts/morning-briefing-wrapper.sh
```

This executes:
1. `morning-briefing.sh` — generates briefing data
2. `briefing-voice.py` — triggers voice call (uses pyenv Python)
3. Rebuilds and deploys Mission Control

---

## Manual Trigger

Run briefing on demand:
```bash
# Generate data only
bash /home/ubuntu/wlp/ops/scripts/morning-briefing.sh

# Generate + voice call
bash /home/ubuntu/wlp/ops/scripts/morning-briefing.sh && python3 /home/ubuntu/wlp/ops/scripts/briefing-voice.py
```

---

## Data Sources

| Component | Source | File |
|-----------|--------|------|
| Weather | Open-Meteo API | API call |
| Tasks | tasks.json | `wlp/ops/tasks.json` |
| Flights | Custom script | `wlp/ops/scripts/flight_check.py` |
| Calendar | Google Calendar API | Via GOG |
| Narrative | narrative.md | `memory/narrative.md` |

---

## Output Format

JSON structure:
```json
{
  "date": "2026-03-26",
  "time": "10:00",
  "timestamp": "2026-03-26T16:00:00Z",
  "timezone": "America/Denver",
  "weather": { /* Open-Meteo response */ },
  "tasks": { "open": 9 },
  "flights": { "top_prices": [189, 203, 215] },
  "generated_by": "morning-briefing"
}
```

---

## Error Handling

- Weather API failure: Report "unavailable"
- Tasks file missing: Report 0 tasks
- Flight check failure: Omit flight section
- Vapi failure: Log error, briefing data still saved

---

## Integration Points

- **HEARTBEAT.md**: Scheduled trigger at 10 AM MDT
- **Mission Control**: Dashboard displays briefing data
- **Vapi**: Voice delivery to phone
- **tasks.json**: Source of task counts
