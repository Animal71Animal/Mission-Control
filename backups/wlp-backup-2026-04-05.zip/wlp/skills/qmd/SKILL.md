---
name: qmd
version: 1.0.0
description: Query Markdown Documents — semantic search across your knowledge base. Indexes markdown files nightly using vector embeddings + BM25 hybrid search. Retrieves only relevant paragraphs instead of full documents for 70%+ token reduction.
triggers:
  - "search my notes"
  - "what do I know about"
  - "find in my vault"
  - "qmd"
  - "semantic search"
---

# QMD — Query Markdown Documents

Semantic search across your knowledge base. Local, private, fast.

## What It Does

1. **Indexes** all markdown files in your vault nightly
2. **Embeds** content using local sentence transformers
3. **Searches** with hybrid BM25 + vector similarity
4. **Returns** only relevant paragraphs — not full documents

## Usage

```bash
# Search your knowledge base
python3 ~/wlp/skills/qmd/scripts/query.py "what did I decide about TikTok handles"

# Rebuild index manually
python3 ~/wlp/skills/qmd/scripts/index.py --full

# Add new file to index
python3 ~/wlp/skills/qmd/scripts/index.py --file ~/wlp/memory/2026-03-24.md
```

## How It Works

| Component | Purpose |
|-----------|---------|
| **ChromaDB** | Local vector database (no cloud) |
| **Sentence-Transformers** | Free local embeddings (all-MiniLM-L6-v2) |
| **BM25** | Keyword search for exact matches |
| **Hybrid Ranking** | Combines semantic + keyword scores |

## Index Locations

By default, indexes:
- `~/memory/*.md` — Daily notes
- `~/wlp/**/*.md` — Project docs, skills, references
- `~/WLP-Vault/*.md` — Obsidian vault (if exists)

## Configuration

Edit `~/wlp/skills/qmd/config.json`:

```json
{
  "index_paths": [
    "~/memory",
    "~/wlp",
    "~/WLP-Vault"
  ],
  "exclude_patterns": [
    "node_modules",
    ".git",
    "archive"
  ],
  "chunk_size": 500,
  "chunk_overlap": 50,
  "top_k": 5
}
```

## Nightly Index

Runs automatically at 2 AM via cron. Incremental updates — only new/changed files.

## Token Savings

| Method | Tokens for Query | Accuracy |
|--------|------------------|----------|
| Full document | 8,000-15,000 | 100% |
| QMD (relevant chunks) | 500-1,500 | 95%+ |
| **Savings** | **70-90%** | — |

## Safety

- All processing is local — no data leaves your machine
- Embeddings are computed locally — no API calls
- Index is stored in `~/.qmd-index/` — portable, deletable
