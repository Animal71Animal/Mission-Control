#!/usr/bin/env python3
"""
query.py - Search QMD index using BM25 + simple similarity
Usage:
    python3 query.py "your search query"
    python3 query.py "what did I decide about TikTok" --top 5
"""

import argparse
import json
import re
import sys
from pathlib import Path
from collections import Counter
import math

INDEX_DIR = Path.home() / ".qmd-index"
INDEX_FILE = INDEX_DIR / "index.json"


def load_index():
    """Load the index."""
    if not INDEX_FILE.exists():
        print("Error: No index found. Run index.py first.", file=sys.stderr)
        return []
    
    with open(INDEX_FILE) as f:
        return json.load(f)


def tokenize(text: str):
    """Simple tokenization."""
    return re.findall(r'\b[a-zA-Z]+\b', text.lower())


def bm25_score(query: str, doc: str, k1=1.5, b=0.75):
    """Calculate BM25 score for a document."""
    query_tokens = tokenize(query)
    doc_tokens = tokenize(doc)
    
    if not doc_tokens:
        return 0
    
    doc_len = len(doc_tokens)
    avg_doc_len = 100  # Approximation
    
    token_counts = Counter(doc_tokens)
    score = 0
    
    for token in query_tokens:
        tf = token_counts.get(token, 0)
        if tf == 0:
            continue
        
        # Simplified IDF (assume small corpus)
        idf = 1.0
        
        # BM25 formula
        numerator = tf * (k1 + 1)
        denominator = tf + k1 * (1 - b + b * (doc_len / avg_doc_len))
        score += idf * (numerator / denominator)
    
    return score


def simple_similarity(query: str, doc: str):
    """Simple word overlap similarity."""
    query_words = set(tokenize(query))
    doc_words = set(tokenize(doc))
    
    if not query_words or not doc_words:
        return 0
    
    intersection = query_words & doc_words
    return len(intersection) / len(query_words)


def search(query: str, top_k: int = 5):
    """Search the index."""
    docs = load_index()
    if not docs:
        return []
    
    # Score all documents
    scored = []
    for doc in docs:
        content = doc.get("content", "")
        bm25 = bm25_score(query, content)
        sim = simple_similarity(query, content)
        
        # Hybrid score
        final_score = (bm25 * 0.6) + (sim * 0.4)
        
        scored.append((final_score, doc))
    
    # Sort by score
    scored.sort(key=lambda x: x[0], reverse=True)
    
    return scored[:top_k]


def format_result(score: float, doc: dict):
    """Format a search result."""
    file_path = doc.get("file", "unknown")
    chunk_idx = doc.get("chunk_index", 0)
    total_chunks = doc.get("total_chunks", 1)
    content = doc.get("content", "")
    
    # Truncate content for display
    preview = content[:300].replace("\n", " ")
    if len(content) > 300:
        preview += "..."
    
    return f"""
[Score: {score:.3f}] {Path(file_path).name} (chunk {chunk_idx+1}/{total_chunks})
{preview}
"""


def main():
    parser = argparse.ArgumentParser(description="QMD Search")
    parser.add_argument("query", nargs="?", help="Search query")
    parser.add_argument("--top", "-n", type=int, default=5, help="Number of results")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    if not args.query:
        # Interactive mode
        print("QMD Search — Enter queries (Ctrl+D to exit)")
        while True:
            try:
                query = input("\n> ")
                if not query.strip():
                    continue
                results = search(query, args.top)
                for score, doc in results:
                    print(format_result(score, doc))
            except EOFError:
                break
            except KeyboardInterrupt:
                break
        return 0
    
    # Single query mode
    results = search(args.query, args.top)
    
    if args.json:
        output = [
            {
                "score": score,
                "file": doc.get("file"),
                "chunk": doc.get("chunk_index"),
                "content": doc.get("content")
            }
            for score, doc in results
        ]
        print(json.dumps(output, indent=2))
    else:
        print(f"Query: '{args.query}'")
        print(f"Found {len(results)} results:\n")
        for score, doc in results:
            print(format_result(score, doc))
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
