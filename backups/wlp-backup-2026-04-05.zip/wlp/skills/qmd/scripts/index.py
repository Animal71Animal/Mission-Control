#!/usr/bin/env python3
"""
index.py - Build and maintain QMD index
Usage:
    python3 index.py --full          # Full reindex
    python3 index.py --incremental   # Incremental update (default)
    python3 index.py --file path.md  # Index single file
"""

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime
from pathlib import Path

# Config
CONFIG_PATH = Path(__file__).parent.parent / "config.json"
INDEX_DIR = Path.home() / ".qmd-index"
STATE_FILE = INDEX_DIR / "index-state.json"

DEFAULT_CONFIG = {
    "index_paths": [
        str(Path.home() / "memory"),
        str(Path.home() / "wlp"),
        str(Path.home() / "WLP-Vault")
    ],
    "exclude_patterns": ["node_modules", ".git", "archive", "__pycache__"],
    "chunk_size": 500,
    "chunk_overlap": 50,
    "embedding_model": "all-MiniLM-L6-v2"
}


def load_config():
    """Load or create config."""
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            return {**DEFAULT_CONFIG, **json.load(f)}
    return DEFAULT_CONFIG


def get_markdown_files(config):
    """Find all markdown files to index."""
    files = []
    for path_str in config["index_paths"]:
        path = Path(path_str).expanduser()
        if not path.exists():
            continue
        for md_file in path.rglob("*.md"):
            # Check exclusions
            if any(pat in str(md_file) for pat in config["exclude_patterns"]):
                continue
            files.append(md_file)
    return files


def chunk_text(text: str, chunk_size: int, overlap: int):
    """Split text into overlapping chunks."""
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start = end - overlap
    return chunks


def get_file_hash(filepath: Path):
    """Get MD5 hash of file contents."""
    with open(filepath, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def load_state():
    """Load index state (file hashes)."""
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def save_state(state):
    """Save index state."""
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def index_file(filepath: Path, config: dict):
    """Index a single markdown file."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        print(f"  Error reading {filepath}: {e}")
        return []
    
    # Chunk the content
    chunks = chunk_text(content, config["chunk_size"], config["chunk_overlap"])
    
    # Create document records
    docs = []
    for i, chunk in enumerate(chunks):
        docs.append({
            "id": f"{filepath}:{i}",
            "file": str(filepath),
            "chunk_index": i,
            "content": chunk,
            "total_chunks": len(chunks)
        })
    
    return docs


def main():
    parser = argparse.ArgumentParser(description="QMD Indexer")
    parser.add_argument("--full", action="store_true", help="Full reindex")
    parser.add_argument("--incremental", action="store_true", help="Incremental update")
    parser.add_argument("--file", type=str, help="Index single file")
    args = parser.parse_args()
    
    config = load_config()
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    
    # Single file mode
    if args.file:
        filepath = Path(args.file).expanduser()
        print(f"Indexing single file: {filepath}")
        docs = index_file(filepath, config)
        print(f"  Created {len(docs)} chunks")
        # Save to simple JSON for now
        output_file = INDEX_DIR / f"{filepath.stem}.json"
        with open(output_file, "w") as f:
            json.dump(docs, f, indent=2)
        print(f"  Saved to {output_file}")
        return 0
    
    # Find files
    print("Finding markdown files...")
    files = get_markdown_files(config)
    print(f"  Found {len(files)} files")
    
    # Load state for incremental
    state = {} if args.full else load_state()
    
    # Index files
    all_docs = []
    new_state = {}
    
    for filepath in files:
        file_hash = get_file_hash(filepath)
        new_state[str(filepath)] = file_hash
        
        # Skip unchanged files in incremental mode
        if not args.full and state.get(str(filepath)) == file_hash:
            continue
        
        print(f"Indexing: {filepath}")
        docs = index_file(filepath, config)
        all_docs.extend(docs)
        print(f"  +{len(docs)} chunks")
    
    # Save state
    save_state(new_state)
    
    # Save index
    index_file_path = INDEX_DIR / "index.json"
    with open(index_file_path, "w") as f:
        json.dump(all_docs, f, indent=2)
    
    print(f"\nIndex complete: {len(all_docs)} total chunks from {len(files)} files")
    print(f"Index saved to: {index_file_path}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
