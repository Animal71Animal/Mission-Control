# Final URLs

## Director of Entertainment Pitch
**URL:** https://animal-talent-manager.surge.sh
**Purpose:** DOE pitch deck — live on the web
**Last Updated:** 2026-03-25

## Mission Control
**URL:** https://animal-mission-control.surge.sh
**Purpose:** WLP dashboard — Mission Control with refactored components
**Last Updated:** 2026-03-25
